package com.wosmart.ukprotocollibary;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.ScanRecord;

public class WristbandScanCallback {

    /**
     * call back when found a remote device
     *
     * @param device
     * @param rssi
     * @param scanRecord
     */
    public void onWristbandDeviceFind(BluetoothDevice device, int rssi, byte[] scanRecord) {
    }

    /**
     * callback when found a remote device
     *
     * @param device
     * @param rssi
     * @param scanRecord
     */
    public void onWristbandDeviceFind(BluetoothDevice device, int rssi, ScanRecord scanRecord) {
    }

    /**
     * callback when start or stop bluetooth scan
     *
     * @param enable
     */
    public void onLeScanEnable(boolean enable) {
    }

    /**
     * callback when remote device longin status changed
     *
     * @param connected
     */
    public void onWristbandLoginStateChange(boolean connected) {
    }

    public void onStartLeScan() {

    }

    public void onStopLeScan() {

    }

    public void onCancelLeScan() {

    }
}
