package com.wosmart.ukprotocollibary.util;

public class ImgHeadUtil {

    static byte[] uuid = new byte[]{0x6d, 0x67, (byte) 0xde, (byte) 0xf1, 0x3e, 0x33, (byte) 0xe8, 0x11, (byte) 0xb1, 0x02, 0x4d, 0x2d, (byte) 0xf4, 0x0c, (byte) 0xde, 0x01};
    static byte[] uuid1 = new byte[]{0x1d, 0x6A, (byte) 0x69, (byte) 0xf1, 0x2f, 0x38, (byte) 0xeA, 0x11, (byte) 0x82, (byte) 0xA7, 0x67, 0x37, (byte) 0x0A, 0x3c, (byte) 0xA3, 0x2e};

    static int[] crc16_table =
            new int[]{
                    0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241,
                    0xC601, 0x06C0, 0x0780, 0xC741, 0x0500, 0xC5C1, 0xC481, 0x0440,
                    0xCC01, 0x0CC0, 0x0D80, 0xCD41, 0x0F00, 0xCFC1, 0xCE81, 0x0E40,
                    0x0A00, 0xCAC1, 0xCB81, 0x0B40, 0xC901, 0x09C0, 0x0880, 0xC841,
                    0xD801, 0x18C0, 0x1980, 0xD941, 0x1B00, 0xDBC1, 0xDA81, 0x1A40,
                    0x1E00, 0xDEC1, 0xDF81, 0x1F40, 0xDD01, 0x1DC0, 0x1C80, 0xDC41,
                    0x1400, 0xD4C1, 0xD581, 0x1540, 0xD701, 0x17C0, 0x1680, 0xD641,
                    0xD201, 0x12C0, 0x1380, 0xD341, 0x1100, 0xD1C1, 0xD081, 0x1040,
                    0xF001, 0x30C0, 0x3180, 0xF141, 0x3300, 0xF3C1, 0xF281, 0x3240,
                    0x3600, 0xF6C1, 0xF781, 0x3740, 0xF501, 0x35C0, 0x3480, 0xF441,
                    0x3C00, 0xFCC1, 0xFD81, 0x3D40, 0xFF01, 0x3FC0, 0x3E80, 0xFE41,
                    0xFA01, 0x3AC0, 0x3B80, 0xFB41, 0x3900, 0xF9C1, 0xF881, 0x3840,
                    0x2800, 0xE8C1, 0xE981, 0x2940, 0xEB01, 0x2BC0, 0x2A80, 0xEA41,
                    0xEE01, 0x2EC0, 0x2F80, 0xEF41, 0x2D00, 0xEDC1, 0xEC81, 0x2C40,
                    0xE401, 0x24C0, 0x2580, 0xE541, 0x2700, 0xE7C1, 0xE681, 0x2640,
                    0x2200, 0xE2C1, 0xE381, 0x2340, 0xE101, 0x21C0, 0x2080, 0xE041,
                    0xA001, 0x60C0, 0x6180, 0xA141, 0x6300, 0xA3C1, 0xA281, 0x6240,
                    0x6600, 0xA6C1, 0xA781, 0x6740, 0xA501, 0x65C0, 0x6480, 0xA441,
                    0x6C00, 0xACC1, 0xAD81, 0x6D40, 0xAF01, 0x6FC0, 0x6E80, 0xAE41,
                    0xAA01, 0x6AC0, 0x6B80, 0xAB41, 0x6900, 0xA9C1, 0xA881, 0x6840,
                    0x7800, 0xB8C1, 0xB981, 0x7940, 0xBB01, 0x7BC0, 0x7A80, 0xBA41,
                    0xBE01, 0x7EC0, 0x7F80, 0xBF41, 0x7D00, 0xBDC1, 0xBC81, 0x7C40,
                    0xB401, 0x74C0, 0x7580, 0xB541, 0x7700, 0xB7C1, 0xB681, 0x7640,
                    0x7200, 0xB2C1, 0xB381, 0x7340, 0xB101, 0x71C0, 0x7080, 0xB041,
                    0x5000, 0x90C1, 0x9181, 0x5140, 0x9301, 0x53C0, 0x5280, 0x9241,
                    0x9601, 0x56C0, 0x5780, 0x9741, 0x5500, 0x95C1, 0x9481, 0x5440,
                    0x9C01, 0x5CC0, 0x5D80, 0x9D41, 0x5F00, 0x9FC1, 0x9E81, 0x5E40,
                    0x5A00, 0x9AC1, 0x9B81, 0x5B40, 0x9901, 0x59C0, 0x5880, 0x9841,
                    0x8801, 0x48C0, 0x4980, 0x8941, 0x4B00, 0x8BC1, 0x8A81, 0x4A40,
                    0x4E00, 0x8EC1, 0x8F81, 0x4F40, 0x8D01, 0x4DC0, 0x4C80, 0x8C41,
                    0x4400, 0x84C1, 0x8581, 0x4540, 0x8701, 0x47C0, 0x4680, 0x8641,
                    0x8201, 0x42C0, 0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040};

    public static byte[] getImgHeader(byte[] originData) {
        int len = 1024;
        byte[] data = new byte[len];

        for (int i = 0; i < len; i++) {
            data[i] = (byte) 0xff;
        }

        data[0] = 0x05;
        data[1] = 0x00;
        data[2] = 0x70;
        data[3] = (byte) 0xFD;
        data[4] = (byte) 0xFE;
        data[5] = (byte) 0xFF;

        int crc16 = CrcUtil.crc16(originData);
        data[6] = (byte) (crc16 & 0xFF);
        data[7] = (byte) ((crc16 & 0xFF) >> 8);

        int originLen = originData.length;
        data[8] = (byte) (originLen & 0xFF);
        data[9] = (byte) ((originLen >> 8) & 0xFF);
        data[10] = (byte) ((originLen >> 16) & 0xFF);
        data[11] = (byte) ((originLen >> 24) & 0xFF);

        System.arraycopy(uuid, 0, data, 12, uuid.length);

        return data;
    }

    public static byte[] getImgHeaderNew(byte[] originData) {
        int HEADER_LEN = 1024;
        int HASH_OFFSET = 272;
        int CRC_OFFSET = HASH_OFFSET + 32;  // 304
        int LENGTH_OFFSET = 312;
        int FILL_ZERO_FROM = 316;

        byte[] data = new byte[HEADER_LEN];
        // 初始用 0xFF 填充
        for (int i = 0; i < HEADER_LEN; i++) {
            data[i] = (byte) 0xFF;
        }

        data[CRC_OFFSET + 2] = 0x11;
        data[CRC_OFFSET + 3] = 0x00;
        data[CRC_OFFSET + 4] = 0x00;
        data[CRC_OFFSET + 5] = 0x01;
        data[CRC_OFFSET + 6] = (byte) 0xFD;
        data[CRC_OFFSET + 7] = (byte) 0xFF;

        // 写入原始数据长度（4 字节，低位优先）
        int originLen = originData.length;
        data[LENGTH_OFFSET] = (byte) (originLen & 0xFF);
        data[LENGTH_OFFSET + 1] = (byte) ((originLen >> 8) & 0xFF);
        data[LENGTH_OFFSET + 2] = (byte) ((originLen >> 16) & 0xFF);
        data[LENGTH_OFFSET + 3] = (byte) ((originLen >> 24) & 0xFF);

        // 从第 316 字节开始，填充为 0x00
        for (int i = FILL_ZERO_FROM; i < HEADER_LEN; i++) {
            data[i] = 0x00;
        }

        data[HASH_OFFSET + 80] = (byte) 0xA5;
        data[HASH_OFFSET + 81] = 0x12;
        data[HASH_OFFSET + 82] = 0x5A;
        data[HASH_OFFSET + 83] = 0x5A;

        // 获取CRC_OFFSET+2以后的所有data字节，并加上originData 生成新的Data
        byte[] newData = new byte[HEADER_LEN - CRC_OFFSET - 2 + originData.length];
        System.arraycopy(data, CRC_OFFSET + 2, newData, 0, HEADER_LEN - CRC_OFFSET - 2);
        System.arraycopy(originData, 0, newData, HEADER_LEN - CRC_OFFSET - 2, originData.length);

        // 写入 CRC16（2 字节，低位在前）
        int crc16 = bdCrc16(0, newData);
        data[CRC_OFFSET] = (byte) (crc16 & 0xFF);         // 低位
        data[CRC_OFFSET + 1] = (byte) ((crc16 >> 8) & 0xFF);  // 高位

        // 获取SHA256位数之后所有内容生成SHA256值
        byte[] hashData = new byte[HEADER_LEN - CRC_OFFSET + originData.length];
        System.arraycopy(data, CRC_OFFSET, hashData, 0, HEADER_LEN - CRC_OFFSET);
        System.arraycopy(originData, 0, hashData, HEADER_LEN - CRC_OFFSET, originData.length);

        // 写入 SHA256（32 字节）
        byte[] sha256Hash = sha256(hashData);
        System.arraycopy(sha256Hash, 0, data, HASH_OFFSET, 32);

        return data;
    }

    private static int bdCrc16(int crc, byte[] buffer) {
        for (byte b : buffer) {
            crc = (crc >> 8) ^ crc16_table[(crc ^ (b & 0xFF)) & 0xFF];
        }
        return crc & 0xFFFF;
    }

    private static byte[] sha256(byte[] data) {
        try {
            java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
            return digest.digest(data);
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }

    public static byte[] getImgHeaderToVD(byte[] originData) {
        int len = 1024;
        byte[] data = new byte[len];

        for (int i = 0; i < len; i++) {
            data[i] = (byte) 0xff;
        }

        data[0] = 0x09;
        data[1] = 0x00;
        data[2] = 0x70;
        data[3] = (byte) 0xFD;
        data[4] = (byte) 0xFE;
        data[5] = (byte) 0xFF;

        data[6] = 0x00;
        data[7] = 0x00;

        int originLen = originData.length;
        data[8] = (byte) (originLen & 0xFF);
        data[9] = (byte) ((originLen >> 8) & 0xFF);
        data[10] = (byte) ((originLen >> 16) & 0xFF);
        data[11] = (byte) ((originLen >> 24) & 0xFF);

        System.arraycopy(uuid1, 0, data, 12, uuid1.length);
        for (int i = 0; i < 68; i++) {
            data[28+i] = (byte) 0xFF;
        }
        data[96] = 0x00;
        data[97] = 0x00;
        data[98] = 0x00;
        data[99] = 0x10;
        return data;
    }

    public static byte[] getMpHeader(byte[] originData) {
        int len = 512;
        byte[] data = new byte[len];

        for (int i = 0; i < len; i++) {
            data[i] = 0x00;
        }

        // bin
        data[0] = 0x01;
        data[1] = 0x00;
        data[2] = 0x02;
        data[3] = 0x02;
        data[4] = 0x09;

        //version
        data[5] = 0x02;
        data[6] = 0x00;
        data[7] = 0x04;
        data[8] = 0x00;
        data[9] = 0x00;
        data[10] = 0x00;
        data[11] = 0x00;

        //part number
        data[12] = 0x03;
        data[13] = 0x00;
        data[14] = 0x20;
        data[15] = 0x00;
        for (int i = 0; i < 31; i++) {
            data[16 + i] = (byte) 0xFF;
        }

        //origin data length
        data[47] = 0x04;
        data[48] = 0x00;
        data[49] = 0x04;
        int fullLength = originData.length + 1024;
        data[50] = (byte) (fullLength & 0xFF);
        data[51] = (byte) ((fullLength >> 8) & 0xFF);
        data[52] = (byte) ((fullLength >> 16) & 0xFF);
        data[53] = (byte) ((fullLength >> 24) & 0xFF);

        // ota version
        data[54] = 0x11;
        data[55] = 0x00;
        data[56] = 0x01;
        data[57] = 0x01;

        //image id
        data[58] = 0x12;
        data[59] = 0x00;
        data[60] = 0x02;
        data[61] = (byte) 0xFE;
        data[62] = (byte) 0xFF;

        //full image size
        data[63] = 0x14;
        data[64] = 0x00;
        data[65] = 0x04;

        int originLen = originData.length + 1024;
        data[66] = (byte) (originLen & 0xFF);
        data[67] = (byte) ((originLen >> 8) & 0xFF);
        data[68] = (byte) ((originLen >> 16) & 0xFF);
        data[69] = (byte) ((originLen >> 24) & 0xFF);

        //secure version
        data[70] = 0x15;
        data[71] = 0x00;
        data[72] = 0x01;
        data[73] = 0x00;

        //image version
        data[74] = 0x16;
        data[75] = 0x00;
        data[76] = 0x04;
        data[77] = 0x00;
        data[78] = 0x00;
        data[79] = 0x00;
        data[80] = 0x00;

        return data;
    }

    public static byte[] getMpHeaderNew(byte[] originData) {
        int len = 512;
        byte[] data = new byte[len];

        // 初始化为 0x00
        for (int i = 0; i < len; i++) {
            data[i] = 0x00;
        }

        // [0~4] 固定头部标识
        data[0] = 0x01;
        data[1] = 0x00;
        data[2] = 0x02;
        data[3] = 0x02;
        data[4] = (byte) 0xF0;

        // [5~11] version 信息（第11字节需动态设置）
        data[5] = 0x02;
        data[6] = 0x00;
        data[7] = 0x04;
        data[8] = 0x00;
        data[9] = 0x00;
        data[10] = 0x00;
        data[11] = 0x00; // 可变版本字段

        // [12~24] part number: 固定前缀 + 填充0
        data[12] = 0x03;
        data[13] = 0x00;
        data[14] = 0x20;
        String partNum = "RTL8773EWE";
        byte[] partNumBytes = partNum.getBytes();
        System.arraycopy(partNumBytes, 0, data, 15, partNumBytes.length);

        // [25~46] Part Number填充 0x00 (已经在初始化时设置为0x00)

        // [47~53] origin data 长度（+1024）字段
        data[47] = 0x04;
        data[48] = 0x00;
        data[49] = 0x04;
        int originLen = originData.length + 1024;
        data[50] = (byte) (originLen & 0xFF);
        data[51] = (byte) ((originLen >> 8) & 0xFF);
        data[52] = (byte) ((originLen >> 16) & 0xFF);
        data[53] = (byte) ((originLen >> 24) & 0xFF);

        // [54~57] ota version
        data[54] = 0x11;
        data[55] = 0x00;
        data[56] = 0x01;
        data[57] = 0x02;

        // [58~62] image id
        data[58] = 0x12;
        data[59] = 0x00;
        data[60] = 0x02;
        data[61] = (byte) 0xFD;
        data[62] = (byte) 0xFF;

        // [63~69] full image size（+1024）
        data[63] = 0x14;
        data[64] = 0x00;
        data[65] = 0x04;
        int fullLength = originData.length + 1024;
        data[66] = (byte) (fullLength & 0xFF);
        data[67] = (byte) ((fullLength >> 8) & 0xFF);
        data[68] = (byte) ((fullLength >> 16) & 0xFF);
        data[69] = (byte) ((fullLength >> 24) & 0xFF);

        // [70~73] secure version
        data[70] = 0x15;
        data[71] = 0x00;
        data[72] = 0x01;
        data[73] = 0x00;

        // [74~80] image version（第80字节需动态设置）
        data[74] = 0x16;
        data[75] = 0x00;
        data[76] = 0x04;
        data[77] = 0x00;
        data[78] = 0x00;
        data[79] = 0x00;
        data[80] = 0x00; // 可变 image version

        // [81~84] 保留字段 1B (固定)
        data[81] = 0x1B;
        data[82] = 0x00;
        data[83] = 0x04;
        data[84] = 0x10;

        // [85~88] 固定设备标识或芯片
        data[85] = 0x01;
        data[86] = 0x00;
        data[87] = 0x00;
        data[88] = (byte) 0xFE;

        // [89~91] 协议/兼容标识
        data[89] = 0x00;
        data[90] = 0x01;
        data[91] = 0x01;

        return data;
    }

    public static byte[] getMpHeaderToVD(byte[] originData) {
        int len = 512;
        byte[] data = new byte[len];

        for (int i = 0; i < len; i++) {
            data[i] = 0x00;
        }

        // bin
        data[0] = 0x01;
        data[1] = 0x00;
        data[2] = 0x02;
        data[3] = 0x01;
        data[4] = 0x09;

        //version
        data[5] = 0x02;
        data[6] = 0x00;
        data[7] = 0x04;
        data[8] = 0x00;
        data[9] = 0x00;
        data[10] = 0x00;
        data[11] = 0x10;

        //part number
        data[12] = 0x03;
        data[13] = 0x00;
        data[14] = 0x20;
        data[15] = 0x00;
        for (int i = 0; i < 31; i++) {
            data[16 + i] = (byte) 0xFF;
        }

        //origin data length
        data[47] = 0x04;
        data[48] = 0x00;
        data[49] = 0x04;
        int fullLength = originData.length + 1024;
        data[50] = (byte) (fullLength & 0xFF);
        data[51] = (byte) ((fullLength >> 8) & 0xFF);
        data[52] = (byte) ((fullLength >> 16) & 0xFF);
        data[53] = (byte) ((fullLength >> 24) & 0xFF);

        // ota version
        data[54] = 0x11;
        data[55] = 0x00;
        data[56] = 0x01;
        data[57] = 0x01;

        //image id
        data[58] = 0x12;
        data[59] = 0x00;
        data[60] = 0x02;
        data[61] = (byte) 0xFE;
        data[62] = (byte) 0xFF;

        //full image size
        data[63] = 0x14;
        data[64] = 0x00;
        data[65] = 0x04;

        int originLen = originData.length + 1024;
        data[66] = (byte) (originLen & 0xFF);
        data[67] = (byte) ((originLen >> 8) & 0xFF);
        data[68] = (byte) ((originLen >> 16) & 0xFF);
        data[69] = (byte) ((originLen >> 24) & 0xFF);

        //secure version
        data[70] = 0x15;
        data[71] = 0x00;
        data[72] = 0x01;
        data[73] = 0x00;

        //image version
        data[74] = 0x16;
        data[75] = 0x00;
        data[76] = 0x04;
        data[77] = 0x00;
        data[78] = 0x00;
        data[79] = 0x00;
        data[80] = 0x10;
        data[81] = 0x22;
        data[82] = 0x00;
        data[83] = 0x01;
        data[84] = 0x02;

        return data;
    }

}