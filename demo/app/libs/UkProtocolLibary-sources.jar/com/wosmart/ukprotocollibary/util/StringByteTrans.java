package com.wosmart.ukprotocollibary.util;

import android.text.TextUtils;
import android.util.Log;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

public class StringByteTrans {

	/**
	 * Convert hexadecimal string to byte array
	 *
	 * @param src Byte string, there is no separator between each Byte
	 * @return byte[] The corresponding byte array
	 */
	public static byte[] hexStringToByteArray(String src) {
		int len = src.length();
		byte[] data = new byte[len / 2];
		src = src.toUpperCase();
		char[] hexs = src.toCharArray();
		// judge the input string good or not
		if (len % 2 == 1) {
			return null;
		}
		// judge the input string good or not
		for (int i = 0; i < len; i++) {
			if ((hexs[i] >= '0' && hexs[i] <= '9') || (hexs[i] >= 'A' && hexs[i] <= 'F')) {
			} else {
				return null;
			}
		}
		for (int i = 0; i < len; i += 2) {
			data[i / 2] = (byte) ((Character.digit(src.charAt(i), 16) << 4) + Character.digit(src.charAt(i + 1), 16));
		}

		return data;
	}

	/**
	 * ASCII string convert to Byte array
	 *
	 * @param str ascii string
	 * @return byte[]
	 */
	public static byte[] Str2Bytes(String str) {
		if (str == null) {
			throw new IllegalArgumentException(
					"Argument str ( String ) is null! ");
		}
		byte[] b = new byte[str.length() / 2];

		try {
			b = str.getBytes("US-ASCII");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
	}

	/**
	 * bytes array convert to a normal string corresponding character (ASCII)
	 *
	 * @param bytearray byte[]
	 * @return String
	 */
	public static String Byte2String(byte[] bytearray) {
		StringBuilder result = new StringBuilder();
		char temp;

		int length = bytearray.length;
		for (int i = 0; i < length; i++) {
			temp = (char) bytearray[i];
			result.append(temp);
		}
		return result.toString();
	}

	public static String byte2Mac(byte[] b) {
		StringBuilder sb = new StringBuilder();
		byte[] var3 = b;
		int var4 = b.length;

		for (int var5 = var4 - 1; var5 >= 0; --var5) {
			byte aB = var3[var5];
			String stmp = Integer.toHexString(aB & 255);
			sb.append(stmp.length() == 1 ? "0" + stmp : stmp);
			sb.append(":");
		}
		String mac = sb.toString().toLowerCase();
		return mac.substring(0, mac.length() - 1);
	}


	/**
	 * String into a unicode String
	 *
	 * @param strText The Angle of the string
	 * @return String No separator between each unicode
	 * @throws Exception
	 */
	public static String strToUnicode(String strText)
			throws Exception {
		char c;
		StringBuilder str = new StringBuilder();
		int intAsc;
		String strHex;
		for (int i = 0; i < strText.length(); i++) {
			c = strText.charAt(i);
			intAsc = (int) c;
			strHex = Integer.toHexString(intAsc);
			if (intAsc > 128)
				str.append("\\u").append(strHex);
			else // 00 low in the front
				str.append("\\u00").append(strHex);
		}
		return str.toString();
	}

	/**
	 * Unicode String into a String
	 *
	 * @param hex Hexadecimal values string (a unicode 2 byte)
	 * @return String The Angle of the string
	 */
	public static String unicodeToString(String hex) {
		int t = hex.length() / 6;
		StringBuilder str = new StringBuilder();
		for (int i = 0; i < t; i++) {
			String s = hex.substring(i * 6, (i + 1) * 6);
			// Need to catch up on high 00 turn again
			String s1 = s.substring(2, 4) + "00";
			// Low directly
			String s2 = s.substring(4);
			// The hexadecimal string to an int
			int n = Integer.valueOf(s1, 16) + Integer.valueOf(s2, 16);
			// To convert an int to characters
			char[] chars = Character.toChars(n);
			str.append(new String(chars));
		}
		return str.toString();
	}

	public static byte[] stringToBytes(String content, int byteCount) {
		byte[] contentData = new byte[byteCount];
		if (!TextUtils.isEmpty(content)) {
			byte[] contentByteData = content.getBytes(StandardCharsets.UTF_8);
			if (contentByteData.length > byteCount - 1) {
				// 防止截取字节后不足以完整展示最后一个字符(例如最后一个字符转换后为 [29, 30, 31], 此时截取到 30 位将不能展示最后一个字符)
				String newContent = getWholeText(content, byteCount - 1);
				byte[] newContentByteData = newContent.getBytes(StandardCharsets.UTF_8);
				int newContentByteDataLen = newContentByteData.length;
				System.arraycopy(newContentByteData, 0, contentData, 0, newContentByteDataLen);
				// 此时长度可能不足 byteCount - 1，补 0
				if (newContentByteData.length < byteCount - 1) {
					for (int i = newContentByteData.length; i < byteCount - 1; i++) {
						contentData[i] = 0;
					}
				}
			} else {
				int contentLen = contentByteData.length;
				System.arraycopy(contentByteData, 0, contentData, 0, contentLen);
				// 剩余位补 0
				for (int i = contentLen; i < byteCount; i++) {
					contentData[i] = 0;
				}
			}
		} else {
			for (int i = 0; i < byteCount; i++) {
				contentData[i] = 0;
			}
		}

		// 最后一位为 0
		contentData[byteCount - 1] = 0;

		return contentData;
	}

	public static String getWholeText(String text, int byteCount) {
		if (text != null && text.getBytes(StandardCharsets.UTF_8).length > byteCount) {
			char[] tempChars = text.toCharArray();
			int sumByte = 0;
			int charIndex = 0;
			for (int i = 0, len = tempChars.length; i < len; i++) {
				char itemChar = tempChars[i];
				// 根据 Unicode 值，判断它占用的字节数
				if (itemChar >= 0x0000 && itemChar <= 0x007F) {
					sumByte += 1;
				} else if (itemChar >= 0x0080 && itemChar <= 0x07FF) {
					sumByte += 2;
				} else {
					sumByte += 3;
				}
				if (sumByte > byteCount) {
					charIndex = i;
					break;
				}
			}
			return String.valueOf(tempChars, 0, charIndex);
		}
		return text;
	}

}
