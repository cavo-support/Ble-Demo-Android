package com.wosmart.ukprotocollibary.util;

public interface OldServiceCallback {

    void onLinkLossAlertLevelChanged(byte level);

    void onBatteryLevelChanged(int i, boolean b);

    void onHrpValueReceive(int value);

}
