package com.wosmart.ukprotocollibary.util;

import java.io.UnsupportedEncodingException;

public class DataConverter {
    private static final String HEX_CODE = "0123456789ABCDEF";

    public DataConverter() {
    }

    public static String str2Hex(String str) {
        char[] chars = "0123456789ABCDEF".toCharArray();
        StringBuilder sb = new StringBuilder("");
        byte[] bs = str.getBytes();
        byte[] var5 = bs;
        int var6 = bs.length;

        for(int var7 = 0; var7 < var6; ++var7) {
            byte b = var5[var7];
            int bit = (b & 240) >> 4;
            sb.append(chars[bit]);
            bit = b & 15;
            sb.append(chars[bit]);
            sb.append(' ');
        }

        return sb.toString().trim();
    }

    public static String hex2Str(String hexStr) {
        hexStr = hexStr.toUpperCase();
        char[] hexs = hexStr.toCharArray();
        byte[] bytes = new byte[hexStr.length() / 2];
        if (hexStr.length() % 2 == 1) {
            return "";
        } else {
            int n;
            for(n = 0; n < hexStr.length(); ++n) {
                if ((hexs[n] < '0' || hexs[n] > '9') && (hexs[n] < 'A' || hexs[n] > 'F')) {
                    return "";
                }
            }

            for(int i = 0; i < bytes.length; ++i) {
                n = "0123456789ABCDEF".indexOf(hexs[2 * i]) * 16;
                n += "0123456789ABCDEF".indexOf(hexs[2 * i + 1]);
                bytes[i] = (byte)(n & 255);
            }

            return new String(bytes);
        }
    }

    public static String str2Unicode(String strText) throws Exception {
        StringBuilder str = new StringBuilder();

        for(int i = 0; i < strText.length(); ++i) {
            char c = strText.charAt(i);
            String strHex = Integer.toHexString(c);
            if (c > 128) {
                str.append("\\u" + strHex);
            } else {
                str.append("\\u00" + strHex);
            }
        }

        return str.toString();
    }

    public static String unicode2Str(String hex) {
        int t = hex.length() / 6;
        StringBuilder str = new StringBuilder();

        for(int i = 0; i < t; ++i) {
            String s = hex.substring(i * 6, (i + 1) * 6);
            String s1 = s.substring(2, 4) + "00";
            String s2 = s.substring(4);
            int n = Integer.valueOf(s1, 16) + Integer.valueOf(s2, 16);
            char[] chars = Character.toChars(n);
            str.append(new String(chars));
        }

        return str.toString();
    }

    public static byte[] str2Bytes(String str) {
        if (str == null) {
            throw new IllegalArgumentException("Argument str ( String ) is null! ");
        } else {
            byte[] b = new byte[str.length() / 2];

            try {
                b = str.getBytes("US-ASCII");
            } catch (UnsupportedEncodingException var3) {
                var3.printStackTrace();
            }

            return b;
        }
    }

    public static String bytes2Str(byte[] bytearray) {
        String result = "";
        int length = bytearray.length;
        byte[] var4 = bytearray;
        int var5 = bytearray.length;

        for(int var6 = 0; var6 < var5; ++var6) {
            byte aBytearray = var4[var6];
            char temp = (char)aBytearray;
            result = result + temp;
        }

        return result;
    }

    public static String bytes2Hex(byte[] b) {
        StringBuilder sb = new StringBuilder("");
        byte[] var3 = b;
        int var4 = b.length;

        for(int var5 = 0; var5 < var4; ++var5) {
            byte aB = var3[var5];
            String stmp = Integer.toHexString(aB & 255);
            sb.append(stmp.length() == 1 ? "0" + stmp : stmp);
            sb.append(" ");
        }

        return sb.toString().toUpperCase().trim();
    }

    public static byte[] hex2Bytes(String src) {
        int len = src.length();
        byte[] data = new byte[len / 2];
        src = src.toUpperCase();
        char[] hexs = src.toCharArray();
        if (len % 2 == 1) {
            return null;
        } else {
            int i;
            for(i = 0; i < len; ++i) {
                if ((hexs[i] < '0' || hexs[i] > '9') && (hexs[i] < 'A' || hexs[i] > 'F')) {
                    return null;
                }
            }

            for(i = 0; i < len; i += 2) {
                data[i / 2] = (byte)((Character.digit(src.charAt(i), 16) << 4) + Character.digit(src.charAt(i + 1), 16));
            }

            return data;
        }
    }

    public static byte[] hex2BigBytes(String src) {
        int len = src.length();
        byte[] data = new byte[len / 2];
        src = src.toUpperCase();
        char[] hexs = src.toCharArray();
        if (len % 2 == 1) {
            return null;
        } else {
            int i;
            for(i = 0; i < len; ++i) {
                if ((hexs[i] < '0' || hexs[i] > '9') && (hexs[i] < 'A' || hexs[i] > 'F')) {
                    return null;
                }
            }

            for(i = 0; i < len; i += 2) {
                data[len / 2 - i / 2 - 1] = (byte)((Character.digit(src.charAt(i), 16) << 4) + Character.digit(src.charAt(i + 1), 16));
            }

            return data;
        }
    }
}
