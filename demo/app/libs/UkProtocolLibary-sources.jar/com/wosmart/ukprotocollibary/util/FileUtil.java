package com.wosmart.ukprotocollibary.util;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;

public class FileUtil {


    public static void appendToFile(Context context,String content, String fileName) {
        try {
            String fileDir = context.getCacheDir().getAbsolutePath() + "/WoFit/File/";
            String fullName = fileDir + fileName;
            File file = new File(fileDir);
            if (!file.exists()) {
                file.mkdirs();
            }
            File file2 = new File(fullName);

            long size = getFileSize(file2);
            if (size > 10 * 1048576) {
                //大于5m 先删除
                file2.delete();
                file2.createNewFile();
                append(content, fullName);
            } else {
                append(content, fullName);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private static void append(String content, String fullName) {
        RandomAccessFile randomFile = null;
        try {
            // 打开一个随机访问文件流，按读写方式
            randomFile = new RandomAccessFile(fullName, "rw");
            // 文件长度，字节数
            long fileLength = randomFile.length();
            // 将写文件指针移到文件尾。
            randomFile.seek(fileLength);
            randomFile.write(content.getBytes("gb2312"));
            randomFile.write("\n".getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (randomFile != null) {
                try {
                    randomFile.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 获取指定文件大小
     *
     * @param file
     * @return
     * @throws Exception
     */
    private static long getFileSize(File file) throws Exception {
        long size = 0;
        if (file.exists()) {
            FileInputStream fis = null;
            try {
                fis = new FileInputStream(file);
                size = fis.available();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (null != fis) {
                        fis.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            file.createNewFile();
            Log.e("获取文件大小", "文件不存在!");
        }
        return size;
    }
}
