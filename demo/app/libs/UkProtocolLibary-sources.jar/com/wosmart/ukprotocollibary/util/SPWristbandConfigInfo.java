package com.wosmart.ukprotocollibary.util;

import android.content.Context;
import android.content.SharedPreferences;

public class SPWristbandConfigInfo {
    private static boolean DEFAULT_GENDAR = false;
    private static int DEFAULT_AGE = 20;
    private static int DEFAULT_HEIGHT = 170;
    private static int DEFAULT_WEIGHT = 60;
    private static int DEFAULT_TOTAL_STEP = 7000;
    private static int DEFAULT_LONG_SIT_ALARM_TIME = 60;
    private static int DEFAULT_LONG_SIT_START_HOUR = 9;
    private static int DEFAULT_LONG_SIT_END_HOUR = 18;
    private static int DEFAULT_ALARM_TIME = 15;
    private static boolean DEFAULT_NOTIFY_FLAG_CALL = false;
    private static boolean DEFAULT_NOTIFY_FLAG_MESSAGE = false;
    private static boolean DEFAULT_NOTIFY_FLAG_QQ = false;
    private static boolean DEFAULT_NOTIFY_FLAG_WECHAT = false;
    private static boolean DEFAULT_NOTIFY_FLAG_LINE = false;
    private static boolean DEFAULT_NOTIFY_FLAG_TWITTER = false;
    private static boolean DEFAULT_NOTIFY_FLAG_FACEBOOK = false;
    private static boolean DEFAULT_NOTIFY_FLAG_MESSENGER = false;
    private static boolean DEFAULT_NOTIFY_FLAG_WHATSAPP = false;
    private static boolean DEFAULT_NOTIFY_FLAG_LINKEDIN = false;
    private static boolean DEFAULT_NOTIFY_FLAG_INSTAGRAM = false;
    private static boolean DEFAULT_NOTIFY_FLAG_SKYPE = false;
    private static boolean DEFAULT_NOTIFY_FLAG_VIBER = false;
    private static boolean DEFAULT_NOTIFY_FLAG_KAKAOTALK = false;
    private static boolean DEFAULT_NOTIFY_FLAG_VKONTAKTE = false;
    private static boolean DEFAULT_CONTROL_SWITCH_LOST = false;
    private static boolean DEFAULT_CONTROL_SWITCH_LONG_SIT = false;
    private static boolean DEFAULT_CONTROL_TURN_OVER_WRIST = true;
    private static boolean DEFAULT_FIRST_INITIAL = false;
    private static boolean DEFAULT_IS_24_HOUR = false;
    private static boolean DEFAULT_IS_METRIC = true;
    private static boolean DEFAULT_DISTURB = false;
    private static int DEFAULT_DISTURB_START_HOUR = 22;
    private static int DEFAULT_DISTURB_START_MINUTE = 0;
    private static int DEFAULT_DISTURB_END_HOUR = 8;
    private static int DEFAULT_DISTURB_END_MINUTE = 0;
    private static int DEFAULT_LIGHT_DURATION = 5;

    public static int DEFAULT_INVALID_VALUE = -1;
    public static int DEFAULT_CONTINUE_HRP_INTERVAL = 5;

    private static String SP_KEY_GENDAR = "SPKeyGendar";
    private static String SP_KEY_AGE = "SPKeyAge";
    private static String SP_KEY_HEIGHT = "SPKeyHeight";
    private static String SP_KEY_WEIGHT = "SPKeyWeight";
    private static String SP_KEY_TOTAL_STEP = "SPKeyTotalStep";
    private static String SP_KEY_LONG_SIT_ALARM_TIME = "SPKeyLongSitAlarmTime";
    private static String SP_KEY_LOST_ALARM_TIME = "SPKeyAlarmTime";
    private static String SP_KEY_LOST_ALARM_MUSIC = "SPKeyAlarmMusic";
    private static String SP_KEY_NOTIFY_FLAG_CALL = "SPKeyNotifyCall";
    private static String SP_KEY_NOTIFY_FLAG_MESSAGE = "SPKeyNotifyMessage";
    private static String SP_KEY_NOTIFY_FLAG_QQ = "SPKeyNotifyQQ";
    private static String SP_KEY_NOTIFY_FLAG_WECHAT = "SPKeyNotifyWechat";
    private static String SP_KEY_NOTIFY_FLAG_LINE = "SPKeyNotifyLine";
    private static String SP_KEY_NOTIFY_FLAG_TWITTER = "SPKeyNotifyTwitter";
    private static String SP_KEY_NOTIFY_FLAG_FACEBOOK = "SPKeyNotifyFacebook";
    private static String SP_KEY_NOTIFY_FLAG_MESSENGER = "SPKeyNotifyMessenger";
    private static String SP_KEY_NOTIFY_FLAG_WHATSAPP = "SPKeyNotifyWhatsApp";
    private static String SP_KEY_NOTIFY_FLAG_LINKEDIN = "SPKeyNotifyLinkedIn";
    private static String SP_KEY_NOTIFY_FLAG_INSTAGRAM = "SPKeyNotifyInstagram";
    private static String SP_KEY_NOTIFY_FLAG_SKYPE = "SPKeyNotifySkype";
    private static String SP_KEY_NOTIFY_FLAG_VIBER = "SPKeyNotifyViber";
    private static String SP_KEY_NOTIFY_FLAG_KAKAOTALK = "SPKeyNotifyKakaoTalk";
    private static String SP_KEY_NOTIFY_FLAG_VKONTAKTE = "SPKeyNotifyVkontakte";
    private static String SP_KEY_NOTIFY_FLAG_TIM = "SPKeyNotifyTim";
    private static String SP_KEY_NOTIFY_FLAG_GMAIL = "SPKeyNotifyGmail";
    private static String SP_KEY_NOTIFY_FLAG_DINGTALK = "SPKeyNotifyDingTalk";
    private static String SP_KEY_NOTIFY_FLAG_WORK_WECHAT = "SPKeyNotifyWorkWechat";
    private static String SP_KEY_NOTIFY_FLAG_OTHER = "SPKeyNotifyOther";
    private static String SP_KEY_CONTROL_SWITCH_LOST = "SPKeyControlSwitchLost";
    private static String SP_KEY_CONTROL_SWITCH_LONG_SIT = "SPKeyControlSwitchLongSit";
    private static String SP_KEY_LONG_SIT_START_HOUR = "SPKeyLongSitStartHour";
    private static String SP_KEY_LONG_SIT_END_HOUR = "SPKeyLongSitEndHour";
    private static String SP_KEY_CONTROL_SWITCH_TURN_OVER_WRIST = "SPKeyControlSwitchTurnOverWrist";
    private static String SP_KEY_AVATAR_PATH = "SPKeyAvatarPath";
    private static String SP_KEY_NAME = "SPKeyName";
    private static String SP_KEY_BONDED_DEVICE = "SPKeyBondedDevice";
    private static String SP_KEY_ALARM_CONTROL_ONE = "SPKeyAlarmControlOne";
    private static String SP_KEY_ALARM_TIME_ONE = "SPKeyAlarmTimeOne";
    private static String SP_KEY_ALARM_FLAG_ONE = "SPKeyAlarmFlagOne";
    private static String SP_KEY_ALARM_CONTROL_TWO = "SPKeyAlarmControlTwo";
    private static String SP_KEY_ALARM_TIME_TWO = "SPKeyAlarmTimeTwo";
    private static String SP_KEY_ALARM_FLAG_TWO = "SPKeyAlarmFlagTwo";
    private static String SP_KEY_ALARM_CONTROL_THREE = "SPKeyAlarmControlThree";
    private static String SP_KEY_ALARM_TIME_THREE = "SPKeyAlarmTimeThree";
    private static String SP_KEY_ALARM_FLAG_THREE = "SPKeyAlarmFlagThree";
    private static String SP_KEY_FIRST_INITIAL_FLAG = "SPKeyFirstInitialFlag";
    private static String SP_KEY_FIRST_OTA_START_FLAG = "SPKeyFirstOTAStartFlag";
    private static String SP_KEY_FIRST_APP_START_FLAG = "SPKeyFirstAPPStartFlag";
    private static String SP_KEY_FIRST_SPLASH_START_FLAG = "SPKeyFirstSplashStartFlag";
    private static String SP_KEY_USER_ID = "SPKeyUserId";
    private static String SP_KEY_USER_NAME = "SPKeyUserName";
    private static String SP_KEY_USER_PSW = "SPKeyUserPsw";
    private static String SP_KEY_DEBUG_LOG_TYPE_MODULE_APP = "SPKeyDebugLogTypeModuleApp";
    private static String SP_KEY_DEBUG_LOG_TYPE_MODULE_LOWER_STACK = "SPKeyDebugLogTypeModuleLowerStack";
    private static String SP_KEY_DEBUG_LOG_TYPE_MODULE_UPPER_STACK = "SPKeyDebugLogTypeModuleUpperStack";
    private static String SP_KEY_DEBUG_LOG_TYPE_SLEEP = "SPKeyDebugLogTypeSleep";
    private static String SP_KEY_DEBUG_LOG_TYPE_SPORT = "SPKeyDebugLogTypeSport";
    private static String SP_KEY_DEBUG_LOG_TYPE_CONFIG = "SPKeyDebugLogTypeConfig";
    private static String SP_KEY_CONTINUE_HRP_CONTROL = "SPKeyContinueHrpControl";
    private static String SP_KEY_CONTINUE_HRP_CONTROL_INTERVAL = "SPKeyContinueHrpControlInterval";

    private static String SP_KEY_ADJUST_TARGET_STEP = "SPKeyAdjustTargetStep";
    private static String SP_KEY_ADJUST_TARGET_DISTANCE = "SPKeyAdjustTargetDistance";
    private static String SP_KEY_ADJUST_TARGET_CAL = "SPKeyAdjustTargetCal";

    // For Internet mode
    private static String SP_KEY_BMOB_LAST_HISTORY_SYNC_DATE = "SPKeyBmobLastHistorySyncDate";
    private static String SP_KEY_BMOB_LAST_SYNC_DATE = "SPKeyBmobLastSyncDate";

    private static String SP_WRISTBAND_CONFIG_INFO = "SPWristbandConfigInfo";

    private static String SP_KEY_24_HOUR = "SPIs24Hour";

    private static String SP_KEY_METRIC_SYSTEM = "SPIsMetricSystem";

    private static String SP_KEY_DISTURB = "SPDisturb";

    private static String SP_KEY_DISTURB_START_HOUR = "SPDisturbStartHour";

    private static String SP_KEY_DISTURB_START_MINUTE = "SPDisturbStartMinute";

    private static String SP_KEY_DISTURB_END_HOUR = "SPDisturbEndHour";

    private static String SP_KEY_DISTURB_END_MINUTE = "SPDisturbEndMinute";

    private static String SP_KEY_LIGHT_DURATION = "SPLightDuration";

    private static String SP_KEY_LIGHT_PERCENT = "SPLightPercent";

    private static String SP_KEY_TEMP_MEASURE = "SPTempMeasure";

    private static String SP_KEY_TEMP_ADJUST = "SPTempAdjust";

    private static String SP_KEY_TEMP_UNIT = "SPTempUNIT";

    private static String SP_KEY_STOP_WATCH = "SpStopWatch";

    private static String SP_KEY_Find_PHONE = "SpFindPhone";

    private static String SP_KEY_AUTO_LOCK = "SpAutoLock";

    private static String SP_KEY_DUAL_SLIDE = "SpDualSlide";

    private static String SP_KEY_VOICE_ASSIST = "SpVoiceAssist";

    private static String SP_KEY_BP_MEASURE = "SPBpMeasure";

    private static String SP_KEY_BP_PRIVATE_MODE = "SPBpPrivate";

    private static String SP_KEY_BP_PRIVATE_HIGH = "SPBpPrivateHigh";

    private static String SP_KEY_BP_PRIVATE_LOW = "SPBpPrivateLow";

    public static String SP_KEY_DEVICE_NAME = "SPDeviceName";
    public static String SP_KEY_DEVICE_INFO = "SPDeviceInfo";

    public static boolean getTempUnit(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean unit = sp.getBoolean(SP_KEY_TEMP_UNIT, true);
        return unit;
    }

    public static boolean getTempAdjust(Context context) {
        if (context == null) {
            return false;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean adjust = sp.getBoolean(SP_KEY_TEMP_ADJUST, true);
        return adjust;
    }

    public static boolean getTempMeasure(Context context) {
        if (context == null) {
            return false;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean measure = sp.getBoolean(SP_KEY_TEMP_MEASURE, false);
        return measure;
    }

    public static boolean getBpMeasure(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean measure = sp.getBoolean(SP_KEY_BP_MEASURE, false);
        return measure;
    }

    public static boolean getBpPrivateMode(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean measure = sp.getBoolean(SP_KEY_BP_PRIVATE_MODE, false);
        return measure;
    }

    public static int getBpPrivateHigh(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        return sp.getInt(SP_KEY_BP_PRIVATE_HIGH, 120);
    }

    public static int getBpPrivateLow(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        return sp.getInt(SP_KEY_BP_PRIVATE_LOW, 80);
    }

    public static int getStopWatch(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int measure = sp.getInt(SP_KEY_STOP_WATCH, 0);
        return measure;
    }

    public static int getFindPhone(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int measure = sp.getInt(SP_KEY_Find_PHONE, 0);
        return measure;
    }

    public static int getAutoLock(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int autoLock = sp.getInt(SP_KEY_AUTO_LOCK, 0);
        return autoLock;
    }

    public static int getDualSlide(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int dualSlide = sp.getInt(SP_KEY_DUAL_SLIDE, 3);
        return dualSlide;
    }

    public static int getVoiceAssist(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int dualSlide = sp.getInt(SP_KEY_VOICE_ASSIST, 3);
        return dualSlide;
    }

    public static int getLightDuration(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int duration = sp.getInt(SP_KEY_LIGHT_DURATION, DEFAULT_LIGHT_DURATION);
        return duration;
    }

    public static int getLightPercent(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int duration = sp.getInt(SP_KEY_LIGHT_PERCENT, 50);
        return duration;
    }

    public static boolean getDisturb(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean disturb = sp.getBoolean(SP_KEY_DISTURB, DEFAULT_DISTURB);
        return disturb;
    }

    public static int getDisturbStartHour(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int disturb = sp.getInt(SP_KEY_DISTURB_START_HOUR, DEFAULT_DISTURB_START_HOUR);
        return disturb;
    }

    public static int getDisturbStartMinute(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int disturb = sp.getInt(SP_KEY_DISTURB_START_MINUTE, DEFAULT_DISTURB_START_MINUTE);
        return disturb;
    }

    public static int getDisturbEndHour(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int disturb = sp.getInt(SP_KEY_DISTURB_END_HOUR, DEFAULT_DISTURB_END_HOUR);
        return disturb;
    }

    public static int getDisturbEndMinute(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int disturb = sp.getInt(SP_KEY_DISTURB_END_MINUTE, DEFAULT_DISTURB_END_MINUTE);
        return disturb;
    }

    public static boolean getIs24Hour(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean flag = sp.getBoolean(SP_KEY_24_HOUR, DEFAULT_IS_24_HOUR);
        return flag;
    }

    public static boolean getIsMetric(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean flag = sp.getBoolean(SP_KEY_METRIC_SYSTEM, DEFAULT_IS_METRIC);
        return flag;
    }

    public static boolean getGendar(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean gender = sp.getBoolean(SP_KEY_GENDAR, DEFAULT_GENDAR);
        return gender;
    }

    public static int getAge(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int value = sp.getInt(SP_KEY_AGE, DEFAULT_AGE);
        return value;
    }

    public static int getHeight(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int value = sp.getInt(SP_KEY_HEIGHT, DEFAULT_HEIGHT);
        return value;
    }

    public static int getWeight(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int value = sp.getInt(SP_KEY_WEIGHT, DEFAULT_WEIGHT);
        return value;
    }

    public static int getTotalStep(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int value = sp.getInt(SP_KEY_TOTAL_STEP, DEFAULT_TOTAL_STEP);
        return value;
    }

    public static int getLongSitAlarmTime(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int value = sp.getInt(SP_KEY_LONG_SIT_ALARM_TIME, DEFAULT_LONG_SIT_ALARM_TIME);
        return value;
    }

    public static int getLongSitStartHour(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int value = sp.getInt(SP_KEY_LONG_SIT_START_HOUR, DEFAULT_LONG_SIT_START_HOUR);
        return value;
    }

    public static int getLongSitEndHour(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int value = sp.getInt(SP_KEY_LONG_SIT_END_HOUR, DEFAULT_LONG_SIT_END_HOUR);
        return value;
    }

    public static int getLostAlarmTime(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int value = sp.getInt(SP_KEY_LOST_ALARM_TIME, DEFAULT_ALARM_TIME);
        return value;
    }

    public static String getLostAlarmMusic(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        String value = sp.getString(SP_KEY_LOST_ALARM_MUSIC, null);
        return value;
    }

    public static boolean getNotifyCallFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_CALL, DEFAULT_NOTIFY_FLAG_CALL);
        return value;
    }

    public static boolean getNotifyMessageFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_MESSAGE, DEFAULT_NOTIFY_FLAG_MESSAGE);
        return value;
    }

    public static boolean getNotifyQQFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_QQ, DEFAULT_NOTIFY_FLAG_QQ);
        return value;
    }

    public static boolean getNotifyWechatFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_WECHAT, DEFAULT_NOTIFY_FLAG_WECHAT);
        return value;
    }

    public static boolean getNotifyLineFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_LINE, DEFAULT_NOTIFY_FLAG_LINE);
        return value;
    }

    public static boolean getNotifyTwitterFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_TWITTER, DEFAULT_NOTIFY_FLAG_TWITTER);
        return value;
    }

    public static boolean getNotifyFacebookFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_FACEBOOK, DEFAULT_NOTIFY_FLAG_FACEBOOK);
        return value;
    }

    public static boolean getNotifyMessengerFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_MESSENGER, DEFAULT_NOTIFY_FLAG_MESSENGER);
        return value;
    }

    public static boolean getNotifyWhatsAppFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_WHATSAPP, DEFAULT_NOTIFY_FLAG_WHATSAPP);
        return value;
    }

    public static boolean getNotifyLinkedInFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_LINKEDIN, DEFAULT_NOTIFY_FLAG_LINKEDIN);
        return value;
    }

    public static boolean getNotifyInstagramFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_INSTAGRAM, DEFAULT_NOTIFY_FLAG_INSTAGRAM);
        return value;
    }

    public static boolean getNotifySkypeFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_SKYPE, DEFAULT_NOTIFY_FLAG_SKYPE);
        return value;
    }

    public static boolean getNotifyViberFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_VIBER, DEFAULT_NOTIFY_FLAG_VIBER);
        return value;
    }

    public static boolean getNotifyKakaoTalkFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_KAKAOTALK, DEFAULT_NOTIFY_FLAG_KAKAOTALK);
        return value;
    }

    public static boolean getNotifyVkontakteFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_VKONTAKTE, DEFAULT_NOTIFY_FLAG_VKONTAKTE);
        return value;
    }

    public static boolean getNotifyTimFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_TIM, DEFAULT_NOTIFY_FLAG_VKONTAKTE);
        return value;
    }

    public static boolean getNotifyGmailFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_GMAIL, DEFAULT_NOTIFY_FLAG_VKONTAKTE);
        return value;
    }

    public static boolean getNotifyDingtalkFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_DINGTALK, DEFAULT_NOTIFY_FLAG_VKONTAKTE);
        return value;
    }

    public static boolean getNotifyWorkWechatFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_WORK_WECHAT, DEFAULT_NOTIFY_FLAG_VKONTAKTE);
        return value;
    }

    public static boolean getNotifyOtherFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_NOTIFY_FLAG_OTHER, DEFAULT_NOTIFY_FLAG_VKONTAKTE);
        return value;
    }


    public static boolean getControlSwitchLost(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_CONTROL_SWITCH_LOST, DEFAULT_CONTROL_SWITCH_LOST);
        return value;
    }

    public static boolean getControlSwitchLongSit(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_CONTROL_SWITCH_LONG_SIT, DEFAULT_CONTROL_SWITCH_LONG_SIT);
        return value;
    }

    public static boolean getControlSwitchTurnOverWrist(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_CONTROL_SWITCH_TURN_OVER_WRIST, DEFAULT_CONTROL_TURN_OVER_WRIST);
        return value;
    }

    public static String getAvatarPath(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        String value = sp.getString(SP_KEY_AVATAR_PATH, null);
        return value;
    }

    public static String getName(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        String value = sp.getString(SP_KEY_NAME, null);
        return value;
    }

    public static String getBondedDevice(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        String value = sp.getString(SP_KEY_BONDED_DEVICE, null);
        return value;
    }

    public static Boolean getAlarmControlOne(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        Boolean value = sp.getBoolean(SP_KEY_ALARM_CONTROL_ONE, false);
        return value;
    }

    public static String getAlarmTimeOne(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        String value = sp.getString(SP_KEY_ALARM_TIME_ONE, null);
        return value;
    }

    public static byte getAlarmFlagOne(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int value = sp.getInt(SP_KEY_ALARM_FLAG_ONE, 0);
        byte ret = (byte) (value & 0xff);
        return ret;
    }

    public static Boolean getAlarmControlTwo(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        Boolean value = sp.getBoolean(SP_KEY_ALARM_CONTROL_TWO, false);
        return value;
    }

    public static String getAlarmTimeTwo(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        String value = sp.getString(SP_KEY_ALARM_TIME_TWO, null);
        return value;
    }

    public static byte getAlarmFlagTwo(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int value = sp.getInt(SP_KEY_ALARM_FLAG_TWO, 0);
        byte ret = (byte) (value & 0xff);
        return ret;
    }

    public static Boolean getAlarmControlThree(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        Boolean value = sp.getBoolean(SP_KEY_ALARM_CONTROL_THREE, false);
        return value;
    }

    public static String getAlarmTimeThree(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        String value = sp.getString(SP_KEY_ALARM_TIME_THREE, null);
        return value;
    }

    public static byte getAlarmFlagThree(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int value = sp.getInt(SP_KEY_ALARM_FLAG_THREE, 0);
        byte ret = (byte) (value & 0xff);
        return ret;
    }

    public static boolean getFirstInitialFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_FIRST_INITIAL_FLAG, DEFAULT_FIRST_INITIAL);
        return value;
    }

    public static boolean getFirstOTAStartFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_FIRST_OTA_START_FLAG, true);
        return value;
    }

    public static boolean getFirstAppStartFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_FIRST_APP_START_FLAG, true);
        return value;
    }

    public static boolean getFirstSplashStartFlag(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_FIRST_SPLASH_START_FLAG, true);
        return value;
    }

    public static String getUserId(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        String value = sp.getString(SP_KEY_USER_ID, "");
        return value;
    }

    public static String getUserName(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        String value = sp.getString(SP_KEY_USER_NAME, null);
        return value;
    }

    public static String getUserPsw(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        String value = sp.getString(SP_KEY_USER_PSW, null);
        return value;
    }

    public static String getBmobLastHistorySyncDate(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        String value = sp.getString(SP_KEY_BMOB_LAST_HISTORY_SYNC_DATE, null);
        return value;
    }

    public static String getBmobLastSyncDate(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        String value = sp.getString(SP_KEY_BMOB_LAST_SYNC_DATE, null);
        return value;
    }

    public static String getInfoKeyValue(Context context, String key) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        String value = sp.getString(key, null);
        return value;
    }

    public static boolean getDebugLogTypeModuleApp(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_DEBUG_LOG_TYPE_MODULE_APP, true);
        return value;
    }

    public static boolean getDebugLogTypeModuleLowerStack(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_DEBUG_LOG_TYPE_MODULE_LOWER_STACK, true);
        return value;
    }

    public static boolean getDebugLogTypeModuleUpperStack(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_DEBUG_LOG_TYPE_MODULE_UPPER_STACK, true);
        return value;
    }

    public static boolean getDebugLogTypeSleep(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_DEBUG_LOG_TYPE_SLEEP, true);
        return value;
    }

    public static boolean getDebugLogTypeSport(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_DEBUG_LOG_TYPE_SPORT, true);
        return value;
    }

    public static boolean getDebugLogTypeConfig(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_DEBUG_LOG_TYPE_CONFIG, true);
        return value;
    }

    public static long getAdjustTargetStep(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        long value = sp.getLong(SP_KEY_ADJUST_TARGET_STEP, DEFAULT_INVALID_VALUE);
        return value;
    }

    public static long getAdjustTargetDistance(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        long value = sp.getLong(SP_KEY_ADJUST_TARGET_DISTANCE, DEFAULT_INVALID_VALUE);
        return value;
    }

    public static long getAdjustTargetCal(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        long value = sp.getLong(SP_KEY_ADJUST_TARGET_CAL, DEFAULT_INVALID_VALUE);
        return value;
    }

    public static boolean getContinueHrpControl(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        boolean value = sp.getBoolean(SP_KEY_CONTINUE_HRP_CONTROL, true);
        return value;
    }

    public static int getContinueHrpControlInterval(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        int value = sp.getInt(SP_KEY_CONTINUE_HRP_CONTROL_INTERVAL, DEFAULT_CONTINUE_HRP_INTERVAL);
        return value;
    }

    public static void setTempUnit(Context context, boolean v) {
        if (context == null) {
            return;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_TEMP_UNIT, v);
        ed.apply();
    }

    public static void setTempAdjust(Context context, boolean v) {
        if (context == null) {
            return;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_TEMP_ADJUST, v);
        ed.apply();
    }

    public static void setTempMeasure(Context context, boolean v) {
        if (context == null) {
            return;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_TEMP_MEASURE, v);
        ed.apply();
    }

    public static void setBpMeasure(Context context, boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_BP_MEASURE, v);
        ed.apply();
    }

    public static void setBpPrivateMode(Context context, boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_BP_PRIVATE_MODE, v);
        ed.apply();
    }

    public static void setBpPrivateHigh(Context context, int v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_BP_PRIVATE_HIGH, v);
        ed.apply();
    }

    public static void setBpPrivateLow(Context context, int v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_BP_PRIVATE_LOW, v);
        ed.apply();
    }

    public static void setStopWatch(Context context, int v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_STOP_WATCH, v);
        ed.apply();
    }

    public static void setFindPhone(Context context, int v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_Find_PHONE, v);
        ed.apply();
    }

    public static void setAutoLock(Context context, int v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_AUTO_LOCK, v);
        ed.apply();
    }

    public static void setDualSlide(Context context, int v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_DUAL_SLIDE, v);
        ed.apply();
    }

    public static void setVoiceAssist(Context context, int v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_VOICE_ASSIST, v);
        ed.apply();
    }

    public static void setLightDuration(Context context, Integer v) {
        if (v == null) {
            v = DEFAULT_LIGHT_DURATION;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_LIGHT_DURATION, v);
        ed.apply();
    }


    public static void setLightPercent(Context context, Integer v) {
        if (v == null) {
            v = 50;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_LIGHT_PERCENT, v);
        ed.apply();
    }

    public static void setDisturb(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_DISTURB;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_DISTURB, v);
        ed.apply();
    }

    public static void setDisturbStartHour(Context context, int v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_DISTURB_START_HOUR, v);
        ed.apply();
    }

    public static void setDisturbStartMinute(Context context, int v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_DISTURB_START_MINUTE, v);
        ed.apply();
    }

    public static void setDisturbEndHour(Context context, int v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_DISTURB_END_HOUR, v);
        ed.apply();
    }

    public static void setDisturbEndMinute(Context context, int v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_DISTURB_END_MINUTE, v);
        ed.apply();
    }

    public static void setIs24Hour(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_IS_24_HOUR;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_24_HOUR, v);
        ed.apply();
    }

    public static void setIsMetricSystem(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_IS_METRIC;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_METRIC_SYSTEM, v);
        ed.apply();
    }


    public static void setGender(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_GENDAR;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_GENDAR, v);
        ed.apply();
    }

    public static void setAge(Context context, Integer v) {
        if (v == null) {
            v = DEFAULT_AGE;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_AGE, v);
        ed.apply();
    }

    public static void setHeight(Context context, Integer v) {
        if (v == null) {
            v = DEFAULT_HEIGHT;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_HEIGHT, v);
        ed.apply();
    }

    public static void setWeight(Context context, Integer v) {
        if (v == null) {
            v = DEFAULT_WEIGHT;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_WEIGHT, v);
        ed.apply();
    }

    public static void setTotalStep(Context context, Integer v) {
        if (v == null) {
            v = DEFAULT_TOTAL_STEP;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_TOTAL_STEP, v);
        ed.apply();
    }

    public static void setLongSitAlarmTime(Context context, Integer v) {
        if (v == null) {
            v = DEFAULT_LONG_SIT_ALARM_TIME;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_LONG_SIT_ALARM_TIME, v);
        ed.apply();
    }

    public static void setLongSitStartHour(Context context, Integer v) {
        if (v == null) {
            v = DEFAULT_LONG_SIT_START_HOUR;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_LONG_SIT_START_HOUR, v);
        ed.apply();
    }

    public static void setLongSitEndHour(Context context, Integer v) {
        if (v == null) {
            v = DEFAULT_LONG_SIT_END_HOUR;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_LONG_SIT_END_HOUR, v);
        ed.apply();
    }

    public static void setLostAlarmTime(Context context, Integer v) {
        if (v == null) {
            v = DEFAULT_LONG_SIT_ALARM_TIME;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_LOST_ALARM_TIME, v);
        ed.apply();
    }

    public static void setLostAlarmMusic(Context context, String v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(SP_KEY_LOST_ALARM_MUSIC, v);
        ed.apply();
    }

    public static void setNotifyCallFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_CALL;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_CALL, v);
        ed.apply();
    }

    public static void setNotifyMessageFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_MESSAGE;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_MESSAGE, v);
        ed.apply();
    }

    public static void setNotifyQQFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_QQ;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_QQ, v);
        ed.apply();
    }

    public static void setNotifyWechatFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_WECHAT;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_WECHAT, v);
        ed.apply();
    }

    public static void setNotifyLineFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_LINE;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_LINE, v);
        ed.apply();
    }

    public static void setNotifyTwitterFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_TWITTER;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_TWITTER, v);
        ed.apply();
    }

    public static void setNotifyFacebookFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_FACEBOOK;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_FACEBOOK, v);
        ed.apply();
    }

    public static void setNotifyMessengerFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_MESSENGER;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_MESSENGER, v);
        ed.apply();
    }

    public static void setNotifyWhatsAppFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_WHATSAPP;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_WHATSAPP, v);
        ed.apply();
    }

    public static void setNotifyLinkedInFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_LINKEDIN;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_LINKEDIN, v);
        ed.apply();
    }

    public static void setNotifyInstagramFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_INSTAGRAM;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_INSTAGRAM, v);
        ed.apply();
    }

    public static void setNotifySkypeFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_SKYPE;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_SKYPE, v);
        ed.apply();
    }

    public static void setNotifyViberFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_VIBER;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_VIBER, v);
        ed.apply();
    }

    public static void setNotifyKakaoTalkFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_KAKAOTALK;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_KAKAOTALK, v);
        ed.apply();
    }

    public static void setNotifyVkontakteFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_VKONTAKTE;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_VKONTAKTE, v);
        ed.apply();
    }

    public static void setNotifyTimFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_VKONTAKTE;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_TIM, v);
        ed.apply();
    }

    public static void setNotifyGmailFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_VKONTAKTE;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_GMAIL, v);
        ed.apply();
    }

    public static void setNotifyDingTalkFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_VKONTAKTE;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_DINGTALK, v);
        ed.apply();
    }

    public static void setNotifyWorkWechatFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_VKONTAKTE;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_WORK_WECHAT, v);
        ed.apply();
    }

    public static void setNotifyOtherFlag(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_NOTIFY_FLAG_VKONTAKTE;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_NOTIFY_FLAG_OTHER, v);
        ed.apply();
    }

    public static void setControlSwitchLost(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_CONTROL_SWITCH_LOST;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_CONTROL_SWITCH_LOST, v);
        ed.apply();
    }

    public static void setControlSwitchLongSit(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_CONTROL_SWITCH_LONG_SIT;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_CONTROL_SWITCH_LONG_SIT, v);
        ed.apply();
    }

    public static void setControlSwitchTurnOverWrist(Context context, Boolean v) {
        if (v == null) {
            v = DEFAULT_CONTROL_TURN_OVER_WRIST;
        }
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_CONTROL_SWITCH_TURN_OVER_WRIST, v);
        ed.apply();
    }

    public static void setAvatarPath(Context context, String v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(SP_KEY_AVATAR_PATH, v);
        ed.apply();
    }

    public static void setName(Context context, String v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(SP_KEY_NAME, v);
        ed.apply();
    }

    public static void setBondedDevice(Context context, String v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(SP_KEY_BONDED_DEVICE, v);
        ed.apply();
    }

    public static void setAlarmControlOne(Context context, Boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_ALARM_CONTROL_ONE, v);
        ed.apply();
    }

    public static void setAlarmTimeOne(Context context, String v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(SP_KEY_ALARM_TIME_ONE, v);
        ed.apply();
    }

    public static void setAlarmFlagOne(Context context, byte v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_ALARM_FLAG_ONE, v);
        ed.apply();
    }

    public static void setAlarmControlTwo(Context context, Boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_ALARM_CONTROL_TWO, v);
        ed.apply();
    }

    public static void setAlarmTimeTwo(Context context, String v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(SP_KEY_ALARM_TIME_TWO, v);
        ed.apply();
    }

    public static void setAlarmFlagTwo(Context context, byte v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_ALARM_FLAG_TWO, v);
        ed.apply();
    }

    public static void setAlarmControlThree(Context context, Boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_ALARM_CONTROL_THREE, v);
        ed.apply();
    }

    public static void setAlarmTimeThree(Context context, String v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(SP_KEY_ALARM_TIME_THREE, v);
        ed.apply();
    }

    public static void setAlarmFlagThree(Context context, byte v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_ALARM_FLAG_THREE, v);
        ed.apply();
    }

    public static void setFirstInitialFlag(Context context, boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_FIRST_INITIAL_FLAG, v);
        ed.apply();
    }

    public static void setFirstOtaStartFlag(Context context, boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_FIRST_OTA_START_FLAG, v);
        ed.apply();
    }

    public static void setFirstAppStartFlag(Context context, boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_FIRST_APP_START_FLAG, v);
        ed.apply();
    }

    public static void setFirstSplashStartFlag(Context context, boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_FIRST_SPLASH_START_FLAG, v);
        ed.apply();
    }

    public static void setUserId(Context context, String v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(SP_KEY_USER_ID, v);
        ed.apply();
    }

    public static void setUserName(Context context, String v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(SP_KEY_USER_NAME, v);
        ed.apply();
    }

    public static void setUserPsw(Context context, String v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(SP_KEY_USER_PSW, v);
        ed.apply();
    }

    public static void setBmobLastHistorySyncDate(Context context, String v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(SP_KEY_BMOB_LAST_HISTORY_SYNC_DATE, v);
        ed.apply();
    }

    // First login must set this value
    public static void setBmobLastSyncDate(Context context, String v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(SP_KEY_BMOB_LAST_SYNC_DATE, v);
        ed.apply();
    }

    public static void setDebugLogTypeModuleApp(Context context, boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_DEBUG_LOG_TYPE_MODULE_APP, v);
        ed.apply();
    }

    public static void setDebugLogTypeModuleLowerStack(Context context, boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_DEBUG_LOG_TYPE_MODULE_LOWER_STACK, v);
        ed.apply();
    }

    public static void setDebugLogTypeModuleUpperStack(Context context, boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_DEBUG_LOG_TYPE_MODULE_UPPER_STACK, v);
        ed.apply();
    }


    public static void setDebugLogTypeSleep(Context context, boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_DEBUG_LOG_TYPE_SLEEP, v);
        ed.apply();
    }

    public static void setDebugLogTypeSport(Context context, boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_DEBUG_LOG_TYPE_SPORT, v);
        ed.apply();
    }

    public static void setDebugLogTypeConfig(Context context, boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_DEBUG_LOG_TYPE_CONFIG, v);
        ed.apply();
    }

    public static void setInfoKeyValue(Context context, String key, String v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(key, v);
        ed.apply();
    }

    public static void setAdjustTargetStep(Context context, long v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putLong(SP_KEY_ADJUST_TARGET_STEP, v);
        ed.apply();
    }

    public static void setAdjustTargetDistance(Context context, long v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putLong(SP_KEY_ADJUST_TARGET_DISTANCE, v);
        ed.apply();
    }

    public static void setAdjustTargetCal(Context context, long v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putLong(SP_KEY_ADJUST_TARGET_CAL, v);
        ed.apply();
    }

    public static void setContinueHrpControl(Context context, boolean v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean(SP_KEY_CONTINUE_HRP_CONTROL, v);
        ed.apply();
    }

    public static void setContinueHrpControlInterval(Context context, int v) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(SP_KEY_CONTINUE_HRP_CONTROL_INTERVAL, v);
        ed.apply();
    }

    public static void deleteAll(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SP_WRISTBAND_CONFIG_INFO, Context.MODE_PRIVATE);
        sp.edit().clear().apply();
    }
}
