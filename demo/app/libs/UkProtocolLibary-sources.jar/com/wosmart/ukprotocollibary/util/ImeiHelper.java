package com.wosmart.ukprotocollibary.util;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;

import java.lang.reflect.Method;
import java.util.UUID;

/**
 * Created by rain1_wen on 2017/5/16.
 */

public class ImeiHelper {

    public static String getIMEI(Context context) {
//        String imei = null;
//
//        int permissionCheck = ContextCompat.checkSelfPermission(context,
//                Manifest.permission.READ_PHONE_STATE);
//        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
//            TelephonyManager telephonyManager = (TelephonyManager) context
//                    .getSystemService(Context.TELEPHONY_SERVICE);
//            if (telephonyManager != null) {
//                imei = telephonyManager.getDeviceId();
//            }
//        } else {
//            SDKLogger.w("permission not grated, " + Manifest.permission.READ_PHONE_STATE);
//        }
//
//        if (TextUtils.isEmpty(imei)) {
//            imei = android.os.Build.SERIAL;
//        }
//
//        if (TextUtils.isEmpty(imei)) {
//            imei = android.os.Build.HARDWARE;
//        }
//        return imei == null ? "" : imei;
        return getUUID(context);
    }


    public static String getUUID(Context context) {
        String serial = null;

        String m_szDevIDShort = "35" +
                Build.BOARD.length() % 10 + Build.BRAND.length() % 10 +

                Build.CPU_ABI.length() % 10 + Build.DEVICE.length() % 10 +

                Build.DISPLAY.length() % 10 + Build.HOST.length() % 10 +

                Build.ID.length() % 10 + Build.MANUFACTURER.length() % 10 +

                Build.MODEL.length() % 10 + Build.PRODUCT.length() % 10 +

                Build.TAGS.length() % 10 + Build.TYPE.length() % 10 +

                Build.USER.length() % 10; //13 位

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                    serial = android.os.Build.getSerial();
                } else {
                    serial = "serial";
                }
            } else {
                serial = Build.SERIAL;
            }
            //API>=9 使用serial号
            return new UUID(m_szDevIDShort.hashCode(), serial.hashCode()).toString();
        } catch (Exception exception) {
            //serial需要一个初始化
            serial = "serial"; // 随便一个初始化
        }
        //使用硬件信息拼凑出来的15位号码
        return new UUID(m_szDevIDShort.hashCode(), serial.hashCode()).toString();
    }

    // The same to android.os.Build.SERIAL
    private static String getSerialNumber() {

        String serial = null;

        try {

            Class<?> c = Class.forName("android.os.SystemProperties");

            Method get = c.getMethod("get", String.class);

            serial = (String) get.invoke(c, "ro.serialno");

        } catch (Exception e) {

            e.printStackTrace();

        }

        return serial;

    }
}
