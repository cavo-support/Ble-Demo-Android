package com.wosmart.ukprotocollibary.util;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.wosmart.ukprotocollibary.v2.common.logger.DiskLogAdapter;
import com.wosmart.ukprotocollibary.v2.common.logger.JWLogger;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SDKLogger {

    private static final String LINE_SEPARATOR = System.getProperty("line.separator");
    private static final String NULL_TIPS = "Log with null object";
    private static final String TAG = "Realtek";
    private static final String SUFFIX = ".java";
    private static final String PARAM = "Param";
    private static final String NULL = "null";
    public static boolean LOG_ENABLED = true;
    private static boolean bShowLink = false;

    public static final int VERBOSE = 1;
    public static final int DEBUG = 2;
    public static final int INFO = 3;
    public static final int WARN = 4;
    public static final int ERROR = 5;
    public static final int ASSET = 6;

    public static final int NONE = 99;

    private static final int JSON = 7;
    private static final int XML = 8;

    private static int logLevel = VERBOSE;

    public static final String SDKLOG_NAME = "SDKLog";

    private static final boolean writeToFile = true;
    private static Context context;
    /**
     * 是否开启Log日志写入文件
     * 路径：<11--Documlents/WoFit/File/xxxSDKLog.txt
     * >=11--Android/data/com.***\/cache/WoFit/File/xxxSDKLog.txt
     */
    private static boolean isOpenLog = true;

    /**
     * 连接设备时是否验证用户（0---不验证  1---验证）
     */
    private static int isVerifyUser = 1;

    private static String saveDate;

    /**
     * 更新打印日志级别
     *
     * @see SDKLogger#VERBOSE
     * @see SDKLogger#DEBUG
     * @see SDKLogger#INFO
     * @see SDKLogger#WARN
     * @see SDKLogger#ERROR
     * @see SDKLogger#ASSET
     * @see SDKLogger#NONE 不打印日志
     *
     * @param level 日志级别
     */
    public static void updatePrintLogLevel(int level) {
        SDKLogger.logLevel = level;
    }

    public static boolean isIsOpenLog() {
        return isOpenLog;
    }

    public static void setIsOpenLog(boolean isOpenLog) {
        SDKLogger.isOpenLog = isOpenLog;
    }

    public static int getIsVerifyUser() {
        return isVerifyUser;
    }

    public static void setIsVerifyUser(int isVerifyUser) {
        SDKLogger.isVerifyUser = isVerifyUser;
    }

    public static void setContext(Context context) {
        SDKLogger.context = context;
    }

    public SDKLogger() {
    }

    public static void v(String log) {
        printWrapper(LOG_ENABLED, 1, "Realtek", log);
    }

    public static void v(boolean enabled, String log) {
        printWrapper(enabled, 1, "Realtek", log);
    }

    public static void v(boolean enabled, String tag, String log) {
        printWrapper(enabled, 1, tag, log);
    }

    public static void d(String log) {
        printWrapper(LOG_ENABLED, 2, "Realtek", log);
    }

    public static void d(boolean enabled, String log) {
        printWrapper(enabled, 2, "Realtek", log);
    }

    public static void d(boolean enabled, String tag, String log) {
        printWrapper(enabled, 2, tag, log);
    }

    public static void i(String log) {
        printWrapper(LOG_ENABLED, 3, "Realtek", log);
    }

    public static void i(boolean enabled, String log) {
        printWrapper(enabled, 3, "Realtek", log);
    }

    public static void i(boolean enabled, String tag, String log) {
        printWrapper(enabled, 3, tag, log);
    }

    public static void w(String log) {
        printWrapper(LOG_ENABLED, 4, "Realtek", log);
    }

    public static void w(boolean enabled, String log) {
        printWrapper(enabled, 4, "Realtek", log);
    }

    public static void w(boolean enabled, String tag, String log) {
        printWrapper(enabled, 4, tag, log);
    }

    public static void e(String log) {
        printWrapper(LOG_ENABLED, 5, "Realtek", log);
    }

    public static void e(boolean enabled, String log) {
        printWrapper(enabled, 5, "Realtek", log);
    }

    public static void e(boolean enabled, String tag, String log) {
        printWrapper(enabled, 5, tag, log);
    }

    private static void printWrapper(boolean enabled, int level, String tagStr, Object objectMsg) {
        if (enabled) {
            String[] contents = wrapper(tagStr, objectMsg);
            String tag = contents[0];
            String msg = contents[1];
            String headString = contents[2];
            print(level, tag, headString + msg);

            if (isOpenLog) {
                String todayDate = getTodayDate();
                if (!TextUtils.equals(todayDate, saveDate)) {
                    saveDate = todayDate;
                    JWLogger.clearLogAdapters(JWLogger.LOG_TYPE_SDK);
                    String logPath = context.getCacheDir().getAbsolutePath() + "/WoFit/";
                    JWLogger.addLogAdapter(JWLogger.LOG_TYPE_SDK, new DiskLogAdapter(logPath, todayDate + SDKLOG_NAME));
                }
                JWLogger.log(JWLogger.LOG_TYPE_SDK, level, tag,headString + msg, null);

//                FileUtil.appendToFile(context,"\n"+ DateUtil.toTime2(DateUtil.getCurTime())+ " " + headString + msg, getTodayDate() + SDKLOG_NAME);
            }
        }
    }


    public static String getTodayDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(new Date());
    }

    private static void print(int level, String tag, String msg) {
        if (level < logLevel) {
            return;
        }
        switch (level) {
            case 1:
                Log.v(tag, msg);
                break;
            case 2:
                Log.d(tag, msg);
                break;
            case 3:
                Log.i(tag, msg);
                break;
            case 4:
                Log.w(tag, msg);
                break;
            case 5:
                Log.e(tag, msg);
                break;
            case 6:
                Log.wtf(tag, msg);
        }
    }

    private static String getClassName() {
        StackTraceElement traceElement = (new Exception()).getStackTrace()[2];
        String result = traceElement.getClassName();
        int lastIndex = result.lastIndexOf(".");
        result = result.substring(lastIndex + 1, result.length());
        return result;
    }

    private static String callMethodAndLine() {
        if (!bShowLink) {
            return "";
        } else {
            String result = "at ";
            StackTraceElement traceElement = (new Exception()).getStackTrace()[1];
            result = result + traceElement.getClassName() + ".";
            result = result + traceElement.getMethodName();
            result = result + "(" + traceElement.getFileName();
            result = result + ":" + traceElement.getLineNumber() + ")  ";
            return result;
        }
    }

    private static String[] wrapper(String tagStr, Object... objects) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        int index = 5;
        String className = stackTrace[index].getClassName();
        String[] classNameInfo = className.split("\\.");
        if (classNameInfo.length > 0) {
            className = classNameInfo[classNameInfo.length - 1] + ".java";
        }

        if (className.contains("$")) {
            className = className.split("\\$")[0] + ".java";
        }

        String methodName = stackTrace[index].getMethodName();
        int lineNumber = stackTrace[index].getLineNumber();
        if (lineNumber < 0) {
            lineNumber = 0;
        }

        String methodNameShort = methodName.substring(0, 1).toUpperCase() + methodName.substring(1);
        String tag = tagStr == null ? className : tagStr;
        if (TextUtils.isEmpty(tag)) {
            tag = "Realtek";
        }

        String msg = objects == null ? "" : getObjectsString(objects);
        StringBuilder sb = new StringBuilder();
        sb.append("[(").append(className).append(":").append(lineNumber).append(") #").append(methodNameShort).append("] ");
        String headString = sb.toString();
        return new String[]{tag, msg, headString};
    }

    private static String[] wrapper2(String tagStr, Object... objects) {
        StackTraceElement[] stackTrace = (new Throwable()).getStackTrace();
        int index = 5;
        String className = stackTrace[index].getClassName();
        String[] classNameInfo = className.split("\\.");
        if (classNameInfo.length > 0) {
            className = classNameInfo[classNameInfo.length - 1] + ".java";
        }

        if (className.contains("$")) {
            className = className.split("\\$")[0] + ".java";
        }

        String methodName = stackTrace[index].getMethodName();
        int lineNumber = stackTrace[index].getLineNumber();
        if (lineNumber < 0) {
            lineNumber = 0;
        }

        String methodNameShort = methodName.substring(0, 1).toUpperCase() + methodName.substring(1);
        String tag = tagStr == null ? className : tagStr;
        if (TextUtils.isEmpty(tag)) {
            tag = "Realtek";
        }

        String msg = objects == null ? "" : getObjectsString(objects);
        StringBuilder sb = new StringBuilder();
        sb.append("[ (").append(className).append(":").append(lineNumber).append(")#").append(methodNameShort).append(" ]");
        String headString = sb.toString();
        return new String[]{tag, msg, headString};
    }

    private static String getObjectsString(Object... objects) {
        if (objects.length > 1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("\n");

            for (int i = 0; i < objects.length; ++i) {
                Object object = objects[i];
                if (object == null) {
                    stringBuilder.append("Param").append("[").append(i).append("]").append(" = ").append("null").append("\n");
                } else {
                    stringBuilder.append("Param").append("[").append(i).append("]").append(" = ").append(object.toString()).append("\n");
                }
            }

            return stringBuilder.toString();
        } else {
            Object object = objects[0];
            return object == null ? "null" : object.toString();
        }
    }
}
