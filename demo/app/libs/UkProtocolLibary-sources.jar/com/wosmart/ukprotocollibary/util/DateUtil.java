package com.wosmart.ukprotocollibary.util;

import android.text.TextUtils;

import androidx.annotation.NonNull;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;


public class DateUtil {

    private static ThreadLocal<DateFormat> threadLocal = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("yyyy-MM-dd");
        }
    };

    private static ThreadLocal<DateFormat> threadLocal2 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("yyyy.MM.dd");
        }
    };

    private static ThreadLocal<DateFormat> threadLocal3 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("MM-dd");
        }
    };

    private static ThreadLocal<DateFormat> threadLocal4 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("MM.dd");
        }
    };

    private static ThreadLocal<DateFormat> threadLocal5 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("yyyy-MM-dd HH:mm");
        }
    };

    private static ThreadLocal<DateFormat> threadLocal6 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        }
    };

    private static ThreadLocal<DateFormat> threadLocalY = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("yyyy");
        }
    };

    private static ThreadLocal<DateFormat> threadLocal7 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("yyyy-MM");
        }
    };

    private static ThreadLocal<DateFormat> threadLocal8 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("yyyy.MM");
        }
    };

    private static ThreadLocal<DateFormat> threadLocal9 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("MM-dd HH:mm");
        }
    };

    private static ThreadLocal<DateFormat> threadLocal10 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("MM-dd | HH:mm");
        }
    };

    private static ThreadLocal<DateFormat> threadLocal11 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("HH:mm");
        }
    };

    private static ThreadLocal<DateFormat> threadLocal12 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("HH:mm:ss");
        }
    };

    private static ThreadLocal<DateFormat> threadLocalH = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("HH");
        }
    };

    private static ThreadLocal<DateFormat> threadLocalM = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("mm");
        }
    };
    private static ThreadLocal<DateFormat> threadLocal13 = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            return new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
        }
    };

    @NonNull
    private static SimpleDateFormat getSimpleDateFormat() {
        return (SimpleDateFormat) threadLocal.get();
    }

    @NonNull
    private static SimpleDateFormat getSdf2() {
        return (SimpleDateFormat) threadLocal2.get();
    }

    @NonNull
    private static SimpleDateFormat getSdf3() {
        return (SimpleDateFormat) threadLocal3.get();
    }

    @NonNull
    private static SimpleDateFormat getSdf4() {
        return (SimpleDateFormat) threadLocal4.get();
    }

    @NonNull
    private static SimpleDateFormat getSdf5() {
        return (SimpleDateFormat) threadLocal5.get();
    }

    @NonNull
    private static SimpleDateFormat getSdf6() {
        return (SimpleDateFormat) threadLocal6.get();
    }

    @NonNull
    private static SimpleDateFormat getYyyy() {
        return (SimpleDateFormat) threadLocalY.get();
    }

    @NonNull
    private static SimpleDateFormat getSdf7() {
        return (SimpleDateFormat) threadLocal7.get();
    }

    @NonNull
    private static SimpleDateFormat getSdf8() {
        return (SimpleDateFormat) threadLocal8.get();
    }

    @NonNull
    private static SimpleDateFormat getSdf9() {
        return (SimpleDateFormat) threadLocal9.get();
    }

    @NonNull
    private static SimpleDateFormat getSdf10() {
        return (SimpleDateFormat) threadLocal10.get();
    }

    @NonNull
    private static SimpleDateFormat getSdf11() {
        return (SimpleDateFormat) threadLocal11.get();
    }

    @NonNull
    private static SimpleDateFormat getSdf12() {
        return (SimpleDateFormat) threadLocal12.get();
    }

    @NonNull
    private static SimpleDateFormat getHh() {
        return (SimpleDateFormat) threadLocalH.get();
    }

    @NonNull
    private static SimpleDateFormat getMm() {
        return (SimpleDateFormat) threadLocalM.get();
    }

    @NonNull
    private static SimpleDateFormat getSdf13() {
        return (SimpleDateFormat) threadLocal13.get();
    }

    /**
     * 获取今天的日期
     *
     * @return
     */
    public static String getTodayDate() {
        SimpleDateFormat sdf = getSimpleDateFormat();
        return sdf.format(new Date());
    }

    /**
     * 获取今天的日期
     *
     * @return
     */
    public static String getTodayMD() {
        SimpleDateFormat sdf = getSdf3();
        return sdf.format(new Date());
    }


    /**
     * 获取今天的日期
     *
     * @return
     */
    public static String getTodayMD2() {
        SimpleDateFormat sdf = getSdf4();
        return sdf.format(new Date());
    }

    /**
     * 获取某个日期几天前的日期数据
     *
     * @param date
     * @param day
     * @return
     */
    public static String[] getDateByLastDate(String date, int day,String logName) {
        String[] dateString = new String[day+1];
        dateString[0] = getTodayDate()+logName;
        SimpleDateFormat sdf = getSimpleDateFormat();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            for (int i = 1; i <= day; i++) {
                Calendar c = Calendar.getInstance();
                c.clear();
                c.setTime(d);
                c.add(Calendar.DAY_OF_MONTH, -i);
                Date dd = c.getTime();
                dateString[i] = sdf.format(dd)+logName;
            }
        }
        return dateString;
    }


    /**
     * 获取某个日期几天后的日期
     *
     * @param date
     * @param day
     * @return
     */
    public static String getDateByDate(String date, int day) {
        SimpleDateFormat sdf = getSimpleDateFormat();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            Calendar c = Calendar.getInstance();
            c.clear();
            c.setTime(d);
            c.add(Calendar.DAY_OF_MONTH, day);
            d = c.getTime();
            return sdf.format(d);
        }
        return "";
    }

    /**
     * 获取某个日期几天后的日期
     *
     * @param date
     * @param day
     * @return
     */
    public static String getDateByDate2(String date, int day) {
        SimpleDateFormat sdf = getSimpleDateFormat();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            Calendar c = Calendar.getInstance();
            c.clear();
            c.setTime(d);
            c.add(Calendar.DAY_OF_MONTH, day);
            d = c.getTime();
            sdf = getSdf2();
            return sdf.format(d);
        }
        return "";
    }

    /**
     * 获取某个日期几天后的日期
     *
     * @param date
     * @param day
     * @return
     */
    public static String getDateByDate3(String date, int day) {
        SimpleDateFormat sdf = getSdf2();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            Calendar c = Calendar.getInstance();
            c.clear();
            c.setTime(d);
            c.add(Calendar.DAY_OF_MONTH, day);
            d = c.getTime();
            return sdf.format(d);
        }
        return "";
    }

    /**
     * 获取某个日期相差月份的日期
     * @param date 某个日期
     * @param month 相差月份
     * @return
     */
    public static String getDateByMonth(String date, int month) {
        SimpleDateFormat sdf = getSimpleDateFormat();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            Calendar c = Calendar.getInstance();
            c.clear();
            c.setTime(d);
            c.add(Calendar.MONTH, month);
            d = c.getTime();
            return sdf.format(d);
        }
        return "";
    }

    public static String getDateByYear(String date, int year) {
        SimpleDateFormat sdf = getSimpleDateFormat();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            Calendar c = Calendar.getInstance();
            c.clear();
            c.setTime(d);
            c.add(Calendar.YEAR, year);
            d = c.getTime();
            return sdf.format(d);
        }
        return "";
    }

    /**
     * 根据生日  初略计算年龄
     *
     * @param date
     * @return
     */
    public static int getAge(String date) {
        SimpleDateFormat sdf = getSimpleDateFormat();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (null != d) {
            Calendar cal1 = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            cal1.clear();
            cal1.setTimeInMillis(d.getTime());
            int year1 = cal1.get(Calendar.YEAR);
            int year2 = cal2.get(Calendar.YEAR);
            if (year1 > year2) {
                return 0;
            } else {
                return year2 - year1;
            }
        } else {
            return 0;
        }
    }

    /**
     * 获取某个日期几天后的日期
     *
     * @param t
     * @param day
     * @return
     */
    public static String getDateByDate(long t, int day) {
        SimpleDateFormat sdf = getSimpleDateFormat();
        Calendar c = Calendar.getInstance();
        c.clear();
        c.setTimeInMillis(t);
        c.add(Calendar.DAY_OF_MONTH, day);
        Date d = c.getTime();
        return sdf.format(d);

    }

    /**
     * 获取时间的毫秒数
     *
     * @param time 时间
     * @return
     */
    public static long getTime(String time) {
        SimpleDateFormat sdf = getSdf5();
        Date d = null;
        try {
            d = sdf.parse(time);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            return d.getTime();
        } else {
            return 0L;
        }
    }


    /**
     * 获取日期的毫秒数
     *
     * @param date 日期
     * @return
     */
    public static long getDate(String date) {
        SimpleDateFormat sdf = getSimpleDateFormat();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            return d.getTime();
        } else {
            return 0L;
        }
    }

    /**
     * 获取日期的毫秒数
     *
     * @param date 日期
     * @return
     */
    public static long getDate(long date) {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.setTimeInMillis(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        return calendar.getTimeInMillis();
    }

    /**
     * 获取日期的毫秒数
     */
    public static long getDate(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month - 1);
        calendar.set(Calendar.DAY_OF_MONTH, day);
        return calendar.getTimeInMillis();
    }

    /**
     * 获取日期的毫秒数
     *
     * @param date 日期
     * @return
     */
    public static long getDate2(String date) {
        SimpleDateFormat sdf = getSdf2();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            return d.getTime();
        } else {
            return 0L;
        }
    }

    /**
     * 获取日期的毫秒数
     *
     * @param date 日期(格式：yyyy.MM.dd HH:mm:ss)
     * @return
     */
    public static long getDate3(String date) {
        SimpleDateFormat sdf = getSdf13();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            return d.getTime();
        } else {
            return 0L;
        }
    }


    /**
     * 根据毫秒数获取日期
     *
     * @param date
     * @return
     */
    public static String toDate(long date) {
        SimpleDateFormat sdf = getSimpleDateFormat();
        Date d = new Date();
        d.setTime(date);
        return sdf.format(d);
    }

    /**
     * 根据毫秒数获取日期
     *
     * @param date
     * @return
     */
    public static String toDate2(long date) {
        SimpleDateFormat sdf = getSdf2();
        Date d = new Date();
        d.setTime(date);
        return sdf.format(d);
    }

    /**
     * 根据毫秒数获取时间
     *
     * @param time
     * @return
     */
    public static String toTime(long time) {
        SimpleDateFormat sdf = getSdf5();
        Date d = new Date();
        d.setTime(time);
        return sdf.format(d);
    }

    /**
     * 根据毫秒数获取时间
     *
     * @param time
     * @return
     */
    public static String toTime2(long time) {
        SimpleDateFormat sdf = getSdf6();
        Date d = new Date();
        d.setTime(time);
        return sdf.format(d);
    }


    public static int getDayOfWeek(String date) {
        Long t = getDate(date);
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(t);
        cal.setFirstDayOfWeek(Calendar.SUNDAY);
        return cal.get(Calendar.DAY_OF_WEEK);
    }

    public static int getDayOfWeek(long t) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(t);
        cal.setFirstDayOfWeek(Calendar.SUNDAY);
        return cal.get(Calendar.DAY_OF_WEEK);
    }

    /**
     * 获取当前月过去的月份
     * @param i 过去的几个月
     * @return 2021.02
     */
    public static String getLastMonth(int i){
        Date date1 = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(date1);
        c.add(Calendar.MONTH,-i);
        SimpleDateFormat sdf = getSdf8();
        return sdf.format(c.getTime());
    }

    public static int getDayOfMonth(String date) {
        Long t = getDate(date);
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(t);
        cal.setFirstDayOfWeek(Calendar.SUNDAY);
        return cal.get(Calendar.DAY_OF_MONTH);
    }

    public static int getDayOfMonth(long t) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(t);
        cal.setFirstDayOfWeek(Calendar.SUNDAY);
        return cal.get(Calendar.DAY_OF_MONTH);
    }

    public static int getDayOfYear(String date) {
        Long t = getDate(date);
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(t);
        return cal.get(Calendar.DAY_OF_YEAR);
    }

    public static int getDayOfYear(long t) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(t);
        return cal.get(Calendar.DAY_OF_YEAR);
    }

    /**
     * 根据日期获取月份的天数
     * @param date
     * @return
     */
    public static int getDayCountOfMonth(String date) {
        Long t = getDate(date);
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(t);
        cal.setFirstDayOfWeek(Calendar.SUNDAY);
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

    public static int getDayCountOfYear(String date) {
        Long t = getDate(date);
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(t);
        cal.setFirstDayOfWeek(Calendar.SUNDAY);
        return cal.getActualMaximum(Calendar.DAY_OF_YEAR);
    }


    /**
     * 获取周数
     *
     * @param date
     * @return
     */
    public static int getWeekNum(String date) {
        SimpleDateFormat sdf = getSimpleDateFormat();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            Calendar cal = Calendar.getInstance();
            cal.clear();
            cal.setTime(d);
            return cal.get(Calendar.WEEK_OF_YEAR);
        } else {
            return 0;
        }
    }


    public static long getCurTime() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        return cal.getTime().getTime();
    }

    public static long getWeekFirstDay(String date) {
        SimpleDateFormat sdf = getSimpleDateFormat();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            Calendar cal = Calendar.getInstance();
            cal.clear();
            cal.setTime(d);
            //获取周的第一天
            cal.setFirstDayOfWeek(Calendar.SUNDAY);
            cal.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
            return cal.getTime().getTime();
        } else {
            return 0L;
        }
    }

    /**
     * 根据日期获取日期所在周的毫秒数列表
     *
     * @param date
     * @return
     */
    public static List<Long> getWeekDate(String date) {
        SimpleDateFormat sdf = getSimpleDateFormat();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            Calendar cal = Calendar.getInstance();
            cal.clear();
            cal.setTime(d);
            //获取周的第一天
            cal.setFirstDayOfWeek(Calendar.SUNDAY);
            cal.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
            List<Long> ts = new ArrayList<>();
            long t = cal.getTime().getTime();
            long curT = getCurTime();
            if (t <= curT) {
                ts.add(t);
            }
            for (int i = 1; i < 7; i++) {
                cal.add(Calendar.DAY_OF_MONTH, 1);
                long t1 = cal.getTime().getTime();
                if (t1 <= curT) {
                    ts.add(t1);
                }
            }
            return ts;
        } else {
            return null;
        }
    }

    public static long getMonthFirstDay(String date) {
        SimpleDateFormat sdf = getSimpleDateFormat();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            Calendar cal = Calendar.getInstance();
            cal.clear();
            cal.setTime(d);
            //获取月的第一天
            cal.set(Calendar.DAY_OF_MONTH, 1);
            return cal.getTime().getTime();
        } else {
            return 0L;
        }
    }

    public static List<Long> getMonthDate(String date) {
        SimpleDateFormat sdf = getSimpleDateFormat();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            Calendar cal = Calendar.getInstance();
            cal.clear();
            cal.setTime(d);
            //获取月的第一天
            cal.set(Calendar.DAY_OF_MONTH, 1);
            int month = cal.get(Calendar.MONTH);
            List<Long> ts = new ArrayList<>();
            long t = cal.getTime().getTime();
            ts.add(t);
            for (int i = 1; i < 31; i++) {
                cal.add(Calendar.DAY_OF_MONTH, 1);
                int month2 = cal.get(Calendar.MONTH);
                if (month2 != month) {
                    //下个月
                    break;
                } else {
                    long t1 = cal.getTime().getTime();
                    ts.add(t1);
                }
            }
            return ts;
        } else {
            return null;
        }
    }

    public static String formatYear(long t) {
        SimpleDateFormat sdf = getYyyy();
        Date d = new Date();
        d.setTime(t);
        return sdf.format(d);
    }


    public static String formatYM(long t) {
        SimpleDateFormat sdf = getSdf7();
        Date d = new Date();
        d.setTime(t);
        return sdf.format(d);
    }


    public static String formatYM2(long t) {
        SimpleDateFormat sdf = getSdf8();
        Date d = new Date();
        d.setTime(t);
        return sdf.format(d);
    }


    public static String formatDate(long t) {
        SimpleDateFormat sdf = getSdf9();
        Date d = new Date();
        d.setTime(t);
        return sdf.format(d);
    }


    public static String formatMd(long t) {
        SimpleDateFormat sdf = getSdf3();
        Date d = new Date();
        d.setTime(t);
        return sdf.format(d);
    }

    public static String formatMd2(long t) {
        SimpleDateFormat sdf = getSdf4();
        Date d = new Date();
        d.setTime(t);
        return sdf.format(d);
    }

    public static String getMonthDay(String date, int day) {
        SimpleDateFormat sdf = getSimpleDateFormat();
        SimpleDateFormat sdf2 = getSdf4();
        Date d = null;
        try {
            d = sdf.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != d) {
            Calendar c = Calendar.getInstance();
            c.setTime(d);
            c.add(Calendar.DAY_OF_MONTH, day);
            return sdf2.format(c.getTime());
        }
        return "";
    }

    public static String formatLastUpdateTime(long t) {
        SimpleDateFormat sdf = getSdf5();
        Date d = new Date();
        d.setTime(t);
        return sdf.format(d);
    }

    public static String formatMDHM(long t) {
        SimpleDateFormat sdf = getSdf10();
        Date d = new Date();
        d.setTime(t);
        return sdf.format(d);
    }


    public static String formatHm(long t) {
        SimpleDateFormat sdf = getSdf11();
        Date d = new Date();
        d.setTime(t);
        return sdf.format(d);
    }

    public static String formatHms(long t) {
        SimpleDateFormat sdf = getSdf12();
        Date d = new Date();
        d.setTime(t);
        return sdf.format(d);
    }

    public static String formatH(long t) {
        SimpleDateFormat sdf = getHh();
        Date d = new Date();
        d.setTime(t);
        return sdf.format(d);
    }

    public static String formatM(long t) {
        SimpleDateFormat sdf = getMm();
        Date d = new Date();
        d.setTime(t);
        return sdf.format(d);
    }


    public static int getYear(long date) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(date);
        return cal.get(Calendar.YEAR);
    }

    public static int getMonth(long date) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(date);
        return cal.get(Calendar.MONTH) + 1;
    }

    public static int getDay(long date) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(date);
        return cal.get(Calendar.DAY_OF_MONTH);
    }

    public static int getHour(long date) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(date);
        return cal.get(Calendar.HOUR_OF_DAY);
    }

    public static int getMinute(long date) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(date);
        return cal.get(Calendar.MINUTE);
    }

    public static int getSeconds(long date) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(date);
        return cal.get(Calendar.SECOND);
    }

    /**
     * 获取当年的开始时间戳
     *
     * @param timeStamp 毫秒级时间戳
     * @return
     */
    public static Long getYearStartTime(Long timeStamp) {
        Calendar calendar = Calendar.getInstance();// 获取当前日期
        calendar.setTimeInMillis(timeStamp);
        calendar.add(Calendar.YEAR, 0);
        calendar.add(Calendar.DATE, 0);
        calendar.add(Calendar.MONTH, 0);
        calendar.set(Calendar.DAY_OF_YEAR, 1);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTimeInMillis();
    }

    /**
     * 获取当年的最后时间戳
     *
     * @param timeStamp 毫秒级时间戳
     * @return
     */
    public static Long getYearEndTime(Long timeStamp) {
        Calendar calendar = Calendar.getInstance();// 获取当前日期
        calendar.setTimeInMillis(timeStamp);
        int year = calendar.get(Calendar.YEAR);
        calendar.clear();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);
        calendar.roll(Calendar.DAY_OF_YEAR, -1);
        return calendar.getTimeInMillis();
    }

    /**
     * 日期格式转换
     * @param date 2021.03.14
     * @return 2021-03-14
     */
    public static String formatDate(String date){
        if(TextUtils.isEmpty(date)){
            return "";
        }
        return date.replace(".","-");
    }


    /**
     * 获取时区
     *
     * @return 时区 -12到12
     */
    public static int getTimeZone() {
        int result = 0;
        Locale defaultLocal = Locale.getDefault();
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"),
                defaultLocal);
        Date currentLocalTime = calendar.getTime();
        DateFormat date = new SimpleDateFormat("Z", defaultLocal);
        String localTime = date.format(currentLocalTime);
        if (!TextUtils.isEmpty(localTime)) {
            localTime = localTime.toLowerCase(defaultLocal);
            int start_add = localTime.indexOf("+");
            int start_subtract = localTime.indexOf("-");
            if (start_add >= 0) {
                String _short_time = localTime.substring(start_add + 1);
                if (_short_time.length() >= 2) {
                    result = Integer.parseInt(_short_time.substring(0, 2));
                }
            } else if (start_subtract >= 0) {
                String _short_time = localTime.substring(start_subtract + 1);
                if (_short_time.length() >= 2) {
                    result = Integer.parseInt(_short_time.substring(0, 2)) * -1;
                }
            }
        }
        return result;
    }

    public static long getLastSecondOfTheDay(long time) {
        Calendar cal = Calendar.getInstance();

        cal.clear();
        cal.setTimeInMillis(time);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);

        // 获取当天的 0 点时间
        long zeroTime = cal.getTimeInMillis();

        long oneDayTime = 24 * 3600000 - 1000;

        return zeroTime + oneDayTime;
    }
}
