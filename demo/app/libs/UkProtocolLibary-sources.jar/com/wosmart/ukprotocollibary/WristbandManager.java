package com.wosmart.ukprotocollibary;


import static com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayer.DEBUG_LOG_TYPE_MAX_CNT;
import static com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayer.LOGIN_RSP_SUCCESS;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.os.ParcelUuid;
import android.text.TextUtils;
import android.util.SparseArray;

import com.wosmart.ukprotocollibary.util.DataConverter;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayer;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerAddressBookPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerAlarm2Packet;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerAlarmPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerAlarmsPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerBeginPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerBp2ControlPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerBp3ContinuousPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerBpListItemPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerBpListPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerBpPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerCallback;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerCustomNotifyPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerCustomUiPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerDeviceInfoPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerDeviceStatusPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerDisturbPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerECGPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerEarMacPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerEarStatusPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerEcgBeltToDevicePacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerEcgToDevicePacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerFacSensorPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerFunctionPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerGLUPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerHRMovementDataPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerHighHeartRatePacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerHrpItemPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerHrpPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerHrpParamsPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerLogResponsePacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMedicationReminderListPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMulBloodFatPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMulBloodSugarCyclePacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMulDrinkWaterReminderPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMulPrivateBloodFatPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMulPrivateBpPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMulPrivateUricAcidPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMulTemperatureReminderPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMulUricAcidPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMultiSportPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMusicPlayerPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerNotifyPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerPrivateBpPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerPulseDataPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerRateItemPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerRateListPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerReadHealthPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerRecentlySportPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerRtkHrvPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSOSNumberPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSaunaDataPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerScreenStylePacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSitPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSleepAdjustPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSleepPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSleepTimeAdjustPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSpo2Packet;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSportItemPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSportPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerStepItemPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerStepPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSwitchPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSyncSwitchItemPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSyncSwitchPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerTempFunctionPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerTemperatureControlPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerTimerPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerTodayAdjustPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerTodaySleepPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerTodaySportPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerTodaySumSportPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerUnitPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerUserPacket;
import com.wosmart.ukprotocollibary.corespec.BatteryService2;
import com.wosmart.ukprotocollibary.corespec.DebugService;
import com.wosmart.ukprotocollibary.corespec.DfuService;
import com.wosmart.ukprotocollibary.corespec.EcgTestService;
import com.wosmart.ukprotocollibary.corespec.HeartRateService;
import com.wosmart.ukprotocollibary.corespec.ImmediateAlertService2;
import com.wosmart.ukprotocollibary.corespec.LinkLossService2;
import com.wosmart.ukprotocollibary.model.db.GlobalGreenDAO;
import com.wosmart.ukprotocollibary.model.enums.DeviceFunctionStatus;
import com.wosmart.ukprotocollibary.model.enums.DeviceLanguage;
import com.wosmart.ukprotocollibary.model.enums.NotifyType;
import com.wosmart.ukprotocollibary.model.hrp.HrpData;
import com.wosmart.ukprotocollibary.model.sleep.SleepData;
import com.wosmart.ukprotocollibary.model.sport.SportData;
import com.wosmart.ukprotocollibary.model.sport.SportSubData;
import com.wosmart.ukprotocollibary.util.DateStampUtil;
import com.wosmart.ukprotocollibary.util.OldServiceCallback;
import com.wosmart.ukprotocollibary.util.SDKLogger;
import com.wosmart.ukprotocollibary.util.SPWristbandConfigInfo;
import com.wosmart.ukprotocollibary.util.TranslateBpUtil;
import com.wosmart.ukprotocollibary.util.WristbandCalculator;
import com.wosmart.ukprotocollibary.v2.BaseConstants;
import com.wosmart.ukprotocollibary.v2.JWCallback;
import com.wosmart.ukprotocollibary.v2.JWSDKConfig;
import com.wosmart.ukprotocollibary.v2.common.JWBridge;
import com.wosmart.ukprotocollibary.v2.common.JWSDKInfo;
import com.wosmart.ukprotocollibary.v2.common.executor.JWArchTaskExecutor;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodFatInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.UricAcidInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWFemaleHealthInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRMovementInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateVariabilityInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPulseInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSaunaInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSleepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSpO2Info;
import com.wosmart.ukprotocollibary.v2.entity.JWSportInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWStepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSyncDataCounter;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUltravioletInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWearingTimeInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWeatherInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWDefaultFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWHealthRiskAssessmentInfo;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

public class WristbandManager
        implements OldServiceCallback, DfuService.OnServiceListener, HeartRateService.OnServiceListener, DebugService.OnServiceListener, EcgTestService.OnServiceListener {
    // Log
    private final static String TAG = "WristbandManager";

    private final static boolean D = true;

    // Message
    private static final int MSG_STATE_CONNECTED = 0;
    private static final int MSG_STATE_DISCONNECTED = 1;
    private static final int MSG_WRIST_STATE_CHANGED = 2;
    private static final int MSG_RECEIVE_STEP_INFO = 3;
    private static final int MSG_RECEIVE_SLEEP_INFO = 4;
    private static final int MSG_RECEIVE_HISTORY_SYNC_BEGIN = 5;
    private static final int MSG_RECEIVE_HISTORY_SYNC_END = 6;
    private static final int MSG_RECEIVE_ALARMS_INFO = 7;
    private static final int MSG_RECEIVE_NOTIFY_MODE_SETTING = 8;
    private static final int MSG_RECEIVE_LONG_SIT_SETTING = 9;
    private static final int MSG_RECEIVE_FAC_SENSOR_INFO = 10;
    private static final int MSG_RECEIVE_DFU_VERSION_INFO = 11;
    private static final int MSG_RECEIVE_DEVICE_NAME_INFO = 12;
    private static final int MSG_RECEIVE_BATTERY_INFO = 13;
    private static final int MSG_RECEIVE_BATTERY_CHANGE_INFO = 14;
    private static final int MSG_RECEIVE_HRP_INFO = 15;
    private static final int MSG_RECEIVE_TAKE_PHOTO_RSP = 16;
    private static final int MSG_RECEIVE_TURN_OVER_WRIST_SETTING = 17;
    private static final int MSG_RECEIVE_HRP_DEVICE_CANCEL_SINGLE_READ = 18;
    private static final int MSG_RECEIVE_HRP_CONTINUE_PARAM_RSP = 19;
    private static final int MSG_RECEIVER_SPORT_FUNCTION = 20;
    private static final int MSG_RECEIVER_REMINDER_FUNCTION = 21;
    private static final int MSG_RECEIVER_DEVICE_FUNCTION = 22;
    private static final int MSG_RECEIVER_HOUR_SYSTEM = 23;
    private static final int MSG_RECEIVER_UNIT_SYSTEM = 24;
    private static final int MSG_RECEIVER_DISTURB = 25;
    private static final int MSG_RECEIVER_LANGUAGE = 27;
    private static final int MSG_RECEIVER_END_CALL = 28;
    private static final int MSG_RECEIVER_BP_INFO = 29;
    private static final int MSG_RECEIVE_BP_DEVICE_CANCEL_SINGLE_READ = 30;
    private static final int MSG_RECEIVE_SPORT_INFO = 31;
    private static final int MSG_RECEIVE_EAR_ADDRESS = 32;
    private static final int MSG_RECEIVE_EAR_CONNECT_STATUS = 33;
    private static final int MSG_RECEIVE_HOME_PAGER = 34;
    private static final int MSG_RECEIVE_CHARGE_STATUS = 35;
    private static final int MSG_RECEIVE_DEVICE_INFO = 36;
    private static final int MSG_RECEIVE_HRP_PARAMS = 37;
    private static final int MSG_RECEIVE_SCREEN_LIGHT = 38;
    private static final int MSG_RECEIVE_AUTO_LOCK = 39;
    private static final int MSG_RECEIVE_FIND_PHONE = 40;
    private static final int MSG_RECEIVE_TIMER_INFO = 41;
    private static final int MSG_RECEIVE_EAR_STATUS = 42;
    private static final int MSG_SPORT_RATE_STOP = 43;
    private static final int MSG_RATE_LIST = 44;
    private static final int MSG_TODAY_ADJUST = 45;
    private static final int MSG_LANGCO_TRANSLATE = 46;

    private static final int MSG_RECEIVE_LOG_START = 50;
    private static final int MSG_RECEIVE_LOG_END = 51;
    private static final int MSG_RECEIVE_LOG_RSP = 52;


    private static final int MSG_TEMPERATERE_DATA = 53;
    private static final int MSG_TEMPERATURE_LIST = 54;
    private static final int MSG_TEMPERATURE_STATUS = 55;

    private static final int MSG_TEMPERATURE_SETTING = 56;

    private static final int MSG_FAC_TODAY_SLEEP = 57;

    private static final int MSG_HEART_RATE_CHANGE = 58;

    private static final int MSG_DEBUG_DATA_RECEIVE = 59;

    private static final int MSG_HISTORY_INDEX = 60;

    private static final int MSG_BP_LIST = 61;

    private static final int MSG_BP_CONTROL = 62;

    private static final int MSG_MUSIC_PLAY = 63;

    private static final int MSG_MUSIC_PAUSE = 64;

    private static final int MSG_MUSIC_TOGGLE = 65;

    private static final int MSG_MUSIC_PRE = 66;

    private static final int MSG_MUSIC_NEXT = 67;

    private static final int MSG_MUSIC_VOLUME_UP = 68;

    private static final int MSG_MUSIC_VOLUME_DOWN = 69;

    private static final int MSG_SILENCE_UPGRADE_MODEL = 70;

    private static final int MSG_CUSTOM_UI_SETTING = 71;

    private static final int MSG_ALARM2 = 72;

    private static final int MSG_RECEIVER_ACCEPT_CALL = 73;

    private static final int MSG_RECEIVE_DEVICE_STATUS = 74;

    private static final int MSG_RECEIVE_SILENCE_OTA_STATUS = 75;

    private static final int MSG_RECEIVE_CUSTOM_NOTIFY = 76;

    private static final int MSG_SPO2_DATA = 77;

    private static final int MSG_SPO2_STATUS = 78;

    private static final int MSG_CUS_STATUS = 79;

    private static final int MSG_RECEIVE_FIND_PHONE2 = 80;

    private static final int MSG_SPO2_CONTINUOUS_RSP = 81;

    private static final int MSG_BOND_CHIP_TYPE_RSP = 82;

    private static final int MSG_ECG_STATUS_RSP = 83;

    private static final int MSG_ECG_DATA_RSP = 84;

    private static final int MSG_ECG_DATA_RSP_2 = 85;

    private static final int MSG_READ_HEALTH_RSP = 86;

    private static final int MSG_SET_ADDRESS_BOOK_RSP = 87;

    private static final int MSG_RTK_HRV_DATA_RSP = 88;

    private static final int MSG_AUDIO_SWITCH_RSP = 89;

    private static final int MSG_ECG_TO_DEVICE_RSP = 90;

    private static final int MSG_BOND_FAIL_RSP = 91;

    private static final int MSG_BOND_TIMEOUT_RSP = 92;

    private static final int MSG_BOND_CONFIRM_RSP = 93;

    private static final int MSG_CONNECTION_SUCCESS = 94;

    private static final int RESET_CONNECT_DEVICE = 95;

    private static final int CONNECT_TIMEOUT = 96;

    private static final int MSG_SYNC_SWITCH_RSP = 97;

    private static final int MSG_BP3_CONTINUOUS_RSP = 98;

    private static final int MSG_GLU_DATA_RESULT = 110;

    private static final int MSG_GLU_TEST_DIS = 111;

    private static final int MSG_PRIVATE_GLU_RSP = 112;

    private static final int MSG_UNIT_RSP = 113;

    private static final int MSG_SLEEP_ALL_SWITCH = 114;

    private static final int MSG_HYPOXIA_SWITCH = 115;

    private static final int MSG_HIGH_HRV_SWITCH = 116;

    private static final int MSG_DEVICE_DATE_FORMAT = 117;

    private static final int MSG_SET_SOS_NUMBER_RSP = 119;

    private static final int MSG_ERROR = 100;


    public static final int OTA_MODE_MAIN_DISPLAY_RESOURCE = 0;//主显示资源 Main display resource
    public static final int OTA_MODE_DISPLAY_FONT = 1;//显示字库 Display font
    public static final int OTA_MODE_MAIN_FONT_LIBRARIES_INVOLVED_IN_THE_MAIN_INTERFACE = 2;//主界面涉及到的字库 Font libraries involved in the main interface
    public static final int OTA_MODE_CUSTOM_INTERFACE_RESOURCES = 3;//自定义界面资源 Custom interface resources
    public static final int OTA_MODE_DIAL_MARKET_RESOURCES = 4;//表盘市场资源 Dial market resources


    // Wristband state manager
    private int mWristState;
    public static final int STATE_WRIST_INITIAL = 0;
    public static final int STATE_WRIST_LOGING = 91;
    public static final int STATE_WRIST_BONDING = 2;
    public static final int STATE_WRIST_LOGIN = 3;
    public static final int STATE_WRIST_SYNC_DATA = 4;
    public static final int STATE_WRIST_SYNC_HISTORY_DATA = 5;
    public static final int STATE_WRIST_SYNC_LOG_DATA = 6;
    public static final int STATE_WRIST_ENTER_TEST_MODE = 7;

    private boolean mErrorStatus;
    public static final int ERROR_CODE_NO_LOGIN_RESPONSE_COME = 101;
    public static final int ERROR_CODE_BOND_ERROR = 2;
    public static final int ERROR_CODE_COMMAND_SEND_ERROR = 3;

    // Token Key
    private final byte[] TEST_TOKEN_KEY = {(byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01,
            (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01,
            (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01,
            (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01,
            (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01,
            (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01};

    private Context mContext;

    private static volatile WristbandManager mInstance;

    private final Object mRequestResponseLock = new Object();

//    private final int MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME = 65000;
    private final int MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME = 30000;

    private volatile boolean isResponseCome;

    private volatile boolean isNeedWaitForResponse;

    // Use to manager command send transaction
    private volatile boolean isInSendCommand;

    private volatile boolean isCommandSend;

    private volatile boolean isCommandSendOk;

    private final Object mCommandSendLock = new Object();

    private final int MAX_COMMAND_SEND_WAIT_TIME = 20000;

    /**
     * scan
     */
    private BluetoothManager mBluetoothManager;

    private BluetoothAdapter mBluetoothAdapter;

    private BluetoothLeScanner mScanner;

    private ScanSettings mScanSettings;

    private List<ScanFilter> mScanFilters;

    private ScanCallback mScanCallback;

    private BluetoothAdapter.LeScanCallback mLeScanCallback;

    private WristbandScanCallback scanCallback;

    public final static UUID WRISTBAND_SERVICE_UUID = UUID.fromString("000001ff-3c17-d293-8e48-14fe2e4da212");
    public final static UUID FD50_SERVICE_UUID = UUID.fromString("0000fd50-0000-1000-8000-00805f9b34fb");// 涂鸦服务

    public final static UUID ZH_SERVICE_UUID = UUID.fromString("00000001-0000-1000-8000-00805f9b34fb");

    public final static UUID VEP_SERVICE_UUID = UUID.fromString("0000fee7-0000-1000-8000-00805f9b34fb");

    public final static UUID QC_SERVICE_UUID = UUID.fromString("0000fcf8-0000-1000-8000-00805f9b34fb");// 岍丞

    private boolean mScanning;

    private Handler scanHandler;

    private boolean isInSyncDataToService = false;

    private String mDeviceName;

    private String mDeviceAddress;

    private String mUserID = "";

    // Application Layer Object
    private ApplicationLayer mApplicationLayer;

    private ApplicationLayerCallback mApplicationCallback;

    // Extend Service
    private BatteryService2 mBatteryService;

    private ImmediateAlertService2 mImmediateAlertService;

    private LinkLossService2 mLinkLossService;

    private DfuService mDfuService;

    private HeartRateService mHeartRateService;

    private DebugService mDebugService;

    private EcgTestService ecgTestService;

    private boolean isConnected;

    private final Object mLockObject = new Object();

    // object
    private CopyOnWriteArrayList<WristbandManagerCallback> mCallbacks;

    private Map<String, String> deviceMap = new HashMap<>();

    private volatile int mAppVersion = -1;

    private volatile int mPatchVersion = -1;

    // Login response
    private boolean mLoginResponse;

    private boolean mLoginIsConfirm = false;

    private int mLoginResponseStatus;

    // green dao
    private GlobalGreenDAO mGlobalGreenDAO;

    private ApplicationLayerTodaySportPacket stepCountPacket;

    // 设备自带开关，如果设备返回了，上层不要再设置
    private ApplicationLayerSyncSwitchPacket syncSwitchPacket;

    private final ApplicationLayerTempFunctionPacket tempFunctionPacket = new ApplicationLayerTempFunctionPacket();

    private final SparseArray<JWCallback> callbackMap = new SparseArray<>();

    private ApplicationLayerFunctionPacket functionPacket;

    private boolean isInit = false;

    private final JWSyncDataCounter syncDataCounter = new JWSyncDataCounter();

    private JWSDKConfig sdkConfig = new JWSDKConfig();


    public void setStepCountPacket(ApplicationLayerTodaySportPacket stepCountPacket) {
        this.stepCountPacket = stepCountPacket;
    }

    private WristbandManager() {
    }

    private void init(JWSDKConfig config) {
        isInit = true;
        SDKLogger.setContext(mContext);
        SDKLogger.d("init");

//        RealtekSDK.init(mContext);

        GlobalGreenDAO.initial(mContext, config);

        mGlobalGreenDAO = GlobalGreenDAO.getInstance();

        //initial bluetooth manager and callback
        initialScanCallBack();

        mBluetoothManager = (BluetoothManager) mContext.getSystemService(Context.BLUETOOTH_SERVICE);

        mBluetoothAdapter = mBluetoothManager.getAdapter();

        scanHandler = new Handler();

        isConnected = false;

        // initial Wristband Application Layer and register the callback
        initialApplicationCallback();

        mApplicationLayer = new ApplicationLayer(mContext, mApplicationCallback);

        // Initial Callback list
        mCallbacks = new CopyOnWriteArrayList<>();

        // Initial State
        mWristState = STATE_WRIST_INITIAL;
    }

    /**
     * this method was deprecated, please use getInstance(), and use initSDK(Context context) first
     * @see WristbandManager#getInstance()
     */
    @Deprecated
    public static WristbandManager getInstance(Context context) {
        if (null == mInstance) {
            synchronized (WristbandManager.class) {
                if (null == mInstance) {
                    mInstance = new WristbandManager();
                }
            }
        }
        synchronized (WristbandManager.class) {
            if (!mInstance.isInit) {
                mInstance.initSDK(context);
            }
        }
        return mInstance;
    }

    public static WristbandManager getInstance() {
        if (null == mInstance) {
            synchronized (WristbandManager.class) {
                if (null == mInstance) {
                    mInstance = new WristbandManager();
                }
            }
        }
        return mInstance;
    }

    public void initSDK(Context context) {
        this.initSDK(context, new JWSDKConfig());
    }

    public void initSDK(Context context, JWSDKConfig config) {
        this.mContext = context;
        this.sdkConfig = config;
        if (!isInit) {
            init(config);
        }
    }

    public JWSDKConfig getSDKConfig() {
        return this.sdkConfig;
    }

    public static void setManagerInstanceNull() {
        mInstance = null;
    }

    private void initialScanCallBack() {
        if (null == mLeScanCallback) {
            mLeScanCallback = new BluetoothAdapter.LeScanCallback() {

                @SuppressLint("MissingPermission")
                @Override
                public void onLeScan(final BluetoothDevice device, final int rssi, final byte[] scanRecord) {
                    if (!mScanning) {
                        SDKLogger.d(D, "is stop le scan, return");
                        return;
                    }
                    if (null != scanCallback) {
                        if (!TextUtils.isEmpty(device.getAddress())) {
                            deviceMap.put(device.getAddress(), device.getName());
                        }
                        scanCallback.onWristbandDeviceFind(device, rssi, scanRecord);
                    }
                }
            };
        }
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (null == mScanCallback) {
                mScanCallback = new ScanCallback() {

                    @SuppressLint("MissingPermission")
                    @Override
                    public void onScanResult(int callbackType, ScanResult result) {
                        super.onScanResult(callbackType, result);
                        if (!mScanning) {
                            SDKLogger.d(D, "is stop le scan, return");
                            return;
                        }
                        if (null != scanCallback) {
                            if (!TextUtils.isEmpty(result.getDevice().getAddress())) {
                                deviceMap.put(result.getDevice().getAddress().toUpperCase(), result.getDevice().getName());
                            }
                            scanCallback.onWristbandDeviceFind(result.getDevice(), result.getRssi(), result.getScanRecord());
                        }
                    }

                    @Override
                    public void onBatchScanResults(List<ScanResult> results) {
                        super.onBatchScanResults(results);

                        SDKLogger.i("find device result size = " + results.size());
                    }

                    @Override
                    public void onScanFailed(int errorCode) {
                        super.onScanFailed(errorCode);

                        SDKLogger.d(D, "onScanFailed, errorCode = " + errorCode);
                        if (null != scanCallback) {
                            scanCallback.onStopLeScan();
                        }
                    }
                };
            }
        }
    }

    /**
     * when disconnect the remote device should call this function
     * should call it on the main thread
     * 断开连接时，远程设备应调用此函数
     * 应该在主线程上调用它
     */
    public void close() {
        SDKLogger.d(D, "close()");
//        if (mDeviceAddress != null && isConnected) {
//            if (mWristState != STATE_WRIST_INITIAL) {
        // be careful here!!!!
        isConnected = false;

        // close all.
//        if (mBatteryService != null) {
//            mBatteryService.close();
//            mImmediateAlertService.close();
//            mLinkLossService.close();
//            mDfuService.close();
//            mHeartRateService.close();
//            mDebugService.close();
//        }

//        mApplicationLayer.close();
        mApplicationLayer.disconnect();

        mApplicationLayer.deviceFunction = null;

        syncSwitchPacket = null;

        tempFunctionPacket.init();
        callbackMap.clear();

        mUserID = null;
        mDeviceAddress = null;

        // close all wait lock
        synchronized (mRequestResponseLock) {
            isResponseCome = false;
            isNeedWaitForResponse = false;
            mRequestResponseLock.notifyAll();
        }

        synchronized (mCommandSendLock) {
            isCommandSend = false;
            isCommandSendOk = false;
            isInSendCommand = false;
            mCommandSendLock.notifyAll();
        }
        updateWristState(STATE_WRIST_INITIAL);

//           }
//        }
    }


    /**
     * user to check has opened bluetooth
     * 判断用户是否打开蓝牙
     *
     * @return
     */
    @SuppressLint("MissingPermission")
    public boolean isOpenBt() {
        if (null != mBluetoothAdapter && mBluetoothAdapter.isEnabled()) {
            return true;
        }
        return false;
    }

    /**
     * user to check has opened bluetooth
     * 设置打开蓝牙
     *
     * @return
     */
    @SuppressLint("MissingPermission")
    public boolean openBt() {
        if (null != mBluetoothAdapter && !mBluetoothAdapter.isEnabled()) {
            return mBluetoothAdapter.enable();
        }
        return false;
    }

    /**
     * start scan remote device
     * 开始扫描设备
     *
     * @param front    is front
     * @param callback
     */
    public void startScan(final boolean front, final WristbandScanCallback callback) {
        SDKLogger.d(D, "startScan, front = " + front + ", mScanning = " + mScanning);
//        registerScanCallback(callback);
        int duration = 0;
        if (front) {
            duration = 20000;
        } else {
            duration = 60000;
        }
        this.scanCallback = callback;
        scanLeDevice(true, front);
        scanHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mScanning) {
                    scanLeDevice(false, front);
                }
            }
        }, duration);
    }

    /**
     * 停止扫描设备
     */
    public void stopScan() {
        scanLeDevice(false, true);
    }

    /**
     * scan remote device
     *
     * @param enable true: start scan; false: stop scan.
     */
    @SuppressLint("MissingPermission")
    private void scanLeDevice(boolean enable, boolean front) {
        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            SDKLogger.d(D, "please ensure bluetooth is enabled.");
            mScanning = false;
            if (null != scanCallback) {
                scanCallback.onLeScanEnable(false);

                scanCallback.onCancelLeScan();
            }
            return;
        }

        if (enable) {
//            if (!PermissionUtil.checkSelfPermissions(mContext, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION})) {
//                SDKLogger.d(D, "Need ACCESS_COARSE_LOCATION or ACCESS_FINE_LOCATION permission to get scan results");
//                mScanning = false;
//                if (null != scanCallback) {
//                    scanCallback.onLeScanEnable(false);
//
//                    scanCallback.onCancelLeScan();
//                }
//                return;
//            }
            // avoid repetition operator
            if (mScanning) {
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    if (null != mScanner) {
                        mScanner.stopScan(mScanCallback);
                    }
                } else {
                    mBluetoothAdapter.stopLeScan(mLeScanCallback);
                }
            }


            boolean isDeepFit = mContext != null && TextUtils.equals(mContext.getPackageName(), "com.hl.deepfit");

            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                if (null == mScanner) {
                    mScanner = mBluetoothAdapter.getBluetoothLeScanner();
                }
                if (front) {
//                    if (null == mScanSettings) {
                    mScanSettings = new ScanSettings.Builder()
                            //前台设置扫描模式为低时延
                            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                            .build();
//                    }
                    /*
                    * setScanMode()
                      SCAN_MODE_LOW_LATENCY：连续不断的扫描，建议使用在前台时扫描使用。但会消耗比较多的电量，扫描结果也会比较快一些。
                    * SCAN_MODE_LOW_POWER：这个是Android默认的扫描模式，耗电量最小，如果扫描不在前台，则强制执行此模式。
                    *                       在这种模式下，Android会扫描0.5s，暂停4.5s
                    * SCAN_MODE_BALANCED：平衡模式，平衡扫描频率和耗电量的关系。
                    *                       在这种模式下，Android会自动扫描2s，暂停3s
                    * SCAN_MODE_OPPORTUNISTIC：这种模式下，只会监听其他APP的扫描结果回调，无法发现你想发现的设备。
                    *
                    * setCallbackType()
                    * 这个属性决定搜索到设备，回调的策略
                    * CALLBACK_TYPE_ALL_MATCHES：每搜索到一个新设备，就会即时回调。
                    * CALLBACK_TYPE_FIRST_MATCH：只有搜索到第一个设备时回调，随后扫描到其他设备不进行回调。
                    * CALLBACK_TYPE_MATCH_LOST：当发现第一个设备后，不再搜索到其他设备时回调。
                    *
                    * setMatchMode()--这个属性如果定义，搜索"match"到一个设备
                    * MATCH_MODE_AGGRESSIVE：即使信号微弱，也能匹配到设备。
                    * MATCH_MODE_STICKY：与MATCH_MODE_AGGRESSIVE相反，需要收到设备比较强大的信号才能搜索到。
                    *
                    * setNumOfMatches()--这个属性控制需要匹配多少设备
                    * MATCH_NUM_ONE_ADVERTISEMENT
                    * MATCH_NUM_FEW_ADVERTISEMENT
                    *
                    * setReportDelay()
                    * 设置扫描结果回调的延时，如果延时时间大于0，Android将会收集搜索结果，并在延时时间到达后通知，这种情况会回调onBatchScanResults方法而不是onScanResult方法。
                    *
                    * */
                } else {
                    mScanSettings = new ScanSettings.Builder()
                            //退到后台时设置扫描模式为低能耗
                            .setScanMode(ScanSettings.SCAN_MODE_LOW_POWER)
                            .build();
                }
                //过滤扫描蓝牙设备的主服务
                if (null == mScanFilters) {
                    mScanFilters = new ArrayList<>();
                    //uk
                    mScanFilters.add(new ScanFilter.Builder()
                            .setServiceUuid(ParcelUuid.fromString(WRISTBAND_SERVICE_UUID.toString()))
                            .build());
                    mScanFilters.add(new ScanFilter.Builder()
                            .setServiceUuid(ParcelUuid.fromString(FD50_SERVICE_UUID.toString()))
                            .build());
                    //zh
                    mScanFilters.add(new ScanFilter.Builder()
                            .setServiceUuid(ParcelUuid.fromString(ZH_SERVICE_UUID.toString()))
                            .build());

                    if (!isDeepFit) {
                        //vep
                        mScanFilters.add(new ScanFilter.Builder()
                            .setServiceUuid(ParcelUuid.fromString(VEP_SERVICE_UUID.toString()))
                            .build());
                        //qc
                        mScanFilters.add(new ScanFilter.Builder()
                                .setServiceUuid(ParcelUuid.fromString(QC_SERVICE_UUID.toString()))
                                .build());
                    }

                }
                mScanner.startScan(mScanFilters, mScanSettings, mScanCallback);
            } else {
                //通过特定的service UUID搜索设备
                UUID[] serviceUUIDs;
                if (isDeepFit) {
                    serviceUUIDs = new UUID[]{WRISTBAND_SERVICE_UUID, FD50_SERVICE_UUID, ZH_SERVICE_UUID};
                } else {
                    serviceUUIDs = new UUID[]{WRISTBAND_SERVICE_UUID, FD50_SERVICE_UUID, ZH_SERVICE_UUID, VEP_SERVICE_UUID, QC_SERVICE_UUID};
                }
                mBluetoothAdapter.startLeScan(serviceUUIDs, mLeScanCallback);

            }
            mScanning = enable;
            if (null != scanCallback) {
                scanCallback.onLeScanEnable(enable);

                scanCallback.onStartLeScan();
            }
        } else {
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                if (null != mScanner) {
                    mScanner.stopScan(mScanCallback);
                }
            } else {
                mBluetoothAdapter.stopLeScan(mLeScanCallback);
            }

            mScanning = false;
            if (null != scanCallback) {
                scanCallback.onLeScanEnable(false);

                SDKLogger.d(D, "onStopLeScan, enable = " + false);
                scanCallback.onStopLeScan();
            }
        }
    }

    /**
     * check remote device connect status
     * 检查远程设备连接状态
     *
     * @return
     */
    public boolean isConnect() {
        return isConnected;
    }


    /**
     * get current remote device mac address
     * 获取当前设备mac地址
     *
     * @return
     */
    public String getBluetoothAddress() {
        return mDeviceAddress;
    }

    /**
     * register operate callback
     * 注册设备连接回调
     *
     * @param callback
     */
    public void registerCallback(WristbandManagerCallback callback) {
        synchronized (mLockObject) {
            if (!mCallbacks.contains(callback)) {
                mCallbacks.add(callback);
            }
        }
    }

    /**
     * check has registered operate callback
     * 检查设备连接回调
     *
     * @param callback
     * @return
     */
    public boolean isCallbackRegistered(WristbandManagerCallback callback) {
        boolean isCon;
        synchronized (mLockObject) {
            isCon = mCallbacks.contains(callback);
        }
        return isCon;
    }

    /**
     * un registered option callback
     * 删除设备连接回调
     *
     * @param callback
     */
    public void unRegisterCallback(WristbandManagerCallback callback) {
        synchronized (mLockObject) {
            mCallbacks.remove(callback);
        }
    }


    /**
     * Connect to the remote device.
     * 连接远程设备
     *
     * @param address remote device mac address
     */
    public void connect(String address) {
        SDKLogger.d(D, "WristbandManager connect to: " + address);
        if (TextUtils.isEmpty(address)) {
            return;
        }
        address = address.toUpperCase();

        String deviceName = "";
        if (deviceMap.containsKey(address)) {
            deviceName = deviceMap.get(address);
            SPWristbandConfigInfo.setInfoKeyValue(mContext, SPWristbandConfigInfo.SP_KEY_DEVICE_NAME, deviceName);
        } else {
            // 如果没有的话去本地获取上次链接的设备
            deviceName = SPWristbandConfigInfo.getInfoKeyValue(mContext, SPWristbandConfigInfo.SP_KEY_DEVICE_NAME);
        }
        String deviceInfo = SPWristbandConfigInfo.getInfoKeyValue(mContext, SPWristbandConfigInfo.SP_KEY_DEVICE_INFO);
        SDKLogger.d(D, "WristbandManager Connect to: " + address + ", name = " + deviceName + ", deviceInfo = " + deviceInfo);
        // register callback
//        registerCallback(callback);

        // connect to the device
        mDeviceAddress = address;
        mApplicationLayer.connect(address);

        syncSwitchPacket = null;

        tempFunctionPacket.init();
        callbackMap.clear();

        // Add first initial flag

        // close all.
        if (mBatteryService != null) {
            mBatteryService.close();
            mImmediateAlertService.close();
            mLinkLossService.close();
            mDfuService.close();
            mHeartRateService.close();
            mDebugService.close();
            ecgTestService.close();
        }

        // Extend service
//        if (null == mBatteryService) {
        mBatteryService = new BatteryService2(mDeviceAddress, this);
//        }
        mBatteryService.initial();
//        if (null == mImmediateAlertService) {
        mImmediateAlertService = new ImmediateAlertService2(mDeviceAddress);
//        }
        mImmediateAlertService.initial();
//        if (null == mLinkLossService) {
        mLinkLossService = new LinkLossService2(mDeviceAddress, this);
//        }
        mLinkLossService.initial();
//        if (null == mDfuService) {
        mDfuService = new DfuService(mDeviceAddress, this);
//        }
        mDfuService.initial();
//        if (null == mHeartRateService) {
        mHeartRateService = new HeartRateService(mDeviceAddress, this);
//        }
        mHeartRateService.initial();
//        if (null == mDebugService) {
        mDebugService = new DebugService(mDeviceAddress, this);
//        }
        mDebugService.initial();

        ecgTestService = new EcgTestService(mDeviceAddress, this);
        ecgTestService.initial();

//        if(null != mHandler) {
//            mHandler.removeMessages(CONNECT_TIMEOUT);
//            mHandler.sendEmptyMessageDelayed(CONNECT_TIMEOUT,20000);
//        }

        SDKLogger.d(D, "WristbandManager service init() ");

    }

    /**
     * start login
     * 开始登录
     *
     * @param id user id
     */
    public void startLoginProcess(final String id) {
        SDKLogger.d(D,"AAAAA startLoginProcess");
        SPWristbandConfigInfo.setUserId(mContext, id);
        mUserID = id;
        new Thread(new Runnable() {
            @Override
            public void run() {
                // update state
                updateWristState(STATE_WRIST_LOGING);

                // Enable battery notification
                enableBatteryNotification(true);

                // Request to login
                if (!requestLogin(id)) {
                    SDKLogger.d(D,"登录失败");
                    if (!mErrorStatus) {
                        // update state
                        updateWristState(STATE_WRIST_BONDING);
                        // Request to bond
                        if(mLoginIsConfirm){
                            updateWristState(STATE_WRIST_LOGIN);
                            return;
                        }
                        if (requestBond(id)) {
                            SDKLogger.d(D,"绑定成功 initFlag=");
                            // do all the setting work.
                            sendMessage(MSG_CONNECTION_SUCCESS, null, -1, -1);
                            setDataSync(false);
                            if (requestSetNeedInfoTemp()) {
                                // update state
                                updateWristState(STATE_WRIST_LOGIN);
                            }
                        } else {
                            SDKLogger.d(D, "绑定失败 Something error in bond. isResponseCome: " + isResponseCome);
                            // some thing error
                            if (isResponseCome) {
                                if (SDKLogger.getIsVerifyUser() == 1) {
                                    sendErrorMessage(ERROR_CODE_BOND_ERROR);
                                } else {
                                    sendMessage(MSG_CONNECTION_SUCCESS, null, -1, -1);
                                    setDataSync(false);
                                    if (requestSetNeedInfoTemp()) {
                                        // update state
                                        updateWristState(STATE_WRIST_LOGIN);
                                    }
                                }
                            } else {
                                sendErrorMessage(ERROR_CODE_NO_LOGIN_RESPONSE_COME);
                            }
                            return;
                        }
                    } else {
                        // some thing error
                        sendErrorMessage(ERROR_CODE_NO_LOGIN_RESPONSE_COME);
                        SDKLogger.d(D, "long time no login response, do disconnect");
                        return;
                    }
                } else {
                    SDKLogger.d(D,"登录成功，mLoginResponseStatus = " + mLoginResponseStatus);
                    if (mLoginResponseStatus == LOGIN_RSP_SUCCESS) {
                        sendMessage(MSG_CONNECTION_SUCCESS, null, -1, -1);
                        if (requestSetNeedInfoTemp()) {
                            // update state
                            updateWristState(STATE_WRIST_LOGIN);
                        }
                    }
                }
            }
        }).start();

    }

    /**
     * sync saved notify setting to the remote device
     * 将保存的通知设置同步到远程设备
     *
     * @return operate result
     * 0
     */
    private boolean syncNotifySetting() {
        // initial error status
        mErrorStatus = false;
        isResponseCome = false;
        if (sendNotifyModeRequest()) {
            // wait for a while the remote response
            synchronized (mRequestResponseLock) {
                if (!isResponseCome) {
                    try {
                        // wait a while
                        SDKLogger.d(D, "wait the notify setting response come, wait for: " + MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME + "ms");
                        mRequestResponseLock.wait(MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }

            if (!isResponseCome) {
                SDKLogger.d(D, "wait the notify setting response come failed");

                mErrorStatus = true;
                return false;
            }

            // initial error status
            mErrorStatus = false;
            isResponseCome = false;
            if (sendLongSitRequest()) {
                // wait for a while the remote response
                synchronized (mRequestResponseLock) {
                    if (!isResponseCome) {
                        try {
                            // wait a while
                            SDKLogger.d(D, "wait the long sit setting response come, wait for: " + MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME + "ms");
                            mRequestResponseLock.wait(MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME);
                        } catch (InterruptedException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                }
                if (!isResponseCome) {
                    SDKLogger.d(D, "wait the long sit setting response come failed");
                    mErrorStatus = true;
                    return false;
                }
                return true;
            }
        }
        return false;
    }

    /**
     * sync long sit reminder information to the remote device
     * 将长坐提醒信息同步到远程设备
     *
     * @return
     * 0
     */
    public boolean requestSendLongSitRequestSync() {
        // initial error status
        mErrorStatus = false;
        isResponseCome = false;
        if (sendLongSitRequest()) {
            // wait for a while the remote response
            synchronized (mRequestResponseLock) {
                if (!isResponseCome) {
                    try {
                        // wait a while
                        SDKLogger.d(D, "wait the long sit setting response come, wait for: " + MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME + "ms");
                        mRequestResponseLock.wait(MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
            if (!isResponseCome) {
                SDKLogger.d(D, "wait the long sit setting response come failed");
                mErrorStatus = true;
                return false;
            }
            return true;
        }
        return false;
    }

    /**
     * 在同步完成后设置基础信息
     */
    public void setBaseInfoAfterSync(final boolean isSupportHypoxia, final boolean hypoxiaSwitch,
                                     final boolean isSupportHighHrv, final boolean highHrvSwitch, final int highHrvValue,
                                     final boolean isSupportAllSleep, final boolean allSleepSwitch,
                                     final boolean isSupportDateFormat, final int deviceDateFormat) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                setLongSit();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                setDisturb();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (syncSwitchPacket != null && syncSwitchPacket.getItemPackets() != null) {
                    boolean hasTurnWristSet = false;
                    for (ApplicationLayerSyncSwitchItemPacket itemPacket : syncSwitchPacket.getItemPackets()) {
                        if (itemPacket.getSwitchType() == 9) {
                            // 有转腕亮屏设置，此时不要再主动设置
                            hasTurnWristSet = true;
                            break;
                        }
                    }
                    if (!hasTurnWristSet) {
                        setTurnWrist();
                    }
                } else {
                    setTurnWrist();
                }
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                setAllNotify();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (isSupportHypoxia) {
                    setHypoxiaSwitch(hypoxiaSwitch);
                }
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (isSupportHighHrv) {
                    ApplicationLayerHighHeartRatePacket highHrvPacket = new ApplicationLayerHighHeartRatePacket();
                    highHrvPacket.setOpen(highHrvSwitch);
                    highHrvPacket.setHighHeartRate(highHrvValue);
                    setHighHeartRateSwitch(highHrvPacket);
                }
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (isSupportAllSleep) {
                    setSleepAllSwitch(allSleepSwitch);
                }
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (isSupportDateFormat) {
                    setDeviceDateFormat(deviceDateFormat);
                }
            }
        }).start();
    }

    /**
     * 临时改版方便，只设置 setTimeSync 和 setPhoneOS，其它信息交给上层回调再设置
     */
    private boolean requestSetNeedInfoTemp() {
        return setTimeSync() && setPhoneOS();
    }

    /**
     * set base information to the remote device
     * 设置远程设备的基本信息
     *
     * @return operate result
     */
    private boolean requestSetNeedInfo() {
//        if (setUserProfile()) {
//            if (setTargetStep()) {
        if (setTimeSync()) {
            if (setPhoneOS()) {
//                return true;
//                if (sendSyncTodayStepCommand()) {
//                    if (sendSyncTodayNearlyOffsetStepCommand()) {
//                        if (sendContinueHrpParamRequest()) {

                if (setLongSit()) {
                    if (setDisturb()) {
                        if (setTurnWrist()) {
//                            if (setLightDuration()) {
//                                if (setLightPercent()) {
//                                    if (setHrpParams()) {
                                        if (setAllNotify()) {
//                                            if (setTempConfig()) {
//                                                if (setBpConfig()) {
//                                                    if (settingAutoLock()) {
//                                                        SDKLogger.d(D, "all set is ok!");
                                                        return true;
//                                                    } else {
//                                                        SDKLogger.d(D, "settingAutoLock-->false");
//                                                    }
//                                                } else {
//                                                    SDKLogger.d(D, "setBpConfig-->false");
//                                                }
//                                            } else {
//                                                SDKLogger.d(D, "setTempConfig-->false");
//                                            }
                                        } else {
                                            SDKLogger.d(D, "setAllNotify-->false");
                                        }
//                                    } else {
//                                        SDKLogger.d(D, "setHrpParams-->false");
//                                    }
//                                } else {
//                                    SDKLogger.d(D, "setLightPercent-->false");
//                                }
//                            } else {
//                                SDKLogger.d(D, "setLightDuration-->false");
//                            }
                        } else {
                            SDKLogger.d(D, "setTurnWrist-->false");
                        }
                    } else {
                        SDKLogger.d(D, "setDisturb-->false");
                    }
                } else {
                    SDKLogger.d(D, "setLongSit-->false");
                }

//                    }
//                }
//                }
            }else{
                SDKLogger.d(D, "setPhoneOS-->false");
            }
        }else{
            SDKLogger.d(D, "setTimeSync-->false");
        }
//            }
//        }
        return false;
    }

    /**
     * set base information to the remote device
     * 设置远程设备的基本信息
     *
     * @return operate result
     */
    private boolean requestSetNeedInfo2() {
        if (setTimeSync()) {
            if (setPhoneOS()) {
                return true;
//                if (setLongSit()) {
//                    if (setDisturb()) {
//                        if (setTurnWrist()) {
//                            if (requestTemperatureSetting()) {
//                                if (setBpControlRequest()) {
//                                    return true;
//                                }else{
//                                    SDKLogger.d(D,"setBpControlRequest--false");
//                                }
//                            }else{
//                                SDKLogger.d(D,"requestTemperatureSetting--false");
//                            }
//                        }else{
//                            SDKLogger.d(D,"setTurnWrist--false");
//                        }
//                    }else{
//                        SDKLogger.d(D,"setDisturb--false");
//                    }
//                }else{
//                    SDKLogger.d(D,"setLongSit--false");
//                }
            }else{
                SDKLogger.d(D,"setPhoneOS--false");
            }
        }else{
            SDKLogger.d(D,"setTimeSync--false");
        }
        return false;
    }

    /**
     * set base information to the remote device
     * 设置远程设备的基本信息
     *
     * @return operate result
     */
    private boolean requestSetNeedInfo3() {
//        if (setUserProfile()) {
//            if (setTargetStep()) {
        if (setTimeSync()) {
            if (setPhoneOS()) {
//                if (sendSyncTodayStepCommand()) {
//                    if (sendSyncTodayNearlyOffsetStepCommand()) {
//                        if (sendContinueHrpParamRequest()) {
//                if (setLongSit()) {
//                    if (setDisturb()) {
//                        if (setTurnWrist()) {
//                            if (setLightDuration()) {
//                                if (setLightPercent()) {
//                                    if (setHrpParams()) {
//                                        if (setAllNotify()) {
//                                            if (setTempConfig()) {
//                                                if (setBpConfig()) {
//                                                    if (settingAutoLock()) {
                SDKLogger.d(D, "all set is ok!");
                return true;
//                                                    }
//                                                }
//                                            }
//                                        }
//                                    }
//                                }
//                            }
//                        }
//                    }
//                }
//                    }
//                }
//                }
            }
        }
//            }
//        }
        return false;
    }

    public boolean setEcgCharacteristic(boolean enable) {
        return mApplicationLayer.setEcgCharacteristic(enable);
    }

    /**
     * Use to sync the notify mode
     * 用于同步通知模式
     *
     * @return the operate result
     * 1
     */
    public boolean setNotifyMode(NotifyType type, boolean flag) {
        byte mode;
        switch (type) {
            case CALL:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ON;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_OFF;
                }
                SPWristbandConfigInfo.setNotifyCallFlag(mContext, flag);
                break;
            case QQ:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_QQ;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_QQ;
                }
                SPWristbandConfigInfo.setNotifyQQFlag(mContext, flag);
                break;
            case WECHAT:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_WECHAT;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_WECHAT;
                }
                SPWristbandConfigInfo.setNotifyWechatFlag(mContext, flag);
                break;
            case SMS:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_MESSAGE;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_MESSAGE;
                }
                SPWristbandConfigInfo.setNotifyMessageFlag(mContext, flag);
                break;
            case LINE:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_LINE;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_LINE;
                }
                SPWristbandConfigInfo.setNotifyLineFlag(mContext, flag);
                break;
            case TWITTER:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_TWITTER;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_TWITTER;
                }
                SPWristbandConfigInfo.setNotifyTwitterFlag(mContext, flag);
                break;
            case FACEBOOK:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_FACEBOOK;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_FACEBOOK;
                }
                SPWristbandConfigInfo.setNotifyFacebookFlag(mContext, flag);
                break;
            case MESSENGER:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_MESSENGER;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_MESSENGER;
                }
                SPWristbandConfigInfo.setNotifyMessengerFlag(mContext, flag);
                break;
            case WHATSAPP:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_WHATSAPP;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_WHATSAPP;
                }
                SPWristbandConfigInfo.setNotifyWhatsAppFlag(mContext, flag);
                break;
            case LINKEDIN:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_LINKEDIN;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_LINKEDIN;
                }
                SPWristbandConfigInfo.setNotifyLinkedInFlag(mContext, flag);
                break;
            case INSTAGRAM:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_INSTAGRAM;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_INSTAGRAM;
                }
                SPWristbandConfigInfo.setNotifyInstagramFlag(mContext, flag);
                break;
            case SKYPE:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_SKYPE;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_SKYPE;
                }
                SPWristbandConfigInfo.setNotifySkypeFlag(mContext, flag);
                break;
            case VIBER:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_VIBER;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_VIBER;
                }
                SPWristbandConfigInfo.setNotifyViberFlag(mContext, flag);
                break;
            case KAKAOTALK:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_KAKAOTALK;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_KAKAOTALK;
                }
                SPWristbandConfigInfo.setNotifyKakaoTalkFlag(mContext, flag);
                break;
            case VKONTAKTE:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_VKONTAKTE;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_VKONTAKE;
                }
                SPWristbandConfigInfo.setNotifyVkontakteFlag(mContext, flag);
                break;
            case TIM:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_TIM;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_TIM;
                }
                SPWristbandConfigInfo.setNotifyTimFlag(mContext, flag);
                break;
            case GMAIL:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_GMAIL;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_GMAIL;
                }
                SPWristbandConfigInfo.setNotifyGmailFlag(mContext, flag);
                break;
            case DINGTALK:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_DINGTALK;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_DINGTALK;
                }
                SPWristbandConfigInfo.setNotifyDingTalkFlag(mContext, flag);
                break;
            case WORKWECHAT:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_WORK_WECHAT;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_WORK_WECHAT;
                }
                SPWristbandConfigInfo.setNotifyWorkWechatFlag(mContext, flag);
                break;
            case OTHER:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_OTHER;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_OTHER;
                }
                SPWristbandConfigInfo.setNotifyOtherFlag(mContext, flag);
                break;
            default:
                if (flag) {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_QQ;
                } else {
                    mode = ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_QQ;
                }
                SPWristbandConfigInfo.setNotifyQQFlag(mContext, flag);
                break;
        }
        SDKLogger.d(D, "mode: " + mode);
        initialCommandSend("setNotifyMode");

        // Try to set notify mode
        mApplicationLayer.SettingCmdCallNotifySetting(mode);

        return waitCommandSend();
    }

    /**
     * set notify setting total
     * 设置通知设置总计
     *
     * @param packet notify setting
     * @return operate result
     * 1
     */
    public boolean setAllNotify(ApplicationLayerNotifyPacket packet) {
        SDKLogger.d(D, "setAllNotify: " + packet.toString());
        DeviceFunctionStatus phone = packet.getCall();
        DeviceFunctionStatus sms = packet.getSms();
        DeviceFunctionStatus qq = packet.getQQ();
        DeviceFunctionStatus weChat = packet.getWeChat();
        DeviceFunctionStatus line = packet.getLine();
        DeviceFunctionStatus twitter = packet.getTwitter();
        DeviceFunctionStatus facebook = packet.getFacebook();
        DeviceFunctionStatus messenger = packet.getMessenger();
        DeviceFunctionStatus whatsApp = packet.getWhatsApp();
        DeviceFunctionStatus linkedIn = packet.getLinkedIn();
        DeviceFunctionStatus instagram = packet.getInstagram();
        DeviceFunctionStatus skype = packet.getSkype();
        DeviceFunctionStatus viber = packet.getViber();
        DeviceFunctionStatus kakaoTalk = packet.getKakaoTalk();
        DeviceFunctionStatus vkonTakte = packet.getVkonTakte();
        DeviceFunctionStatus tim = packet.getTim();
        DeviceFunctionStatus gmail = packet.getGmail();
        DeviceFunctionStatus dingTalk = packet.getDingTalk();
        DeviceFunctionStatus workWechat = packet.getWorkWechat();
        DeviceFunctionStatus other = packet.getOther();

        SPWristbandConfigInfo.setNotifyCallFlag(mContext, phone == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyMessageFlag(mContext, sms == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyQQFlag(mContext, qq == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyWechatFlag(mContext, weChat == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyLineFlag(mContext, line == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyTwitterFlag(mContext, twitter == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyFacebookFlag(mContext, facebook == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyMessengerFlag(mContext, messenger == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyWhatsAppFlag(mContext, whatsApp == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyLinkedInFlag(mContext, linkedIn == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyInstagramFlag(mContext, instagram == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifySkypeFlag(mContext, skype == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyViberFlag(mContext, viber == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyKakaoTalkFlag(mContext, kakaoTalk == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyVkontakteFlag(mContext, vkonTakte == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyTimFlag(mContext, tim == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyGmailFlag(mContext, gmail == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyDingTalkFlag(mContext, dingTalk == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyWorkWechatFlag(mContext, workWechat == DeviceFunctionStatus.SUPPORT_OPEN);
        SPWristbandConfigInfo.setNotifyOtherFlag(mContext, other == DeviceFunctionStatus.SUPPORT_OPEN);

        initialCommandSend("setAllNotify");

        mApplicationLayer.SettingCmdNotifySetting(packet);

        return waitCommandSend();
    }

    /**
     * Use to request current notify mode
     * 用于请求当前通知模式
     *
     * @return the operate result
     * 1
     */
    public boolean sendNotifyModeRequest() {
        SDKLogger.d(D, "SendNotifyModeRequest");
        initialCommandSend("SendNotifyModeRequest");
        // Need add this
        isNeedWaitForResponse = false;
        // Try to request notify mode
        mApplicationLayer.SettingCmdRequestNotifySwitchSetting();

        return waitCommandSend();
    }

    /**
     * Use to start/stop data sync.
     * 用于开始/停止数据同步
     *
     * @param enable start or stop data sync.
     * @return the operate result
     */
    public boolean setDataSync(boolean enable) {
        SDKLogger.d(D, "SetDataSync(): " + enable);
		/*
        if(mWristState != STATE_WRIST_LOGIN && mWristState != STATE_WRIST_SYNC_DATA) {
            if(D) SDKLogger.e(TAG, "SetDataSync failed, with error state: " + mWristState);
            return false;
        }
        */

        initialCommandSend("SetDataSync");

        // Try to start/stop data sync
        if (enable) {
            mApplicationLayer.SportDataCmdSyncSetting(ApplicationLayer.SPORT_DATA_SYNC_MODE_ENABLE);
        } else {
            mApplicationLayer.SportDataCmdSyncSetting(ApplicationLayer.SPORT_DATA_SYNC_MODE_DISABLE);
        }

        return waitCommandSend();
    }

    /**
     * when received sync end command ,should sync this command to remote device
     * 将同步结束命令发送到远程设备
     *
     * @return operate result
     */
    public boolean setDataSyncEnd() {
        SDKLogger.d(D, "setDataSyncEnd");
        initialCommandSend("setDataSyncEnd");
        mApplicationLayer.SettingSyncDataEnd();
        return waitCommandSend();
    }

    /**
     * Use to send data request.
     * 用于发送数据请求
     *
     * @return the operate result
     */
    public boolean sendDataRequest() {
        SDKLogger.d(D, "SendDataRequest()");
        SDKLogger.d(D, "sendDataRequest mWristState=" + mWristState);
        if (mWristState != STATE_WRIST_LOGIN && mWristState != STATE_WRIST_SYNC_DATA) {
            SDKLogger.d(D, "with error state: " + mWristState);
            return false;
        }

        syncDataCounter.init();

        initialCommandSend("SendDataRequest");

        isNeedWaitForResponse = false;

        mApplicationLayer.SportDataCmdRequestData();

        //同步过数据
        SPWristbandConfigInfo.setFirstInitialFlag(mContext, true);
        return waitCommandSend();
    }

    /**
     * sync temperature setting by local
     * 按本地同步温度设置
     *
     * @return
     */
    public boolean setTempConfig() {
        boolean measure = SPWristbandConfigInfo.getTempMeasure(mContext);
        boolean adjust = SPWristbandConfigInfo.getTempAdjust(mContext);
        boolean unit = SPWristbandConfigInfo.getTempUnit(mContext);

        ApplicationLayerTemperatureControlPacket packet = new ApplicationLayerTemperatureControlPacket();
        packet.setShow(measure);
        packet.setAdjust(adjust);
        packet.setCelsiusUnit(unit);

        return setTemperatureControl(packet);
    }

    /**
     * sync bp setting by local
     * 按本地同步血压设置
     *
     * @return
     */
    public boolean setBpConfig() {
        boolean measure = SPWristbandConfigInfo.getBpMeasure(mContext);

        ApplicationLayerBp2ControlPacket packet = new ApplicationLayerBp2ControlPacket();
        packet.setOpen(true);

        return setBp2Control(packet);
    }


    /**
     * Use to enable/disable the continue hrp set
     * 用于启用/禁用继续hrp设置
     *
     * @return the operate result
     */
    public boolean setContinueHrp(boolean enable, int interval) {
        SDKLogger.d(D, "enable: " + enable + "interval" + interval);
        SPWristbandConfigInfo.setContinueHrpControl(mContext, enable);
        SPWristbandConfigInfo.setContinueHrpControlInterval(mContext, interval);

        initialCommandSend("setContinueHrp");

        // Try to set long sit
        mApplicationLayer.SportDataCmdHrpContinueSet(enable, interval);

        return waitCommandSend();
    }


    /**
     * use to request remote device support hrp param
     * 用于请求远程设备支持hrp参数
     *
     * @return the operate result
     */
    public boolean sendContinueHrpParamRequest() {
        SDKLogger.d(D, "SendContinueHrpParamRequest");
        initialCommandSend("SendContinueHrpParamRequest");

        // Try to set long sit
        mApplicationLayer.SportDataCmdHrpContinueParamRequest();

        return waitCommandSend();
    }

    /**
     * Use to enable/disable the long sit set
     * 用于启用/禁用转腕亮屏
     *
     * @return the operate result
     */
    public boolean setTurnOverWrist(boolean enable) {
        SDKLogger.d(D, "setTurnOverWrist, enable: " + enable);

        SPWristbandConfigInfo.setControlSwitchTurnOverWrist(mContext, enable);

        initialCommandSend("setTurnOverWrist");
        // Try to set long sit
        mApplicationLayer.SettingCmdTurnOverWristSetting(enable);

        return waitCommandSend();
    }

    /**
     * Use to sync the long sit set
     * 设置久坐提醒
     *
     * @return the operate result
     */
    public boolean setLongSit(ApplicationLayerSitPacket sit) {
        SDKLogger.d(D, "SetLongSit()");
        SPWristbandConfigInfo.setControlSwitchLongSit(mContext, sit.getmEnable());
        SPWristbandConfigInfo.setLongSitStartHour(mContext, sit.getmStartNotifyTime());
        SPWristbandConfigInfo.setLongSitEndHour(mContext, sit.getmStopNotifyTime());
        SPWristbandConfigInfo.setLongSitAlarmTime(mContext, sit.getmNotifyTime());

        initialCommandSend("SetLongSit");

        // Try to set long sit
        mApplicationLayer.SettingCmdLongSitSetting(sit);

        return waitCommandSend();
    }


    /**
     * Use to request current long sit set
     * 请求当前久坐提醒设置
     *
     * @return the operate result
     */
    public boolean sendLongSitRequest() {
        SDKLogger.d(D, "SendLongSitRequest()");
        initialCommandSend("SendLongSitRequest");
        // Need add this
        isNeedWaitForResponse = false;

        // Try to set long sit
        mApplicationLayer.SettingCmdRequestLongSitSetting();

        return waitCommandSend();
    }

    /**
     * Use to request current long sit set
     * 发送转腕亮屏请求
     *
     * @return the operate result
     */
    public boolean sendTurnOverWristRequest() {
        SDKLogger.d(D, "SendTurnOverWristRequest()");
        initialCommandSend("SendTurnOverWristRequest");
        // Need add this
        isNeedWaitForResponse = false;

        // Try to set long sit
        mApplicationLayer.SettingCmdRequestTurnOverWristSetting();

        return waitCommandSend();
    }

    /**
     * Use to sync the user profile, use local info
     * 用于同步用户配置文件，使用本地信息
     *
     * @return the operate result
     */
    private boolean setUserProfile() {
        SDKLogger.d(D, "SetUserProfile()");
        initialCommandSend("SetUserProfile");
        boolean sex = SPWristbandConfigInfo.getGendar(mContext);
        int age = SPWristbandConfigInfo.getAge(mContext);
        int height = SPWristbandConfigInfo.getHeight(mContext);
        int weight = SPWristbandConfigInfo.getWeight(mContext);

        ApplicationLayerUserPacket user = new ApplicationLayerUserPacket(sex, age, height, weight);
        // Try to set user profile
        mApplicationLayer.SettingCmdUserSetting(user);

        return waitCommandSend();
    }

    /**
     * Use to send the user profile
     * 设置用户信息
     * sex 性别 true == man, false == female
     * age 年龄 0 - 127
     * weight 体重 0 - 5120 精确到(accurate to) 0.5kg, 真实体重 65kg，则该参数为 650(if real weight is 65kg, the value is 650)
     * height 身高 0 - 2560 精确到(accurate to) 0.5cm, 真实身高 170cm，则该参数为 1700(if real height is 170cm, the value is 1700)
     *
     * @return the operate result
     * 1
     */
    public boolean setUserProfile(ApplicationLayerUserPacket user) {
        SDKLogger.d(D, "SetUserProfile()");

        if (null != user) {
            initialCommandSend("SetUserProfile");
            SPWristbandConfigInfo.setGender(mContext, user.ismSex());
            SPWristbandConfigInfo.setAge(mContext, user.getmAge());
            SPWristbandConfigInfo.setHeight(mContext, user.getmHeight());
            SPWristbandConfigInfo.setWeight(mContext, user.getmWeight());

            // Try to set user profile
            mApplicationLayer.SettingCmdUserSetting(user);

            return waitCommandSend();
        } else {
            SDKLogger.d(D, "user == null");
            return false;
        }
    }

    /**
     * Use to send the target step, user local info
     * 设置目标步数，使用本地保存信息
     *
     * @return the operate result
     */
    public boolean setTargetStep() {
        initialCommandSend("setTargetStep");

        int step = SPWristbandConfigInfo.getTotalStep(mContext);
        SDKLogger.d(D, "step: " + step);

        // Try to set step
        mApplicationLayer.SettingCmdStepTargetSetting(step);

        return waitCommandSend();
    }

    /**
     * Use to sync the target step
     * 设置目标步数
     *
     * @param step 目标步数, 1000 - 65000
     * @return the operate result
     */
    public boolean setTargetStep(long step) {
        SDKLogger.d(D, "step: " + step);

        SPWristbandConfigInfo.setTotalStep(mContext, (int) step);
        initialCommandSend("setTargetStep");

        // Try to set step
        mApplicationLayer.SettingCmdStepTargetSetting(step);

        return waitCommandSend();
    }


    /**
     * use to sync the target sleep
     * 设置目标睡眠
     *
     * @param sleepMinute minute of all sleep, 90 - 900
     * @return the operate result
     */
    public boolean setTargetSleep(int sleepMinute) {
        SDKLogger.d(D, "setTargetSleep, sleepMinute: " + sleepMinute);
        initialCommandSend("setTargetSleep");

        // Try to set step
        mApplicationLayer.SettingCmdSleepTargetSetting(sleepMinute);

        return waitCommandSend();
    }

    /**
     * use to sync the target sleep
     * 设置目标卡路里
     *
     * @param kCalc kCalc, 100 - 9999
     * @return the operate result
     */
    public boolean setTargetCalc(int kCalc) {
        SDKLogger.d(D, "setTargetCalc, kCalc: " + kCalc);
        initialCommandSend("setTargetCalc");

        // Try to set step
        mApplicationLayer.SettingCmdCalcTargetSetting(kCalc);

        return waitCommandSend();
    }

    /**
     * Use to set the phone os
     * 设置操作系统
     *
     * @return the operate result
     */
    public boolean setPhoneOS() {
        SDKLogger.d(D, "SetPhoneOS");
        initialCommandSend("setPhoneOS");

        // Try to set step
        mApplicationLayer.SettingCmdPhoneOSSetting(ApplicationLayer.PHONE_OS_ANDROID);

        return waitCommandSend();
    }


    /**
     * use to send local long sit reminder setting
     * 用于发送本地久坐提醒设置
     *
     * @return the operate result
     */
    public boolean setLongSit() {
        boolean longSit = SPWristbandConfigInfo.getControlSwitchLongSit(mContext);
        int startHour = SPWristbandConfigInfo.getLongSitStartHour(mContext);
        int endHour = SPWristbandConfigInfo.getLongSitEndHour(mContext);
        int interval = SPWristbandConfigInfo.getLongSitAlarmTime(mContext);
        ApplicationLayerSitPacket sit = new ApplicationLayerSitPacket();
        sit.setmEnable(longSit);
        sit.setmStartNotifyTime(startHour);
        sit.setmStopNotifyTime(endHour);
        sit.setmNotifyTime(interval);
        sit.setmThreshold(200);
        sit.setmDayFlags(ApplicationLayerSitPacket.REPETITION_ALL);
        return setLongSit(sit);
    }

    /**
     * use to send local disturb setting
     * 用于发送本地勿扰模式设置
     *
     * @return the operate result
     */
    public boolean setDisturb() {
        boolean disturb = SPWristbandConfigInfo.getDisturb(mContext);
        int startHour = SPWristbandConfigInfo.getDisturbStartHour(mContext);
        int startMinute = SPWristbandConfigInfo.getDisturbStartMinute(mContext);
        int endHour = SPWristbandConfigInfo.getDisturbEndHour(mContext);
        int endMinute = SPWristbandConfigInfo.getDisturbEndMinute(mContext);
        ApplicationLayerDisturbPacket packet = new ApplicationLayerDisturbPacket(disturb, startHour, startMinute, endHour, endMinute);
        return settingDisturb(packet);
    }

    /**
     * use to send local notify setting
     * 用于发送本地通知设置
     *
     * @return the operate result
     */
    public boolean setAllNotify() {
        boolean phone = SPWristbandConfigInfo.getNotifyCallFlag(mContext);
        boolean qq = SPWristbandConfigInfo.getNotifyQQFlag(mContext);
        boolean weChat = SPWristbandConfigInfo.getNotifyWechatFlag(mContext);
        boolean sms = SPWristbandConfigInfo.getNotifyMessageFlag(mContext);
        boolean line = SPWristbandConfigInfo.getNotifyLineFlag(mContext);
        boolean twitter = SPWristbandConfigInfo.getNotifyTwitterFlag(mContext);
        boolean faceBook = SPWristbandConfigInfo.getNotifyFacebookFlag(mContext);
        boolean messenger = SPWristbandConfigInfo.getNotifyMessengerFlag(mContext);
        boolean whatsApp = SPWristbandConfigInfo.getNotifyWhatsAppFlag(mContext);
        boolean LinkedIn = SPWristbandConfigInfo.getNotifyLinkedInFlag(mContext);
        boolean instagram = SPWristbandConfigInfo.getNotifyInstagramFlag(mContext);
        boolean skype = SPWristbandConfigInfo.getNotifySkypeFlag(mContext);
        boolean viber = SPWristbandConfigInfo.getNotifyViberFlag(mContext);
        boolean kakaoTalk = SPWristbandConfigInfo.getNotifyKakaoTalkFlag(mContext);
        boolean vkontakte = SPWristbandConfigInfo.getNotifyVkontakteFlag(mContext);
        boolean tim = SPWristbandConfigInfo.getNotifyTimFlag(mContext);
        boolean gmail = SPWristbandConfigInfo.getNotifyGmailFlag(mContext);
        boolean dingTalk = SPWristbandConfigInfo.getNotifyDingtalkFlag(mContext);
        boolean workWeChat = SPWristbandConfigInfo.getNotifyWorkWechatFlag(mContext);
        boolean other = SPWristbandConfigInfo.getNotifyOtherFlag(mContext);

        ApplicationLayerNotifyPacket packet = new ApplicationLayerNotifyPacket();
        packet.setCall(phone ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setQQ(qq ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setWeChat(weChat ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setSms(sms ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setLine(line ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setTwitter(twitter ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setFacebook(faceBook ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setMessenger(messenger ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setWhatsApp(whatsApp ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setLinkedIn(LinkedIn ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setInstagram(instagram ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setSkype(skype ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setViber(viber ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setKakaoTalk(kakaoTalk ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setVkonTakte(vkontakte ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setTim(tim ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setGmail(gmail ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setDingTalk(dingTalk ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setWorkWechat(workWeChat ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
        packet.setOther(other ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);

        return setAllNotify(packet);
    }

    /**
     * sync base switch to device by local
     * 设置自动锁屏，使用本地保存信息
     *
     * @return
     */
    public boolean settingAutoLock() {
        int stopWatch = SPWristbandConfigInfo.getStopWatch(mContext);
        int findPhone = SPWristbandConfigInfo.getFindPhone(mContext);
        int autoLock = SPWristbandConfigInfo.getAutoLock(mContext);
        int dualSlide = SPWristbandConfigInfo.getDualSlide(mContext);
        int voiceAssist = SPWristbandConfigInfo.getVoiceAssist(mContext);

        ApplicationLayerSwitchPacket packet = new ApplicationLayerSwitchPacket();
        if (stopWatch == 3) {
            packet.setStopWatch(DeviceFunctionStatus.SUPPORT_OPEN);
        } else if (stopWatch == 1) {
            packet.setStopWatch(DeviceFunctionStatus.SUPPORT_CLOSE);
        } else {
            packet.setStopWatch(DeviceFunctionStatus.UN_SUPPORT);
        }

        if (findPhone == 3) {
            packet.setFindPhone(DeviceFunctionStatus.SUPPORT_OPEN);
        } else if (findPhone == 1) {
            packet.setFindPhone(DeviceFunctionStatus.SUPPORT_CLOSE);
        } else {
            packet.setFindPhone(DeviceFunctionStatus.UN_SUPPORT);
        }

        if (autoLock == 3) {
            packet.setAutoLock(DeviceFunctionStatus.SUPPORT_OPEN);
        } else if (autoLock == 1) {
            packet.setAutoLock(DeviceFunctionStatus.SUPPORT_CLOSE);
        } else {
            packet.setAutoLock(DeviceFunctionStatus.UN_SUPPORT);
        }

        if (dualSlide == 3) {
            packet.setDualSlide(DeviceFunctionStatus.SUPPORT_OPEN);
        } else if (dualSlide == 1) {
            packet.setDualSlide(DeviceFunctionStatus.SUPPORT_CLOSE);
        } else {
            packet.setDualSlide(DeviceFunctionStatus.UN_SUPPORT);
        }

        if (voiceAssist == 3) {
            packet.setVoiceAssistant(DeviceFunctionStatus.SUPPORT_OPEN);
        } else if (voiceAssist == 1) {
            packet.setVoiceAssistant(DeviceFunctionStatus.SUPPORT_CLOSE);
        } else {
            packet.setVoiceAssistant(DeviceFunctionStatus.UN_SUPPORT);
        }

        return settingAutoLock(packet);
    }

    /**
     * use to set hrp setting
     * 设置Hrp设置
     *
     * @return the operate result
     */
    public boolean setHrpParams() {
        boolean isOpen = SPWristbandConfigInfo.getContinueHrpControl(mContext);
        int interval = SPWristbandConfigInfo.getContinueHrpControlInterval(mContext);
        return setContinueHrp(isOpen, interval);
    }

    /**
     * use to set turn wrist light display setting by local
     * 设置转腕亮屏
     *
     * @return
     */
    public boolean setTurnWrist() {
        boolean turnWrist = SPWristbandConfigInfo.getControlSwitchTurnOverWrist(mContext);
        SDKLogger.i(true, "setTurnWrist", String.valueOf(turnWrist));
        return setTurnOverWrist(turnWrist);
    }


    /**
     * use to set screen light percent by local
     * 设置屏幕亮度，使用本地设置信息
     *
     * @return
     */
    public boolean setLightPercent() {
        int percent = SPWristbandConfigInfo.getLightPercent(mContext);
        return settingScreenLight(percent);
    }


    /**
     * use to set screen light duration by local
     * 设置亮屏时间，使用本地设置信息,
     *
     * @return
     */
    public boolean setLightDuration() {
        int duration = SPWristbandConfigInfo.getLightDuration(mContext);
        return settingScreenLightDuration(duration);
    }

    /**
     * Use to set the clocks
     * 设置闹钟
     *
     * @return the operate result
     */
    public boolean setClocks(ApplicationLayerAlarmsPacket alarms) {
        SDKLogger.d(D, "SetClocks()");
        initialCommandSend("SetClocks");

        // Try to set alarms
        mApplicationLayer.SettingCmdAlarmsSetting(alarms);

        return waitCommandSend();
    }


    /**
     * Use to set the clock
     *
     * @return the operate result
     */
    public boolean setClock(ApplicationLayerAlarmPacket alarm) {
        SDKLogger.d(D, "SetClocks()");
        initialCommandSend("SetClocks");
        ApplicationLayerAlarmsPacket alarms = new ApplicationLayerAlarmsPacket();
        alarms.add(alarm);
        // Try to set alarms
        mApplicationLayer.SettingCmdAlarmsSetting(alarms);

        return waitCommandSend();
    }

    /**
     * set alarm2
     * 设置第二版闹钟
     *
     * @param packet
     * @return
     */
    public boolean setAlarm2(ApplicationLayerAlarm2Packet packet) {
        SDKLogger.d(D, "setAlarm2()");
        initialCommandSend("SetClocks");

        // Try to set alarms
        mApplicationLayer.SettingAlarm2(packet);

        return waitCommandSend();
    }

    /**
     * set medication reminder
     * 设置吃药提醒
     */
    public boolean setMedicationReminder(ApplicationLayerMedicationReminderListPacket packet) {
        SDKLogger.d(D, "setMedicationReminder()");
        initialCommandSend("setMedicationReminder");

        mApplicationLayer.setMedicationReminder(packet);

        return waitCommandSend();
    }


    /**
     * Use to sync the clock
     * 同步闹钟请求
     *
     * @return the operate result
     */
    public boolean setClocksSyncRequest() {
        SDKLogger.d(D, "SetClocksSyncRequest()");
        initialCommandSend("SetClocksSyncRequest");

        isNeedWaitForResponse = false;

        mApplicationLayer.SettingCmdRequestAlarmList();

        return waitCommandSend();
    }

    /**
     * Use to request the alarm2 list
     * 请求第二版闹钟列表
     *
     * @return the operate result
     */
    public boolean requestAlarm2() {
        SDKLogger.d(D, "requestAlarm2()");
        initialCommandSend("requestAlarm2");

        mApplicationLayer.RequestAlarm2();

        return waitCommandSend();
    }

    /**
     * get medication reminder
     * 获取吃药提醒设置
     *
     * @return the operate result
     */
    public boolean getMedicationReminder() {
        SDKLogger.d(D, "getMedicationReminder");
        initialCommandSend("getMedicationReminder");

        mApplicationLayer.getMedicationReminder();

        return waitCommandSend();
    }

    /**
     * set audio switch
     * 设置通话音频开关(0-关闭，1-打开)
     *
     * @param switchInt
     * @return
     * 1
     */
    public boolean setAudioSwitch(int switchInt) {
        initialCommandSend("setAudioSwitch");
        mApplicationLayer.SettingAudioSwitch(switchInt);
        return waitCommandSend();
    }

    /**
     * get audio switch
     * 获取通话音频开关(0-关闭，1-打开)
     *
     * @return
     * 1
     */
    public boolean getAudioSwitch() {
        initialCommandSend("getAudioSwitch");
        mApplicationLayer.GetAudioSwitch();
        return waitCommandSend();
    }

    /**
     * Use to sync the time
     * 设置同步时间
     *
     * @return the operate result
     */
    public boolean setTimeSync() {
        SDKLogger.d(D, "SetTimeSync()");
        initialCommandSend("SetTimeSync");

        // Try to set time
        //in nexus9, Calendar's month is not right
        Calendar c1 = Calendar.getInstance();
        SDKLogger.d(D, c1.toString());
        mApplicationLayer.SettingCmdTimeSetting(c1.get(Calendar.YEAR),
                c1.get(Calendar.MONTH) + 1, // here need add 1, because it origin range is 0 - 11;
                c1.get(Calendar.DATE),
                c1.get(Calendar.HOUR_OF_DAY),
                c1.get(Calendar.MINUTE),
                c1.get(Calendar.SECOND));
        return waitCommandSend();
    }

    /**
     * Use to send the call notify info
     *
     * @return the operate result
     */
    public boolean sendCallNotifyInfo() {
        SDKLogger.d(D, "SendCallNotifyInfo");
        initialCommandSend("SendCallNotifyInfo");

        mApplicationLayer.NotifyCmdCallNotifyInfoSetting();

        return waitCommandSend();
    }

    /**
     * 发送呼叫通知信息
     *
     * @param show 呼叫名
     * @return
     */
    public boolean sendCallNotifyInfo(String show) {
        SDKLogger.d(D, "SendCallNotifyInfo");
        initialCommandSend("SendCallNotifyInfo");

        mApplicationLayer.NotifyCmdCallNotifyInfoSetting(show);

        return waitCommandSend();
    }

    /**
     * Use to send the call accept notify info
     * 发送呼叫接听通知信息
     *
     * @return the operate result
     */
    public boolean sendCallAcceptNotifyInfo() {
        SDKLogger.d(D, "SendCallAcceptNotifyInfo");
        initialCommandSend("SendCallAcceptNotifyInfo");

        mApplicationLayer.NotifyCmdCallAcceptNotifyInfoSetting();

        return waitCommandSend();
    }

    /**
     * Use to send the call reject notify info
     * 发送呼叫拒绝接听通知信息
     *
     * @return the operate result
     */
    public boolean sendCallRejectNotifyInfo() {
        SDKLogger.d(D, "SendCallRejectNotifyInfo");
        initialCommandSend("SendCallRejectNotifyInfo");

        mApplicationLayer.NotifyCmdCallRejectNotifyInfoSetting();

        return waitCommandSend();
    }

    /**
     * Use to send the other notify info
     * 发送其他通知信息
     *
     * @return the operate result
     */
    public boolean sendOtherNotifyInfo(NotifyType type) {
        return sendOtherNotifyInfo(type, "");
    }

    /**
     * use to send other notify info
     * 发送其他通知信息
     *
     * @param type notify type 通知类型
     * @param show notify content 通知内容
     * @return operate result
     */
    public boolean sendOtherNotifyInfo(NotifyType type, String show) {
        byte info;
        switch (type) {
            case OTHER:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_OTHER;
                break;
            case QQ:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_QQ;
                break;
            case SMS:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_SMS;
                break;
            case LINE:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_LINE;
                break;
            case SKYPE:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_SKYPE;
                break;
            case VIBER:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_VIBER;
                break;
            case WECHAT:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_WECHAT;
                break;
            case TWITTER:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_TWITTER;
                break;
            case FACEBOOK:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_FACEBOOK;
                break;
            case LINKEDIN:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_LINKEDIN;
                break;
            case WHATSAPP:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_WHATSAPP;
                break;
            case INSTAGRAM:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_INSTAGRAM;
                break;
            case KAKAOTALK:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_KAKAOTALK;
                break;
            case MESSENGER:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_MESSENGER;
                break;
            case VKONTAKTE:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_VKONTAKTE;
                break;
            case TIM:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_TIM;
                break;
            case GMAIL:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_GMAIL;
                break;
            case DINGTALK:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_DINGTALK;
                break;
            case WORKWECHAT:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_WORKWECHAT;
                break;
            default:
                info = ApplicationLayer.OTHER_NOTIFY_INFO_SMS;
                break;
        }
        SDKLogger.d(D, "info: " + info + "; showData: " + show);
        initialCommandSend("sendOtherNotifyInfo");

        mApplicationLayer.NotifyCmdOtherNotifyInfoSetting(info, show);

        return waitCommandSend();
    }

    /**
     * use to request remote device support function
     * 请求远程设备支持功能
     *
     * @return operate result
     * 0
     */
    public boolean sendFunctionReq() {
        SDKLogger.d(D, "sendFunctionReq");
        initialCommandSend("sendFunctionReq");

        mApplicationLayer.SettingCmdRequestDeviceFunctionSetting();

        return waitCommandSend();
    }

    /**
     * Use to send enable fac test mode
     *
     * @return the operate result
     * 0
     */
    private boolean sendEnableFacTest() {
        SDKLogger.d(D, "SendEnableFacTest");
        if (mWristState != STATE_WRIST_INITIAL) {
            return false;
        }
        initialCommandSend("SendEnableFacTest");

        mApplicationLayer.FACCmdEnterTestMode(null);

        return waitCommandSend();
    }

    /**
     * Use to send request today sleep
     * 请求发送今天睡眠
     *
     * @return the operate result
     * 0
     */
    public boolean sendTodaySleepRequest() {
        SDKLogger.d(D, "sendTodaySleepRequest");
        initialCommandSend("sendTodaySleepRequest");

        mApplicationLayer.FACCmdRequestTodaySleep();

        return waitCommandSend();
    }


    /**
     * Use to send enter silence upgrade mode
     * 请求发送升级模式
     * @param model see {@link WristbandManager#OTA_MODE_MAIN_DISPLAY_RESOURCE}
     *                  {@link WristbandManager#OTA_MODE_DISPLAY_FONT}
     *                  {@link WristbandManager#OTA_MODE_MAIN_FONT_LIBRARIES_INVOLVED_IN_THE_MAIN_INTERFACE}
     *                  {@link WristbandManager#OTA_MODE_CUSTOM_INTERFACE_RESOURCES}
     *                  {@link WristbandManager#OTA_MODE_DIAL_MARKET_RESOURCES}
     */
    public boolean sendEnterSilenceModel(int model) {
        SDKLogger.d(D, "sendEnterSilenceModel");
        initialCommandSend("sendEnterSilenceModel");

        mApplicationLayer.FACCmdSetSilenceUpgradeModel(model);

        return waitCommandSend();
    }

    /**
     * Use to send request silence upgrade mode
     * 请求发送升级模式
     *
     * @return the operate result
     */
    public boolean sendRequestSilenceModel() {
        SDKLogger.d(D, "sendRequestSilenceModel");
        initialCommandSend("sendRequestSilenceModel");

        mApplicationLayer.FACCmdRequestSilenceUpgradeModel();

        return waitCommandSend();
    }


    /**
     * Use to send request history data index
     *
     * @return the operate result
     * 0
     */
    public boolean sendHistoryIndexRequest() {
        SDKLogger.d(D, "sendHistoryIndexRequest");
        initialCommandSend("sendHistoryIndexRequest");

        mApplicationLayer.FACCmdRequestHistoryIndex();

        return waitCommandSend();
    }

    /**
     * reset device
     * 恢复出厂设置
     * @return
     * 0
     */
    public boolean sendResetRequest(){
        SDKLogger.d(D, "sendResetRequest");
        initialCommandSend("sendResetRequest");

        mApplicationLayer.FACCmdRequestReset();

        return waitCommandSend();
    }

    /**
     * use to setting device hour system
     * 设置小时制
     *
     * @param is24Model true 24 false 12
     * @return operate result
     * 1
     */
    public boolean setHourSystem(boolean is24Model) {
        SDKLogger.d(D, "setHourSystem");
        SPWristbandConfigInfo.setIs24Hour(mContext, is24Model);

        initialCommandSend("setHourSystem");

        mApplicationLayer.SettingCmdSettingHourSystem(is24Model ? ApplicationLayer.HOUR_24_MODEL : ApplicationLayer.HOUR_12_MODEL);

        return waitCommandSend();
    }

    /**
     * use to request hour system
     *  12/24小时制设置
     * @return
     */
    public boolean sendHourSystemReq() {
        SDKLogger.d(D, "sendHourSystemReq");

        initialCommandSend("sendHourSystemReq");

        mApplicationLayer.SettingCmdRequestHourSystemSetting();

        return waitCommandSend();
    }

    /**
     * use to set device unit system
     * 单位设置
     *
     * @param isMetric true metric system  false english system
     * @return the operate result
     */
    public boolean settingUnitSystem(boolean isMetric) {
        SDKLogger.d(D, "settingUnitSystem isMetric = :" + isMetric);
        SPWristbandConfigInfo.setIsMetricSystem(mContext, isMetric);

        initialCommandSend("settingUnitSystem");

        mApplicationLayer.SettingCmdSettingUnit(isMetric ? ApplicationLayer.UNIT_METRIC_SYSTEM : ApplicationLayer.UNIT_ENGLISH_SYSTEM);

        return waitCommandSend();
    }

    /**
     * use to request unit system
     * 请求发送单位设置
     *
     * @return the operate system
     */
    public boolean sendUnitSystemReq() {
        SDKLogger.d(D, "sendUnitSystemReq ");
        initialCommandSend("sendUnitSystemReq");

        mApplicationLayer.SettingCmdRequestUnit();

        return waitCommandSend();
    }

    /**
     * use to send disturb setting
     * 设置勿扰模式
     *
     * @param packet disturb setting
     * @return the operate result
     */
    public boolean settingDisturb(ApplicationLayerDisturbPacket packet) {
        SDKLogger.d(D, "settingDisturb " + packet.toString());
        SPWristbandConfigInfo.setDisturb(mContext, packet.isOpen());
        SPWristbandConfigInfo.setDisturbStartHour(mContext, packet.getStartHour());
        SPWristbandConfigInfo.setDisturbStartMinute(mContext, packet.getStartMinute());
        SPWristbandConfigInfo.setDisturbEndHour(mContext, packet.getEndHour());
        SPWristbandConfigInfo.setDisturbEndMinute(mContext, packet.getEndMinute());

        initialCommandSend("settingDisturb");

        mApplicationLayer.SettingCmdSettingDisturbSetting(packet);

        return waitCommandSend();
    }

    /**
     * use to request disturb setting
     * 请求发送勿扰模式
     *
     * @return
     */
    public boolean sendDisturbSettingReq() {
        SDKLogger.d(D, "sendDisturbSettingReq ");
        initialCommandSend("sendDisturbSettingReq");

        mApplicationLayer.SettingCmdRequestDisturbSetting();

        return waitCommandSend();
    }

    /**
     * use to setting screen light duration, 0 - 30, unit second
     * 设置亮屏时长，0 - 30，单位 秒
     *
     * @param duration screen light duration
     * @return operate result
     */
    public boolean settingScreenLightDuration(int duration) {
        SDKLogger.d(D, "settingScreenLightDuration duration= " + duration);

        SPWristbandConfigInfo.setLightDuration(mContext, duration);

        initialCommandSend("settingScreenLightDuration");

        mApplicationLayer.SettingCmdSettingScreenLightDuration(duration);

        return waitCommandSend();
    }

    /**
     * use to request screen light duration
     * 请求发送亮屏时长
     *
     * @return operate result
     */
    public boolean sendScreenLightDurationReq() {
        SDKLogger.d(D, "sendScreenLightDurationReq ");
        initialCommandSend("sendScreenLightDurationReq");

        mApplicationLayer.SettingCmdRequestScreenLightDurationSetting();

        return waitCommandSend();
    }

    /**
     * use to setting device language
     * 设置设备语言
     *
     * @param language language type
     * @return operate result
     */
    public boolean settingLanguage(DeviceLanguage language) {
        SDKLogger.d(D, "settingLanguage " + language);
        initialCommandSend("settingLanguage");

        mApplicationLayer.SettingCmdSettingLanguage(language);

        return waitCommandSend();
    }

    /**
     * use to send device language request
     * 请求发送设备语言
     *
     * @return operate result
     */
    public boolean sendDeviceLanguageReq() {
        SDKLogger.d(D, "sendDeviceLanguageReq ");
        initialCommandSend("sendDeviceLanguageReq");

        mApplicationLayer.SettingCmdRequestLanguage();

        return waitCommandSend();
    }


    /**
     * Use to send disable fac test mode
     *
     * @return the operate result
     */
    private boolean sendDisableFacTest() {
        SDKLogger.d(D, "SendDisableFacTest");
        if (mWristState != STATE_WRIST_ENTER_TEST_MODE) {
            return false;
        }
        initialCommandSend("SendDisableFacTest");

        mApplicationLayer.FACCmdExitTestMode(null);

        return waitCommandSend();
    }

    /**
     * Use to send enable led
     *
     * @param led the led want to enable
     * @return the operate result
     */
    private boolean sendEnableFacLed(byte led) {
        SDKLogger.d(D, "SendEnableFacLed");
        initialCommandSend("SendEnableFacLed");

        mApplicationLayer.FACCmdEnableLed(led);

        return waitCommandSend();
    }

    /**
     * Use to send enable vibrate
     *
     * @return the operate result
     */
    private boolean sendEnableFacVibrate() {
        SDKLogger.d(D, "SendEnableFacVibrate");
        initialCommandSend("SendEnableFacVibrate");

        mApplicationLayer.FACCmdEnableVibrate();

        return waitCommandSend();
    }

    public boolean setDefaultFunction(JWDefaultFunctionInfo functionInfo) {
        if (functionInfo == null) {
            return false;
        }
        SDKLogger.d(D, "setDefaultFunction, functionInfo = " + functionInfo);
        initialCommandSend("setDefaultFunction");

        mApplicationLayer.FACCmdSetDefaultFunction(functionInfo);

        return waitCommandSend();
    }

    public boolean readDefaultFunction() {
        SDKLogger.d(D, "readDefaultFunction");
        initialCommandSend("readDefaultFunction");

        mApplicationLayer.FACCmdReadDefaultFunction();

        return waitCommandSend();
    }

    /**
     * Use to send request sensor data
     *
     * @return the operate result
     */
    private boolean sendEnableFacSensorDataRequest() {
        SDKLogger.d(D, "SendEnableFacSensorData");
        initialCommandSend("SendEnableFacSensorData");

        mApplicationLayer.FACCmdRequestSensorData();

        return waitCommandSend();
    }

    /**
     * Use to send open log command
     *
     * @return the operate result
     */
    private boolean sendLogEnableCommand(byte[] keyArray) {
        SDKLogger.d(D, "SendLogEnableCommand");
        initialCommandSend("SendLogEnableCommand");

        mApplicationLayer.LogCmdOpenLog(keyArray);

        return waitCommandSend();
    }

    /**
     * send enable command
     *
     * @return operate result
     */
    private boolean sendLogEnableCommand() {
        int cnt = 0;
        byte[] temp = new byte[DEBUG_LOG_TYPE_MAX_CNT];
        if (SPWristbandConfigInfo.getDebugLogTypeModuleApp(mContext)) {
            temp[cnt] = ApplicationLayer.DEBUG_LOG_TYPE_MODULE_APP;
            cnt++;
        }
        if (SPWristbandConfigInfo.getDebugLogTypeModuleUpperStack(mContext)) {
            temp[cnt] = ApplicationLayer.DEBUG_LOG_TYPE_MODULE_UPSTACK;
            cnt++;
        }
        if (SPWristbandConfigInfo.getDebugLogTypeModuleLowerStack(mContext)) {
            temp[cnt] = ApplicationLayer.DEBUG_LOG_TYPE_MODULE_LOWERSTACK;
            cnt++;
        }
        if (SPWristbandConfigInfo.getDebugLogTypeSleep(mContext)) {
            temp[cnt] = ApplicationLayer.DEBUG_LOG_TYPE_SLEEP_DATA;
            cnt++;
        }
        if (SPWristbandConfigInfo.getDebugLogTypeSport(mContext)) {
            temp[cnt] = ApplicationLayer.DEBUG_LOG_TYPE_SPORT_DATA;
            cnt++;
        }
        if (SPWristbandConfigInfo.getDebugLogTypeConfig(mContext)) {
            temp[cnt] = ApplicationLayer.DEBUG_LOG_TYPE_CONFIG_DATA;
            cnt++;
        }
        if (cnt == 0) {
            SDKLogger.d(D, "No need to enable SDKLogger.");
            return true;
        }
        byte[] keyArray = new byte[cnt];
        System.arraycopy(temp, 0, keyArray, 0, cnt);

        return sendLogEnableCommand(keyArray);
    }

    /**
     * Use to send open log command
     *
     * @return the operate result
     */
    private boolean sendLogCloseCommand() {
        SDKLogger.d(D, "SendLogCloseCommand");
        initialCommandSend("SendLogCloseCommand");

        mApplicationLayer.LogCmdCloseLog();

        return waitCommandSend();
    }

    /**
     * Use to send request log command
     *
     * @return the operate result
     */
    private boolean sendLogRequestCommand(byte key) {
        SDKLogger.d(D, "SendLogRequestCommand");
        initialCommandSend("SendLogRequestCommand");

        mApplicationLayer.LogCmdRequestLog(key);

        return waitCommandSend();
    }

    /**
     * Use to send sync today step command
     * 请求发送同步今天步数（这个方法放到{@link ApplicationLayerCallback#onTodayAdjust}回调中使用）
     *
     * @return the operate result
     */
    public boolean sendSyncTodayNearlyOffsetStepCommand() {
        SDKLogger.d(D, "SendSyncTodayNearlyOffsetStepCommand");
        initialCommandSend("SendSyncTodayNearlyOffsetStepCommand");
        Calendar c1 = Calendar.getInstance();
        List<SportData> sports = mGlobalGreenDAO.loadSportDataByDate(c1.get(Calendar.YEAR),
                c1.get(Calendar.MONTH) + 1,// here need add 1, because it origin range is 0 - 11;
                c1.get(Calendar.DATE));

        SportData subData = WristbandCalculator.getNearlyOffsetStepData(sports);

        ApplicationLayerRecentlySportPacket packet;
        if (subData != null) {
            packet = new ApplicationLayerRecentlySportPacket((byte) (subData.getMode() & 0xff)
                    , subData.getActiveTime()
                    , subData.getCalory()
                    , subData.getStepCount()
                    , subData.getDistance());
        } else {
            packet = new ApplicationLayerRecentlySportPacket((byte) 0x00
                    , 0
                    , 0
                    , 0
                    , 0);
        }
        // Try to sync total step data
        SDKLogger.d(D, "sendSyncTodayNearlyOffsetStepCommand--" + packet.toString());
        mApplicationLayer.SportDataCmdSyncRecently(packet);

        return waitCommandSend();
    }

    /**
     * Use to send today total step request
     * 请求发送今天总步数
     *
     * @return the o`perate result
     */
    public boolean sendTodayAdjustRequest() {
        SDKLogger.d(D, "sendTodayAdjustRequest");
        initialCommandSend("sendTodayAdjustRequest");
        // Try to sync total step data
        mApplicationLayer.SportDataRequestTodayAdjust();

        return waitCommandSend();
    }


    /**
     * 设置睡眠质量
     * set sleep quality
     */
    public boolean settingSleepAdjust(ApplicationLayerSleepAdjustPacket packet) {
        SDKLogger.d(D, "settingSleepAdjust");
        initialCommandSend("settingSleepAdjust");
        // Try to sync total step data
        mApplicationLayer.SettingSleepAdjust(packet);

        return waitCommandSend();
    }

    /**
     * 设置入睡时间清醒时间
     * set fall sleep and wake up for sleep
     */
    public boolean settingSleepTimeAdjust(ApplicationLayerSleepTimeAdjustPacket packet) {
        SDKLogger.d(D, "settingSleepTimeAdjust");
        initialCommandSend("settingSleepTimeAdjust");
        // Try to sync total step data
        mApplicationLayer.SettingSleepTimeAdjust(packet);

        return waitCommandSend();
    }

    /**
     * Use to send remove bond command
     * 请求发送删除绑定命令
     *
     * @return the operate result
     */
    public boolean sendRemoveBondCommand() {
        SDKLogger.d(D, "SendRemoveBondCommand");
        initialCommandSend("SendRemoveBondCommand");

        mApplicationLayer.BondCmdRequestRemoveBond();

        // when send remove bond command, we just think link is lost.
        isConnected = false;
        return waitCommandSend();
    }

    /**
     * Use to send camera control command
     * 请求发送相机控制命令
     *
     * @param enable true /false
     * @return the operate result
     */
    public boolean sendCameraControlCommand(boolean enable) {
        SDKLogger.d(D, "SendRemoveBondCommand, enable: " + enable);
        initialCommandSend("SendRemoveBondCommand");
        mApplicationLayer.ControlCmdCameraControl(
                enable ? ApplicationLayer.CAMERA_CONTROL_APP_IN_FORE : ApplicationLayer.CAMERA_CONTROL_APP_IN_BACK);

        return waitCommandSend();
    }

    /**
     * Use to send sync today step command
     * 请求发送同步今天步数命令
     *
     * @return the operate result
     */
    public boolean sendSyncTodayStepCommand() {
        ApplicationLayerTodaySportPacket packet;
        ApplicationLayerTodaySportPacket localPacket;
        Calendar c1 = Calendar.getInstance();
        List<SportData> sports = mGlobalGreenDAO.loadSportDataByDate(c1.get(Calendar.YEAR),
                c1.get(Calendar.MONTH) + 1,// here need add 1, because it origin range is 0 - 11;
                c1.get(Calendar.DATE));

        SportSubData subData = WristbandCalculator.sumOfSportDataByDate(c1.get(Calendar.YEAR),
                c1.get(Calendar.MONTH) + 1,// here need add 1, because it origin range is 0 - 11;
                c1.get(Calendar.DATE),
                sports);
        if (null != sports && sports.size() > 0) {
            SDKLogger.d(D, "sendSyncTodayStepCommand--sports.size=" + sports.size() + "\tcalendar=" + c1.toString());
        } else {
            SDKLogger.d(D, "sendSyncTodayStepCommand--sports = null" + "\tcalendar=" + c1.toString());
        }
        if (subData != null) {
            SDKLogger.d(D, "sendSyncTodayStepCommand--subData = " + subData.toString());
            localPacket = new ApplicationLayerTodaySportPacket((long) subData.getStepCount()
                    , (long) subData.getDistance()
                    , (long) subData.getCalory());
        } else {
            SDKLogger.d(D, "sendSyncTodayStepCommand--subData = null");
            localPacket = new ApplicationLayerTodaySportPacket(0
                    , 0
                    , 0);
        }
        if (null == stepCountPacket) {
            packet = localPacket;
        } else {
            if (localPacket.getmStepTarget() > stepCountPacket.getmStepTarget()) {
                packet = localPacket;
            } else {
                packet = stepCountPacket;
            }
        }
        if (null == packet) {
            SDKLogger.d(D, "sendSyncTodayStepCommand--stepCountPacket = null");
        } else {
            SDKLogger.d(D, "sendSyncTodayStepCommand--stepCountPacket = " + packet.toString());
        }
        // Try to sync total step data
        return sendSyncTodayStepCommand(packet);
    }

    /**
     * Use to send sync today step command
     * 请求发送同步今天步数命令
     *
     * @return the operate result
     */
    public boolean sendSyncTodayStepCommand(long step, long distance, long calory) {
        ApplicationLayerTodaySportPacket localPacket = new ApplicationLayerTodaySportPacket(step,distance,calory);
        return sendSyncTodayStepCommand(localPacket);
    }


    /**
     * use to send sync toay step command
     * 请求发送同步今天步数
     *
     * @param packet
     * @return
     */
    public boolean sendSyncTodayStepCommand(ApplicationLayerTodaySportPacket packet) {
        SDKLogger.d(D, "SendSyncTodayStepCommand");
        initialCommandSend("SendSyncTodayStepCommand");

        mApplicationLayer.SportDataCmdSyncToday(packet);
        SDKLogger.d(D, "sendSyncTodayStepCommand--" + packet.toString());
        return waitCommandSend();
    }

    /**
     * check is sending command
     * 检查正在发送命令
     *
     * @return is sending result
     */
    public boolean isInSendCommand() {
        return this.isInSendCommand;
    }

    private int sendIndent = 0;

    private long lastLogTime = 0;

    /**
     * initial send command
     * 初始化发送命令
     *
     * @return operate result
     */
    private boolean initialCommandSend(String methodName) {
        SDKLogger.d(D, "initialCommandSend, methodName = " + methodName + ", isInSendCommand = " + isInSendCommand + ", isNeedWaitForResponse = " + isNeedWaitForResponse);

        while (isInSendCommand || isNeedWaitForResponse) {
            if (!isConnect()) {
                SDKLogger.d(D, "isConnect = false");
                return false;
            }
            long curTime = System.currentTimeMillis();
            if (curTime - lastLogTime > 5000) {
                // 小于 5 秒内的都不打印
                SDKLogger.d(D, "Wait for last command send ok. isInSendCommand: " + isInSendCommand + ", isNeedWaitForResponse: " + isNeedWaitForResponse);
            }
            lastLogTime = curTime;

            if (sendIndent == 0) {
                sendIndent = 1;
                Message message = new Message();
                message.what = MSG_ERROR;
                message.obj = ERROR_CODE_COMMAND_SEND_ERROR;
                mHandler.sendMessageDelayed(message, 10000);
                SDKLogger.d(D, "sendMessage-->msg_error:" + MSG_ERROR + "\tsendIndent=" + sendIndent);
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        synchronized (mCommandSendLock) {
            // initial status
            mErrorStatus = false;
            isCommandSend = false;
            isCommandSendOk = false;

            isInSendCommand = true;
        }

        SDKLogger.d(D, "initialCommandSend end, methodName = " + methodName);
        return true;
    }

    /**
     * wait command send finish
     * 等待命令发送完成
     *
     * @return operate result
     */
    private boolean waitCommandSend() {
//        if (BuildConfig.DEBUG) {
//            return true;
//        }
        sendIndent = 0;
        mHandler.removeMessages(MSG_ERROR);
        SDKLogger.d(D, "waitCommandSend()-->removeMessage:msg_error\tsendIndent=" + sendIndent);

        //不验证发送蓝牙命令成功
//        isInSendCommand = false;
//        return true;
        boolean commandSendReady = false;
        synchronized (mCommandSendLock) {
            if (!isCommandSend) {
                try {
                    // wait a while
                    SDKLogger.d(D, "wait the time set callback, wait for: " + MAX_COMMAND_SEND_WAIT_TIME + "ms");
                    mCommandSendLock.wait(MAX_COMMAND_SEND_WAIT_TIME);

                    SDKLogger.d(D, "isCommandSendOk=" + isCommandSendOk + ", isInSendCommand=" + isInSendCommand);
                    isInSendCommand = false;

                    commandSendReady = isCommandSendOk;
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
        return commandSendReady;
    }

    /**
     * Request Login
     * 请求登录
     *
     * @return the login result, fail or success
     * @id the user id
     */
    public boolean requestLogin(String id) {
        SDKLogger.d(D, "id: " + id);
        // initial error status
        mErrorStatus = false;
        isResponseCome = false;
        mLoginResponse = false;
        mLoginIsConfirm = false;
        mLoginResponseStatus = LOGIN_RSP_SUCCESS;


        // Try to login
        mApplicationLayer.BondCmdRequestLogin(id);// it will wait the onBondCmdRequestLogin callback invoke.

        synchronized (mRequestResponseLock) {
            if (!isResponseCome) {
                try {
                    // wait a while
                    SDKLogger.d(D, "wait the login response come, wait for: " + MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME + "ms");
                    mRequestResponseLock.wait(MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

        if (!isResponseCome) {
            mErrorStatus = true;
            return false;
        }

        if (mLoginResponse) {
            setDataSync(false);
        }

        if (isResponseCome && (mLoginResponseStatus == ApplicationLayer.LOGIN_LOSS_LOGIN_INFO)) {
            //
            SDKLogger.d(D, "Be-careful, may be last connection loss sync info, do again.");
//            if (!initFlag) {
//                requestSetNeedInfo2();
//                // update state
//                updateWristState(STATE_WRIST_LOGIN);
//            } else {
//                requestSetNeedInfo();
//                // update state
//                updateWristState(STATE_WRIST_LOGIN);
//            }

//            requestSetNeedInfo();
//            // update state
//            updateWristState(STATE_WRIST_LOGIN);
        }
        return mLoginResponse;
    }

    // Login response
    private boolean mBondResponse;


    /**
     * Request Bond
     * 请求绑定
     *
     * @return the bond result, fail or success
     * @id the user id
     */
    private boolean requestBond(String id) {
        SDKLogger.d(D, "id: " + id);
        // initial error status
        mErrorStatus = false;
        isResponseCome = false;
        mBondResponse = false;

        // Try to login
        mApplicationLayer.BondCmdRequestBond(id);// it will wait the onBondCmdRequestLogin callback invoke.

        synchronized (mRequestResponseLock) {
            if (!isResponseCome) {
                try {
                    // wait a while
                    SDKLogger.d(D, "wait the bond response come, wait for: " + MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME + "ms");
                    mRequestResponseLock.wait(MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

        if (!isResponseCome) {
            mErrorStatus = true;
            return false;
        }
        return mBondResponse;
    }

    public boolean isReady() {
        SDKLogger.d(D, "mWristState: " + mWristState);
        return mWristState == STATE_WRIST_SYNC_DATA;
    }

    private void requestConfirmBond(String id) {
        SDKLogger.d(D, "id: " + id);
        mApplicationLayer.BondConfirmRequestBond(id);
    }

    /**
     * Use to set the remote Immediate Alert Level
     * 用于设置远程即时警报级别
     *
     * @param enable enable/disable Immediate Alert
     */
    public boolean enableImmediateAlert(boolean enable) {
        initialCommandSend("enableImmediateAlert");
        boolean result = mImmediateAlertService.setAlertLevelEnabled(mDeviceAddress, enable);
        isInSendCommand = false;
        return result;
    }

    /**
     * Use to set the remote Link Loss Alert Level
     *
     * @param enable enable/disable Link Loss Alert
     */
    private boolean enableLinkLossAlert(boolean enable) {
        initialCommandSend("enableLinkLossAlert");
        boolean result = mLinkLossService.setAlertEnabled(enable);
        isInSendCommand = false;
        return result;
    }

    /**
     * Use to read the remote Battery Level
     * 读取设备电池电量
     *
     * @return operate result
     */
    public boolean readBatteryLevel() {
        SDKLogger.d(D, "readBatteryLevel");
        if (mBatteryService != null) {
            boolean result = mBatteryService.readBatteryLevel();
            SDKLogger.d(D, "result = " + result);
            return result;
        } else {
            SDKLogger.d(D, "readBatteryLevel batteryService = null");
            mBatteryService = new BatteryService2(mDeviceAddress, this);
            mBatteryService.initial();
            if (mBatteryService != null) {
                boolean result = mBatteryService.readBatteryLevel();
                SDKLogger.d(D, "result = " + result);
                return result;
            } else {
                return false;
            }
        }
    }

    /**
     * use to send measure heart rate value
     * 读取心率
     *
     * @return operate result
     */
    public boolean readHrpValue() {
        SDKLogger.d(D, "readHrpValue");
        initialCommandSend("readHrpValue");

        mApplicationLayer.SportDataCmdHrpSingleRequest(true);

        return waitCommandSend();
    }

    public boolean readHeartRateValue() {
        if (mHeartRateService != null) {
            initialCommandSend("readHeartRateValue");

            boolean result = mHeartRateService.readHeartRate();

            isInSendCommand = false;
            return result;
        } else {
            return false;
        }
    }

    /**
     * Use to request the earphone mac address
     * 请求经典蓝牙mac地址
     *
     * @return the operate result
     */
    public boolean requestClassicAddress() {
        SDKLogger.d(D, "requestClassicAddress");
        initialCommandSend("requestClassicAddress");

        mApplicationLayer.RequestClassicAddress();

        return waitCommandSend();
    }


    /**
     * use to request earphone connect status
     * 请求经典蓝牙状态
     *
     * @return the operate result
     */
    public boolean requestClassicStatus() {
        SDKLogger.d(D, "requestClassicStatus");
        initialCommandSend("requestClassicStatus");

        mApplicationLayer.RequestClassicStatus();

        return waitCommandSend();
    }

    /**
     * use to set rate detect when app start exercise
     * 用于设置应用程序启动运动时的速率检测
     *
     * @param flag start or stop
     * @return the operate result
     */
    public boolean setAppSportRateDetect(boolean flag) {
        SDKLogger.d(D, "setAppSportRateDetect");
        initialCommandSend("setAppSportRateDetect");

        mApplicationLayer.SettingAppSportRateDetect(flag);

        return waitCommandSend();
    }

    /**
     * use to check rate detect when app start exercise
     * 用于检查应用程序何时开始运动的速率检测
     *
     * @return the operate result
     */
    public boolean checkAppSportRateDetect() {
        SDKLogger.d(D, "setAppSportRateDetect");
        initialCommandSend("setAppSportRateDetect");

        mApplicationLayer.CheckAppSportRateDetect();

        return waitCommandSend();
    }

    /**
     * use to start bp measure
     * 读取血压值
     *
     * @return the operate result
     */
    public boolean readBpValue() {
        SDKLogger.d(D, "readBpValue");
        initialCommandSend("readBpValue");

        mApplicationLayer.SportDataCmdBpSingleRequest(true);

        return waitCommandSend();
    }


    /**
     * use to stop bp measure
     * 停止读取心率值
     *
     * @return the operate result
     */
    public boolean stopReadHrpValue() {
        SDKLogger.d(D, "stopReadHrpValue");
        //isInSendCommand = true;
        initialCommandSend("stopReadHrpValue");

        mApplicationLayer.SportDataCmdHrpSingleRequest(false);

        return waitCommandSend();
    }

    /**
     * use to stop bp measure
     * 停止读取血压值
     *
     * @return
     */
    public boolean stopReadBpValue() {
        SDKLogger.d(D, "stopReadBpValue");
        //isInSendCommand = true;
        initialCommandSend("stopReadBpValue");

        mApplicationLayer.SportDataCmdBpSingleRequest(false);

        return waitCommandSend();
    }


    private boolean readLinkLossLevel() {
        SDKLogger.d(D, "readLinkLossLevel");
        initialCommandSend("readLinkLossLevel");

        if (!mLinkLossService.readAlertLevel()) {
            SDKLogger.d(D, "readLinkLossLevel, failed");
            isInSendCommand = false;

            return false;
        }

        return waitCommandSend();
    }


    private boolean readDfuVersion() {
        SDKLogger.d(D, "readDfuVersion");
        initialCommandSend("readDfuVersion");

        if (!mDfuService.readInfo()) {
            SDKLogger.d(D, "readDfuVersion, failed");
            isInSendCommand = false;
            return false;
        }

        return waitCommandSend();
    }


    private int[] readSavedDfuVersion() {
        if ((mAppVersion != -1) && (mPatchVersion != -1)) {
            int[] dfuVersin = new int[2];
            dfuVersin[0] = mAppVersion;
            dfuVersin[1] = mPatchVersion;
            return dfuVersin;
        } else {
            return null;
        }
    }

    private void setDfuVersion(int appVersion, int patchVersion) {
        mAppVersion = appVersion;
        mPatchVersion = patchVersion;
    }


    private int getBatteryLevel() {
        if (mBatteryService != null) {
            return mBatteryService.getBatteryValue();
        } else {
            return -1;
        }
    }

    private int getHeartRateValue() {
        if (mHeartRateService != null) {
            return mHeartRateService.getmHeartRateValue();
        } else {
            return -1;
        }
    }

    private boolean checkSupportedExtendFlash() {
        if (mDfuService != null) {
            return mDfuService.checkSupportedExtendFlash();
        } else {
            return false;
        }
    }


    /**
     * Use to set battery power notification
     * 设置电池电量通知
     *
     * @param enable true or false
     * @return the operate result
     */
    private boolean enableBatteryNotification(boolean enable) {
        SDKLogger.d(D, "enableBatteryNotification: " + enable);
        if (mBatteryService != null) {
            // enable notification
            return mBatteryService.setNotificationEnabled(enable);
        } else {
            return false;
        }
    }


    /**
     * Use to set heart rate notification
     * 设置心率通知
     *
     * @param enable true or false
     * @return the operate result
     */
    private boolean enableHeartRateNotification(boolean enable) {
        SDKLogger.d(D, "enableHeartRateNotification: " + enable);
        if (mHeartRateService != null) {
            initialCommandSend("enableHeartRateNotification");
            // enable notification
            boolean result = mHeartRateService.setNotificationEnabled(enable);
            isInSendCommand = false;
            return result;
        } else {
            return false;
        }
    }

    /**
     * use to request home pager index
     * 请求主页页面
     *
     * @return the operate result
     */
    public boolean requestHomePager() {
        SDKLogger.d(D, "requestHomePager");

        initialCommandSend("requestHomePager");

        mApplicationLayer.SettingCmdRequestHomePager();

        return waitCommandSend();
    }

    /**
     * use to request support multi sport model
     *
     * @return the operate result
     */
    public boolean requestMultiSportModel() {
        SDKLogger.d(D, "requestMultiSportModel");

        initialCommandSend("requestMultiSportModel");

        mApplicationLayer.SettingCmdRequestMultiSport();

        return waitCommandSend();
    }

    /**
     * use to request support hrp params
     * 用于请求支持hrp参数
     *
     * @return
     */
    public boolean requestHrParams() {
        SDKLogger.d(D, "requestHrParams");

        initialCommandSend("requestHrParams");

        mApplicationLayer.SettingCmdRequestHrpParams();

        return waitCommandSend();
    }


    /**
     * use to set home pager index
     * 设置主页页面
     *
     * @param index home screen index
     * @return operate result
     */
    public boolean settingHomePager(int index) {
        SDKLogger.d(D, "settingHomePager");

        initialCommandSend("settingHomePager");

        mApplicationLayer.SettingCmdHomePagerSetting(index);

        return waitCommandSend();
    }

    /**
     * use to request device information
     * 请求设备信息
     *
     * @return the operate result
     */
    public boolean requestDeviceInfo() {
        SDKLogger.d(D, "requestDeviceInfo");

        initialCommandSend("requestDeviceInfo");

        mApplicationLayer.SettingCmdRequestDeviceInfo();

        return waitCommandSend();
    }

    /**
     * use to setting screen light percent
     * 设置屏幕亮度
     *
     * @param lightPercent 20-100
     * @return the operate duration
     */
    public boolean settingScreenLight(int lightPercent) {
        SDKLogger.d(D, "settingScreenLight");

        SPWristbandConfigInfo.setLightPercent(mContext, lightPercent);

        initialCommandSend("settingScreenLight");

        mApplicationLayer.SettingCmdSettingScreenLight(lightPercent);

        return waitCommandSend();
    }

    /**
     * use to request screen light percent
     * 请求屏幕亮度
     *
     * @return the operate duration
     */
    public boolean requestScreenLight() {
        SDKLogger.d(D, "settingScreenLight");
        initialCommandSend("settingScreenLight");

        mApplicationLayer.SettingCmdRequestScreenLight();

        return waitCommandSend();
    }

    /**
     * use to setting base switch
     * 设置自动锁屏
     *
     * @param switchPacket basee switch setting
     * @return the operate result
     */
    public boolean settingAutoLock(ApplicationLayerSwitchPacket switchPacket) {
        SDKLogger.d(D, "settingAutoLock");

        DeviceFunctionStatus stopWatch = switchPacket.getStopWatch();
        DeviceFunctionStatus findPhone = switchPacket.getFindPhone();
        DeviceFunctionStatus autoLock = switchPacket.getAutoLock();
        DeviceFunctionStatus dualSlide = switchPacket.getDualSlide();
        DeviceFunctionStatus voiceAssistant = switchPacket.getVoiceAssistant();

        int StopWatch = 0;
        if (stopWatch == DeviceFunctionStatus.SUPPORT_OPEN) {
            StopWatch = 3;
        } else if (stopWatch == DeviceFunctionStatus.SUPPORT_CLOSE) {
            StopWatch = 1;
        }
        SPWristbandConfigInfo.setStopWatch(mContext, StopWatch);

        int FindPhone = 0;
        if (findPhone == DeviceFunctionStatus.SUPPORT_OPEN) {
            FindPhone = 3;
        } else if (findPhone == DeviceFunctionStatus.SUPPORT_CLOSE) {
            FindPhone = 1;
        }
        SPWristbandConfigInfo.setFindPhone(mContext, FindPhone);

        int AutoLock = 0;
        if (autoLock == DeviceFunctionStatus.SUPPORT_OPEN) {
            AutoLock = 3;
        } else if (autoLock == DeviceFunctionStatus.SUPPORT_CLOSE) {
            AutoLock = 1;
        }
        SPWristbandConfigInfo.setAutoLock(mContext, AutoLock);

        int DualSlide = 0;
        if (dualSlide == DeviceFunctionStatus.SUPPORT_OPEN) {
            DualSlide = 3;
        } else if (dualSlide == DeviceFunctionStatus.SUPPORT_CLOSE) {
            DualSlide = 1;
        }
        SPWristbandConfigInfo.setDualSlide(mContext, DualSlide);

        int VoiceAssist = 0;
        if (voiceAssistant == DeviceFunctionStatus.SUPPORT_OPEN) {
            VoiceAssist = 3;
        } else if (voiceAssistant == DeviceFunctionStatus.SUPPORT_CLOSE) {
            VoiceAssist = 1;
        }
        SPWristbandConfigInfo.setVoiceAssist(mContext, VoiceAssist);


        initialCommandSend("settingAutoLock");

        mApplicationLayer.SettingCmdSettingSwitch(switchPacket);

        return waitCommandSend();
    }

    /**
     * use to request base switch information
     * 请求自动锁屏开关
     *
     * @return the operate result
     */
    public boolean requestSwitch() {
        SDKLogger.d(D, "requestAutoLock");
        initialCommandSend("requestAutoLock");

        mApplicationLayer.SettingCmdRequestSwitch();

        return waitCommandSend();
    }

    /**
     * use to request timer setting
     * 用于请求定时器设置
     *
     * @return the operate result
     */
    public boolean readTimerInfo() {
        SDKLogger.d(D, "readTimerInfo");
        initialCommandSend("readTimerInfo");

        mApplicationLayer.RequestTimerInfo();

        return waitCommandSend();
    }

    /**
     * use to setting timer information
     * 设置定时器信息
     *
     * @param packet
     * @return
     */
    public boolean setTimerInfo(ApplicationLayerTimerPacket packet) {
        SDKLogger.d(D, "setTimerInfo");
        initialCommandSend("setTimerInfo");

        mApplicationLayer.SettingTimerInfo(packet);

        return waitCommandSend();
    }

    /**
     * use to read custom ui config
     * 读取设备主题UI
     *
     * @return
     */
    public boolean readCustomUi() {
        SDKLogger.d(D, "readCustomUi");
        initialCommandSend("readCustomUi");

        mApplicationLayer.RequestCustomUi();

        return waitCommandSend();
    }

    /**
     * use to set custom ui config
     * 设置设备主题UI
     *
     * @param packet
     * @return
     */
    public boolean setCustomUi(ApplicationLayerCustomUiPacket packet) {
        SDKLogger.d(D, "readCustomUi");
        initialCommandSend("readCustomUi");

        mApplicationLayer.SettingCustomUi(packet);

        return waitCommandSend();
    }

    /**
     * use to setting music status
     * 设置音乐控制状态
     *
     * @param packet
     * @return
     */
    public boolean setMusicStatus(ApplicationLayerMusicPlayerPacket packet) {
        SDKLogger.d(D, "setMusicStatus");
        initialCommandSend("setMusicStatus");

        mApplicationLayer.SettingMusicStatus(packet);

        return waitCommandSend();
    }

    /**
     * 当数据丢失时执行此命令，设备端会将数据指针移到最开始的地方
     * Execute this command when history data is lost, the device will move the index to the beginning
     *
     * @return
     */
    public boolean setFullSync() {
        SDKLogger.d(D, "setFullSync");
        initialCommandSend("setFullSync");

        mApplicationLayer.SettingFullSync();
        SDKLogger.d(D, "setFullSync");
        return waitCommandSend();
    }


    /**
     * request temperature detect status
     * 请求温度检测状态
     *
     * @return
     */
    public boolean checkTemperatureStatus() {
        SDKLogger.d(D, "checkTemperatureStatus");
        initialCommandSend("checkTemperatureStatus");

        mApplicationLayer.CheckTemperatureMeasure();

        return waitCommandSend();
    }

    /**
     * start or stop temperature measure
     * 设置温度检测状态
     *
     * @param openFlag start or stop
     * @return
     */
    public boolean setTemperatureStatus(boolean openFlag) {
        SDKLogger.d(D, "setTemperatureStatus");
        initialCommandSend("setTemperatureStatus");

        mApplicationLayer.SetTemperatureMeasure(openFlag);

        return waitCommandSend();
    }

    /**
     * start or stop spo2 measure
     * 开始/停止第二版血氧测量
     *
     * @param openFlag start or stop
     * @return
     */
    public boolean setSpo2Status(boolean openFlag) {
        SDKLogger.d(D, "setSpo2Status");
        initialCommandSend("setSpo2Status");

        mApplicationLayer.SetSpo2Measure(openFlag);

        return waitCommandSend();
    }

    /**
     * check spo2 measure status
     * 检查第二版血氧检测状态
     *
     * @param
     * @return
     */
    public boolean checkSpo2Status() {
        SDKLogger.d(D, "checkSpo2Status");
        initialCommandSend("checkSpo2Status");

        mApplicationLayer.CheckSpo2MeasureStatus();

        return waitCommandSend();
    }

    /**
     * request temperature setting
     * 请求温度设置
     *
     * @return
     */
    public boolean requestTemperatureSetting() {
        SDKLogger.d(D, "requestTemperatureSetting");
        initialCommandSend("requestTemperatureSetting");

        mApplicationLayer.RequestTemperatureSetting();

        return waitCommandSend();
    }

    /**
     * setting Temperature config
     * 设置温度配置
     *
     * @param packet setting info
     * @return
     */
    public boolean setTemperatureControl(ApplicationLayerTemperatureControlPacket packet) {
        SDKLogger.d(D, "setTemperatureControl");

        SPWristbandConfigInfo.setTempMeasure(mContext, packet.isShow());
        SPWristbandConfigInfo.setTempAdjust(mContext, packet.isAdjust());
        SPWristbandConfigInfo.setTempUnit(mContext, packet.isCelsiusUnit());

        initialCommandSend("setTemperatureControl");

        mApplicationLayer.SetTemperatureControl(packet);

        return waitCommandSend();
    }

    /**
     * setting bp control
     * 设置血压控制
     *
     * @param packet
     * @return
     */
    public boolean setBp2Control(ApplicationLayerBp2ControlPacket packet) {
        SDKLogger.d(D, "setBp2Control");
        SPWristbandConfigInfo.setBpMeasure(mContext, packet.isOpen());

        initialCommandSend("setBp2Control");

        mApplicationLayer.SetBp2Control(packet);

        return waitCommandSend();
    }

    /**
     * setting SleepAllSwitch
     * 设置全天睡眠开关
     *
     * @param enable
     * @return
     */
    public boolean setSleepAllSwitch(boolean enable) {
        SDKLogger.d(D, "setSleepAllSwitch");

        initialCommandSend("setSleepAllSwitch");

        mApplicationLayer.SetSleepAllSwitch(enable);

        return waitCommandSend();
    }

    /**
     * setting HypoxiaSwitch
     * 设置低氧提醒开关
     *
     * @param enable
     * @return
     */
    public boolean setHypoxiaSwitch(boolean enable) {
        SDKLogger.d(D, "setHypoxiaSwitch");

        initialCommandSend("setHypoxiaSwitch");

        mApplicationLayer.SetHypoxiaSwitch(enable);

        return waitCommandSend();
    }

    /**
     * setting HighHeartRateSwitch
     * 设置心率过高开关
     *
     * @param packet
     * @return
     */
    public boolean setHighHeartRateSwitch(ApplicationLayerHighHeartRatePacket packet) {
        SDKLogger.d(D, "setHighHeartRateSwitch");

        initialCommandSend("setHighHeartRateSwitch");

        mApplicationLayer.SetHighHeartRateSwitch(packet);

        return waitCommandSend();
    }

    /**
     * setting deviceDateFormat
     * 设置日期格式
     *
     * @param deviceDateFormat
     * @return
     */
    public boolean setDeviceDateFormat(int deviceDateFormat) {
        SDKLogger.d(D, "setDeviceDateFormat");

        initialCommandSend("setDeviceDateFormat");

        mApplicationLayer.SetDeviceDateFormat(deviceDateFormat);

        return waitCommandSend();
    }


    /**
     * set private bp setting
     * 设置私人血压
     *
     * @param packet
     * @return
     */
    public boolean setPrivateBp(final ApplicationLayerPrivateBpPacket packet) {

        SPWristbandConfigInfo.setBpPrivateMode(mContext, packet.isOpen());

        SPWristbandConfigInfo.setBpPrivateHigh(mContext, packet.getHighValue());

        SPWristbandConfigInfo.setBpPrivateLow(mContext, packet.getLowValue());

        if (tempFunctionPacket.getMulPrivateBpPacket() != null) {
            // 设置支持私人血压
            SDKLogger.d(D, "setPrivateBp");

            initialCommandSend("setPrivateBp");

            mApplicationLayer.setPrivateBp(packet.isOpen(), packet.getHighValue(), packet.getLowValue());

            return waitCommandSend();
        }
        return true;
    }

    /**
     * read private bp setting
     * 读取私人血压
     *
     * @return
     */
    public ApplicationLayerPrivateBpPacket readPrivateBp() {
        boolean isOpen = SPWristbandConfigInfo.getBpPrivateMode(mContext);

        int highValue = SPWristbandConfigInfo.getBpPrivateHigh(mContext);

        int lowValue = SPWristbandConfigInfo.getBpPrivateLow(mContext);

        return new ApplicationLayerPrivateBpPacket(isOpen, highValue, lowValue);
    }

    /**
     * request current bp2 setting
     * 请求当前血压设置
     *
     * @return
     */
    public boolean setBpControlRequest() {
        SDKLogger.d(D, "setBpControlRequest");

        initialCommandSend("setBpControlRequest");

        mApplicationLayer.RequestBp2Setting();

        return waitCommandSend();
    }

    /**
     * request current SleepAllSwitch setting
     * 请求全体睡眠设置
     *
     * @return
     */
    public boolean setSleepAllSwitchRequest() {
        SDKLogger.d(D, "setSleepAllSwitchRequest");

        initialCommandSend("setSleepAllSwitchRequest");

        mApplicationLayer.RequestSleepAllSwitch();

        return waitCommandSend();
    }

    /**
     * request current HypoxiaSwitch setting
     * 请求当前低氧提醒设置
     *
     * @return
     */
    public boolean setHypoxiaSwitchRequest() {
        SDKLogger.d(D, "setHypoxiaSwitchRequest");

        initialCommandSend("setHypoxiaSwitchRequest");

        mApplicationLayer.RequestHypoxiaSwitch();

        return waitCommandSend();
    }

    /**
     * request current HighHrvSwitch setting
     * 请求当前心率过高设置
     *
     * @return
     */
    public boolean setHighHrvSwitchRequest() {
        SDKLogger.d(D, "setHighHrvSwitchRequest");

        initialCommandSend("setHighHrvSwitchRequest");

        mApplicationLayer.RequestHighHrvSwitch();

        return waitCommandSend();
    }

    /**
     * request current DateFormat setting
     * 请求当前日期格式设置
     *
     * @return
     */
    public boolean setDeviceDateFormatRequest() {
        SDKLogger.d(D, "setDeviceDateFormatRequest");

        initialCommandSend("setDeviceDateFormatRequest");

        mApplicationLayer.RequestDeviceDateFormat();

        return waitCommandSend();
    }

    /**
     * set temperature unit
     * 设置温度单位
     *
     * @param isCelsiusUnit
     * @return
     */
    public boolean setTempUnit(boolean isCelsiusUnit) {
        SDKLogger.d(D, "setTempUnit isCelsiusUnit = " + isCelsiusUnit);
        SPWristbandConfigInfo.setTempUnit(mContext, isCelsiusUnit);

        boolean measure = SPWristbandConfigInfo.getTempMeasure(mContext);
        if (syncSwitchPacket != null && syncSwitchPacket.getItemPackets() != null) {
            for (ApplicationLayerSyncSwitchItemPacket itemPacket : syncSwitchPacket.getItemPackets()) {
                if (itemPacket.getSwitchType() == 5) {
                    // 有独立温度监测开关配置，以设备为主
                    measure = itemPacket.getSwitchValue() == 1;
                    break;
                }
            }
        }

        boolean adjust = SPWristbandConfigInfo.getTempAdjust(mContext);

        ApplicationLayerTemperatureControlPacket packet = new ApplicationLayerTemperatureControlPacket();
        packet.setShow(measure);
        packet.setAdjust(adjust);
        packet.setCelsiusUnit(isCelsiusUnit);

        return setTemperatureControl(packet);
    }

    /**
     * request current bp2 setting
     * 发送请求勿扰状态
     *
     * @return
     */
    public boolean sendRequestSilenceOtaStatus() {
        SDKLogger.d(D, "sendRequestSilenceOtaStatus");

        initialCommandSend("sendRequestSilenceOtaStatus");

        mApplicationLayer.ReqSilenceOtaStatus();

        return waitCommandSend();
    }

    /**
     * @return
     */
    public boolean setCustomExerciseLack() {
        SDKLogger.d(D, "setCustomExercise");

        initialCommandSend("setCustomExercise");

        mApplicationLayer.SetCustomExerciseLack();

        return waitCommandSend();
    }

    /**
     * @return
     */
    public boolean reqCustomNotify() {
        SDKLogger.d(D, "reqCustomNotify");

        initialCommandSend("reqCustomNotify");

        mApplicationLayer.ReqCustomNotify();

        return waitCommandSend();
    }

    /**
     * @return
     */
    public boolean setCustomNotify(ApplicationLayerCustomNotifyPacket packet) {
        SDKLogger.d(D, "setCustomNotify");

        initialCommandSend("setCustomNotify");

        mApplicationLayer.SetCustomNotify(packet);

        return waitCommandSend();
    }

    /**
     * @return
     */
    public boolean syncCustomNotify() {
        SDKLogger.d(D, "syncCustomNotify");

        initialCommandSend("syncCustomNotify");

        mApplicationLayer.SyncCustomNotify();

        return waitCommandSend();
    }

    /**
     * send custom notify
     * @param content notify
     */
    public boolean sendCustomNotify(String content) {
        SDKLogger.d(D, "sendCustomNotify");
        if (TextUtils.isEmpty(content)) {
            return false;
        }

        initialCommandSend("sendCustomNotify");

        mApplicationLayer.sendCustomNotify(content);

        return waitCommandSend();
    }

    /**
     * setting custom style color
     * 设置更换表盘颜色
     *
     * @param color 0-7
     *              0-默认，1-COM60Y100,2-COM75Y100,3-COM0Y100,
     *              4-C75M0Y100,5-C100M50Y0,6-C100M100Y0,7-C60M90Y0
     * @return
     */
    public boolean setCustomStyleColor(int color) {
        SDKLogger.d(D, "syncCustomNotify");

        initialCommandSend("syncCustomNotify");

        mApplicationLayer.SetCustomStyleColor(color);

        return waitCommandSend();
    }

    /**
     * set heart rate service notify
     * 设置心率服务通知
     *
     * @param isOpen
     * @return
     */
    public boolean setHeartRateNotify(boolean isOpen) {
        SDKLogger.d(D, "setHeartRateNotify isOpen" + isOpen);
        return mHeartRateService.setNotificationEnabled(isOpen);
    }

    /**
     * set debug service notify
     *
     * @param isOpen
     * @return
     */
    public boolean setDebugNotify(boolean isOpen) {
        SDKLogger.d(D, "setDebugNotify isOpen " + isOpen);
        return mDebugService.setNotificationEnabled(isOpen);
    }

    public boolean setEcgTestNotify(boolean isOpen) {
        SDKLogger.d(D, "setEcgTestNotify isOpen " + isOpen);
        return ecgTestService.setNotificationEnabled(isOpen);
    }

    public boolean readCusStatus() {
        SDKLogger.d(D, "readCusStatus");

        initialCommandSend("readCusStatus");

        mApplicationLayer.RequestCusStatus();

        return waitCommandSend();
    }

    public boolean requestSpo2Continuous() {
        SDKLogger.d(D, "requestSpo2Continuous");

        initialCommandSend("requestSpo2Continuous");

        mApplicationLayer.RequestSpo2Continuous();

        return waitCommandSend();
    }

    public boolean setSpo2Continuous(boolean enable, int interval) {
        SDKLogger.d(D, "setSpo2Continuous");

        initialCommandSend("setSpo2Continuous");

        mApplicationLayer.SetSpo2Continuous(enable, interval);

        return waitCommandSend();
    }

    /**
     * use to start ecg measure
     * 开始心电数据采集
     *
     * @return the operate result
     */
    public boolean startEcgTest() {
        SDKLogger.d(D, "startEcgTest");
        initialCommandSend("startEcgTest");

        mApplicationLayer.StartEcgTestRequest(true);

        return waitCommandSend();
    }

    /**
     * use to stop ecg measure
     * 停止心电数据采集
     *
     * @return
     */
    public boolean stopEcgTest() {
        SDKLogger.d(D, "stopEcgTest");
        //isInSendCommand = true;
        initialCommandSend("stopEcgTest");

        mApplicationLayer.StartEcgTestRequest(false);

        return waitCommandSend();
    }

    /**
     * use to start ecg belt measure
     * 开关心电带数据采集
     *
     * @return the operate result
     */
    public boolean setEcgBeltMeasure(boolean enable) {
        SDKLogger.d(D, "setEcgBeltMeasure, enable = " + enable);
        initialCommandSend("setEcgBeltMeasure");

        mApplicationLayer.StartEcgBeltTestRequest(enable);

        return waitCommandSend();
    }

    /**
     * 读取设备正在运行健康功能列表
     * （Ecg、血氧、血压、心率等测试，运动中）
     *
     * @return
     */
    public boolean readHealth() {
        SDKLogger.d(D, "readHealth");
        initialCommandSend("readHealth");

        mApplicationLayer.ReadHealthRequest();

        return waitCommandSend();
    }

    /**
     * 读取设备正在运行功能列表
     * （省电模式是否打开）
     *
     * @return
     */
    public boolean readDeviceStatus() {
        SDKLogger.d(D, "readDeviceStatus");
        initialCommandSend("readDeviceStatus");

        mApplicationLayer.RequestDeviceStatus();

        return waitCommandSend();
    }

    public boolean setAddressBookToDevice(ApplicationLayerAddressBookPacket packet) {
        SDKLogger.d(D, "setAddressBookToDevice");
        initialCommandSend("setAddressBookToDevice");

        mApplicationLayer.SendAddressBook(packet);

        return waitCommandSend();
    }

    public boolean setSOSNumberToDevice(ApplicationLayerSOSNumberPacket packet) {
        SDKLogger.d(D, "setSOSNumberToDevice");
        initialCommandSend("setSOSNumberToDevice");

        mApplicationLayer.SendSOSNumber(packet);

        return waitCommandSend();
    }

    /**
     * 连续血压3.0采集设置
     * @param enable true-打开连续采集
     * @param interval 分钟
     * @return
     */
    public boolean setBp3Continuous(boolean enable,int interval){
        SDKLogger.d(D, "setBp3Continuous");
        initialCommandSend("setBp3Continuous");
        mApplicationLayer.SetBp3Continuous(enable,interval);
        return waitCommandSend();
    }

    /**
     * 获取连续血压3.0采集设置
     * @return
     */
    public boolean getBp3Continuous(){
        SDKLogger.d(D, "getBp3Continuous");
        initialCommandSend("getBp3Continuous");
        mApplicationLayer.GetBp3Continuous();
        return waitCommandSend();
    }

    /**
     * 获取连续血糖采集设置
     */
    public boolean getGluContinuous(){
        SDKLogger.d(D, "getGluContinuous");
        initialCommandSend("getGluContinuous");
        mApplicationLayer.GetGLUContinuous();
        return waitCommandSend();
    }

    /**
     * 连续血糖采集设置
     * @param enable
     * @param interval
     * @return
     */
    public boolean setGluContinuous(boolean enable,int interval){
        SDKLogger.d(D, "setGluContinuous");
        initialCommandSend("setGluContinuous");
        mApplicationLayer.SetGLUContinuous(enable,interval);
        return waitCommandSend();
    }

    /**
     * 测试血糖
     * @param enable true--开始测试，false--停止测试
     * @return
     */
    public boolean startTestGlu(boolean enable){
        SDKLogger.d(D, "startTestGlu");
        initialCommandSend("startTestGlu");
        mApplicationLayer.startTestGlu(enable);
        return waitCommandSend();
    }

    /**
     * 设置私人血糖参数
     * @param height [90]
     * @param low [40]
     * @return
     */
    public boolean setPrivateGlu(int height,int low){
        initialCommandSend("setPrivateGlu");
        mApplicationLayer.SetPrivateGlu(height,low);
        return waitCommandSend();
    }

    /**
     * 获取私人血糖参数
     * @return
     */
    public boolean getPrivateGlu(){
        initialCommandSend("getPrivateGlu");
        mApplicationLayer.GetPrivateGlu();
        return waitCommandSend();
    }

    /**
     * setTemperatureReminder
     *
     * @param isOpen true is open
     * @param value unit celsius, for example 38.5 °C, then value = 385
     */
    public boolean setTemperatureReminder(boolean isOpen, int value) {
        initialCommandSend("setTemperatureReminder");
        mApplicationLayer.setTemperatureReminder(isOpen, value);
        return waitCommandSend();
    }

    /**
     * setDrinkWaterReminder
     *
     * @param isOpen true is open
     * @param startHour 0 - 23, unit hour
     * @param startMin 0 - 59, unit min
     * @param endHour 0 - 23, unit hour
     * @param endMin 0 - 59, unit min
     * @param interval 30 - 240, unit min
     */
    public boolean setDrinkWaterReminder(boolean isOpen, int startHour, int startMin, int endHour, int endMin, int interval) {
        initialCommandSend("setDrinkWaterReminder");
        mApplicationLayer.setDrinkWaterReminder(isOpen, startHour, startMin, endHour, endMin, interval);
        return waitCommandSend();
    }

    /**
     * set pulse
     *
     * @param isOpen true is open
     * @param duration 1 - 15, unit min
     * @param level 1 - 7
     */
    public boolean setPulse(boolean isOpen, int duration, int level, JWCallback callback) {
        callbackMap.put(CallbackKeyConstants.KEY_SET_PULSE, callback);
        initialCommandSend("setPulse");
        mApplicationLayer.setPulse(isOpen, duration, level);
        return waitCommandSend();
    }

    /**
     * set sleep help
     *
     * @param isOpen true is open
     * @param mode 0 - 2
     * @param duration 1 - 120, unit min
     * @param effectiveTime 1 - 120, unit min, must be less than duration
     * @param level 1 - 7
     */
    public boolean setSleepHelp(boolean isOpen, int mode, int duration, int effectiveTime, int level) {
        initialCommandSend("setSleepHelp");
        mApplicationLayer.setSleepHelp(isOpen, mode, duration, effectiveTime, level);
        return waitCommandSend();
    }

    /**
     * set female health info
     *
     * @param healthInfo female health info {@link JWFemaleHealthInfo}
     */
    public boolean setFemaleHealth(JWFemaleHealthInfo healthInfo, JWCallback callback) {
        callbackMap.put(CallbackKeyConstants.KEY_SET_FEMALE_HEALTH, callback);
        initialCommandSend("setFemaleHealth");
        mApplicationLayer.setFemaleHealth(healthInfo);
        return waitCommandSend();
    }

    /**
     * set weather info
     *
     * @param weatherInfo weather info {@link JWWeatherInfo}
     */
    public boolean setWeather(JWWeatherInfo weatherInfo, JWCallback callback) {
        if (weatherInfo == null) {
            return false;
        }
        SDKLogger.i(D, "setWeather: " + weatherInfo.toString());
        callbackMap.put(CallbackKeyConstants.KEY_SET_WEATHER, callback);
        initialCommandSend("setWeather");
        mApplicationLayer.setWeather(weatherInfo);
        return waitCommandSend();
    }

    /**
     * set hrv rmssd
     *
     * @param enable true is open
     * @param interval only support 5 min/times, 10 min/times, 15 min/times
     */
    public boolean setHRVRmssd(boolean enable, int interval) {
        initialCommandSend("setHRVRmssd");
        mApplicationLayer.setHRVRmssd(enable, interval);
        return waitCommandSend();
    }

    /**
     * read hrv rmssd config
     */
    public boolean readHRVRmssdConfig() {
        initialCommandSend("readHRVRmssdConfig");
        mApplicationLayer.readHRVRmssdConfig();
        return waitCommandSend();
    }

    /**
     * set blood sugar risk assessment
     * @param enable true open false close
     */
    public boolean setBloodSugarRiskAssessment(boolean enable) {
        initialCommandSend("setBloodSugarRiskAssessment");
        mApplicationLayer.setBloodSugarRiskAssessment(0, enable);
        return waitCommandSend();
    }

    /**
     * set uric acid risk assessment
     * @param enable true open false close
     */
    public boolean setUricAcidRiskAssessment(boolean enable) {
        initialCommandSend("setUricAcidRiskAssessment");
        mApplicationLayer.setBloodSugarRiskAssessment(1, enable);
        return waitCommandSend();
    }

    /**
     * set blood fat risk assessment
     * @param enable true open false close
     */
    public boolean setBloodFatRiskAssessment(boolean enable) {
        initialCommandSend("setBloodFatRiskAssessment");
        mApplicationLayer.setBloodSugarRiskAssessment(2, enable);
        return waitCommandSend();
    }

    /**
     * read health risk assessment info
     */
    public boolean readHealthRiskAssessment() {
        initialCommandSend("readHealthRiskAssessment");
        mApplicationLayer.readHealthRiskAssessment();
        return waitCommandSend();
    }

    /**
     * 单位请求（血糖）
     * @return
     */
    public boolean getUnitSetting(){
        initialCommandSend("getUnitSetting");
        mApplicationLayer.GetUnitSetting();
        return waitCommandSend();
    }

    /**
     * 单位设置（血糖）
     * @return
     */
    public boolean setUnitSetting(ApplicationLayerUnitPacket unitPacket){
        initialCommandSend("setUnitSetting");
        mApplicationLayer.SetUnitSetting(unitPacket);
        return waitCommandSend();
    }

    /**
     * set uric acid
     * 设置尿酸
     *
     * @param isOpen         true open false close
     * @param privateValue   privateValue
     *                       私人值 男性：238~356 μmol/L man 女性：178~297 μmol/L female
     * @param privateRTCTime 设置私人值时间，默认值为0，精确到秒
     *                       default is 0, unit second
     */
    public boolean setUricAcid(boolean isOpen, int privateValue, int privateRTCTime) {
        ApplicationLayerMulUricAcidPacket uricAcidPacket = tempFunctionPacket.getUricAcidPacket();
        if (uricAcidPacket == null) {
            uricAcidPacket = new ApplicationLayerMulUricAcidPacket();
        }
        uricAcidPacket.setOpen(isOpen);
        uricAcidPacket.setPrivateValue(privateValue);
        uricAcidPacket.setPrivateRtcTime(privateRTCTime);

        initialCommandSend("setUricAcid");
        mApplicationLayer.setUricAcid(isOpen, privateValue, privateRTCTime);
        return waitCommandSend();
    }

    /**
     * set blood fat
     * 设置血脂
     *
     * @param isOpen         true open false close
     * @param privateValue   privateValue
     *                       私人值 男性：238~356 μmol/L man 女性：178~297 μmol/L female
     * @param privateRTCTime 设置私人值时间，默认值为0，精确到秒
     *                       default is 0, unit second
     */
    public boolean setBloodFat(boolean isOpen, int privateValue, int privateRTCTime) {
        ApplicationLayerMulBloodFatPacket bloodFatPacket = tempFunctionPacket.getBloodFatPacket();
        if (bloodFatPacket == null) {
            bloodFatPacket = new ApplicationLayerMulBloodFatPacket();
        }
        bloodFatPacket.setOpen(isOpen);
        bloodFatPacket.setPrivateValue(privateValue);
        bloodFatPacket.setPrivateRtcTime(privateRTCTime);

        initialCommandSend("setBloodFat");
        mApplicationLayer.setBloodFat(isOpen, privateValue, privateRTCTime);
        return waitCommandSend();
    }

    /**
     * set blood sugar cycle
     * 设置血糖周期
     *
     * @param isOpen         true open false close
     * @param privateValue   privateValue
     *                       私人值 4.0~7.0 μmol/L
     * @param privateRTCTime 设置私人值时间，默认值为0，精确到秒
     *                       default is 0, unit second
     */
    public boolean setBloodSugarCycle(boolean isOpen, float privateValue, int privateRTCTime) {
        ApplicationLayerMulBloodSugarCyclePacket bloodSugarCyclePacket = tempFunctionPacket.getBloodSugarCyclePacket();
        if (bloodSugarCyclePacket == null) {
            bloodSugarCyclePacket = new ApplicationLayerMulBloodSugarCyclePacket();
        }
        bloodSugarCyclePacket.setOpen(isOpen);
        bloodSugarCyclePacket.setPrivateValue(privateValue);
        bloodSugarCyclePacket.setPrivateRtcTime(privateRTCTime);

        initialCommandSend("setBloodSugarCycle");
        mApplicationLayer.setBloodSugarCycle(isOpen, (int) (privateValue * 10), privateRTCTime);
        return waitCommandSend();
    }

    /**
     * set private uric acid
     * 设置私人尿酸
     *
     * @param isOpen    true open false close
     * @param value  value, default is 250 - 300, range is 80 - 500
     */
    public boolean setPrivateUricAcid(boolean isOpen, int value) {
        ApplicationLayerMulPrivateUricAcidPacket privateUricAcidPacket = tempFunctionPacket.getPrivateUricAcidPacket();
        if (privateUricAcidPacket == null) {
            privateUricAcidPacket = new ApplicationLayerMulPrivateUricAcidPacket();
        }
        privateUricAcidPacket.setOpen(isOpen);
        privateUricAcidPacket.setValue(value);

        initialCommandSend("setPrivateUricAcid");
        mApplicationLayer.setPrivateUricAcid(isOpen, value);
        return waitCommandSend();
    }

    /**
     * set private blood fat
     * 设置私人血脂
     *
     * @param isOpen true open false close
     * @param value value, default is 1.0 - 3.0, range is 0.5 - 8.0
     */
    public boolean setPrivateBloodFat(boolean isOpen, float value) {
        ApplicationLayerMulPrivateBloodFatPacket privateBloodFatPacket = tempFunctionPacket.getPrivateBloodFatPacket();
        if (privateBloodFatPacket == null) {
            privateBloodFatPacket = new ApplicationLayerMulPrivateBloodFatPacket();
        }
        privateBloodFatPacket.setOpen(isOpen);
        privateBloodFatPacket.setValue(value);

        initialCommandSend("setPrivateBloodFat");
        mApplicationLayer.setPrivateBloodFat(isOpen, (int) (value * 100));
        return waitCommandSend();
    }

    /**
     * set uric acid continuous monitoring
     * 设置尿酸自动监测
     *
     * @param isOpen true open false close
     */
    public boolean setUricAcidContinuousMonitoring(boolean isOpen) {
        initialCommandSend("setUricAcidContinuousMonitoring");
        mApplicationLayer.setUricAcidContinuousMonitoring(isOpen);
        return waitCommandSend();
    }

    /**
     * set blood fat continuous monitoring
     * 设置血脂自动监测
     *
     * @param isOpen true open false close
     */
    public boolean setBloodFatContinuousMonitoring(boolean isOpen) {
        initialCommandSend("setBloodFatContinuousMonitoring");
        mApplicationLayer.setBloodFatContinuousMonitoring(isOpen);
        return waitCommandSend();
    }

    /**
     * set pressure continuous monitoring
     * 设置压力自动监测
     *
     * @param isOpen true open false close
     */
    public boolean setPressureContinuousMonitoring(boolean isOpen) {
        initialCommandSend("setBloodFatContinuousMonitoring");
        mApplicationLayer.setBloodFatContinuousMonitoring(isOpen);
        return waitCommandSend();
    }

    /**
     * set body fat measure
     * 设置体脂监测
     *
     * @param isOpen true open false close
     */
    public boolean setBodyFatMeasure(boolean isOpen) {
        initialCommandSend("setBodyFatMeasure");
        mApplicationLayer.setBodyFatMonitoring(isOpen);
        return waitCommandSend();
    }

    /**
     * get recent body fat measure
     * 获取最近的体脂监测数据
     */
    public boolean getRecentBodyFatData() {
        initialCommandSend("getRecentBodyFatData");
        mApplicationLayer.getRecentBodyFatInfo();
        return waitCommandSend();
    }

    /**
     * get physical exam info
     * 获取体检数据
     */
    public boolean getPhysicalExamInfo() {
        initialCommandSend("getPhysicalExamInfo");
        mApplicationLayer.getPhysicalExamInfo();
        return waitCommandSend();
    }

    /**
     * sync ultraviolet info
     * 同步紫外线数据
     */
    public boolean syncUltraviolet() {
        initialCommandSend("syncUltraviolet");
        mApplicationLayer.syncUltraviolet();
        return waitCommandSend();
    }

    /**
     * sync pressure info
     * 同步压力数据
     */
    public boolean syncPressure() {
        initialCommandSend("syncPressure");
        mApplicationLayer.syncPressure();
        return waitCommandSend();
    }

    /**
     * get sdk info
     * @return see {@link JWSDKInfo}
     */
    public static JWSDKInfo getSDKInfo() {
        return new JWSDKInfo();
    }

    public ApplicationLayerFunctionPacket getFunctionPacket() {
        return functionPacket;
    }

    public ApplicationLayerMulUricAcidPacket getUricAcidPacket() {
        return tempFunctionPacket.getUricAcidPacket();
    }

    public ApplicationLayerMulBloodFatPacket getBloodFatPacket() {
        return tempFunctionPacket.getBloodFatPacket();
    }

    public ApplicationLayerMulBloodSugarCyclePacket getBloodSugarCyclePacket() {
        return tempFunctionPacket.getBloodSugarCyclePacket();
    }

    public ApplicationLayerMulPrivateUricAcidPacket getPrivateUricAcidPacket() {
        return tempFunctionPacket.getPrivateUricAcidPacket();
    }

    public ApplicationLayerMulPrivateBloodFatPacket getPrivateBloodFatPacket() {
        return tempFunctionPacket.getPrivateBloodFatPacket();
    }

    /**
     * 获取设备独立开关配置
     */
    public ApplicationLayerSyncSwitchPacket getSyncSwitchPacket() {
        return syncSwitchPacket;
    }

    public Context getContext() {
        return mContext;
    }

    // The Handler that gets information back from test thread
    //private class MyHandler extends Handler {
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_STATE_CONNECTED:
                    SDKLogger.i(D, "connected");
                    isConnected = true;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onConnectionStateChange(true);
                            SDKLogger.i(D, "callback connected");
                        }
                    }
                    break;
                case MSG_STATE_DISCONNECTED:
                    SDKLogger.i(D, "disConnected");
                    isConnected = false;
                    synchronized (mLockObject) {
                        // do something
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onConnectionStateChange(false);
                            SDKLogger.i(D, "callback disConnected");
                        }
                    }
                    close();
                    break;
                case MSG_ERROR:
                    synchronized (mLockObject) {
                        // do something
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onError(msg.arg1);
                            if (sendIndent == 1) {
                                isInSendCommand = false;
                                sendIndent = 0;
                                SDKLogger.d(D, "msg-->msg_error:" + MSG_ERROR + "\tsendIndent=" + sendIndent);
                            }
                        }
                    }
                    break;
                case MSG_WRIST_STATE_CHANGED:
                    SDKLogger.d(D, "MSG_WRIST_STATE_CHANGED, current state: " + msg.arg1);
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onLoginStateChange(msg.arg1);
                        }
                    }
                    break;
                case MSG_RECEIVE_STEP_INFO:
                    ApplicationLayerStepPacket step = (ApplicationLayerStepPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onStepDataReceiveIndication(step);
                        }
                    }
                    break;
                case MSG_RECEIVE_SPORT_INFO:
                    ApplicationLayerSportPacket sport = (ApplicationLayerSportPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onSportDataReceiveIndication(sport);
                        }
                    }
                    break;
                case MSG_RECEIVE_SLEEP_INFO:
                    ApplicationLayerSleepPacket sleep = (ApplicationLayerSleepPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onSleepDataReceiveIndication(sleep);
                        }
                    }
                    break;
                case MSG_RECEIVE_NOTIFY_MODE_SETTING:
                    ApplicationLayerNotifyPacket applicationLayerNotifyPacket = (ApplicationLayerNotifyPacket) msg.obj;

                    synchronized (mRequestResponseLock) {
                        isResponseCome = true;
                        isNeedWaitForResponse = false;
                        mRequestResponseLock.notifyAll();
                    }
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onNotifyModeSettingReceive(applicationLayerNotifyPacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_LONG_SIT_SETTING:
                    ApplicationLayerSitPacket sitPacket = (ApplicationLayerSitPacket) msg.obj;
                    SDKLogger.d(D, "Current long sit setting is: " + sitPacket.toString());
                    synchronized (mRequestResponseLock) {
                        isResponseCome = true;
                        isNeedWaitForResponse = false;
                        mRequestResponseLock.notifyAll();
                    }
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onLongSitSettingReceive(sitPacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_TURN_OVER_WRIST_SETTING:
                    boolean enable = (boolean) msg.obj;
                    SDKLogger.d(D, "Current turn over wrist setting is: " + enable);
                    synchronized (mRequestResponseLock) {
                        isResponseCome = true;
                        isNeedWaitForResponse = false;
                        mRequestResponseLock.notifyAll();
                    }
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onTurnOverWristSettingReceive(enable);
                        }
                    }
                    break;
                case MSG_RECEIVE_ALARMS_INFO:
                    ApplicationLayerAlarmsPacket alarmPacket = (ApplicationLayerAlarmsPacket) msg.obj;
                    for (final ApplicationLayerAlarmPacket p : alarmPacket.getAlarms()) {
                        byte dayFlag = p.getDayFlags();
                        String hour = String.valueOf(p.getHour()).length() == 1
                                ? "0" + String.valueOf(p.getHour())
                                : String.valueOf(p.getHour());
                        String minute = String.valueOf(p.getMinute()).length() == 1
                                ? "0" + String.valueOf(p.getMinute())
                                : String.valueOf(p.getMinute());
                        String timeString = hour + ":" + minute;
                    }
                    synchronized (mRequestResponseLock) {
                        isResponseCome = true;
                        isNeedWaitForResponse = false;
                        mRequestResponseLock.notifyAll();
                    }
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onAlarmsDataReceive(alarmPacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_TAKE_PHOTO_RSP:
                    SDKLogger.d(D, "MSG_RECEIVE_TAKE_PHOTO_RSP");
                    synchronized (mLockObject) {
                        // do something
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onTakePhotoRsp();
                        }
                    }
                    break;
                case MSG_RECEIVE_FAC_SENSOR_INFO:
                    SDKLogger.d(D, "MSG_RECEIVE_FAC_SENSOR_INFO");
                    ApplicationLayerFacSensorPacket sensorPacket = (ApplicationLayerFacSensorPacket) msg.obj;
                    SDKLogger.d(D, "Receive Fac Sensor info, X: " + sensorPacket.getX() +
                            ", Y: " + sensorPacket.getY() +
                            ", Z: " + sensorPacket.getZ());
                    // show state
                    synchronized (mLockObject) {
                        // do something
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onFacSensorDataReceive(sensorPacket);
                        }
                    }
                    break;
                case MSG_RECEIVER_END_CALL:
                    synchronized (mLockObject) {
                        // do something
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onEndCall();
                        }
                    }
                    break;
                case MSG_RECEIVER_ACCEPT_CALL:
                    synchronized (mLockObject) {
                        // do something
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onAcceptCall();
                        }
                    }
                    break;
                case MSG_RECEIVE_LOG_START:
                    SDKLogger.d(D, "MSG_RECEIVE_LOG_START");
                    long logLength = (long) msg.obj;

                    // show state
                    synchronized (mLockObject) {
                        // do something
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onLogCmdStart(logLength);
                        }
                    }
                    break;
                case MSG_RECEIVE_LOG_END:
                    SDKLogger.d(D, "MSG_RECEIVE_LOG_END");
                    // show state
                    synchronized (mLockObject) {
                        // do something
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onLogCmdEnd();
                        }
                    }
                    break;
                case MSG_RECEIVE_LOG_RSP:
                    SDKLogger.d(D, "MSG_RECEIVE_LOG_RSP");
                    ApplicationLayerLogResponsePacket logResponsePacket = (ApplicationLayerLogResponsePacket) msg.obj;
                    // show state
                    synchronized (mLockObject) {
                        // do something
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onLogCmdRsp(logResponsePacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_DFU_VERSION_INFO:
                    SDKLogger.d(D, "MSG_RECEIVE_DFU_VERSION_INFO");
                    int appVersion = msg.arg1;
                    int patchVersion = msg.arg2;
                    SDKLogger.d(D, "Receive dfu version info, appVersion: " + appVersion +
                            ", patchVersion: " + patchVersion);
                    // show state
                    synchronized (mLockObject) {
                        // do something
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onVersionRead(appVersion, patchVersion);
                        }
                    }
                    break;
                case MSG_RECEIVE_DEVICE_NAME_INFO:
                    SDKLogger.d(D, "MSG_RECEIVE_DEVICE_NAME_INFO");
                    String name = (String) msg.obj;
                    SDKLogger.d(D, "Receive device name info, name: " + name);
                    // show state
                    synchronized (mLockObject) {
                        // do something
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onNameRead(name);
                        }
                    }
                    break;
                case MSG_RECEIVE_BATTERY_INFO:
                    int battery = msg.arg1;
                    SDKLogger.d(D, "MSG_RECEIVE_BATTERY_INFO battery=" + battery);
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onBatteryRead(battery);
                        }
                    }
                    break;
                case MSG_RECEIVE_BATTERY_CHANGE_INFO:
                    SDKLogger.d(D, "MSG_RECEIVE_BATTERY_CHANGE_INFO");
                    int batteryChange = msg.arg1;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onBatteryChange(batteryChange);
                        }
                    }
                    break;
                case MSG_RECEIVE_HRP_INFO:
                    SDKLogger.d(D, "MSG_RECEIVE_HRP_INFO");
                    ApplicationLayerHrpPacket hrpPacket = (ApplicationLayerHrpPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onHrpDataReceiveIndication(hrpPacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_HRP_DEVICE_CANCEL_SINGLE_READ:
                    SDKLogger.d(D, "MSG_RECEIVE_HRP_DEVICE_CANCEL_SINGLE_READ");

                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onDeviceCancelSingleHrpRead();
                        }
                    }
                    break;
                case MSG_RECEIVE_HRP_CONTINUE_PARAM_RSP:
                    SDKLogger.d(D, "MSG_RECEIVE_HRP_CONTINUE_PARAM_RSP");
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onHrpContinueParamRsp((boolean) msg.obj, msg.arg1);
                        }
                    }
                    break;
                case MSG_RECEIVER_SPORT_FUNCTION:
                    ApplicationLayerMultiSportPacket applicationLayerMultiSportPacket = (ApplicationLayerMultiSportPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onSportFunction(applicationLayerMultiSportPacket);
                        }
                    }
                    break;
                case MSG_RECEIVER_REMINDER_FUNCTION:

                    break;
                case MSG_RECEIVER_DEVICE_FUNCTION:
                    SDKLogger.d(D, "MSG_RECEIVER_DEVICE_FUNCTION-->Function list return");
                    ApplicationLayerFunctionPacket applicationLayerFunctionPacket = (ApplicationLayerFunctionPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onDeviceFunction(applicationLayerFunctionPacket);
                        }
                    }
                    break;
                case MSG_RECEIVER_HOUR_SYSTEM:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onHour((boolean) msg.obj);
                        }
                    }
                    break;
                case MSG_RECEIVER_UNIT_SYSTEM:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onUnit((boolean) msg.obj);
                        }
                    }
                    break;
                case MSG_RECEIVER_DISTURB:
                    ApplicationLayerDisturbPacket disturbPacket = (ApplicationLayerDisturbPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onDisturb(disturbPacket);
                        }
                    }
                    break;
                case MSG_RECEIVER_LANGUAGE:
                    DeviceLanguage language = (DeviceLanguage) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onLanguage(language);
                        }
                    }
                    break;
                case MSG_RECEIVER_BP_INFO:
                    ApplicationLayerBpPacket bpPacket = (ApplicationLayerBpPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onBpDataReceiveIndication(bpPacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_BP_DEVICE_CANCEL_SINGLE_READ:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onDeviceCancelSingleBpRead();
                        }
                    }
                    break;
                case MSG_RECEIVE_EAR_ADDRESS:
                    SDKLogger.d(D, "MSG_RECEIVE_CLASSIC_ADDRESS");
                    ApplicationLayerEarMacPacket earMacPacket = (ApplicationLayerEarMacPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onEarMac(earMacPacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_EAR_CONNECT_STATUS:
                    SDKLogger.d(D, "MSG_RECEIVE_CLASSIC_STATUS");
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onEarConnectStatus(msg.arg1);
                        }
                    }
                    break;
                case MSG_RECEIVE_EAR_STATUS:
                    SDKLogger.d(D, "MSG_RECEIVE_CLASSIC_ADDRESS");
                    ApplicationLayerEarStatusPacket earStatusPacket = (ApplicationLayerEarStatusPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onEarStatus(earStatusPacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_HOME_PAGER:
                    SDKLogger.d(D, "MSG_RECEIVE_HOME_PAGER");
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onHomePager((ApplicationLayerScreenStylePacket) msg.obj);
                        }
                    }
                    break;
                case MSG_RECEIVE_CHARGE_STATUS:
                    SDKLogger.d(D, "MSG_RECEIVE_HOME_PAGER");
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onChargeStatus(msg.arg1);
                        }
                    }
                    break;
                case MSG_RECEIVE_DEVICE_INFO:
                    SDKLogger.d(D, "MSG_RECEIVE_DEVICE_INFO");
                    ApplicationLayerDeviceInfoPacket deviceInfoPacket = (ApplicationLayerDeviceInfoPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onDeviceInfo(deviceInfoPacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_DEVICE_STATUS:
                    SDKLogger.d(D, "MSG_RECEIVE_DEVICE_STATUS");
                    ApplicationLayerDeviceStatusPacket deviceStatusPacket = (ApplicationLayerDeviceStatusPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onDeviceStatus(deviceStatusPacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_HRP_PARAMS:
                    SDKLogger.d(D, "MSG_RECEIVE_HRP_PARAMS");
                    ApplicationLayerHrpParamsPacket hrpParamsPacket = (ApplicationLayerHrpParamsPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onHrpParams(hrpParamsPacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_HISTORY_SYNC_BEGIN:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onSyncDataBegin((ApplicationLayerBeginPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_RECEIVE_HISTORY_SYNC_END:
                    ApplicationLayerTodaySumSportPacket sumSportPacket = (ApplicationLayerTodaySumSportPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onSyncDataEnd(sumSportPacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_SCREEN_LIGHT:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onScreenLight(msg.arg1);
                        }
                    }
                    break;
                case MSG_RECEIVE_AUTO_LOCK:
                    ApplicationLayerSwitchPacket switchPacket = (ApplicationLayerSwitchPacket) msg.obj;
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onSwitch(switchPacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_FIND_PHONE:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onFindPhone();
                        }
                    }
                    break;
                case MSG_RECEIVE_TIMER_INFO:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onTimerInfo((ApplicationLayerTimerPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_SPORT_RATE_STOP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onSportRateStatus(msg.arg1);
                        }
                    }
                    break;
                case MSG_RATE_LIST:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            SDKLogger.d("WristbandManagerCallback mCallBacks.size=" + mCallbacks.size());
                            callback.onRateList((ApplicationLayerRateListPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_TODAY_ADJUST:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onTodayAdjust((ApplicationLayerTodayAdjustPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_LANGCO_TRANSLATE:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onLangcoTranslate(msg.arg1);
                        }
                    }
                    break;
                case MSG_TEMPERATERE_DATA:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onTemperatureData((ApplicationLayerHrpPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_TEMPERATURE_LIST:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onTemperatureList((ApplicationLayerRateListPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_TEMPERATURE_STATUS:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onTemperatureMeasureStatus(msg.arg1);
                        }
                    }
                    break;
                case MSG_TEMPERATURE_SETTING:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onTemperatureMeasureSetting((ApplicationLayerTemperatureControlPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_FAC_TODAY_SLEEP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onFacCmdTodaySleep((ApplicationLayerTodaySleepPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_HISTORY_INDEX:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onFacCmdHistoryIndex((byte[]) msg.obj);
                        }
                    }
                    break;
                case MSG_HEART_RATE_CHANGE:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onHeartRateValue(msg.arg1);
                        }
                    }
                    break;
                case MSG_DEBUG_DATA_RECEIVE:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onDebugDataReceiver((byte[]) msg.obj);
                        }
                    }
                    break;
                case MSG_BP_LIST:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onBpList((ApplicationLayerBpListPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_BP_CONTROL:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onBp2Control((ApplicationLayerBp2ControlPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_SLEEP_ALL_SWITCH:
                    boolean sleepALlEnableResult = (boolean) msg.obj;
                    synchronized (mRequestResponseLock) {
                        isResponseCome = true;
                        isNeedWaitForResponse = false;
                        mRequestResponseLock.notifyAll();
                    }
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onSleepAllSwitch(sleepALlEnableResult);
                        }
                    }
                    break;
                case MSG_HYPOXIA_SWITCH:
                    boolean enableResult = (boolean) msg.obj;
                    synchronized (mRequestResponseLock) {
                        isResponseCome = true;
                        isNeedWaitForResponse = false;
                        mRequestResponseLock.notifyAll();
                    }
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onHypoxiaSwitch(enableResult);
                        }
                    }
                    break;
                case MSG_HIGH_HRV_SWITCH:
                    synchronized (mRequestResponseLock) {
                        isResponseCome = true;
                        isNeedWaitForResponse = false;
                        mRequestResponseLock.notifyAll();
                    }
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onHighHeartRateSwitch((ApplicationLayerHighHeartRatePacket) msg.obj);
                        }
                    }
                    break;
                case MSG_DEVICE_DATE_FORMAT:
                    int format = (int) msg.obj;
                    synchronized (mRequestResponseLock) {
                        isResponseCome = true;
                        isNeedWaitForResponse = false;
                        mRequestResponseLock.notifyAll();
                    }
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onDeviceDateFormat(format);
                        }
                    }
                    break;
                case MSG_MUSIC_PLAY:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onMusicPlay();
                        }
                    }
                    break;
                case MSG_MUSIC_PAUSE:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onMusicPause();
                        }
                    }
                    break;
                case MSG_MUSIC_TOGGLE:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onMusicToggle();
                        }
                    }
                    break;
                case MSG_MUSIC_PRE:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onMusicPre();
                        }
                    }
                    break;
                case MSG_MUSIC_NEXT:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onMusicNext();
                        }
                    }
                    break;
                case MSG_MUSIC_VOLUME_UP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onMusicVolumeUp();
                        }
                    }
                    break;
                case MSG_MUSIC_VOLUME_DOWN:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onMusicVolumeDown();
                        }
                    }
                    break;
                case MSG_SILENCE_UPGRADE_MODEL:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onSilenceUpgradeModel((int) msg.arg1);
                        }
                    }
                    break;
                case MSG_CUSTOM_UI_SETTING:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onCustomUiSetting((ApplicationLayerCustomUiPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_ALARM2:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onAlarm2((ApplicationLayerAlarm2Packet) msg.obj);
                        }
                    }
                    break;
                case MSG_RECEIVE_SILENCE_OTA_STATUS:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onSilenceOtaStatus(msg.arg1);
                        }
                    }
                    break;
                case MSG_RECEIVE_CUSTOM_NOTIFY:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onCustomNotify((ApplicationLayerCustomNotifyPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_SPO2_DATA:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onSpo2DataReceive((ApplicationLayerSpo2Packet) msg.obj);
                        }
                    }
                    break;
                case MSG_SPO2_STATUS:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onSpo2MeasureStatus(msg.arg1);
                        }
                    }
                    break;
                case MSG_CUS_STATUS:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onCusStatus(msg.arg1);
                        }
                    }
                    break;
                case MSG_RECEIVE_FIND_PHONE2:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onFindPhone(msg.arg1);
                        }
                    }
                    break;
                case MSG_SPO2_CONTINUOUS_RSP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.requestSpo2Continuous((Boolean) msg.obj, msg.arg1);
                        }
                    }
                    break;
                case MSG_BOND_CHIP_TYPE_RSP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onBondReqChipType(msg.arg1);
                        }
                    }
                    break;
                case MSG_ECG_STATUS_RSP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onEcgTestStatus(msg.arg1);
                        }
                    }
                    break;
                case MSG_ECG_DATA_RSP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onEcgTestData((byte[]) msg.obj);
                        }
                    }
                    break;
                case MSG_ECG_DATA_RSP_2:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onEcgTestDataPacket((ApplicationLayerECGPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_READ_HEALTH_RSP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onReadHealthDataPacket((ApplicationLayerReadHealthPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_SET_ADDRESS_BOOK_RSP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onAddressBookToDevice(msg.arg1);
                        }
                    }
                    break;
                case MSG_SET_SOS_NUMBER_RSP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onSOSNumberToDevice(msg.arg1);
                        }
                    }
                    break;
                case MSG_RTK_HRV_DATA_RSP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onRtkHrvDataRsp((ApplicationLayerRtkHrvPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_AUDIO_SWITCH_RSP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onAudioSwitchRsp(msg.arg1);
                        }
                    }
                    break;
                case MSG_ECG_TO_DEVICE_RSP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onEcgToDeviceRsp((ApplicationLayerEcgToDevicePacket) msg.obj);
                        }
                    }
                    break;
                case MSG_BOND_FAIL_RSP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onBondDeviceFail();
                        }
                    }
                    break;
                case MSG_BOND_TIMEOUT_RSP:
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onBondDeviceTimeout();
                        }
                    }
                    break;
                case MSG_CONNECTION_SUCCESS:
                    //连接成功
                    SDKLogger.d(D,"连接成功");
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onConnectionSuccess(true);
                        }
                    }
                    break;
                case MSG_BOND_CONFIRM_RSP:
                    //登录返回0x02（需要设备同意，发送0x07）
                    SDKLogger.d(D,"登录返回0x02（需要设备同意，发送0x07） userUuid="+ mUserID);
                    requestConfirmBond(mUserID);
                    synchronized (mLockObject) {
                        for (WristbandManagerCallback callback : mCallbacks) {
                            callback.onBondDeviceConfirm();
                        }
                    }
                    break;
                case RESET_CONNECT_DEVICE:
                    if(!TextUtils.isEmpty(mDeviceAddress)) {
                        SDKLogger.d(D,"RESET_CONNECT_DEVICE 重新开始连接");
                        connect(mDeviceAddress);
                    }else{
                        SDKLogger.d(D,"RESET_CONNECT_DEVICE mDeviceAddress = null");
                    }
                    break;
                case CONNECT_TIMEOUT:
                    close();
                    mHandler.sendEmptyMessageDelayed(RESET_CONNECT_DEVICE,1000);
                    break;
                case MSG_SYNC_SWITCH_RSP:
                    synchronized (mLockObject){
                        for (WristbandManagerCallback callback : mCallbacks){
                            callback.onSyncSwitch((ApplicationLayerSyncSwitchPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_BP3_CONTINUOUS_RSP:
                    synchronized (mLockObject){
                        for(WristbandManagerCallback callback : mCallbacks){
                            callback.onBp3Continuous((ApplicationLayerBp3ContinuousPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_GLU_DATA_RESULT:
                    synchronized (mLockObject){
                        for(WristbandManagerCallback callback : mCallbacks){
                            callback.onGluDataRes((ApplicationLayerGLUPacket) msg.obj);
                        }
                    }
                    break;
                case MSG_GLU_TEST_DIS:
                    synchronized (mLockObject){
                        for(WristbandManagerCallback callback : mCallbacks){
                            callback.onGluTestDis();
                        }
                    }
                    break;
                case MSG_PRIVATE_GLU_RSP:
                    synchronized (mLockObject){
                        for(WristbandManagerCallback callback : mCallbacks){
                            callback.onPrivateGlu(msg.arg1,msg.arg2);
                        }
                    }
                    break;
                case MSG_UNIT_RSP:
                    synchronized (mLockObject){
                        for(WristbandManagerCallback callback : mCallbacks){
                            callback.onUnitRes((ApplicationLayerUnitPacket) msg.obj);
                        }
                    }
                    break;

                default:

                    break;
            }
        }
    };

    private boolean statusAll = false;
    private boolean newStateAll = false;

    /**
     * initial application callback
     */
    private void initialApplicationCallback() {
        mApplicationCallback = new ApplicationLayerCallback() {

            @Override
            public void onConnectionStateChange(boolean isConnect, int code, String msg) {
                super.onConnectionStateChange(isConnect, code, msg);
                SDKLogger.d(D, "isConnect: " + isConnect + ", code: " + code + ", msg: " + msg);
                JWArchTaskExecutor.getMainThreadExecutor().execute(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onConnectionStateChange(isConnect, code, msg);
                            }
                        }
                    }
                });
            }

            @Override
            public void onConnectionStateChange(final boolean status, final boolean newState) {
                SDKLogger.d(D, "status: " + status + ", newState: " + newState);
                if(null != mHandler){
                    mHandler.removeMessages(CONNECT_TIMEOUT);
                }
                // if already connect to the remote device, we can do more things here.
//                statusAll = status;
//                newStateAll = newState;
                if (status && newState) {
                    sendMessage(MSG_STATE_CONNECTED, null, -1, -1);
//                    sendMessage(MSG_CONNECTION_SUCCESS, null, -1, -1);
                } else {
                    sendMessage(MSG_STATE_DISCONNECTED, null, -1, -1);
                }
            }

            @Override
            public void onSettingCmdRequestAlarmList(final ApplicationLayerAlarmsPacket alarms) {
                SDKLogger.d(D, "ApplicationLayerAlarmsPacket");
                sendMessage(MSG_RECEIVE_ALARMS_INFO, alarms, -1, -1);
            }

            @Override
            public void onMedicationReminderList(final ApplicationLayerMedicationReminderListPacket packet) {
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onMedicationReminderList(packet);
                            }
                        }
                    }
                });
            }

            @Override
            public void onAlarm2(ApplicationLayerAlarm2Packet alarm2) {
                super.onAlarm2(alarm2);
                SDKLogger.d(D, "onAlarm2");
                sendMessage(MSG_ALARM2, alarm2, -1, -1);
            }

            @Override
            public void onSettingCmdRequestNotifySwitch(ApplicationLayerNotifyPacket applicationLayerNotifyPacket) {
                SDKLogger.d(D, "onSettingCmdRequestNotifySwitch");
                sendMessage(MSG_RECEIVE_NOTIFY_MODE_SETTING, applicationLayerNotifyPacket, -1, -1);
            }

            @Override
            public void onSettingCmdRequestLongSit(ApplicationLayerSitPacket packet) {
                super.onSettingCmdRequestLongSit(packet);
                SDKLogger.d(D, "onSettingCmdRequestLongSit");
                sendMessage(MSG_RECEIVE_LONG_SIT_SETTING, packet, -1, -1);
            }

            @Override
            public void onTurnOverWristSettingReceive(final boolean mode) {
                SDKLogger.d(D, "onTurnOverWristSettingReceive");
                sendMessage(MSG_RECEIVE_TURN_OVER_WRIST_SETTING, mode, -1, -1);
            }

            @Override
            public void onSportDataCmdSportData(ApplicationLayerSportPacket packet) {
                super.onSportDataCmdSportData(packet);
                if (packet == null || packet.getSportItems() == null || packet.getSportItems().isEmpty()) {
                    return;
                }

                syncDataCounter.sportCount += packet.getSportItems().size();

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;

                List<JWSportInfo> sportList = new ArrayList<>();
                for (ApplicationLayerSportItemPacket itemPacket : packet.getSportItems()) {
                    sportList.add(JWBridge.convertToJWSportInfo(userID, mDeviceAddress, packet.getYear(), packet.getMonth(), packet.getDay(), itemPacket));

                    SDKLogger.d(D, "sync receive a sport packet, Find a sport, Year: " + (packet.getYear() + 2000) +
                            ", Month: " + packet.getMonth() +
                            ", Day: " + packet.getDay() +
                            ", sportMode = " + itemPacket.getSportModel());
                }
                mGlobalGreenDAO.saveSportList(sportList);
                sendMessage(MSG_RECEIVE_SPORT_INFO, packet, -1, -1);
            }

            @Override
            public void onSportDataCmdStepData(final List<ApplicationLayerStepPacket> packetList) {
                if (packetList == null || packetList.isEmpty()) {
                    return;
                }

                syncDataCounter.stepCount += packetList.size();

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;

                List<JWStepInfo> stepList = new ArrayList<>();
                for (ApplicationLayerStepPacket packet : packetList) {
                    if (packet.getStepsItems() == null || packet.getStepsItems().isEmpty()) {
                        continue;
                    }
                    ApplicationLayerStepItemPacket itemPacket = packet.getStepsItems().get(0);// 只会有 1 个

                    long time = JWBridge.getTime(packet.getYear(), packet.getMonth(), packet.getDay());
                    time += itemPacket.getOffset() * 15 * 60000;

                    SportData sportData = new SportData(null, packet.getYear() + 2000, packet.getMonth(), packet.getDay(),
                            itemPacket.getOffset(), itemPacket.getMode(), itemPacket.getStepCount(),
                            itemPacket.getActiveTime(), itemPacket.getCalory(), itemPacket.getDistance(), new Date(time), userID);
                    mGlobalGreenDAO.saveSportData(sportData);

                    stepList.add(JWBridge.convertToJWStepInfo(userID, mDeviceAddress, packet.getYear(), packet.getMonth(), packet.getDay(), itemPacket));

                    SDKLogger.d(D, "sync receive a step packet, Find a sport, Year: " + (packet.getYear() + 2000) +
                            ", Month: " + packet.getMonth() +
                            ", Day: " + packet.getDay() +
                            ", mode = " + itemPacket.getMode() +
                            ", offset = " + itemPacket.getOffset() +
                            ", Step count: " + itemPacket.getStepCount() +
                            ", Active time: " + itemPacket.getActiveTime() +
                            ", calorie: " + itemPacket.getCalory() +
                            ", Distance: " + itemPacket.getDistance());

                    sendMessage(MSG_RECEIVE_STEP_INFO, packet, -1, -1);
                }
                mGlobalGreenDAO.saveStepList(stepList);
            }

            @Override
            public void onSportDataCmdSleepData(final List<ApplicationLayerSleepPacket> packetList) {
                if (packetList == null || packetList.isEmpty()) {
                    return;
                }

                syncDataCounter.sleepCount += packetList.size();

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;

                List<JWSleepInfo> sleepList = new ArrayList<>();
                for (ApplicationLayerSleepPacket packet : packetList) {
                    if (packet.getSleepItems() == null || packet.getSleepItems().isEmpty()) {
                        continue;
                    }
                    int minutes = packet.getSleepItems().get(0).getMinutes();// 只会有 1 个
                    int mode = packet.getSleepItems().get(0).getMode();

                    long time = DateStampUtil.getDateStamp(packet.getYear() + 2000, packet.getMonth(), packet.getDay(), minutes, 0);
                    time *= 1000;

                    SleepData sleepData = new SleepData(null, packet.getYear() + 2000,
                            packet.getMonth(), packet.getDay(),
                            minutes, mode, new Date(time), userID);
                    mGlobalGreenDAO.saveSleepData(sleepData);

                    sleepList.add(JWBridge.convertToJWSleepInfo(userID, mDeviceAddress, packet.getYear(), packet.getMonth(), packet.getDay(), minutes, mode));

                    SDKLogger.d(D, "sync receive a sleep packet, Find a sleep, Year: " + (packet.getYear() + 2000) +
                            ", Month: " + packet.getMonth() +
                            ", Day: " + packet.getDay() + ", minutes = " + minutes + ", mode = " + mode);
                    sendMessage(MSG_RECEIVE_SLEEP_INFO, packet, -1, -1);
                }
                mGlobalGreenDAO.saveSleepList(sleepList);
            }

            @Override
            public void onSportDataCmdHistorySyncBegin(ApplicationLayerBeginPacket packet) {
                SDKLogger.d(D, "onSportDataCmdHistorySyncBegin onSyncDataBegin, packet = " + (packet == null ? "null" : packet.toString()));

                syncDataCounter.totalCount = (packet == null ? 0 : packet.getTotalCount());

                updateWristState(STATE_WRIST_SYNC_HISTORY_DATA);
                sendMessage(MSG_RECEIVE_HISTORY_SYNC_BEGIN, packet, -1, -1);

                // 开始前检查一遍是否有错误数据
                mGlobalGreenDAO.deleteErrorHrpData();
            }

            @Override
            public void onSportDataCmdHistorySyncEnd(final ApplicationLayerTodaySumSportPacket packet) {
                SDKLogger.d(D, "onSportDataCmdHistorySyncEnd onSyncData, count = " + syncDataCounter.toString());
                isNeedWaitForResponse = false;
                if (null != packet) {
                    SDKLogger.d(D, "pakect.getOffset()" + packet.getOffset()
                            + ", pakect.getTotalStep()" + packet.getTotalStep()
                            + ", pakect.getTotalCalory()" + packet.getTotalCalory()
                            + ", pakect.getTotalDistance()" + packet.getTotalDistance());
                }
                updateWristState(STATE_WRIST_SYNC_DATA);

                if (sdkConfig == null || sdkConfig.isAutoSyncCheck()) {
                    // 未配置或者已配置自动校验同步数量结果
                    if (syncDataCounter.checkData()) {
                        setDataSyncEnd();
                    }
                }


                sendMessage(MSG_RECEIVE_HISTORY_SYNC_END, packet, -1, -1);
            }

            @Override
            public void onSportDataCmdHrpData(final ApplicationLayerHrpPacket hrp) {
                if (hrp == null || hrp.getHrpItems() == null || hrp.getHrpItems().isEmpty()) {
                    return;
                }

                syncDataCounter.heartRateCount += hrp.getHrpItems().size();

                SDKLogger.d(D, "sync receive a hrp packet, Year: " + (hrp.getYear() + 2000) +
                        ", Month: " + hrp.getMonth() +
                        ", Day: " + hrp.getDay() +
                        ", Item count: " + hrp.getItemCount());

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;

                boolean isSupportTemp = mApplicationLayer.deviceFunction != null && mApplicationLayer.deviceFunction.getTemperature() == DeviceFunctionStatus.SUPPORT;
                for (ApplicationLayerHrpItemPacket p : hrp.getHrpItems()) {
                    if(hrp.getYear() >= 20 && p.getMinutes() <= 1440) {
                        long time = DateStampUtil.getDateStamp(hrp.getYear() + 2000, hrp.getMonth(), hrp.getDay(), p.getMinutes(), p.getSequenceNum());

                        HrpData hrpData = new HrpData(null, hrp.getYear() + 2000, hrp.getMonth(), hrp.getDay(),
                                p.getMinutes(), p.getValue(), time, new Date(time * 1000), userID);
                        if (hrpData.getValue() != 0) {
                            mGlobalGreenDAO.saveHrpData(hrpData);

                            // 新版数据库再保存一份
                            mGlobalGreenDAO.saveHealthData(JWBridge.convertToJWHeartRateInfo(userID, mDeviceAddress, hrp.getYear(), hrp.getMonth(), hrp.getDay(), p));
                            if (isSupportTemp) {
                                mGlobalGreenDAO.saveHealthData(JWBridge.convertToJWTemperatureInfo(userID, mDeviceAddress, hrp.getYear(), hrp.getMonth(), hrp.getDay(), p));
                            }
                        }
                    }
                }

                sendMessage(MSG_RECEIVE_HRP_INFO, hrp, -1, -1);

                if (isSupportTemp) {
                    sendMessage(MSG_TEMPERATERE_DATA, hrp, -1, -1);
                }
            }

            @Override
            public void onSportDataCmdDeviceCancelSingleHrpRead() {
                SDKLogger.d(D, "onSportDataCmdDeviceCancelSingleHrpRead");
                sendMessage(MSG_RECEIVE_HRP_DEVICE_CANCEL_SINGLE_READ, null, -1, -1);
            }

            @Override
            public void onSportDataCmdHrpContinueParamRsp(boolean enable, int interval) {
                SDKLogger.d(D, "enable: " + enable + ", interval: " + interval);

                sendMessage(MSG_RECEIVE_HRP_CONTINUE_PARAM_RSP, enable, interval, -1);
            }

            @Override
            public void onTakePhotoRsp() {
                SDKLogger.d(D, "onTakePhotoRsp");
                sendMessage(MSG_RECEIVE_TAKE_PHOTO_RSP, null, -1, -1);
            }

            @Override
            public void onFACCmdSensorData(final ApplicationLayerFacSensorPacket sensor) {
                SDKLogger.d(D, "onFACCmdSensorData");
                sendMessage(MSG_RECEIVE_FAC_SENSOR_INFO, sensor, -1, -1);
            }

            @Override
            public void onBondCmdRequestBond(final byte status) {
                SDKLogger.d(D, "status: " + status);
                // bond right
                if (status == ApplicationLayer.BOND_RSP_SUCCESS) {
                    mBondResponse = true;
                }
                // bond error
                else {
                    mBondResponse = false;
                }
                synchronized (mRequestResponseLock) {
                    isResponseCome = true;
                    isNeedWaitForResponse = false;
                    mRequestResponseLock.notifyAll();
                }
            }

            @Override
            public void onBondConfirmRequest(byte status) {
                SDKLogger.d(D, "onBondConfirmRequest status: " + status);
                if (status == ApplicationLayer.BOND_RSP_SUCCESS) {
                    sendMessage(MSG_CONNECTION_SUCCESS,null,-1,-1);
                    setDataSync(false);
                    requestSetNeedInfoTemp();
                    synchronized (mRequestResponseLock) {
                        isResponseCome = true;
                        isNeedWaitForResponse = false;
                        mRequestResponseLock.notifyAll();
                    }
                } else if (status == ApplicationLayer.BOND_FAIL_TIMEOUT) {
                    sendMessage(MSG_BOND_TIMEOUT_RSP, null, -1, -1);
                } else {
                    sendMessage(MSG_BOND_FAIL_RSP, null, -1, -1);
                }
            }

            @Override
            public void onBondCmdRequestLogin(final byte status) {
                SDKLogger.d(D, "login status: " + status);
                // Login right
                if (status == ApplicationLayer.LOGIN_RSP_SUCCESS) {
                    mLoginResponseStatus = status;
                    mLoginResponse = true;
                    mLoginIsConfirm = false;
                } else if (status == ApplicationLayer.LOGIN_LOSS_LOGIN_INFO) {
                    mLoginResponseStatus = status;
//                    mLoginResponse = true;
                    mLoginIsConfirm = true;
                    sendMessage(MSG_BOND_CONFIRM_RSP, null, -1, -1);
                    return;
                }
                // Login error
                else {
                    mLoginResponse = false;
                }
                synchronized (mRequestResponseLock) {
                    isResponseCome = true;
                    isNeedWaitForResponse = false;
                    mRequestResponseLock.notifyAll();
                }
            }

            @Override
            public void onEndCallReceived() {
                SDKLogger.d(D, "onEndCallReceived");
                sendMessage(MSG_RECEIVER_END_CALL, null, -1, -1);
            }

            @Override
            public void onAcceptCallReceived() {
                super.onAcceptCallReceived();
                SDKLogger.d(D, "onAcceptCallReceived");
                sendMessage(MSG_RECEIVER_ACCEPT_CALL, null, -1, -1);
            }

            @Override
            public void onLogCmdStart(final long logLength) {
                SDKLogger.d(D, "onLogCmdStart");
                updateWristState(STATE_WRIST_SYNC_LOG_DATA);
                sendMessage(MSG_RECEIVE_LOG_START, logLength, -1, -1);
            }

            @Override
            public void onLogCmdEnd() {
                SDKLogger.d(D, "onLogCmdEnd");
                updateWristState(STATE_WRIST_SYNC_DATA);
                sendMessage(MSG_RECEIVE_LOG_END, null, -1, -1);
            }

            @Override
            public void onLogCmdRsp(final ApplicationLayerLogResponsePacket packet) {
                SDKLogger.d(D, "onLogCmdRsp");
                sendMessage(MSG_RECEIVE_LOG_RSP, packet, -1, -1);
            }

            @Override
            public void onCommandSend(final boolean status, byte command, byte key) {
                SDKLogger.d(D, "status: " + status + ", command: " + command + ", key: " + key);
                // if command send not right(no ACK). we just close it, and think connection is wrong.
                // Or, we can try to reconnect, or do other things.
                if (!status) {
                    isCommandSendOk = false;
                    sendErrorMessage(ERROR_CODE_COMMAND_SEND_ERROR);
//                    mApplicationLayer.close(); // error
//                    close();
                } else {
                    isCommandSendOk = true;
                    if (command == ApplicationLayer.CMD_FACTORY_TEST) {
                        if (key == ApplicationLayer.KEY_FAC_TEST_ENTER_SPUER_KEY) {
                            updateWristState(STATE_WRIST_ENTER_TEST_MODE);
                        } else if (key == ApplicationLayer.KEY_FAC_TEST_LEAVE_SPUER_KEY) {
                            updateWristState(STATE_WRIST_INITIAL);
                        }
                    }
                }
                synchronized (mCommandSendLock) {
                    isCommandSend = true;
                    mCommandSendLock.notifyAll();
                }
            }


            @Override
            public void onNameReceive(final String data) {
                mDeviceName = data;
                sendMessage(MSG_RECEIVE_DEVICE_NAME_INFO, data, -1, -1);
                synchronized (mCommandSendLock) {
                    isCommandSend = true;
                    mCommandSendLock.notifyAll();
                }
            }

            @Override
            public void onUpdateCmdRequestEnterOtaMode(byte status, byte errorCode) {
                super.onUpdateCmdRequestEnterOtaMode(status, errorCode);
            }

            @Override
            public void onSportDataCmdMoreData() {
                super.onSportDataCmdMoreData();
            }

            @Override
            public void onSportDataCmdSleepSetData(ApplicationLayerSleepPacket sleep) {
                super.onSportDataCmdSleepSetData(sleep);

            }

            @Override
            public void onSportFunction(ApplicationLayerMultiSportPacket applicationLayerMultiSportPacket) {
                super.onSportFunction(applicationLayerMultiSportPacket);
                sendMessage(MSG_RECEIVER_SPORT_FUNCTION, applicationLayerMultiSportPacket, -1, -1);
            }

            @Override
            public void onDeviceFunction(ApplicationLayerFunctionPacket applicationLayerFunctionPacket) {
                super.onDeviceFunction(applicationLayerFunctionPacket);

                applicationLayerFunctionPacket.setPrivateBloodPressure(tempFunctionPacket.getMulPrivateBpPacket() == null ? DeviceFunctionStatus.UN_SUPPORT : DeviceFunctionStatus.SUPPORT);
                applicationLayerFunctionPacket.setSOSNumber(tempFunctionPacket.isSupportSOS() ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT);
                applicationLayerFunctionPacket.setTemperatureReminder(tempFunctionPacket.getMulTemperatureReminder() == null ? DeviceFunctionStatus.UN_SUPPORT : DeviceFunctionStatus.SUPPORT);
                applicationLayerFunctionPacket.setDrinkWaterReminder(tempFunctionPacket.getMulDrinkWaterReminder() == null ? DeviceFunctionStatus.UN_SUPPORT : DeviceFunctionStatus.SUPPORT);
                applicationLayerFunctionPacket.setMedicationReminder(tempFunctionPacket.isSupportMedicationReminder() ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT);
                applicationLayerFunctionPacket.setPulse(tempFunctionPacket.isSupportPulse() ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT);
                applicationLayerFunctionPacket.setSleepHelp(tempFunctionPacket.isSupportSleepHelp() ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT);
                applicationLayerFunctionPacket.setSauna(tempFunctionPacket.isSupportSauna() ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT);
                applicationLayerFunctionPacket.setFemaleHealth(tempFunctionPacket.isSupportFemaleHealth() ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT);
                applicationLayerFunctionPacket.setWeather(tempFunctionPacket.isSupportWeather() ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT);
                applicationLayerFunctionPacket.setWearingTime(tempFunctionPacket.isSupportWearingTime() ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT);
                applicationLayerFunctionPacket.setBodyFat(tempFunctionPacket.isSupportBodyFat() ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT);
                applicationLayerFunctionPacket.setPhysicalExam(tempFunctionPacket.isSupportPhysicalExam() ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT);
                applicationLayerFunctionPacket.setUltraviolet(tempFunctionPacket.isSupportUltraviolet() ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT);

                ApplicationLayerMulUricAcidPacket uricAcidPacket = tempFunctionPacket.getUricAcidPacket();
                if (uricAcidPacket == null) {
                    applicationLayerFunctionPacket.setUricAcid(DeviceFunctionStatus.UN_SUPPORT);
                } else {
                    applicationLayerFunctionPacket.setUricAcid(uricAcidPacket.isOpen() ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
                }

                ApplicationLayerMulBloodFatPacket bloodFatPacket = tempFunctionPacket.getBloodFatPacket();
                if (bloodFatPacket == null) {
                    applicationLayerFunctionPacket.setBloodFat(DeviceFunctionStatus.UN_SUPPORT);
                } else {
                    applicationLayerFunctionPacket.setBloodFat(bloodFatPacket.isOpen() ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
                }

                ApplicationLayerMulBloodSugarCyclePacket bloodSugarCyclePacket = tempFunctionPacket.getBloodSugarCyclePacket();
                if (bloodSugarCyclePacket == null) {
                    applicationLayerFunctionPacket.setBloodSugarCycle(DeviceFunctionStatus.UN_SUPPORT);
                } else {
                    applicationLayerFunctionPacket.setBloodSugarCycle(bloodSugarCyclePacket.isOpen() ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
                }

                ApplicationLayerMulPrivateUricAcidPacket privateUricAcidPacket = tempFunctionPacket.getPrivateUricAcidPacket();
                if (privateUricAcidPacket == null) {
                    applicationLayerFunctionPacket.setUricAcidContinuousMonitoring(DeviceFunctionStatus.UN_SUPPORT);
                } else {
                    applicationLayerFunctionPacket.setUricAcidContinuousMonitoring(privateUricAcidPacket.isOpen() ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
                }

                ApplicationLayerMulPrivateBloodFatPacket privateBloodFatPacket = tempFunctionPacket.getPrivateBloodFatPacket();
                if (privateBloodFatPacket == null) {
                    applicationLayerFunctionPacket.setBloodFatContinuousMonitoring(DeviceFunctionStatus.UN_SUPPORT);
                } else {
                    applicationLayerFunctionPacket.setBloodFatContinuousMonitoring(privateBloodFatPacket.isOpen() ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
                }

                functionPacket = applicationLayerFunctionPacket;

                SDKLogger.e("支持功能 = " + applicationLayerFunctionPacket.toString());

                sendMessage(MSG_RECEIVER_DEVICE_FUNCTION, applicationLayerFunctionPacket, -1, -1);
            }

            @Override
            public void onHour(boolean is24Model) {
                super.onHour(is24Model);
                sendMessage(MSG_RECEIVER_HOUR_SYSTEM, is24Model, -1, -1);
            }

            @Override
            public void onUnit(boolean isMetricSystem) {
                super.onUnit(isMetricSystem);
                sendMessage(MSG_RECEIVER_UNIT_SYSTEM, isMetricSystem, -1, -1);
            }

            @Override
            public void onDisturb(ApplicationLayerDisturbPacket packet) {
                super.onDisturb(packet);
                sendMessage(MSG_RECEIVER_DISTURB, packet, -1, -1);
            }

            @Override
            public void onScreenLightDuration(int currentDuration, int defaultDuration) {
                super.onScreenLightDuration(currentDuration, defaultDuration);
                JWArchTaskExecutor.getMainThreadExecutor().execute(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onScreenLightDuration(currentDuration);
                                callback.onScreenLightDuration(currentDuration, defaultDuration);
                            }
                        }
                    }
                });
            }

            @Override
            public void onLanguage(DeviceLanguage language) {
                super.onLanguage(language);
                sendMessage(MSG_RECEIVER_LANGUAGE, language, -1, -1);
            }

            @Override
            public void onSportDataCmdBpData(List<ApplicationLayerBpPacket> packetList) {
                super.onSportDataCmdBpData(packetList);
                if (packetList == null || packetList.isEmpty()) {
                    return;
                }

                syncDataCounter.bloodPressureCount += packetList.size();

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;

                List<JWBloodPressureInfo> bpList = new ArrayList<>();
                for (ApplicationLayerBpPacket packet : packetList) {
                    if (packet.getBpItems() == null || packet.getBpItems().isEmpty()) {
                        continue;
                    }
                    int minutes = packet.getBpItems().get(0).getmMinutes();// 只会有 1 个
                    int highValue = packet.getBpItems().get(0).getmHighValue();
                    int lowValue = packet.getBpItems().get(0).getmLowValue();

                    bpList.add(JWBridge.convertToJWBpInfo(userID, mDeviceAddress, packet.getYear(), packet.getMonth(), packet.getDay(), minutes, highValue, lowValue));

                    SDKLogger.d(D, "sync receive a blood pressure packet, Find a blood pressure, Year: " + (packet.getYear() + 2000) +
                            ", Month: " + packet.getMonth() +
                            ", Day: " + packet.getDay() + ", minutes = " + minutes + ", highValue = " + highValue + ", lowValue = " + lowValue);
                    sendMessage(MSG_RECEIVER_BP_INFO, packet, -1, -1);
                }

                mGlobalGreenDAO.saveBloodPressureList(bpList);
            }

            @Override
            public void onSportDataCmdDeviceCancelSingleBpRead() {
                super.onSportDataCmdDeviceCancelSingleBpRead();
                sendMessage(MSG_RECEIVE_BP_DEVICE_CANCEL_SINGLE_READ, null, -1, -1);
            }

            @Override
            public void onEarMac(ApplicationLayerEarMacPacket packet) {
                super.onEarMac(packet);
                sendMessage(MSG_RECEIVE_EAR_ADDRESS, packet, -1, -1);
            }

            @Override
            public void onEarConnectStatus(int status) {
                super.onEarConnectStatus(status);
                sendMessage(MSG_RECEIVE_EAR_CONNECT_STATUS, null, status, -1);
            }

            @Override
            public void onEarStatus(ApplicationLayerEarStatusPacket packet) {
                super.onEarStatus(packet);
                sendMessage(MSG_RECEIVE_EAR_STATUS, packet, -1, -1);
            }

            @Override
            public void onHomePager(ApplicationLayerScreenStylePacket packet) {
                super.onHomePager(packet);
                sendMessage(MSG_RECEIVE_HOME_PAGER, packet, -1, -1);
            }

            @Override
            public void onChargeStatus(int status) {
                super.onChargeStatus(status);
                sendMessage(MSG_RECEIVE_CHARGE_STATUS, null, status, -1);
            }

            @Override
            public void onDeviceInfo(ApplicationLayerDeviceInfoPacket packet) {
                super.onDeviceInfo(packet);
                packet.setDeviceName(mDeviceName);
                sendMessage(MSG_RECEIVE_DEVICE_INFO, packet, -1, -1);
                SPWristbandConfigInfo.setInfoKeyValue(mContext, SPWristbandConfigInfo.SP_KEY_DEVICE_INFO, packet.toString());
            }

            @Override
            public void onDeviceStatus(ApplicationLayerDeviceStatusPacket packet) {
                super.onDeviceStatus(packet);
                sendMessage(MSG_RECEIVE_DEVICE_STATUS, packet, -1, -1);
            }

            @Override
            public void onHrpParams(ApplicationLayerHrpParamsPacket paramsPacket) {
                super.onHrpParams(paramsPacket);
                sendMessage(MSG_RECEIVE_HRP_PARAMS, paramsPacket, -1, -1);

                //收到心率开关参数时
            }

            @Override
            public void onScreenLight(int lightPercent) {
                super.onScreenLight(lightPercent);
                sendMessage(MSG_RECEIVE_SCREEN_LIGHT, null, lightPercent, -1);
            }

            @Override
            public void onSwitch(ApplicationLayerSwitchPacket switchPacket) {
                super.onSwitch(switchPacket);
                sendMessage(MSG_RECEIVE_AUTO_LOCK, switchPacket, -1, -1);
            }

            @Override
            public void onFindPhone() {
                super.onFindPhone();
                sendMessage(MSG_RECEIVE_FIND_PHONE, null, -1, -1);
            }

            @Override
            public void onTimerInfo(ApplicationLayerTimerPacket packet) {
                super.onTimerInfo(packet);
                sendMessage(MSG_RECEIVE_TIMER_INFO, packet, -1, -1);
            }

            @Override
            public void onSportRateStatus(int status) {
                super.onSportRateStatus(status);
                sendMessage(MSG_SPORT_RATE_STOP, null, status, -1);
            }

            @Override
            public void onRateList(ApplicationLayerRateListPacket packet) {
                super.onRateList(packet);
                if (packet == null || packet.getRateList() == null || packet.getRateList().isEmpty()) {
                    return;
                }

                syncDataCounter.heartRateCount += packet.getRateList().size();

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;
                boolean bpMeasure = SPWristbandConfigInfo.getBpMeasure(mContext);// 自动监测
                int age = SPWristbandConfigInfo.getAge(mContext);

                ApplicationLayerFunctionPacket functionPacket = getFunctionPacket();
                boolean isBp2 = (functionPacket != null && functionPacket.getBp2() == DeviceFunctionStatus.SUPPORT);

                List<ApplicationLayerBpListItemPacket> bpListItemPackets = new ArrayList<>();

                boolean isSupportTemp = (functionPacket != null && functionPacket.getTemperature() == DeviceFunctionStatus.SUPPORT);

                List<ApplicationLayerRateItemPacket> rateItemPacketList = packet.getRateList();

                List<JWBloodPressureInfo> bpList = new ArrayList<>();
                List<JWTemperatureInfo> tempList = new ArrayList<>();
                List<JWHeartRateInfo> hrList = new ArrayList<>();

                for (ApplicationLayerRateItemPacket rateItemPacket : rateItemPacketList) {
                    SDKLogger.d(D, "sync receive a rate list item packet, Year: " + (rateItemPacket.getYear() + 2000) +
                            ", Month: " + rateItemPacket.getMonth() +
                            ", Day: " + rateItemPacket.getDay() +
                            ", minutes: " + rateItemPacket.getMinutes() +
                            ", value: " + rateItemPacket.getValue());
                    // 保存心率
                    if (rateItemPacket.getValue() != 0 && rateItemPacket.getYear() >= 20 && rateItemPacket.getMinutes() <= 1440) {
                        long time = DateStampUtil.getDateStamp(rateItemPacket.getYear() + 2000, rateItemPacket.getMonth(), rateItemPacket.getDay(), rateItemPacket.getMinutes(), rateItemPacket.getSequenceNum());

                        HrpData hrpData = new HrpData(null, rateItemPacket.getYear() + 2000, rateItemPacket.getMonth(), rateItemPacket.getDay(),
                                rateItemPacket.getMinutes(), rateItemPacket.getValue(), time, new Date(time * 1000), userID);
                        mGlobalGreenDAO.saveHrpData(hrpData);

                        hrList.add(JWBridge.convertToJWHeartRateInfo(userID, mDeviceAddress, rateItemPacket));
                    }
                    if (bpMeasure && isBp2) {
                        // 转换 2.0 血压
                        if (rateItemPacket.getValue() > 0) {
                            int minutes = rateItemPacket.getMinutes();
                            int hour = minutes / 60;
                            int min = minutes % 60;
                            if (min > 0) {
                                hour += 1;
                            }
                            //区分 私人血压 和 通用血压
                            int[] temp;
                            boolean isPrivate = SPWristbandConfigInfo.getBpPrivateMode(mContext);
                            if (isPrivate) {
                                temp = TranslateBpUtil.getPrivateBp(rateItemPacket.getValue(), 70, SPWristbandConfigInfo.getBpPrivateHigh(mContext), SPWristbandConfigInfo.getBpPrivateLow(mContext));
                            } else {
                                temp = TranslateBpUtil.getBloodPressure(rateItemPacket.getValue(), hour, age);
                            }
                            ApplicationLayerBpListItemPacket bpItemPacket = new ApplicationLayerBpListItemPacket();
                            bpItemPacket.setmYear(rateItemPacket.getYear());
                            bpItemPacket.setmMonth(rateItemPacket.getMonth());
                            bpItemPacket.setmDay(rateItemPacket.getDay());
                            bpItemPacket.setmMinutes(rateItemPacket.getMinutes());
                            bpItemPacket.setmSequenceNum(rateItemPacket.getSequenceNum());
                            bpItemPacket.setmHighValue(temp[0]);
                            bpItemPacket.setmLowValue(temp[1]);
                            bpListItemPackets.add(bpItemPacket);

                            bpList.add(JWBridge.convertToJWBpInfo(userID, mDeviceAddress, bpItemPacket));
                        }
                    }

                    if (isSupportTemp) {
                        // 转换温度
                        tempList.add(JWBridge.convertToJWTemperatureInfo(userID, mDeviceAddress, rateItemPacket));
                    }
                }

                mGlobalGreenDAO.saveBloodPressureList(bpList);
                mGlobalGreenDAO.saveTemperatureList(tempList);
                mGlobalGreenDAO.saveHeartRateList(hrList);

                // 处理完毕，回调数据
                sendMessage(MSG_RATE_LIST, packet, -1, -1);

                if (bpMeasure && isBp2) {
                    // 2.0 血压
                    ApplicationLayerBpListPacket bpListPacket = new ApplicationLayerBpListPacket();
                    bpListPacket.setBpListItemPackets(bpListItemPackets);
                    sendMessage(MSG_BP_LIST, bpListPacket, -1, -1);
                }

                if (isSupportTemp) {
                    // 温度
                    sendMessage(MSG_TEMPERATURE_LIST, packet, -1, -1);
                }
            }

            @Override
            public void onTodayAdjust(ApplicationLayerTodayAdjustPacket packet) {
                super.onTodayAdjust(packet);

                // 交给外层处理数据
                sendMessage(MSG_TODAY_ADJUST, packet, -1, -1);
            }

            @Override
            public void onLangcoTranslate(int model) {
                super.onLangcoTranslate(model);
                SDKLogger.d(D, "onLangcoTranslate model = " + model);
                sendMessage(MSG_LANGCO_TRANSLATE, null, model, -1);
            }

            @Override
            public void onTemperatureMeasureStatus(int status) {
                super.onTemperatureMeasureStatus(status);
                SDKLogger.d(D, "onTemperatureMeasureStatus = " + status);
                sendMessage(MSG_TEMPERATURE_STATUS, null, status, -1);
            }

            @Override
            public void onTemperatureControl(ApplicationLayerTemperatureControlPacket packet) {
                super.onTemperatureControl(packet);
                SDKLogger.d(D, "onTemperatureControl = " + packet.toString());
                SPWristbandConfigInfo.setTempMeasure(mContext, packet.isShow());
                SPWristbandConfigInfo.setTempAdjust(mContext, packet.isAdjust());
                SPWristbandConfigInfo.setTempUnit(mContext, packet.isCelsiusUnit());
                sendMessage(MSG_TEMPERATURE_SETTING, packet, -1, -1);
            }

            @Override
            public void onFacCmdDefaultFunction(JWDefaultFunctionInfo defaultFunctionInfo) {
                super.onFacCmdDefaultFunction(defaultFunctionInfo);
                JWArchTaskExecutor.getMainThreadExecutor().execute(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onReadDefaultFunctionRsp(defaultFunctionInfo);
                            }
                        }
                    }
                });
            }

            @Override
            public void onFacCmdTodaySleep(ApplicationLayerTodaySleepPacket packet) {
                super.onFacCmdTodaySleep(packet);
                SDKLogger.d(D, "onFacCmdTodaySleep = " + packet.toString());
                sendMessage(MSG_FAC_TODAY_SLEEP, packet, -1, -1);
            }

            @Override
            public void onFacCmdHistoryIndex(byte[] data) {
                super.onFacCmdHistoryIndex(data);
                SDKLogger.d(D, "onFacCmdHistoryIndex = " + DataConverter.bytes2Hex(data));

                sendMessage(MSG_HISTORY_INDEX, data, -1, -1);
            }

            @Override
            public void onBp2Control(ApplicationLayerBp2ControlPacket packet) {
                super.onBp2Control(packet);
                SDKLogger.d(D, "onBp2Control = " + packet.toString());
                SPWristbandConfigInfo.setBpMeasure(mContext, packet.isOpen());
                sendMessage(MSG_BP_CONTROL, packet, -1, -1);
            }

            @Override
            public void onSleepAllSwitch(boolean enable) {
                super.onHypoxiaSwitch(enable);
                SDKLogger.d(D, "onSleepAllSwitch = " + enable);
                sendMessage(MSG_SLEEP_ALL_SWITCH, enable, -1, -1);
            }

            @Override
            public void onHypoxiaSwitch(boolean enable) {
                super.onHypoxiaSwitch(enable);
                SDKLogger.d(D, "onHypoxiaSwitch = " + enable);
                sendMessage(MSG_HYPOXIA_SWITCH, enable, -1, -1);
            }

            @Override
            public void onHighHeartRateSwitch(ApplicationLayerHighHeartRatePacket highHrvPacket) {
                super.onHighHeartRateSwitch(highHrvPacket);
                SDKLogger.d(D, "onHighHrvSwitch = " + highHrvPacket.toString());
                sendMessage(MSG_HIGH_HRV_SWITCH, highHrvPacket,-1,-1);
            }

            @Override
            public void onDeviceDateFormat(int format) {
                super.onDeviceDateFormat(format);
                SDKLogger.d(D, "onDeviceDateFormat = " + format);
                sendMessage(MSG_DEVICE_DATE_FORMAT, format, -1, -1);
            }

            @Override
            public void onMusicPlay() {
                super.onMusicPlay();
                SDKLogger.d(D, "onMusicPlay");
                sendMessage(MSG_MUSIC_PLAY, null, -1, -1);
            }

            @Override
            public void onMusicPause() {
                super.onMusicPause();
                SDKLogger.d(D, "onMusicPause");
                sendMessage(MSG_MUSIC_PAUSE, null, -1, -1);
            }

            @Override
            public void onMusicToggle() {
                super.onMusicToggle();
                SDKLogger.d(D, "onMusicToggle");
                sendMessage(MSG_MUSIC_TOGGLE, null, -1, -1);
            }

            @Override
            public void onMusicPre() {
                super.onMusicPre();
                SDKLogger.d(D, "onMusicPre");
                sendMessage(MSG_MUSIC_PRE, null, -1, -1);
            }

            @Override
            public void onMusicNext() {
                super.onMusicNext();
                SDKLogger.d(D, "onMusicNext");
                sendMessage(MSG_MUSIC_NEXT, null, -1, -1);
            }

            @Override
            public void onMusicVolumeUp() {
                super.onMusicVolumeUp();
                SDKLogger.d(D, "onMusicVolumeUp");
                sendMessage(MSG_MUSIC_VOLUME_UP, null, -1, -1);
            }

            @Override
            public void onMusicVolumeDown() {
                super.onMusicVolumeDown();
                SDKLogger.d(D, "onMusicVolumeDown");
                sendMessage(MSG_MUSIC_VOLUME_DOWN, null, -1, -1);
            }

            @Override
            public void onSilenceUpgradeModel(int model) {
                super.onSilenceUpgradeModel(model);
                SDKLogger.d(D, "onSilenceUpgradeModel");
                sendMessage(MSG_SILENCE_UPGRADE_MODEL, null, model, -1);
            }

            @Override
            public void onCustomUiSetting(ApplicationLayerCustomUiPacket packet) {
                super.onCustomUiSetting(packet);
                SDKLogger.d(D, "onCustomUiSetting");
                sendMessage(MSG_CUSTOM_UI_SETTING, packet, -1, -1);
            }

            @Override
            public void onSilenceOtaStatus(int status) {
                super.onSilenceOtaStatus(status);
                SDKLogger.d(D, "onSilenceOtaStatus = " + status);
                sendMessage(MSG_RECEIVE_SILENCE_OTA_STATUS, null, status, -1);
            }

            @Override
            public void onCustomNotify(ApplicationLayerCustomNotifyPacket packet) {
                super.onCustomNotify(packet);
                SDKLogger.d(D, "onCustomNotify = " + packet.toString());
                sendMessage(MSG_RECEIVE_CUSTOM_NOTIFY, packet, -1, -1);
            }

            @Override
            public void onSpo2DataReceive(List<ApplicationLayerSpo2Packet> packetList) {
                super.onSpo2DataReceive(packetList);
                if (packetList == null || packetList.isEmpty()) {
                    return;
                }

                syncDataCounter.spo2Count += packetList.size();

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;

                List<JWSpO2Info> spo2List = new ArrayList<>();
                for (ApplicationLayerSpo2Packet packet : packetList) {
                    spo2List.add(JWBridge.convertToJWSpO2Info(userID, mDeviceAddress, packet));

                    SDKLogger.d(D, "sync receive a spo2 packet, Find a spo2, Year: " + (packet.getmYear() + 2000) +
                            ", Month: " + packet.getmMonth() +
                            ", Day: " + packet.getmDay() +
                            ", minutes = " + packet.getmMinutes() +
                            ", highValue = " + packet.getmHighValue() +
                            ". lowValue = " + packet.getmLowValue());

                    sendMessage(MSG_SPO2_DATA, packet, -1, -1);
                }

                mGlobalGreenDAO.saveSpO2List(spo2List);
            }

            @Override
            public void onSpo2MeasureStatus(int status) {
                super.onSpo2MeasureStatus(status);
                SDKLogger.d(D, "onSpo2MeasureStatus = " + status);
                sendMessage(MSG_SPO2_STATUS, null, status, -1);
            }

            @Override
            public void onCusStatus(int status) {
                super.onCusStatus(status);

                SDKLogger.d(D, "onCusStatus = " + status);
                sendMessage(MSG_CUS_STATUS, null, status, -1);
            }

            @Override
            public void onFindPhone(int status) {
                super.onFindPhone(status);
                sendMessage(MSG_RECEIVE_FIND_PHONE2, null, status, -1);
            }

            @Override
            public void onSpo2Continuous(boolean enable, int interval) {
                super.onSpo2Continuous(enable, interval);
                sendMessage(MSG_SPO2_CONTINUOUS_RSP, enable, interval, -1);
            }

            @Override
            public void onBondReqChipType(int type) {
                super.onBondReqChipType(type);
                SDKLogger.d(D, "onChipType = " + type);
                sendMessage(MSG_BOND_CHIP_TYPE_RSP, null, type, -1);
            }

            @Override
            public void onEcgTestStatus(int status) {
                super.onEcgTestStatus(status);
                sendMessage(MSG_ECG_STATUS_RSP, null, status, -1);
            }

            @Override
            public void onEcgTestData(ApplicationLayerECGPacket ecgPacket) {
                super.onEcgTestData(ecgPacket);
                sendMessage(MSG_ECG_DATA_RSP_2, ecgPacket, -1, -1);
            }

            @Override
            public void onReadHealth(ApplicationLayerReadHealthPacket readHealthPacket) {
                super.onReadHealth(readHealthPacket);
                sendMessage(MSG_READ_HEALTH_RSP, readHealthPacket, -1, -1);
            }

            @Override
            public void onAddressBookToDevice(int state) {
                super.onAddressBookToDevice(state);
                sendMessage(MSG_SET_ADDRESS_BOOK_RSP, null, state, -1);
            }

            @Override
            public void onSOSNumberToDevice(int state) {
                super.onSOSNumberToDevice(state);
                sendMessage(MSG_SET_SOS_NUMBER_RSP, null, state, -1);
            }

            @Override
            public void onRtkHrvData(List<ApplicationLayerRtkHrvPacket> packetList) {
                super.onRtkHrvData(packetList);
                if (packetList == null || packetList.isEmpty()) {
                    return;
                }
                syncDataCounter.heartRateVariabilityCount += packetList.size();

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;

                List<JWHeartRateVariabilityInfo> hrvList = new ArrayList<>();
                for (ApplicationLayerRtkHrvPacket packet : packetList) {
                    hrvList.add(JWBridge.convertToJWHrvInfo(userID, mDeviceAddress, packet));

                    SDKLogger.d(D, "sync receive a hrv packet, Find a hrv, time: " + (packet.getTime()) +
                            ", dataType: " + packet.getDateType() +
                            ", value: " + packet.getHrvValue());

                    sendMessage(MSG_RTK_HRV_DATA_RSP, packet, -1, -1);
                }
                mGlobalGreenDAO.saveHeartRateVariabilityList(hrvList);
            }

            @Override
            public void onAudioSwitch(int state) {
                super.onAudioSwitch(state);
                sendMessage(MSG_AUDIO_SWITCH_RSP, null, state, -1);
            }

            @Override
            public void onDeviceEcgData(ApplicationLayerEcgToDevicePacket packet) {
                super.onDeviceEcgData(packet);
                sendMessage(MSG_ECG_TO_DEVICE_RSP, packet, -1, -1);
            }

            @Override
            public void onDeviceEcgBeltData(ApplicationLayerEcgBeltToDevicePacket packet) {
                super.onDeviceEcgBeltData(packet);
                JWArchTaskExecutor.getMainThreadExecutor().execute(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onEcgBeltToDeviceRsp(packet);
                            }
                        }
                    }
                });
            }

            @Override
            public void onSyncSwitch(ApplicationLayerSyncSwitchPacket packet) {
                super.onSyncSwitch(packet);
                syncSwitchPacket = packet;

                SDKLogger.i(true, "onSyncSwitch", packet.toString());
                sendMessage(MSG_SYNC_SWITCH_RSP,packet,-1,-1);
            }

            @Override
            public void onBp3Continuous(ApplicationLayerBp3ContinuousPacket bp3ContinuousPacket) {
                super.onBp3Continuous(bp3ContinuousPacket);
                sendMessage(MSG_BP3_CONTINUOUS_RSP,bp3ContinuousPacket,-1,-1);
            }

            @Override
            public void onGluContinuous(boolean enable, int interval) {
                super.onGluContinuous(enable, interval);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onGluContinuous(enable, interval);
                            }
                        }
                    }
                });
            }

            @Override
            public void onGluDataRsp(List<ApplicationLayerGLUPacket> packetList) {
                super.onGluDataRsp(packetList);
                if (packetList == null || packetList.isEmpty()) {
                    return;
                }
                syncDataCounter.bloodSugarCount += packetList.size();

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;

                List<JWBloodSugarInfo> gluList = new ArrayList<>();
                for (ApplicationLayerGLUPacket packet : packetList) {
                    gluList.add(JWBridge.convertToJWBloodSugarInfo(userID, mDeviceAddress, packet));

                    SDKLogger.d(D, "sync receive a glu packet, Find a glu, Year: " + (packet.getmYear() + 2000) +
                            ", Month: " + packet.getmMonth() +
                            ", Day: " + packet.getmDay() +
                            ", minutes = " + packet.getmMinutes() +
                            ", value = " + packet.getmGluValue());

                    sendMessage(MSG_GLU_DATA_RESULT, packet, -1, -1);
                }

                mGlobalGreenDAO.saveBloodSugarList(gluList);
            }

            @Override
            public void onWearingTimeDataRsp(List<JWWearingTimeInfo> packetList) {
                super.onWearingTimeDataRsp(packetList);
                if (packetList == null || packetList.isEmpty()) {
                    return;
                }
                syncDataCounter.wearingTimeCount += packetList.size();

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;

                for (JWWearingTimeInfo packet : packetList) {
                    SDKLogger.d(D, "sync receive a wearing time, Find a wearing time, " + (packet.getTime() ) +
                            ", wearStatus = " + packet.wearStatus);
                    packet.userID = userID;
                    packet.deviceMac = mDeviceAddress;
                }
                mGlobalGreenDAO.saveWearingTimeList(packetList);

                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onWearingTimeDataRes(packetList);
                            }
                        }
                    }
                });
            }

            @Override
            public void onUricAcidDataRsp(List<JWUricAcidInfo> packetList) {
                super.onUricAcidDataRsp(packetList);
                if (packetList == null || packetList.isEmpty()) {
                    return;
                }
                // 包按原数量计算
                syncDataCounter.uricAcidCount += packetList.size();

                // 尿酸协议会返回同一个周期内的多条数据，此处需过滤同一个周期数据，取当前最新周期值
                Map<Long, JWUricAcidInfo> dataMap = new HashMap<>();
                for (JWUricAcidInfo data : packetList) {
                    JWUricAcidInfo cacheData = dataMap.get(data.cycleStartTime);
                    if (cacheData == null) {
                        dataMap.put(data.cycleStartTime, data);
                    } else {
                        // 新周期 dayStatusList 会变大
                        int curDayStatus = UricAcidInfo.convertDayStatusList(data.dayStatusList);
                        int cacheDayStatus = UricAcidInfo.convertDayStatusList(cacheData.dayStatusList);
                        if (curDayStatus > cacheDayStatus) {
                            dataMap.put(data.cycleStartTime, data);
                        }
                    }
                }

                List<JWUricAcidInfo> infoList = new ArrayList<>(dataMap.values());

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;

                for (JWUricAcidInfo packet : infoList) {
                    SDKLogger.d(D, "sync receive a uric acid, Find a uric acid, " + packet.toString());
                    packet.userID = userID;
                    packet.deviceMac = mDeviceAddress;
                }
                mGlobalGreenDAO.saveUricAcidList(infoList);

                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onUricAcidDataRes(infoList);
                            }
                        }
                    }
                });
            }

            @Override
            public void onBloodFatDataRsp(List<JWBloodFatInfo> packetList) {
                super.onBloodFatDataRsp(packetList);
                if (packetList == null || packetList.isEmpty()) {
                    return;
                }
                // 包按原数量计算
                syncDataCounter.bloodFatCount += packetList.size();

                // 血脂协议会返回同一个周期内的多条数据，此处需过滤同一个周期数据，取当前最新周期值
                Map<Long, JWBloodFatInfo> dataMap = new HashMap<>();
                for (JWBloodFatInfo data : packetList) {
                    JWBloodFatInfo cacheData = dataMap.get(data.cycleStartTime);
                    if (cacheData == null) {
                        dataMap.put(data.cycleStartTime, data);
                    } else {
                        // 新周期 dayStatusList 会变大
                        int curDayStatus = BloodFatInfo.convertDayStatusList(data.dayStatusList);
                        int cacheDayStatus = BloodFatInfo.convertDayStatusList(cacheData.dayStatusList);
                        if (curDayStatus > cacheDayStatus) {
                            dataMap.put(data.cycleStartTime, data);
                        }
                    }
                }

                List<JWBloodFatInfo> infoList = new ArrayList<>(dataMap.values());

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;

                for (JWBloodFatInfo packet : infoList) {
                    SDKLogger.d(D, "sync receive a blood fat, Find a blood fat, " + packet.toString());
                    packet.userID = userID;
                    packet.deviceMac = mDeviceAddress;
                }
                mGlobalGreenDAO.saveBloodFatList(infoList);

                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onBloodFatDataRes(infoList);
                            }
                        }
                    }
                });
            }

            @Override
            public void onBloodSugarCycleDataRsp(List<JWBloodSugarCycleInfo> packetList) {
                super.onBloodSugarCycleDataRsp(packetList);
                if (packetList == null || packetList.isEmpty()) {
                    return;
                }
                // 包按原数量计算
                syncDataCounter.bloodSugarCycleCount += packetList.size();

                // 血糖周期协议会返回同一个周期内的多条数据，此处需过滤同一个周期数据，取当前最新周期值
                Map<Long, JWBloodSugarCycleInfo> dataMap = new HashMap<>();
                for (JWBloodSugarCycleInfo data : packetList) {
                    JWBloodSugarCycleInfo cacheData = dataMap.get(data.cycleStartTime);
                    if (cacheData == null) {
                        dataMap.put(data.cycleStartTime, data);
                    } else {
                        // 新周期 dayStatusList 会变大
                        int curDayStatus = BloodSugarCycleInfo.convertDayStatusList(data.dayStatusList);
                        int cacheDayStatus = BloodSugarCycleInfo.convertDayStatusList(cacheData.dayStatusList);
                        if (curDayStatus > cacheDayStatus) {
                            dataMap.put(data.cycleStartTime, data);
                        }
                    }
                }

                List<JWBloodSugarCycleInfo> infoList = new ArrayList<>(dataMap.values());

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;

                for (JWBloodSugarCycleInfo packet : infoList) {
                    SDKLogger.d(D, "sync receive a blood sugar cycle, Find a blood sugar cycle, " + packet.toString());
                    packet.userID = userID;
                    packet.deviceMac = mDeviceAddress;
                }
                mGlobalGreenDAO.saveBloodSugarCycleList(infoList);

                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onBloodSugarCycleDataRes(infoList);
                            }
                        }
                    }
                });
            }

            @Override
            public void onUricAcidContinuousMonitoringDataRsp(List<JWUricAcidContinuousMonitoringInfo> packetList) {
                super.onUricAcidContinuousMonitoringDataRsp(packetList);
                if (packetList == null || packetList.isEmpty()) {
                    return;
                }
                syncDataCounter.uricAcidContinuousMonitoringCount += packetList.size();

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;

                for (JWUricAcidContinuousMonitoringInfo packet : packetList) {
                    SDKLogger.d(D, "sync receive a uric acid continuous monitoring time, Find a uric acid, " + (packet.getTime() ) +
                            ", value = " + packet.value);
                    packet.userID = userID;
                    packet.deviceMac = mDeviceAddress;
                }
                mGlobalGreenDAO.saveUricAcidContinuousMonitoringList(packetList);

                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onUricAcidContinuousMonitoringDataRes(packetList);
                            }
                        }
                    }
                });
            }

            @Override
            public void onBloodFatContinuousMonitoringDataRsp(List<JWBloodFatContinuousMonitoringInfo> packetList) {
                super.onBloodFatContinuousMonitoringDataRsp(packetList);
                if (packetList == null || packetList.isEmpty()) {
                    return;
                }
                syncDataCounter.bloodFatContinuousMonitoringCount += packetList.size();

                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;

                for (JWBloodFatContinuousMonitoringInfo packet : packetList) {
                    SDKLogger.d(D, "sync receive a blood fat continuous monitoring time, Find a blood fat, " + (packet.getTime() ) +
                            ", value = " + packet.value);
                    packet.userID = userID;
                    packet.deviceMac = mDeviceAddress;
                }
                mGlobalGreenDAO.saveBloodFatContinuousMonitoringList(packetList);

                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onBloodFatContinuousMonitoringDataRes(packetList);
                            }
                        }
                    }
                });
            }

            @Override
            public void onDeviceMeasureStatusUpdated(int status) {
                super.onDeviceMeasureStatusUpdated(status);

                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onDeviceMeasureStatusUpdated(status);
                            }
                        }
                    }
                });
            }

            @Override
            public void onBodyFatDataRsp(JWBodyFatInfo bodyFat) {
                super.onBodyFatDataRsp(bodyFat);
                if (bodyFat == null) {
                    return;
                }
                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;
                bodyFat.userID = userID;
                bodyFat.deviceMac = mDeviceAddress;

                mGlobalGreenDAO.saveHealthData(bodyFat);

                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onBodyFatDataRes(bodyFat);
                            }
                        }
                    }
                });
            }

            @Override
            public void onPhysicalExamDataRsp(JWPhysicalExamInfo physicalExam) {
                super.onPhysicalExamDataRsp(physicalExam);
                if (physicalExam == null) {
                    return;
                }
                String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;
                physicalExam.userID = userID;
                physicalExam.deviceMac = mDeviceAddress;

                mGlobalGreenDAO.saveHealthData(physicalExam);

                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onPhysicalDataRes(physicalExam);
                            }
                        }
                    }
                });
            }

            @Override
            public void onTestGluDis() {
                super.onTestGluDis();
                sendMessage(MSG_GLU_TEST_DIS,null,-1,-1);
            }

            @Override
            public void onPrivateGlu(int height, int low) {
                super.onPrivateGlu(height, low);
                sendMessage(MSG_PRIVATE_GLU_RSP,null,height,low);
            }

            @Override
            public void onUnitRes(ApplicationLayerUnitPacket unitPacket) {
                super.onUnitRes(unitPacket);
                sendMessage(MSG_UNIT_RSP,unitPacket,-1,-1);
            }

            @Override
            public void onMulPrivateBp(ApplicationLayerMulPrivateBpPacket packet) {
                super.onMulPrivateBp(packet);
                tempFunctionPacket.setMulPrivateBpPacket(packet);
                if (functionPacket != null) {
                    functionPacket.setPrivateBloodPressure(DeviceFunctionStatus.SUPPORT);
                }
            }

            @Override
            public void onMulSupportSOSNumber() {
                super.onMulSupportSOSNumber();
                tempFunctionPacket.setSupportSOS(true);
                if (functionPacket != null) {
                    functionPacket.setSOSNumber(DeviceFunctionStatus.SUPPORT);
                }
            }

            @Override
            public void onMulTemperatureReminder(ApplicationLayerMulTemperatureReminderPacket packet) {
                super.onMulTemperatureReminder(packet);
                tempFunctionPacket.setMulTemperatureReminder(packet);
                if (functionPacket != null) {
                    functionPacket.setTemperatureReminder(DeviceFunctionStatus.SUPPORT);
                }
            }

            @Override
            public void onMulDrinkWaterReminder(ApplicationLayerMulDrinkWaterReminderPacket packet) {
                super.onMulDrinkWaterReminder(packet);
                tempFunctionPacket.setMulDrinkWaterReminder(packet);
                if (functionPacket != null) {
                    functionPacket.setDrinkWaterReminder(DeviceFunctionStatus.SUPPORT);
                }
            }

            @Override
            public void onMulSupportMedicationReminder() {
                super.onMulSupportMedicationReminder();
                tempFunctionPacket.setSupportMedicationReminder(true);
                if (functionPacket != null) {
                    functionPacket.setMedicationReminder(DeviceFunctionStatus.SUPPORT);
                }
            }

            @Override
            public void onSupportPulse() {
                super.onSupportPulse();
                tempFunctionPacket.setSupportPulse(true);
                if (functionPacket != null) {
                    functionPacket.setPulse(DeviceFunctionStatus.SUPPORT);
                }
            }

            @Override
            public void onSetPulseRsp(boolean isSuccess) {
                super.onSetPulseRsp(isSuccess);
                JWCallback callback = callbackMap.get(CallbackKeyConstants.KEY_SET_PULSE);
                if (callback != null) {
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSuccess) {
                                callback.onSuccess();
                            } else {
                                callback.onError(BaseConstants.ERR_SET_FAILED, "set pulse failed");
                            }
                            callbackMap.remove(CallbackKeyConstants.KEY_SET_PULSE);
                        }
                    });
                }
            }

            @Override
            public void onSupportSleepHelp() {
                super.onSupportSleepHelp();
                tempFunctionPacket.setSupportSleepHelp(true);
                if (functionPacket != null) {
                    functionPacket.setSleepHelp(DeviceFunctionStatus.SUPPORT);
                }
            }

            @Override
            public void onSetSleepHelpRsp(int status) {
                super.onSetSleepHelpRsp(status);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onSetSleepHelpRsp(status);
                            }
                        }
                    }
                });
            }

            @Override
            public void onSyncPulseDataRsp(ApplicationLayerPulseDataPacket packet) {
                super.onSyncPulseDataRsp(packet);
                if (packet.pulseInfoList == null || packet.pulseInfoList.isEmpty()) {
                    return;
                }
                JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
                    @Override
                    public void run() {
                        String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;
                        for (JWPulseInfo pulseInfo : packet.pulseInfoList) {
                            pulseInfo.userID = userID;
                            pulseInfo.deviceMac = mDeviceAddress;
                        }
                        mGlobalGreenDAO.savePulseList(packet.pulseInfoList);
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                synchronized (mLockObject) {
                                    for (WristbandManagerCallback callback : mCallbacks) {
                                        callback.onSyncPulseDataReceived(packet.pulseInfoList);
                                    }
                                }
                            }
                        });
                    }
                });

            }

            @Override
            public void onSyncPulseStatusRsp(int status, int count) {
                super.onSyncPulseStatusRsp(status, count);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                if (status == 1) {
                                    callback.onSyncPulseDataStart(count);
                                } else {
                                    callback.onSyncPulseDataFinished();
                                }
                            }
                        }
                    }
                });
            }

            @Override
            public void onPulseFinishedRsp(int duration) {
                super.onPulseFinishedRsp(duration);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onPulseFinished(duration);
                            }
                        }
                    }
                });
            }

            @Override
            public void onSupportSauna() {
                super.onSupportSauna();
                tempFunctionPacket.setSupportSauna(true);
                if (functionPacket != null) {
                    functionPacket.setSauna(DeviceFunctionStatus.SUPPORT);
                }
            }

            @Override
            public void onSyncSaunaDataRsp(ApplicationLayerSaunaDataPacket packet) {
                super.onSyncSaunaDataRsp(packet);
                if (packet.saunaInfoList == null || packet.saunaInfoList.isEmpty()) {
                    return;
                }
                SDKLogger.d(D, "onSyncSaunaDataRsp, packet = " + packet.toString());
                JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
                    @Override
                    public void run() {
                        String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;
                        for (JWSaunaInfo saunaInfo : packet.saunaInfoList) {
                            saunaInfo.userID = userID;
                            saunaInfo.deviceMac = mDeviceAddress;
                        }
                        mGlobalGreenDAO.saveSaunaList(packet.saunaInfoList);
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                synchronized (mLockObject) {
                                    for (WristbandManagerCallback callback : mCallbacks) {
                                        callback.onSyncSaunaDataReceived(packet.saunaInfoList);
                                    }
                                }
                            }
                        });
                    }
                });
            }

            @Override
            public void onSyncSaunaStatusRsp(int status, int count) {
                super.onSyncSaunaStatusRsp(status, count);
                SDKLogger.d(D, "onSyncSaunaStatusRsp, status = " + status + ", count = " + count);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                if (status == 1) {
                                    callback.onSyncSaunaDataStart(count);
                                } else {
                                    callback.onSyncSaunaDataFinished();
                                }
                            }
                        }
                    }
                });
            }

            @Override
            public void onSyncHRMovementDataRsp(ApplicationLayerHRMovementDataPacket packet) {
                super.onSyncHRMovementDataRsp(packet);
                if (packet.hrMovementInfoList == null || packet.hrMovementInfoList.isEmpty()) {
                    return;
                }
                SDKLogger.d(D, "onSyncHRMovementDataRsp, packet = " + packet.toString());
                JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
                    @Override
                    public void run() {
                        String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;
                        for (JWHRMovementInfo hrMovementInfo : packet.hrMovementInfoList) {
                            hrMovementInfo.userID = userID;
                            hrMovementInfo.deviceMac = mDeviceAddress;
                        }
                        mGlobalGreenDAO.saveHRMovementList(packet.hrMovementInfoList);
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                synchronized (mLockObject) {
                                    for (WristbandManagerCallback callback : mCallbacks) {
                                        callback.onSyncHRMovementDataReceived(packet.hrMovementInfoList);
                                    }
                                }
                            }
                        });
                    }
                });
            }
            @Override
            public void onSupportFemaleHealth() {
                super.onSupportFemaleHealth();
                tempFunctionPacket.setSupportFemaleHealth(true);
                if (functionPacket != null) {
                    functionPacket.setFemaleHealth(DeviceFunctionStatus.SUPPORT);
                }
            }

            @Override
            public void onSupportWeather() {
                super.onSupportWeather();
                tempFunctionPacket.setSupportWeather(true);
                if (functionPacket != null) {
                    functionPacket.setWeather(DeviceFunctionStatus.SUPPORT);
                }
            }

            @Override
            public void onSetFemaleHealthSuccess() {
                super.onSetFemaleHealthSuccess();
                JWCallback callback = callbackMap.get(CallbackKeyConstants.KEY_SET_FEMALE_HEALTH);
                if (callback != null) {
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            callback.onSuccess();
                            callbackMap.remove(CallbackKeyConstants.KEY_SET_FEMALE_HEALTH);
                        }
                    });
                }
            }

            @Override
            public void onSetWeatherSuccess() {
                super.onSetWeatherSuccess();
                JWCallback callback = callbackMap.get(CallbackKeyConstants.KEY_SET_WEATHER);
                if (callback != null) {
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            callback.onSuccess();
                            callbackMap.remove(CallbackKeyConstants.KEY_SET_WEATHER);
                        }
                    });
                }
            }

            @Override
            public void onReadHRVRmssdConfigRsp(boolean enable, int interval) {
                super.onReadHRVRmssdConfigRsp(enable, interval);
                SDKLogger.d(D, "onReadHRVRmssdConfigRsp, enable = " + enable + ", interval = " + interval);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onReadHRVRmssdConfigRsp(enable, interval);
                            }
                        }
                    }
                });
            }

            @Override
            public void onHRVRmssdDataRsp(List<JWHRVRmssdInfo> dataList) {
                super.onHRVRmssdDataRsp(dataList);
                if (dataList == null || dataList.isEmpty()) {
                    return;
                }
                JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
                    @Override
                    public void run() {
                        String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;
                        for (JWHRVRmssdInfo data : dataList) {
                            data.userID = userID;
                            data.deviceMac = mDeviceAddress;
                        }
                        mGlobalGreenDAO.saveHRVRmssdList(dataList);
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                synchronized (mLockObject) {
                                    for (WristbandManagerCallback callback : mCallbacks) {
                                        callback.onSyncHRVRmssdDataReceived(dataList);
                                    }
                                }
                            }
                        });
                    }
                });
            }

            @Override
            public void onSupportUltraviolet() {
                super.onSupportUltraviolet();
                tempFunctionPacket.setSupportUltraviolet(true);
                if (functionPacket != null) {
                    functionPacket.setUltraviolet(DeviceFunctionStatus.SUPPORT);
                }
            }

            @Override
            public void onUltravioletDataRsp(List<JWUltravioletInfo> dataList) {
                super.onUltravioletDataRsp(dataList);
                if (dataList == null || dataList.isEmpty()) {
                    return;
                }
                JWUltravioletInfo info = dataList.get(0);
                if (dataList.size() == 1 && info.getTime() == 2865908079000L
                        && info.value == 111 && info.vd == 118
                        && info.skin == 101 && info.skinCancer == 114) {
                    // 结束标识
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            synchronized (mLockObject) {
                                for (WristbandManagerCallback callback : mCallbacks) {
                                    callback.onSyncUltravioletDataEnd();
                                }
                            }
                        }
                    });
                    return;
                }
                // 正常数据返回
                JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
                    @Override
                    public void run() {
                        String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;
                        for (JWUltravioletInfo data : dataList) {
                            data.userID = userID;
                            data.deviceMac = mDeviceAddress;
                        }
                        mGlobalGreenDAO.saveUltravioletList(dataList);
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                synchronized (mLockObject) {
                                    for (WristbandManagerCallback callback : mCallbacks) {
                                        callback.onSyncUltravioletDataReceived(dataList);
                                    }
                                }
                            }
                        });
                    }
                });
            }

            @Override
            public void onPressureDataRsp(List<JWPressureInfo> dataList) {
                super.onPressureDataRsp(dataList);
                if (dataList == null || dataList.isEmpty()) {
                    return;
                }
                JWPressureInfo info = dataList.get(0);
                if (dataList.size() == 1 && info.getTime() == 2865908079000L && info.value == 111) {
                    // 结束标识
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            synchronized (mLockObject) {
                                for (WristbandManagerCallback callback : mCallbacks) {
                                    callback.onSyncPressureDataEnd();
                                }
                            }
                        }
                    });
                    return;
                }
                // 正常数据返回
                JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
                    @Override
                    public void run() {
                        String userID = TextUtils.isEmpty(mUserID) ? SPWristbandConfigInfo.getUserId(mContext) : mUserID;
                        for (JWPressureInfo data : dataList) {
                            data.userID = userID;
                            data.deviceMac = mDeviceAddress;
                        }
                        mGlobalGreenDAO.savePressureList(dataList);
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                synchronized (mLockObject) {
                                    for (WristbandManagerCallback callback : mCallbacks) {
                                        callback.onSyncPressureDataReceived(dataList);
                                    }
                                }
                            }
                        });
                    }
                });
            }

            @Override
            public void onReadHealthRiskAssessmentRsp(JWHealthRiskAssessmentInfo info) {
                super.onReadHealthRiskAssessmentRsp(info);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onReadHealthRiskAssessmentRsp(info);
                            }
                        }
                    }
                });
            }

            @Override
            public void onSupportWearingTime() {
                super.onSupportWearingTime();
                tempFunctionPacket.setSupportWearingTime(true);
                if (functionPacket != null) {
                    functionPacket.setWearingTime(DeviceFunctionStatus.SUPPORT);
                }
            }

            @Override
            public void onSupportBodyFat() {
                super.onSupportBodyFat();
                tempFunctionPacket.setSupportBodyFat(true);
                if (functionPacket != null) {
                    functionPacket.setBodyFat(DeviceFunctionStatus.SUPPORT);
                }
            }

            @Override
            public void onSupportPhysicalExam() {
                super.onSupportPhysicalExam();
                tempFunctionPacket.setSupportPhysicalExam(true);
                if (functionPacket != null) {
                    functionPacket.setPhysicalExam(DeviceFunctionStatus.SUPPORT);
                }
            }

            @Override
            public void onSupportUricAcid(ApplicationLayerMulUricAcidPacket packet) {
                super.onSupportUricAcid(packet);
                tempFunctionPacket.setUricAcidPacket(packet);
                if (functionPacket != null) {
                    if (packet == null) {
                        functionPacket.setUricAcid(DeviceFunctionStatus.UN_SUPPORT);
                    } else {
                        functionPacket.setUricAcid(packet.isOpen() ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
                    }
                }
                if (packet != null && !packet.isOpen()) {
                    GlobalGreenDAO.getInstance().clearUricAcidInvalidData(mDeviceAddress);
                }
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onUricAcidFunctionChanged(packet);
                            }
                        }
                    }
                });
            }

            @Override
            public void onSupportBloodFat(ApplicationLayerMulBloodFatPacket packet) {
                super.onSupportBloodFat(packet);
                tempFunctionPacket.setBloodFatPacket(packet);
                if (functionPacket != null) {
                    if (packet == null) {
                        functionPacket.setBloodFat(DeviceFunctionStatus.UN_SUPPORT);
                    } else {
                        functionPacket.setBloodFat(packet.isOpen() ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
                    }
                }
                if (packet != null && !packet.isOpen()) {
                    GlobalGreenDAO.getInstance().clearBloodFatInvalidData(mDeviceAddress);
                }
                GlobalGreenDAO.getInstance().clearBloodFatInvalidData(mDeviceAddress);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onBloodFatFunctionChanged(packet);
                            }
                        }
                    }
                });
            }

            @Override
            public void onSupportBloodSugarCycle(ApplicationLayerMulBloodSugarCyclePacket packet) {
                super.onSupportBloodSugarCycle(packet);
                tempFunctionPacket.setBloodSugarCyclePacket(packet);
                if (functionPacket != null) {
                    if (packet == null) {
                        functionPacket.setBloodSugarCycle(DeviceFunctionStatus.UN_SUPPORT);
                    } else {
                        functionPacket.setBloodSugarCycle(packet.isOpen() ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
                    }
                }
                if (packet != null && !packet.isOpen()) {
                    GlobalGreenDAO.getInstance().clearBloodSugarCycleInvalidData(mDeviceAddress);
                }
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (mLockObject) {
                            for (WristbandManagerCallback callback : mCallbacks) {
                                callback.onBloodSugarCycleFunctionChanged(packet);
                            }
                        }
                    }
                });
            }

            @Override
            public void onSupportPrivateUricAcid(ApplicationLayerMulPrivateUricAcidPacket packet) {
                super.onSupportPrivateUricAcid(packet);
                tempFunctionPacket.setPrivateUricAcidPacket(packet);
                if (functionPacket != null) {
                    if (packet == null) {
                        functionPacket.setUricAcidContinuousMonitoring(DeviceFunctionStatus.UN_SUPPORT);
                    } else {
                        functionPacket.setUricAcidContinuousMonitoring(packet.isOpen() ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
                    }
                }
            }

            @Override
            public void onSupportPrivateBloodFat(ApplicationLayerMulPrivateBloodFatPacket packet) {
                super.onSupportPrivateBloodFat(packet);
                tempFunctionPacket.setPrivateBloodFatPacket(packet);
                if (functionPacket != null) {
                    if (packet == null) {
                        functionPacket.setBloodFatContinuousMonitoring(DeviceFunctionStatus.UN_SUPPORT);
                    } else {
                        functionPacket.setBloodFatContinuousMonitoring(packet.isOpen() ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE);
                    }
                }
            }
        };
    }


    private void sendErrorMessage(int error) {
        sendMessage(MSG_ERROR, null, error, -1);
    }


    public void updateWristState(int state) {
        // update the wrist state
        SDKLogger.d(D, "updateWristState state=" + state);
        mWristState = state;
        sendMessage(MSG_WRIST_STATE_CHANGED, null, mWristState, -1);
    }

    /**
     * send message
     *
     * @param msgType Type message type
     * @param obj     object sent with the message set to null if not used
     * @param arg1    parameter sent with the message, set to -1 if not used
     * @param arg2    parameter sent with the message, set to -1 if not used
     **/
    private void sendMessage(int msgType, Object obj, int arg1, int arg2) {
        if (mHandler != null) {
            //	Message msg = new Message();
            Message msg = Message.obtain();
            msg.what = msgType;
            if (arg1 != -1) {
                msg.arg1 = arg1;
            }
            if (arg2 != -1) {
                msg.arg2 = arg2;
            }
            if (null != obj) {
                msg.obj = obj;
            }
            mHandler.sendMessage(msg);
        } else {
            SDKLogger.d(D, "handler is null, can't send message");
        }
    }

    @Override
    public void onVersionRead(int appVersion, int patchVersion) {
        SDKLogger.d(D, "appVersion: " + appVersion + ", patchVersion: " + patchVersion);


        setDfuVersion(appVersion, patchVersion);

        sendMessage(MSG_RECEIVE_DFU_VERSION_INFO, null, appVersion, patchVersion);

        synchronized (mCommandSendLock) {
            isCommandSendOk = true;
            isCommandSend = true;
            mCommandSendLock.notifyAll();
        }
    }

    @Override
    public void onOTADeviceInfoRead(byte[] data) {
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                synchronized (mLockObject) {
                    for (WristbandManagerCallback callback : mCallbacks) {
                        callback.onOTADeviceInfoRead(data);
                    }
                }
            }
        });
    }

    @Override
    public void onResetConnect() {
        close();
        mHandler.sendEmptyMessageDelayed(RESET_CONNECT_DEVICE,1000);
    }

    @Override
    public void onBatteryLevelChanged(int i, boolean b) {
        SDKLogger.d(D, "value: " + i);
        if (b) {
            sendMessage(MSG_RECEIVE_BATTERY_CHANGE_INFO, null, i, -1);
        } else {
            sendMessage(MSG_RECEIVE_BATTERY_INFO, null, i, -1);
        }
    }

    @Override
    public void onHrpValueReceive(int value) {
        SDKLogger.d(D, "value: " + value);
        sendMessage(MSG_RECEIVE_HRP_INFO, null, value, -1);
    }

    @Override
    public void onLinkLossAlertLevelChanged(byte level) {
        SDKLogger.d(D, "level: " + level);
        SPWristbandConfigInfo.setControlSwitchLost(mContext, mLinkLossService.isAlertEnabled());
        synchronized (mCommandSendLock) {
            isCommandSendOk = true;
            isCommandSend = true;
            mCommandSendLock.notifyAll();
        }
    }

    @Override
    public void onHeartRateChanged(int var1, boolean var2) {
        SDKLogger.d(D, "heart rate value : " + var1);
        sendMessage(MSG_HEART_RATE_CHANGE, null, var1, -1);
    }

    @Override
    public void onDataReceiver(byte[] data) {
        SDKLogger.d(D, "debug data receive : " + DataConverter.bytes2Hex(data));
        sendMessage(MSG_DEBUG_DATA_RECEIVE, data, -1, -1);
    }

    @Override
    public void onEcgDataRequest(byte[] data) {
//        SDKLogger.d(D, "EcgTest data receive : " + Arrays.toString(data) +"\ndataHex:" +DataConverter.bytes2Hex(data));
        sendMessage(MSG_ECG_DATA_RSP, data, -1, -1);
    }

    @Override
    public void onEcgDataSend(boolean flag) {
        SDKLogger.d(D, "EcgTest data send : " + flag);
    }

    @Override
    public void onDataSend(boolean flag) {
        SDKLogger.d(D, "debug data send : " + flag);
    }


}
