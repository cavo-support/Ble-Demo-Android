package com.wosmart.ukprotocollibary.corespec;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.os.Environment;

import com.wosmart.ukprotocollibary.util.DataConverter;
import com.wosmart.ukprotocollibary.gattlayer.GlobalGatt2;
import com.wosmart.ukprotocollibary.util.SDKLogger;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class DfuService {
    // LOG
    private static final boolean D = true;
    private static final String TAG = "DfuService";

    // Support Service UUID and Characteristic UUID
    private final static UUID OTA_SERVICE_UUID = UUID.fromString("0000d0ff-3c17-d293-8e48-14fe2e4da212");
    private final static UUID OTA_CHARACTERISTIC_UUID = UUID.fromString("0000ffd1-0000-1000-8000-00805f9b34fb");
    private final static UUID OTA_READ_PATCH_CHARACTERISTIC_UUID = UUID.fromString("0000ffd3-0000-1000-8000-00805f9b34fb");
    private final static UUID OTA_READ_APP_CHARACTERISTIC_UUID = UUID.fromString("0000ffd4-0000-1000-8000-00805f9b34fb");
    private final static UUID OTA_DEVICE_INFO_CHARACTERISTIC_UUID = UUID.fromString("0000fff1-0000-1000-8000-00805f9b34fb");

    public final static UUID CLIENT_CHARACTERISTIC_CONFIG = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");


    public static final UUID DFU_SERVICE_UUID = UUID.fromString("00006287-3c17-d293-8e48-14fe2e4da212");
    // Add for extend OTA upload.
    private final static UUID OTA_EXTEND_FLASH_CHARACTERISTIC_UUID = UUID.fromString("00006587-3c17-d293-8e48-14fe2e4da212");

    // Support Service object and Characteristic object
    private BluetoothGattService mService;
    private BluetoothGattCharacteristic mAppCharac;
    private BluetoothGattCharacteristic mPatchCharac;
    private BluetoothGattCharacteristic mDeviceInfoCharac;
    private BluetoothGattCharacteristic mAppearanceCharac;

    private BluetoothGattService mDfuService;
    private BluetoothGattCharacteristic mExtendCharac;

    // Current Battery value
    private int mAppValue = -1;
    private int mPatchValue = -1;

    private GlobalGatt2 mGlobalGatt;

    private OnServiceListener mCallback;

    private String mBluetoothAddress;

    private static DfuService instance;

    public DfuService(String addr, OnServiceListener callback) {
        mCallback = callback;
        mBluetoothAddress = addr;

        mGlobalGatt = GlobalGatt2.getInstance();
        instance = this;
//        initial();
    }

    public DfuService getInstance(){
        return instance;
    }

    public void close() {
        mGlobalGatt.unRegisterCallback(mBluetoothAddress, mGattCallback);
    }

    public void initial() {
        // register service discovery callback
        mGlobalGatt.registerCallback(mBluetoothAddress, mGattCallback);
    }

    public boolean setService(BluetoothGattService service) {
        if (service.getUuid().equals(OTA_SERVICE_UUID)) {
            mService = service;
            return true;
        }
        return false;
    }

    public List<BluetoothGattCharacteristic> getNotifyCharacteristic() {
        return null;
    }

    public boolean readInfo() {
        if (mDeviceInfoCharac == null) {
            SDKLogger.e(D, "read device info error with null charac");
            return false;
        }
        SDKLogger.d(D, "read device info.");

//        mAppearanceCharac = gatt.getService(Environment.BLUETOOTH_SERVICE_UUID).getCharacteristic(Environment.GAP_APPEARANCE_UUID);
//        if (characteristic != null) {
//            gatt.readCharacteristic(characteristic); // 读取特性值
//        } else {
//            Log.e("BLE", "Appearance characteristic not found");
//        }

        return readDeviceInfo(mDeviceInfoCharac);
    }

    public String getServiceUUID() {
        return OTA_SERVICE_UUID.toString();
    }

    public String getServiceSimpleName() {
        return "Dfu";
    }

    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            SDKLogger.d(D,"uuid-->"+status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                mService = gatt.getService(OTA_SERVICE_UUID);
                if (mService == null) {
                    SDKLogger.e(D, "OTA service not found");
                    return;
                } else {
                    mPatchCharac = mService.getCharacteristic(OTA_READ_PATCH_CHARACTERISTIC_UUID);
                    if (mPatchCharac == null) {
                        SDKLogger.e(D, "OTA Patch characteristic not found");
                        return;
                    } else {
                        SDKLogger.d(D, "OTA Patch characteristic is found, mPatchCharac: " + mPatchCharac.getUuid());
                    }
                    mAppCharac = mService.getCharacteristic(OTA_READ_APP_CHARACTERISTIC_UUID);
                    if (mAppCharac == null) {
                        SDKLogger.e(D, "OTA App characteristic not found");
                        return;
                    } else {
                        SDKLogger.d(D, "OTA App characteristic is found, mAppCharac: " + mAppCharac.getUuid());
                    }
                    mDeviceInfoCharac = mService.getCharacteristic(OTA_DEVICE_INFO_CHARACTERISTIC_UUID);
                    if (mDeviceInfoCharac == null) {
                        SDKLogger.e(D, "OTA device info characteristic not found");
                        return;
                    } else {
                        SDKLogger.d(D, "OTA device info characteristic is found, mDeviceInfoCharac: " + mDeviceInfoCharac.getUuid());
                    }
//                    mAppearanceCharac = gatt.getService(Environment.BLUETOOTH_SERVICE_UUID).getCharacteristic(Environment.GAP_APPEARANCE_UUID);

                    // 服务发现完成，延迟一下再读取设备信息，确保设备准备就绪
                    android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            readInfo();
                        }
                    }, 2500); // 延迟2500ms
                }

                mDfuService = gatt.getService(DFU_SERVICE_UUID);
                if (mDfuService == null) {
                    SDKLogger.e(D, "Dfu Service not found");
                    return;
                } else {
                    SDKLogger.d(D, "Dfu Service is found, mDfuService: " + mDfuService.getUuid());
                    mExtendCharac = mDfuService.getCharacteristic(OTA_EXTEND_FLASH_CHARACTERISTIC_UUID);
                    if (mExtendCharac == null) {
                        SDKLogger.e(D, "Dfu extend characteristic not found");
                        //为空就无法连接`
                        return;
                    } else {
                        SDKLogger.d(D, "Dfu extend characteristic is found, mExtendCharac: " + mExtendCharac.getUuid());
                    }
                }
                //isConnected = true;
            } else {
                SDKLogger.e(D, "Discovery service error: " + status);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            //if(D) Log.d(TAG, "onCharacteristicRead UUID is: " + characteristic.getUuid() + ", addr: " +mBluetoothAddress);
            //if(D) Log.d(TAG, "onCharacteristicRead data value:"+ Arrays.toString(characteristic.getValue()) + ", addr: " +mBluetoothAddress);
            SDKLogger.d(D,"uuid-->"+characteristic.getUuid());
            byte[] data = characteristic.getValue();
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (characteristic.getUuid().equals(OTA_READ_APP_CHARACTERISTIC_UUID)) {
                    SDKLogger.d(D, "data = " + Arrays.toString(characteristic.getValue()));
                    byte[] appVersionValue = characteristic.getValue();
                    ByteBuffer wrapped = ByteBuffer.wrap(appVersionValue);
                    wrapped.order(ByteOrder.LITTLE_ENDIAN);
                    mAppValue = wrapped.getShort(0);

                    //mTargetVersionView.setText(String.valueOf(oldFwVersion));
                    SDKLogger.d(D, "old firmware version: " + mAppValue + " .getValue=" + DataConverter.bytes2Hex(characteristic.getValue()));
                    if (mPatchCharac != null) {
                        readDeviceInfo(mPatchCharac);
                    }
                } else if (characteristic.getUuid().equals(OTA_READ_PATCH_CHARACTERISTIC_UUID)) {
                    byte[] patchVersionValue = characteristic.getValue();
                    ByteBuffer wrapped = ByteBuffer.wrap(patchVersionValue);
                    wrapped.order(ByteOrder.LITTLE_ENDIAN);
                    mPatchValue = wrapped.getShort(0);
                    SDKLogger.d(D, "old patch version: " + mPatchValue + " .getValue=" + DataConverter.bytes2Hex(characteristic.getValue()));
                    //here can add read other characteristic
                    mCallback.onVersionRead(mAppValue, mPatchValue);
                } else if (characteristic.getUuid().equals(OTA_DEVICE_INFO_CHARACTERISTIC_UUID)) {
                    SDKLogger.d(D, "device info data = " + DataConverter.bytes2Hex(characteristic.getValue()));
                    if (mCallback != null) {
                        mCallback.onOTADeviceInfoRead(characteristic.getValue());
                    }
                }
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);
//            SDKLogger.d(D,"uuid-->"+characteristic.getUuid());
        }
    };

    public boolean checkSupportedExtendFlash() {
        return mExtendCharac != null;
    }

    private boolean readDeviceInfo(BluetoothGattCharacteristic characteristic) {
        if (characteristic != null) {
            SDKLogger.d(D, characteristic.getUuid().toString());

            return mGlobalGatt.readCharacteristic(mBluetoothAddress, characteristic);
        } else {
            SDKLogger.e(D, "Characteristic is null");
        }
        return false;
    }

    public int getAppValue() {
        return mAppValue;
    }

    public int getPatchValue() {
        return mPatchValue;
    }

    /**
     * Interface required to be implemented by activity
     */
    public interface OnServiceListener {
        /**
         * Fired when value come.
         *
         * @param appVersion   app Version value
         * @param patchVersion patch Version value
         */
        void onVersionRead(int appVersion, int patchVersion);

        void onOTADeviceInfoRead(byte[] data);

        void onResetConnect();
    }
}
