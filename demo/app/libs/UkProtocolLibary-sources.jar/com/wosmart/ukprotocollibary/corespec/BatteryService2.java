package com.wosmart.ukprotocollibary.corespec;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;

import com.wosmart.ukprotocollibary.BuildConfig;
import com.wosmart.ukprotocollibary.gattlayer.GlobalGatt2;
import com.wosmart.ukprotocollibary.util.OldServiceCallback;
import com.wosmart.ukprotocollibary.util.SDKLogger;

import java.util.Iterator;
import java.util.List;
import java.util.UUID;

public class BatteryService2 {

    private static final boolean D = true;
    private static final String TAG = "BatteryService";
    private static final UUID BATTERY_SERVICE = UUID.fromString("0000180f-0000-1000-8000-00805f9b34fb");
    private static final UUID BATTERY_LEVEL_CHARACTERISTIC = UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb");
    public static final UUID CHARACTERISTIC_PRESENTATION_FORMAT_DESCRIPTOR = UUID.fromString("00002904-0000-1000-8000-00805f9b34fb");
    public static final UUID CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private BluetoothGattService mService;
    private BluetoothGattCharacteristic mBatteryLevelCharacteristic;
    private int mBatteryValue = -1;
    private OldServiceCallback mCallback;
    private String mBluetoothAddress;
    private GlobalGatt2 globalGatt2;
    private static BatteryService2 instance;

//    private boolean notifyFlag;

    public final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            SDKLogger.d(D,"uuid-->"+status);
            if (status == 0) {
                BatteryService2.this.mService = gatt.getService(BatteryService2.BATTERY_SERVICE);
                if (BatteryService2.this.mService == null) {
                    SDKLogger.d("BATTERY_SERVICE not supported");
                } else {
                    BatteryService2.this.mBatteryLevelCharacteristic = BatteryService2.this.mService.getCharacteristic(BatteryService2.BATTERY_LEVEL_CHARACTERISTIC);
                    if (BatteryService2.this.mBatteryLevelCharacteristic == null) {
                        SDKLogger.d("BATTERY_LEVEL_CHARACTERISTIC not supported");
                    } else {
                        SDKLogger.d(true, "find BATTERY_LEVEL_CHARACTERISTIC: " + BatteryService2.BATTERY_LEVEL_CHARACTERISTIC);
                        List<BluetoothGattDescriptor> gattDescriptors = BatteryService2.this.mBatteryLevelCharacteristic.getDescriptors();
                        if (gattDescriptors != null && gattDescriptors.size() > 0) {
                            Iterator var4 = gattDescriptors.iterator();

                            while (var4.hasNext()) {
                                BluetoothGattDescriptor descriptor = (BluetoothGattDescriptor) var4.next();
                                SDKLogger.d("descriptor : " + descriptor.getUuid().toString() + "value = " + descriptor.getValue());
                            }
                        }
                    }

                }
            }
        }

        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
//            SDKLogger.d(D,"uuid-->"+characteristic.getUuid());
            byte[] data = characteristic.getValue();
            if (BatteryService2.this.mBatteryLevelCharacteristic != null) {
                if (BatteryService2.BATTERY_LEVEL_CHARACTERISTIC.equals(characteristic.getUuid())) {
                    BatteryService2.this.mBatteryValue = data[0];
                    SDKLogger.d(true, "mBatteryValue=" + BatteryService2.this.mBatteryValue);
                    if (BatteryService2.this.mCallback != null) {
                        BatteryService2.this.mCallback.onBatteryLevelChanged(BatteryService2.this.mBatteryValue, true);
                    }
                }
            }
        }

        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            SDKLogger.d(D,"uuid-->"+characteristic.getUuid());
            byte[] data = characteristic.getValue();
            if (status == 0) {
                if (BatteryService2.BATTERY_LEVEL_CHARACTERISTIC.equals(characteristic.getUuid())) {
                    BatteryService2.this.mBatteryValue = data[0];
                    SDKLogger.d(true, "mBatteryValue=" + BatteryService2.this.mBatteryValue);
                    if (BatteryService2.this.mCallback != null) {
                        BatteryService2.this.mCallback.onBatteryLevelChanged(BatteryService2.this.mBatteryValue, false);
                    }
                }
            } else {
                SDKLogger.d(true, "Characteristic read error: " + status);
            }

        }

        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
//            SDKLogger.d(D,"uuid-->"+descriptor.getCharacteristic().getUuid());
            if (status == 0) {
//                if (BatteryService2.BATTERY_LEVEL_CHARACTERISTIC.equals(descriptor.getCharacteristic().getUuid()) && BatteryService.CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR.equals(descriptor.getUuid())) {
//                    SDKLogger.d(true, "CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR write OK.");
//                }
                if (BatteryService2.BATTERY_LEVEL_CHARACTERISTIC.equals(descriptor.getCharacteristic().getUuid())) {
                    SDKLogger.d(true, "CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR write OK.");
                }
            } else {
                SDKLogger.d(true, "Descriptor write error: " + status);
            }

        }
    };

    public BatteryService2(String addr, OldServiceCallback callback) {
        this.mCallback = callback;
        this.mBluetoothAddress = addr;
        this.initial();
        this.globalGatt2 = GlobalGatt2.getInstance();
        instance = this;
    }
    public static BatteryService2 getInstance(){
        return instance;
    }

    public void initial() {
        GlobalGatt2.getInstance().registerCallback(this.mBluetoothAddress, this.mGattCallback);
    }

    public void close() {
//        setNotificationEnabled(false);
        GlobalGatt2.getInstance().unRegisterCallback(this.mBluetoothAddress, this.mGattCallback);
    }

    public boolean readBatteryLevel() {
        if (this.mBatteryLevelCharacteristic == null) {
            if(this.mService != null) {
                BatteryService2.this.mBatteryLevelCharacteristic = BatteryService2.this.mService.getCharacteristic(BatteryService2.BATTERY_LEVEL_CHARACTERISTIC);
                SDKLogger.d(true, "BATTERY_LEVEL_CHARACTERISTIC not supported or notify enable");
                if (this.mBatteryLevelCharacteristic != null) {
                    SDKLogger.d(true, "readBatteryLevel readCharacteristicSync()");
                    return GlobalGatt2.getInstance().readCharacteristicSync(this.mBluetoothAddress, this.mBatteryLevelCharacteristic);
                } else {
                    SDKLogger.d(true, "mBatteryLevelCharacteristic = null");
                    return false;
                }
            }else{
                if(null != globalGatt2 && globalGatt2.getGatt() != null) {
                    BatteryService2.this.mService = globalGatt2.getGatt().getService(BatteryService2.BATTERY_SERVICE);
                    if (this.mService != null) {
                        BatteryService2.this.mBatteryLevelCharacteristic = BatteryService2.this.mService.getCharacteristic(BatteryService2.BATTERY_LEVEL_CHARACTERISTIC);
                        SDKLogger.d(true, "BATTERY_LEVEL_CHARACTERISTIC not supported or notify enable");
                        if (this.mBatteryLevelCharacteristic != null) {
                            SDKLogger.d(true, "readBatteryLevel1 readCharacteristicSync()");
                            return GlobalGatt2.getInstance().readCharacteristicSync(this.mBluetoothAddress, this.mBatteryLevelCharacteristic);
                        } else {
                            SDKLogger.d(true, "mBatteryLevelCharacteristic = null");
                            return false;
                        }
                    } else {
                        SDKLogger.d(true, "mService = null");
                        return false;
                    }
                }else{
                    return false;
                }
            }
        } else {
            SDKLogger.d(true, "readBatteryLevel2 readCharacteristicSync()");
            return GlobalGatt2.getInstance().readCharacteristicSync(this.mBluetoothAddress, this.mBatteryLevelCharacteristic);
        }
    }

    public boolean setNotificationEnabled(boolean enable) {
        SDKLogger.d(D,"AAAAA setNotificationEnabled");
        if (this.mBatteryLevelCharacteristic == null) {
            SDKLogger.d(true, "BATTERY_LEVEL_CHARACTERISTIC not supported");
            return false;
        } else {
            return GlobalGatt2.getInstance().setCharacteristicNotification(this.mBluetoothAddress, this.mBatteryLevelCharacteristic, enable);
        }
    }

    public int getBatteryValue() {
        return this.mBatteryValue;
    }

    public static boolean memcmp(byte[] data1, byte[] data2, int len) {
        if (data1 == null && data2 == null) {
            return true;
        } else if (data1 != null && data2 != null) {
            if (data1 == data2) {
                return true;
            } else {
                boolean bEquals = true;

                for (int i = 0; i < data1.length && i < data2.length && i < len; ++i) {
                    if (data1[i] != data2[i]) {
                        bEquals = false;
                        break;
                    }
                }

                return bEquals;
            }
        } else {
            return false;
        }
    }

    public interface OnServiceListener {
        void onBatteryLevelChanged(int var1, boolean var2);
    }
}
