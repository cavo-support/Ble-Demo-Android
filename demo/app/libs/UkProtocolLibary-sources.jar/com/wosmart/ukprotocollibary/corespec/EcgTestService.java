package com.wosmart.ukprotocollibary.corespec;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;

import com.wosmart.ukprotocollibary.util.DataConverter;
import com.wosmart.ukprotocollibary.gattlayer.GlobalGatt2;
import com.wosmart.ukprotocollibary.util.SDKLogger;

import java.util.UUID;

public class EcgTestService {
    // LOG
    private static final boolean D = true;
    private static final String TAG = "EcgTestService";

    public static EcgTestService instance;

    // Support Service UUID and Characteristic UUID
    private final static UUID DEBUG_SERVICE_UUID = UUID.fromString("0000e0ff-0000-1000-8000-00805f9b34fb");
    private final static UUID DEBUG_CHARACTERISTIC_NOTIFY_UUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");
    private final static UUID DEBUG_CHARACTERISTIC_WRITE_UUID = UUID.fromString("0000ffe9-0000-1000-8000-00805f9b34fb");

    // Support Service object and Characteristic object
    private BluetoothGattService mEcgTestService;
    private BluetoothGattCharacteristic mNotifyCharac;
    private BluetoothGattCharacteristic mWriteCharac;

    private OnServiceListener mCallback;

    private String mBluetoothAddress;

    public EcgTestService(String addr, OnServiceListener callback) {
        mCallback = callback;
        mBluetoothAddress = addr;
        instance = this;
//        initial();
    }

    public void initial() {
        // register service discovery callback
        SDKLogger.d(D,"EcgTestService init() address="+mBluetoothAddress);
        GlobalGatt2.getInstance().registerCallback(mBluetoothAddress, mGattCallback);
    }

    public static EcgTestService getInstance(){
        return instance;
    }

    /**
     * Send data
     *
     * @param data the data need to send
     */
    public boolean sendData(byte[] data) {
        if (mWriteCharac == null) {
            SDKLogger.w(D, "WRISTBAND_WRITE_CHARACTERISTIC_UUID not supported");
            return false;
        }
        if (!GlobalGatt2.getInstance().isConnected(mBluetoothAddress)) {
            SDKLogger.w(D, "disconnected, addr=" + mBluetoothAddress);
            return false;
        }
        SDKLogger.d(D, "-->> " + DataConverter.bytes2Hex(data));

        // Send the data
        mWriteCharac.setValue(data);
        return GlobalGatt2.getInstance().writeCharacteristic(mBluetoothAddress, mWriteCharac);
//		return true;
    }

    /**
     * When the le services manager close, it must disconnect and close the gatt.
     */
    public void close() {
        GlobalGatt2.getInstance().unRegisterCallback(this.mBluetoothAddress, this.mGattCallback);
    }

    public final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {

        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            SDKLogger.d(D, "mtu=" + mtu + ", status=" + status);
        }


        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            SDKLogger.d(D,"uuid-->"+status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                mEcgTestService = gatt.getService(DEBUG_SERVICE_UUID);
                if (mEcgTestService == null) {
                    SDKLogger.e(D, "ecgtest service not found");
                    return;
                } else {
                    mNotifyCharac = mEcgTestService.getCharacteristic(DEBUG_CHARACTERISTIC_NOTIFY_UUID);
                    if (mNotifyCharac == null) {
                        SDKLogger.e(D, "ecgtest notify characteristic not found");
                        return;
                    } else {
                        SDKLogger.d(D, "ecgtest notify characteristic is found, mPatchCharac: " + mNotifyCharac.getUuid());
                    }
                    mWriteCharac = mEcgTestService.getCharacteristic(DEBUG_CHARACTERISTIC_WRITE_UUID);
                    if (mWriteCharac == null) {
                        SDKLogger.e(D, "ecgtest write characteristic not found");
                        return;
                    } else {
                        SDKLogger.d(D, "ecgtest write characteristic is found, mAppCharac: " + mWriteCharac.getUuid());
                    }
//                    setNotificationEnabled(true);
                }
                //isConnected = true;
            } else {
                SDKLogger.e(D, "Discovery service error: " + status);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            SDKLogger.d(D, "onCharacteristicRead UUID is: " + characteristic.getUuid() + ", addr: " + mBluetoothAddress);
            //if(D) Log.d(TAG, "onCharacteristicRead data value:"+ Arrays.toString(characteristic.getValue()) + ", addr: " +mBluetoothAddress);
            byte[] data = characteristic.getValue();
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (characteristic.getUuid().equals(DEBUG_CHARACTERISTIC_NOTIFY_UUID)) {
                    mCallback.onEcgDataRequest(data);
                }
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);
//            SDKLogger.d(D, "onCharacteristicChanged UUID is: " + characteristic.getUuid() + ", addr: " + mBluetoothAddress);
            byte[] data = characteristic.getValue();
//            SDKLogger.d(D,"data[]-->"+ Arrays.toString(data));
            if (EcgTestService.this.mNotifyCharac != null) {
                if (characteristic.getUuid().equals(DEBUG_CHARACTERISTIC_NOTIFY_UUID)) {
                    mCallback.onEcgDataRequest(data);
                }
            }
        }

        @Override
        public void onCharacteristicWrite(final BluetoothGatt gatt, final BluetoothGattCharacteristic characteristic, final int status) {
            SDKLogger.d(D,"onCharacteristicWrite UUID is:"+characteristic.getUuid());
            if (DEBUG_CHARACTERISTIC_WRITE_UUID.equals(characteristic.getUuid())) {
                mCallback.onEcgDataSend(status == BluetoothGatt.GATT_SUCCESS);
            }
        }
    };


    public boolean setNotificationEnabled(boolean enable) {
        if(null != mNotifyCharac) {
            return GlobalGatt2.getInstance().setEcgTestCharacteristicNotification(mBluetoothAddress, mNotifyCharac, enable);
        } else {
            // 若没有 ecg 服务，ecg 数据会从主服务里返回，此时认为已开启
            return true;
        }
    }

    /**
     * Interface required to be implemented by activity
     */
    public interface OnServiceListener {
        /**
         * on debug data receiver
         *
         * @param data
         */
        void onEcgDataRequest(byte[] data);

        void onEcgDataSend(boolean flag);
    }
}
