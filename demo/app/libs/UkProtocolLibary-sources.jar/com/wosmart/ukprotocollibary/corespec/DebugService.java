package com.wosmart.ukprotocollibary.corespec;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;

import com.wosmart.ukprotocollibary.util.DataConverter;
import com.wosmart.ukprotocollibary.gattlayer.GlobalGatt2;
import com.wosmart.ukprotocollibary.util.SDKLogger;

import java.util.UUID;

public class DebugService {
    // LOG
    private static final boolean D = true;
    private static final String TAG = "DebugService";

    // Support Service UUID and Characteristic UUID
    private final static UUID DEBUG_SERVICE_UUID = UUID.fromString("0000a00a-0000-1000-8000-00805f9b34fb");
    private final static UUID DEBUG_CHARACTERISTIC_NOTIFY_UUID = UUID.fromString("0000b003-0000-1000-8000-00805f9b34fb");
    private final static UUID DEBUG_CHARACTERISTIC_WRITE_UUID = UUID.fromString("0000b002-0000-1000-8000-00805f9b34fb");

    // Support Service object and Characteristic object
    private BluetoothGattService mDebugService;
    private BluetoothGattCharacteristic mNotifyCharac;
    private BluetoothGattCharacteristic mWriteCharac;

    private OnServiceListener mCallback;

    private String mBluetoothAddress;

    private static DebugService instance;

    public DebugService(String addr, OnServiceListener callback) {
        mCallback = callback;
        mBluetoothAddress = addr;
        instance = this;
//        initial();
    }

    public static DebugService getInstance(){
        return instance;
    }

    public void initial() {
        // register service discovery callback
        GlobalGatt2.getInstance().registerCallback(mBluetoothAddress, mGattCallback);
    }

    /**
     * Send data
     *
     * @param data the data need to send
     */
    public boolean sendData(byte[] data) {
        if (mWriteCharac == null) {
            SDKLogger.w(D, "WRISTBAND_WRITE_CHARACTERISTIC_UUID not supported");
            return false;
        }
        if (!GlobalGatt2.getInstance().isConnected(mBluetoothAddress)) {
            SDKLogger.w(D, "disconnected, addr=" + mBluetoothAddress);
            return false;
        }
        SDKLogger.d(D, "-->> " + DataConverter.bytes2Hex(data));

        // Send the data
        mWriteCharac.setValue(data);
        return GlobalGatt2.getInstance().writeCharacteristic(mBluetoothAddress, mWriteCharac);
//		return true;
    }

    /**
     * When the le services manager close, it must disconnect and close the gatt.
     */
    public void close() {
        GlobalGatt2.getInstance().unRegisterCallback(this.mBluetoothAddress, this.mGattCallback);
    }

    public final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {

        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            SDKLogger.d(D, "mtu=" + mtu + ", status=" + status);
        }


        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            SDKLogger.d(D,"uuid-->"+status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                mDebugService = gatt.getService(DEBUG_SERVICE_UUID);
                if (mDebugService == null) {
                    SDKLogger.e(D, "debug service not found");
                    return;
                } else {
                    mNotifyCharac = mDebugService.getCharacteristic(DEBUG_CHARACTERISTIC_NOTIFY_UUID);
                    if (mNotifyCharac == null) {
                        SDKLogger.e(D, "debug notify characteristic not found");
                        return;
                    } else {
                        SDKLogger.d(D, "debug notify characteristic is found, mPatchCharac: " + mNotifyCharac.getUuid());
                    }
                    mWriteCharac = mDebugService.getCharacteristic(DEBUG_CHARACTERISTIC_WRITE_UUID);
                    if (mWriteCharac == null) {
                        SDKLogger.e(D, "debug write characteristic not found");
                        return;
                    } else {
                        SDKLogger.d(D, "debug write characteristic is found, mAppCharac: " + mWriteCharac.getUuid());
                    }
//                    setNotificationEnabled(true);
                }
                //isConnected = true;
            } else {
                SDKLogger.e(D, "Discovery service error: " + status);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
//            SDKLogger.d(D, "onCharacteristicRead UUID is: " + characteristic.getUuid() + ", addr: " + mBluetoothAddress);
            //if(D) Log.d(TAG, "onCharacteristicRead data value:"+ Arrays.toString(characteristic.getValue()) + ", addr: " +mBluetoothAddress);
            SDKLogger.d(D,"uuid-->"+characteristic.getUuid());
            byte[] data = characteristic.getValue();
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (characteristic.getUuid().equals(DEBUG_CHARACTERISTIC_NOTIFY_UUID)) {
                    mCallback.onDataReceiver(data);
                }
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);
//            SDKLogger.d(D, "onCharacteristicChanged UUID is: " + characteristic.getUuid() + ", addr: " + mBluetoothAddress);
//            SDKLogger.d(D,"uuid-->"+characteristic.getUuid());
            byte[] data = characteristic.getValue();
            if (DebugService.this.mNotifyCharac != null) {
                if (characteristic.getUuid().equals(DEBUG_CHARACTERISTIC_NOTIFY_UUID)) {
                    mCallback.onDataReceiver(data);
                }
            }
        }

        @Override
        public void onCharacteristicWrite(final BluetoothGatt gatt, final BluetoothGattCharacteristic characteristic, final int status) {
            SDKLogger.d(D,"uuid-->"+characteristic.getUuid());
            if (DEBUG_CHARACTERISTIC_WRITE_UUID.equals(characteristic.getUuid())) {
                mCallback.onDataSend(status == BluetoothGatt.GATT_SUCCESS);
            }
        }
    };


    public boolean setNotificationEnabled(boolean enable) {
        if(null != mNotifyCharac) {
            return GlobalGatt2.getInstance().setCharacteristicNotification(mBluetoothAddress, mNotifyCharac, enable);
        } else {
            return true;
        }
    }

    /**
     * Interface required to be implemented by activity
     */
    public interface OnServiceListener {
        /**
         * on debug data receiver
         *
         * @param data
         */
        void onDataReceiver(byte[] data);

        void onDataSend(boolean flag);
    }
}
