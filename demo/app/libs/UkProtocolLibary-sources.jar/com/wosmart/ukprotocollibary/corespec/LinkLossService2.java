package com.wosmart.ukprotocollibary.corespec;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;

import com.wosmart.ukprotocollibary.gattlayer.GlobalGatt2;
import com.wosmart.ukprotocollibary.util.OldServiceCallback;
import com.wosmart.ukprotocollibary.util.SDKLogger;

import java.util.Iterator;
import java.util.List;
import java.util.UUID;

public class LinkLossService2 {

    private static LinkLossService2 instance;
    private static final boolean D = true;
    private static final String TAG = "LinkLossService";
    private static final UUID LINK_LOSS_SERVICE = UUID.fromString("00001803-0000-1000-8000-00805f9b34fb");
    private static final UUID ALERT_LEVEL_CHARACTERISTIC = UUID.fromString("00002a06-0000-1000-8000-00805f9b34fb");
    public static final byte ALERT_LEVEL_DISABLE = 0;
    public static final byte ALERT_LEVEL_ENABLE_WITH_LED = 1;
    public static final byte ALERT_LEVEL_ENABLE_WITH_LED_BUZZER = 2;
    private byte mAlertLevel = 0;
    private BluetoothGattService mService;
    private BluetoothGattCharacteristic mAlertLevelCharac;
    private OldServiceCallback mCallback;
    private String mBluetoothAddress;
    public final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == 0) {
                LinkLossService2.this.mService = gatt.getService(LinkLossService2.LINK_LOSS_SERVICE);
                if (LinkLossService2.this.mService == null) {
                    SDKLogger.d(true, "LINK_LOSS_SERVICE not supported");
                } else {
                    LinkLossService2.this.mAlertLevelCharac = LinkLossService2.this.mService.getCharacteristic(LinkLossService2.ALERT_LEVEL_CHARACTERISTIC);
                    if (LinkLossService2.this.mAlertLevelCharac == null) {
                        SDKLogger.d(true, "ALERT_LEVEL_CHARACTERISTIC_UUID not supported");
                    } else {
                        SDKLogger.d(true, "ALERT_LEVEL_CHARACTERISTIC_UUID: " + LinkLossService2.this.mAlertLevelCharac.getUuid());
                        LinkLossService2.this.mAlertLevelCharac.setWriteType(2);
                        List<BluetoothGattDescriptor> gattDescriptors = LinkLossService2.this.mAlertLevelCharac.getDescriptors();
                        if (gattDescriptors != null && gattDescriptors.size() > 0) {
                            Iterator var4 = gattDescriptors.iterator();

                            while (var4.hasNext()) {
                                BluetoothGattDescriptor descriptor = (BluetoothGattDescriptor) var4.next();
                                SDKLogger.d("descriptor : " + descriptor.getUuid().toString());
                            }
                        }
                    }
                }
            }

        }

        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            SDKLogger.d(D,"uuid-->"+characteristic.getUuid());
            byte[] data = characteristic.getValue();
            if (status == 0) {
                if (LinkLossService2.this.mAlertLevelCharac != null && LinkLossService2.ALERT_LEVEL_CHARACTERISTIC.equals(characteristic.getUuid())) {
                    LinkLossService2.this.mAlertLevel = data[0];
                    SDKLogger.d(true, "mAlertLevel=" + LinkLossService2.this.mAlertLevel);
                    if (LinkLossService2.this.mCallback != null) {
                        LinkLossService2.this.mCallback.onLinkLossAlertLevelChanged(LinkLossService2.this.mAlertLevel);
                    }
                }
            } else {
                SDKLogger.d(true, "Characteristic read error: " + status);
            }

        }
    };

    public LinkLossService2(String addr, OldServiceCallback callback) {
        this.mCallback = callback;
        this.mBluetoothAddress = addr;
        instance = this;
//        this.initial();
    }

    public static LinkLossService2 getInstance(){
        return instance;
    }

    public void initial() {
        GlobalGatt2.getInstance().registerCallback(this.mBluetoothAddress, this.mGattCallback);
    }

    public void close() {
        GlobalGatt2.getInstance().unRegisterCallback(this.mBluetoothAddress, this.mGattCallback);
    }

    public boolean isAlertEnabled() {
        if (this.mService != null && this.mAlertLevelCharac != null) {
            return this.mAlertLevel != 0;
        } else {
            return false;
        }
    }

    public boolean isMidAlertEnabled() {
        if (this.mService != null && this.mAlertLevelCharac != null) {
            return this.mAlertLevel == 1;
        } else {
            return false;
        }
    }

    public boolean isHighAlertEnabled() {
        if (this.mService != null && this.mAlertLevelCharac != null) {
            return this.mAlertLevel == 2;
        } else {
            return false;
        }
    }

    public byte getAlertLevel() {
        return this.mAlertLevel;
    }

    public boolean readAlertLevel() {
        if (this.mAlertLevelCharac == null) {
            SDKLogger.d(true, "ALERT_LEVEL_CHARACTERISTIC_UUID not supported");
            return false;
        } else {
            SDKLogger.d(true, "read alert info.");
            return GlobalGatt2.getInstance().readCharacteristic(this.mBluetoothAddress, this.mAlertLevelCharac);
        }
    }

    public boolean setAlertLevel(byte level) {
        return this.setAlertLevel(this.mBluetoothAddress, level);
    }

    public boolean setAlertLevel(String addr, byte level) {
        if (this.mAlertLevelCharac == null) {
            SDKLogger.d(true, "ALERT_LEVEL_CHARACTERISTIC not supported");
            return false;
        } else {
            byte[] data = new byte[]{level};
            this.mAlertLevelCharac.setValue(data);
            this.mAlertLevel = level;
            return GlobalGatt2.getInstance().writeCharacteristicSync(addr, this.mAlertLevelCharac);
        }
    }

    public boolean setAlertEnabled(boolean enable) {
        SDKLogger.d(true, "enable: " + enable);
        if (this.mAlertLevelCharac == null) {
            SDKLogger.d(true, "ALERT_LEVEL_CHARACTERISTIC_UUID not supported");
            return false;
        } else {
            byte[] data;
            if (enable) {
                data = new byte[]{2};
                this.mAlertLevelCharac.setValue(data);
            } else {
                data = new byte[]{0};
                this.mAlertLevelCharac.setValue(data);
            }

            return GlobalGatt2.getInstance().writeCharacteristicSync(this.mBluetoothAddress, this.mAlertLevelCharac);
        }
    }

    public interface OnServiceListener {
        void onLinkLossAlertLevelChanged(byte var1);
    }
}
