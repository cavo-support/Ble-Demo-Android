package com.wosmart.ukprotocollibary.corespec;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;

import com.wosmart.ukprotocollibary.gattlayer.GlobalGatt2;
import com.wosmart.ukprotocollibary.util.SDKLogger;

import java.util.Iterator;
import java.util.List;
import java.util.UUID;

public class HeartRateService {
    private static final boolean D = true;
    private static final String TAG = "HeartRateService";
    private static final UUID HEART_RATE_SERVICE = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb");
    private static final UUID HEART_RATE_MEASUREMENT_CHARACTERISTIC = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb");
    public static final UUID CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private BluetoothGattService mService;
    private BluetoothGattCharacteristic mHeartRateCharacteristic;
    private int mHeartRateValue = -1;
    private HeartRateService.OnServiceListener mCallback;
    private String mBluetoothAddress;
    private static HeartRateService instance;

    public final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            SDKLogger.d(D,"uuid-->"+status);
            if (status == 0) {
                HeartRateService.this.mService = gatt.getService(HeartRateService.HEART_RATE_SERVICE);
                if (HeartRateService.this.mService == null) {
                    SDKLogger.d("HEART_RATE_SERVICE not supported");
                } else {
                    HeartRateService.this.mHeartRateCharacteristic = HeartRateService.this.mService.getCharacteristic(HeartRateService.HEART_RATE_MEASUREMENT_CHARACTERISTIC);
                    if (HeartRateService.this.mHeartRateCharacteristic == null) {
                        SDKLogger.d("HEART_RATE_CHARACTERISTIC not supported");
                    } else {
                        SDKLogger.d(true, "find HEART_RATE_CHARACTERISTIC: " + HeartRateService.HEART_RATE_MEASUREMENT_CHARACTERISTIC);
                        List<BluetoothGattDescriptor> gattDescriptors = HeartRateService.this.mHeartRateCharacteristic.getDescriptors();
                        if (gattDescriptors != null && gattDescriptors.size() > 0) {
                            Iterator var4 = gattDescriptors.iterator();

                            while (var4.hasNext()) {
                                BluetoothGattDescriptor descriptor = (BluetoothGattDescriptor) var4.next();
                                SDKLogger.d("descriptor : " + descriptor.getUuid().toString());
                            }
                        }
                    }
                }
            }
        }

        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
//            SDKLogger.d(D,"uuid-->"+characteristic.getUuid());
            byte[] data = characteristic.getValue();
            if (HeartRateService.this.mHeartRateCharacteristic != null) {
                if (HeartRateService.HEART_RATE_MEASUREMENT_CHARACTERISTIC.equals(characteristic.getUuid())) {
                    HeartRateService.this.mHeartRateValue = ((data[0] & 0xff) << 8) | (data[1] & 0xff);
                    SDKLogger.d(true, "mHeartRateValue=" + HeartRateService.this.mHeartRateValue);
                    if (HeartRateService.this.mCallback != null) {
                        HeartRateService.this.mCallback.onHeartRateChanged(HeartRateService.this.mHeartRateValue, true);
                    }
                }
            }
        }

        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            SDKLogger.d(D,"uuid-->"+characteristic.getUuid());
            byte[] data = characteristic.getValue();
            if (status == 0) {
                if (HeartRateService.HEART_RATE_MEASUREMENT_CHARACTERISTIC.equals(characteristic.getUuid())) {
                    HeartRateService.this.mHeartRateValue = ((data[0] & 0xff) << 8) | (data[1] & 0xff);
                    SDKLogger.d(true, "mHeartRateValue=" + HeartRateService.this.mHeartRateValue);
                    if (HeartRateService.this.mCallback != null) {
                        HeartRateService.this.mCallback.onHeartRateChanged(HeartRateService.this.mHeartRateValue, false);
                    }
                }
            } else {
                SDKLogger.d(true, "Characteristic read error: " + status);
            }

        }

        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
//            SDKLogger.d(D,"uuid-->"+descriptor.getCharacteristic().getUuid());
            if (status == 0) {
                if (HeartRateService.CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR.equals(descriptor.getCharacteristic().getUuid()) && HeartRateService.CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR.equals(descriptor.getUuid())) {
                    SDKLogger.d(true, "CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR write OK.");
                }
            } else {
                SDKLogger.d(true, "Descriptor write error: " + status);
            }

        }
    };

    public HeartRateService(String addr, HeartRateService.OnServiceListener callback) {
        this.mCallback = callback;
        this.mBluetoothAddress = addr;
        instance = this;
//        this.initial();
    }

    public static HeartRateService getInstance(){
        return instance;
    }

    public void initial() {
        GlobalGatt2.getInstance().registerCallback(this.mBluetoothAddress, this.mGattCallback);
    }

    public void close() {
        GlobalGatt2.getInstance().unRegisterCallback(this.mBluetoothAddress, this.mGattCallback);
    }

    public boolean readHeartRate() {
        if (this.mHeartRateCharacteristic == null) {
            SDKLogger.d(true, "HEART_RATE_CHARACTERISTIC not supported");
            return false;
        } else {
            SDKLogger.d(true, "HeartRateService readCharacteristicSync()");
            return GlobalGatt2.getInstance().readCharacteristicSync(this.mBluetoothAddress, this.mHeartRateCharacteristic);
        }
    }

    public boolean setNotificationEnabled(boolean enable) {
        SDKLogger.d(D,"AAAAA setNotificationEnabled");
        if (this.mHeartRateCharacteristic == null) {
            SDKLogger.d(true, "HEART_RATE_CHARACTERISTIC not supported");
            return false;
        } else {
            return GlobalGatt2.getInstance().setCharacteristicNotificationSync(this.mBluetoothAddress, this.mHeartRateCharacteristic, CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR, enable);
        }
    }

    public int getmHeartRateValue() {
        return mHeartRateValue;
    }

    public static boolean memcmp(byte[] data1, byte[] data2, int len) {
        if (data1 == null && data2 == null) {
            return true;
        } else if (data1 != null && data2 != null) {
            if (data1 == data2) {
                return true;
            } else {
                boolean bEquals = true;

                for (int i = 0; i < data1.length && i < data2.length && i < len; ++i) {
                    if (data1[i] != data2[i]) {
                        bEquals = false;
                        break;
                    }
                }

                return bEquals;
            }
        } else {
            return false;
        }
    }

    public interface OnServiceListener {
        void onHeartRateChanged(int var1, boolean var2);
    }
}
