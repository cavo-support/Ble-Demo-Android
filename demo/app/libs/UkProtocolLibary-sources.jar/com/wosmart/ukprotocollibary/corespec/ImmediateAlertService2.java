package com.wosmart.ukprotocollibary.corespec;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;

import com.wosmart.ukprotocollibary.gattlayer.GlobalGatt2;
import com.wosmart.ukprotocollibary.util.SDKLogger;

import java.util.Iterator;
import java.util.List;
import java.util.UUID;

public class ImmediateAlertService2 {

    private static ImmediateAlertService2 instance;
    private static final boolean D = true;
    private static final String TAG = "ImmediateAlertService";
    private static final UUID IMMEDIATE_ALERT_SERVICE = UUID.fromString("00001802-0000-1000-8000-00805f9b34fb");
    private static final UUID ALERT_LEVEL_CHARACTERISTIC = UUID.fromString("00002a06-0000-1000-8000-00805f9b34fb");
    public static final byte ALERT_LEVEL_DISABLE = 0;
    public static final byte ALERT_LEVEL_ENABLE_WITH_LED = 1;
    public static final byte ALERT_LEVEL_ENABLE_WITH_LED_BUZZER = 2;
    private byte mAlertLevel = 0;
    private BluetoothGattService mService;
    private BluetoothGattCharacteristic mAlertLevelCharacteristic;
    private Object mLock = new Object();
    private volatile boolean isGetInfo = false;
    private final int LOCK_WAIT_TIME = 5000;
    private String mBluetoothAddress;
    public final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == 0) {
                ImmediateAlertService2.this.mService = gatt.getService(ImmediateAlertService2.IMMEDIATE_ALERT_SERVICE);
                if (ImmediateAlertService2.this.mService == null) {
                    SDKLogger.d(true, "IMMEDIATE_ALERT_SERVICE not supported");
                } else {
                    ImmediateAlertService2.this.mAlertLevelCharacteristic = ImmediateAlertService2.this.mService.getCharacteristic(ImmediateAlertService2.ALERT_LEVEL_CHARACTERISTIC);
                    if (ImmediateAlertService2.this.mAlertLevelCharacteristic == null) {
                        SDKLogger.d(true, "ALERT_LEVEL_CHARACTERISTIC not supported");
                    } else {
                        SDKLogger.d(true, "find ALERT_LEVEL_CHARACTERISTIC : " + ImmediateAlertService2.ALERT_LEVEL_CHARACTERISTIC);
                        ImmediateAlertService2.this.mAlertLevelCharacteristic.setWriteType(1);
                        List<BluetoothGattDescriptor> gattDescriptors = ImmediateAlertService2.this.mAlertLevelCharacteristic.getDescriptors();
                        if (gattDescriptors != null && gattDescriptors.size() > 0) {
                            Iterator var4 = gattDescriptors.iterator();

                            while(var4.hasNext()) {
                                BluetoothGattDescriptor descriptor = (BluetoothGattDescriptor)var4.next();
                                SDKLogger.d("descriptor : " + descriptor.getUuid().toString());
                            }
                        }
                    }
                }
            }
        }
    };

    public ImmediateAlertService2(String addr) {
        this.mBluetoothAddress = addr;
        instance = this;
//        this.initial();
    }

    public static ImmediateAlertService2 getInstance(){
        return instance;
    }

    public void initial() {
        GlobalGatt2.getInstance().registerCallback(this.mBluetoothAddress, this.mGattCallback);
    }

    public void close() {
        GlobalGatt2.getInstance().unRegisterCallback(this.mBluetoothAddress, this.mGattCallback);
    }

    public boolean setAlertLevel(byte level) {
        return this.setAlertLevel(this.mBluetoothAddress, level);
    }

    public boolean setAlertLevel(String addr, byte level) {
        if (this.mAlertLevelCharacteristic == null) {
            SDKLogger.d(true, "ALERT_LEVEL_CHARACTERISTIC not supported");
            ImmediateAlertService2.this.mService = GlobalGatt2.getInstance().getGatt().getService(ImmediateAlertService2.IMMEDIATE_ALERT_SERVICE);
            if(this.mService != null){
                ImmediateAlertService2.this.mAlertLevelCharacteristic = ImmediateAlertService2.this.mService.getCharacteristic(ImmediateAlertService2.ALERT_LEVEL_CHARACTERISTIC);
                if(this.mAlertLevelCharacteristic != null){
                    byte[] data = new byte[]{level};
                    this.mAlertLevelCharacteristic.setValue(data);
                    this.mAlertLevel = level;
                    return GlobalGatt2.getInstance().writeCharacteristicSync(addr, this.mAlertLevelCharacteristic);
                }else{
                    SDKLogger.d(true, "mAlertLevelCharacteristic = null");
                    return false;
                }
            }else{
                SDKLogger.d(true, "mService = null");
                return false;
            }
        } else {
            byte[] data = new byte[]{level};
            this.mAlertLevelCharacteristic.setValue(data);
            this.mAlertLevel = level;
            return GlobalGatt2.getInstance().writeCharacteristicSync(addr, this.mAlertLevelCharacteristic);
        }
    }

    public boolean setAlertLevelEnabled(boolean enabled) {
        return this.setAlertLevelEnabled(this.mBluetoothAddress, enabled);
    }

    public boolean setAlertLevelEnabled(String mBluetoothAddress, boolean enabled) {
        SDKLogger.d(true, "enabled=" + enabled);
        byte level;
        if (enabled) {
            level = 2;
        } else {
            level = 0;
        }

        return this.setAlertLevel(mBluetoothAddress, level);
    }
}
