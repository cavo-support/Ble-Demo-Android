package com.wosmart.ukprotocollibary.model.db;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.AbstractDaoSession;
import org.greenrobot.greendao.Property;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseStatement;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.List;

public class BodyFatDataDao extends AbstractDao<JWBodyFatInfo, Long> {

    public static final String TABLENAME = "BODY_FAT_DATA";


    public static class Properties {
        public final static Property time = new Property(0, Long.class, "time", true, "TIME");
        public final static Property userID = new Property(1, String.class, "userID", true, "USER_ID");
        public final static Property mac = new Property(2, String.class, "mac", true, "MAC");
        public final static Property date = new Property(3, java.util.Date.class, "date", false, "DATE");
        public final static Property weight = new Property(4, int.class, "weight", false, "WEIGHT");
        public final static Property weightLevel = new Property(5, int.class, "weightLevel", false, "WEIGHT_LEVEL");
        public final static Property weightMaxLevel = new Property(6, int.class, "weightMaxLevel", false, "WEIGHT_MAX_LEVEL");
        public final static Property bmi = new Property(7, int.class, "bmi", false, "BMI");
        public final static Property bmiLevel = new Property(8, int.class, "bmiLevel", false, "BMI_LEVEL");
        public final static Property bmiMaxLevel = new Property(9, int.class, "bmiMaxLevel", false, "BMI_MAX_LEVEL");
        public final static Property bmr = new Property(10, int.class, "bmr", false, "BMR");
        public final static Property bmrLevel = new Property(11, int.class, "bmrLevel", false, "BMR_LEVEL");
        public final static Property bmrMaxLevel = new Property(12, int.class, "bmrMaxLevel", false, "BMR_MAX_LEVEL");
        public final static Property bodyFat = new Property(13, int.class, "bodyFat", false, "BODY_FAT_RATE");
        public final static Property bodyFatLevel = new Property(14, int.class, "bodyFatLevel", false, "BODY_FAT_RATE_LEVEL");
        public final static Property bodyFatMaxLevel = new Property(15, int.class, "bodyFatMaxLevel", false, "BODY_FAT_RATE_MAX_LEVEL");
        public final static Property bodyWater = new Property(16, int.class, "bodyWater", false, "BODY_WATER");
        public final static Property bodyWaterLevel = new Property(17, int.class, "bodyWaterLevel", false, "BODY_WATER_LEVEL");
        public final static Property bodyWaterMaxLevel = new Property(18, int.class, "bodyWaterMaxLevel", false, "BODY_WATER_MAX_LEVEL");
        public final static Property protein = new Property(19, int.class, "protein", false, "PROTEIN");
        public final static Property proteinLevel = new Property(20, int.class, "proteinLevel", false, "PROTEIN_LEVEL");
        public final static Property proteinMaxLevel = new Property(21, int.class, "proteinMaxLevel", false, "PROTEIN_MAX_LEVEL");
        public final static Property boneMass = new Property(22, int.class, "boneMass", false, "BONE_MASS");
        public final static Property boneMassLevel = new Property(23, int.class, "boneMassLevel", false, "BONE_MASS_LEVEL");
        public final static Property boneMassMaxLevel = new Property(24, int.class, "boneMassMaxLevel", false, "BONE_MASS_MAX_LEVEL");
        public final static Property muscle = new Property(25, int.class, "muscle", false, "MUSCLE_RATE");
        public final static Property muscleLevel = new Property(26, int.class, "muscleLevel", false, "MUSCLE_RATE_LEVEL");
        public final static Property muscleMaxLevel = new Property(27, int.class, "muscleMaxLevel", false, "MUSCLE_RATE_MAX_LEVEL");
    }

    public BodyFatDataDao(DaoConfig config) {
        super(config);
    }

    public BodyFatDataDao(DaoConfig config, AbstractDaoSession daoSession) {
        super(config, daoSession);
    }

    public JWBodyFatInfo queryRecentData(String userID, String mac, long timeBegin) {
        String timeColName = Properties.time.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;
        String dateColName = Properties.date.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition = (timeColName + " >= " + timeBegin);

        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");
        String macCondition = TextUtils.isEmpty(mac) ? "" : (" " + macColName + " = '" + mac + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        if (!TextUtils.isEmpty(macCondition)) {
            sb.append(" and ").append(macCondition);
        }
        sb.append(")");

        String orderBy = " ORDER BY " + dateColName + " ASC ";

        sb.append(orderBy);

        List<JWBodyFatInfo> bodyFatInfoList = queryRaw(sb.toString());
        if (bodyFatInfoList == null || bodyFatInfoList.isEmpty()) {
            return null;
        }
        JWBodyFatInfo recentBodyFat = null;
        for (JWBodyFatInfo bodyFatInfo : bodyFatInfoList) {
            if (recentBodyFat == null || bodyFatInfo.time > recentBodyFat.time) {
                recentBodyFat = bodyFatInfo;
            }
        }

        return recentBodyFat;
    }

    public List<JWBodyFatInfo> queryDataList(String userID, String mac, long timeBegin, long timePeriod, int count) {
        String timeColName = Properties.time.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;
        String dateColName = Properties.date.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition;
        if (timeBegin == 0) {
            // 从当前时间
            timeCondition = timeColName + " <= " + System.currentTimeMillis();
        } else {
            timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));
        }
        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");
        String macCondition = TextUtils.isEmpty(mac) ? "" : (" " + macColName + " = '" + mac + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        if (!TextUtils.isEmpty(macCondition)) {
            sb.append(" and ").append(macCondition);
        }
        sb.append(")");

        String orderBy = "ORDER BY " + dateColName + " ASC";
        String limit = count == 0 ? "" : (" LIMIT " + count);

        sb.append(orderBy);
        sb.append(limit);

        return queryRaw(sb.toString());
    }



    public void deleteByTime(String userID, String mac, long timeBegin, long timePeriod) {
        String timeColName = Properties.time.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;

        String timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));

        StringBuilder sb = new StringBuilder();

        sb.append("DELETE FROM " + TABLENAME + " WHERE ");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userID)) {
            sb.append(" and ").append(userIDColName).append(" = '").append(userID).append("' ");
        }
        if (!TextUtils.isEmpty(mac)) {
            sb.append(" and ").append(macColName).append(" = '").append(mac).append("' ");
        }

        GlobalGreenDAO.getInstance().getSQLDatabase().execSQL(sb.toString());
    }






    public static void createTable(Database db) {
        db.execSQL("create table IF NOT EXISTS " + TABLENAME + "\n" +
                "(\n" +
                Properties.time.columnName + " bigint not null ,\n" +
                Properties.userID.columnName + " varchar(256) not null ,\n" +
                Properties.mac.columnName + " varchar(256) ,\n" +
                Properties.date.columnName + " varchar(50) not null ,\n" +
                Properties.weight.columnName + " int not null ,\n" +
                Properties.weightLevel.columnName + " int not null ,\n" +
                Properties.weightMaxLevel.columnName + " int not null ,\n" +
                Properties.bmi.columnName + " int not null ,\n" +
                Properties.bmiLevel.columnName + " int not null ,\n" +
                Properties.bmiMaxLevel.columnName + " int not null ,\n" +
                Properties.bmr.columnName + " int not null ,\n" +
                Properties.bmrLevel.columnName + " int not null ,\n" +
                Properties.bmrMaxLevel.columnName + " int not null ,\n" +
                Properties.bodyFat.columnName + " int not null ,\n" +
                Properties.bodyFatLevel.columnName + " int not null ,\n" +
                Properties.bodyFatMaxLevel.columnName + " int not null ,\n" +
                Properties.bodyWater.columnName + " int not null ,\n" +
                Properties.bodyWaterLevel.columnName + " int not null ,\n" +
                Properties.bodyWaterMaxLevel.columnName + " int not null ,\n" +
                Properties.protein.columnName + " int not null ,\n" +
                Properties.proteinLevel.columnName + " int not null ,\n" +
                Properties.proteinMaxLevel.columnName + " int not null ,\n" +
                Properties.boneMass.columnName + " int not null ,\n" +
                Properties.boneMassLevel.columnName + " int not null ,\n" +
                Properties.boneMassMaxLevel.columnName + " int not null ,\n" +
                Properties.muscle.columnName + " int not null ,\n" +
                Properties.muscleLevel.columnName + " int not null ,\n" +
                Properties.muscleMaxLevel.columnName + " int not null ,\n" +
                " primary key (" + Properties.time.columnName + ", " + Properties.userID.columnName + ")\n" +
                ");");
    }

    public static void dropTable(Database db) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
    }

    @Override
    protected JWBodyFatInfo readEntity(Cursor cursor, int offset) {
        long time = cursor.getLong(offset + Properties.time.ordinal);
        String userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        String mac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        int weight = cursor.getInt(offset + Properties.weight.ordinal);
        int weightLevel = cursor.getInt(offset + Properties.weightLevel.ordinal);
        int weightMaxLevel = cursor.getInt(offset + Properties.weightMaxLevel.ordinal);
        int bmi = cursor.getInt(offset + Properties.bmi.ordinal);
        int bmiLevel = cursor.getInt(offset + Properties.bmiLevel.ordinal);
        int bmiMaxLevel = cursor.getInt(offset + Properties.bmiMaxLevel.ordinal);
        int bmr = cursor.getInt(offset + Properties.bmr.ordinal);
        int bmrLevel = cursor.getInt(offset + Properties.bmrLevel.ordinal);
        int bmrMaxLevel = cursor.getInt(offset + Properties.bmrMaxLevel.ordinal);
        int bodyFat = cursor.getInt(offset + Properties.bodyFat.ordinal);
        int bodyFatLevel = cursor.getInt(offset + Properties.bodyFatLevel.ordinal);
        int bodyFatMaxLevel = cursor.getInt(offset + Properties.bodyFatMaxLevel.ordinal);
        int bodyWater = cursor.getInt(offset + Properties.bodyWater.ordinal);
        int bodyWaterLevel = cursor.getInt(offset + Properties.bodyWaterLevel.ordinal);
        int bodyWaterMaxLevel = cursor.getInt(offset + Properties.bodyWaterMaxLevel.ordinal);
        int protein = cursor.getInt(offset + Properties.protein.ordinal);
        int proteinLevel = cursor.getInt(offset + Properties.proteinLevel.ordinal);
        int proteinMaxLevel = cursor.getInt(offset + Properties.proteinMaxLevel.ordinal);
        int boneMass = cursor.getInt(offset + Properties.boneMass.ordinal);
        int boneMassLevel = cursor.getInt(offset + Properties.boneMassLevel.ordinal);
        int boneMassMaxLevel = cursor.getInt(offset + Properties.boneMassMaxLevel.ordinal);
        int muscle = cursor.getInt(offset + Properties.muscle.ordinal);
        int muscleLevel = cursor.getInt(offset + Properties.muscleLevel.ordinal);
        int muscleMaxLevel = cursor.getInt(offset + Properties.muscleMaxLevel.ordinal);

        JWBodyFatInfo info = new JWBodyFatInfo();
        info.setTime(time);
        info.setUserID(userID);
        info.setDeviceMac(mac);

        info.weight = JWUtils.parserRound(1, weight / 10f);
        info.weightLevel = weightLevel;
        info.weightMaxLevel = weightMaxLevel;
        info.bmi = JWUtils.parserRound(1, bmi / 10f);
        info.bmiLevel = bmiLevel;
        info.bmiMaxLevel = bmiMaxLevel;
        info.bmr = JWUtils.parserRound(1, bmr / 10f);
        info.bmrLevel = bmrLevel;
        info.bmrMaxLevel = bmrMaxLevel;
        info.bodyFat = JWUtils.parserRound(1, bodyFat / 10f);
        info.bodyFatLevel = bodyFatLevel;
        info.bodyFatMaxLevel = bodyFatMaxLevel;
        info.bodyWater = JWUtils.parserRound(1, bodyWater / 10f);
        info.bodyWaterLevel = bodyWaterLevel;
        info.bodyWaterMaxLevel = bodyWaterMaxLevel;
        info.protein = JWUtils.parserRound(1, protein / 10f);
        info.proteinLevel = proteinLevel;
        info.proteinMaxLevel = proteinMaxLevel;
        info.boneMass = JWUtils.parserRound(1, boneMass / 10f);
        info.boneMassLevel = boneMassLevel;
        info.boneMassMaxLevel = boneMassMaxLevel;
        info.muscle = JWUtils.parserRound(1, muscle / 10f);
        info.muscleLevel = muscleLevel;
        info.muscleMaxLevel = muscleMaxLevel;

        return info;
    }

    @Override
    protected Long readKey(Cursor cursor, int offset) {
        return cursor.getLong(offset);
    }

    @Override
    protected void readEntity(Cursor cursor, JWBodyFatInfo info, int offset) {
        long time = cursor.getLong(offset + Properties.time.ordinal);
        String userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        String mac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        int weight = cursor.getInt(offset + Properties.weight.ordinal);
        int weightLevel = cursor.getInt(offset + Properties.weightLevel.ordinal);
        int weightMaxLevel = cursor.getInt(offset + Properties.weightMaxLevel.ordinal);
        int bmi = cursor.getInt(offset + Properties.bmi.ordinal);
        int bmiLevel = cursor.getInt(offset + Properties.bmiLevel.ordinal);
        int bmiMaxLevel = cursor.getInt(offset + Properties.bmiMaxLevel.ordinal);
        int bmr = cursor.getInt(offset + Properties.bmr.ordinal);
        int bmrLevel = cursor.getInt(offset + Properties.bmrLevel.ordinal);
        int bmrMaxLevel = cursor.getInt(offset + Properties.bmrMaxLevel.ordinal);
        int bodyFat = cursor.getInt(offset + Properties.bodyFat.ordinal);
        int bodyFatLevel = cursor.getInt(offset + Properties.bodyFatLevel.ordinal);
        int bodyFatMaxLevel = cursor.getInt(offset + Properties.bodyFatMaxLevel.ordinal);
        int bodyWater = cursor.getInt(offset + Properties.bodyWater.ordinal);
        int bodyWaterLevel = cursor.getInt(offset + Properties.bodyWaterLevel.ordinal);
        int bodyWaterMaxLevel = cursor.getInt(offset + Properties.bodyWaterMaxLevel.ordinal);
        int protein = cursor.getInt(offset + Properties.protein.ordinal);
        int proteinLevel = cursor.getInt(offset + Properties.proteinLevel.ordinal);
        int proteinMaxLevel = cursor.getInt(offset + Properties.proteinMaxLevel.ordinal);
        int boneMass = cursor.getInt(offset + Properties.boneMass.ordinal);
        int boneMassLevel = cursor.getInt(offset + Properties.boneMassLevel.ordinal);
        int boneMassMaxLevel = cursor.getInt(offset + Properties.boneMassMaxLevel.ordinal);
        int muscle = cursor.getInt(offset + Properties.muscle.ordinal);
        int muscleLevel = cursor.getInt(offset + Properties.muscleLevel.ordinal);
        int muscleMaxLevel = cursor.getInt(offset + Properties.muscleMaxLevel.ordinal);

        info.setTime(time);
        info.setUserID(userID);
        info.setDeviceMac(mac);

        info.weight = JWUtils.parserRound(1, weight / 10f);
        info.weightLevel = weightLevel;
        info.weightMaxLevel = weightMaxLevel;
        info.bmi = JWUtils.parserRound(1, bmi / 10f);
        info.bmiLevel = bmiLevel;
        info.bmiMaxLevel = bmiMaxLevel;
        info.bmr = JWUtils.parserRound(1, bmr / 10f);
        info.bmrLevel = bmrLevel;
        info.bmrMaxLevel = bmrMaxLevel;
        info.bodyFat = JWUtils.parserRound(1, bodyFat / 10f);
        info.bodyFatLevel = bodyFatLevel;
        info.bodyFatMaxLevel = bodyFatMaxLevel;
        info.bodyWater = JWUtils.parserRound(1, bodyWater / 10f);
        info.bodyWaterLevel = bodyWaterLevel;
        info.bodyWaterMaxLevel = bodyWaterMaxLevel;
        info.protein = JWUtils.parserRound(1, protein / 10f);
        info.proteinLevel = proteinLevel;
        info.proteinMaxLevel = proteinMaxLevel;
        info.boneMass = JWUtils.parserRound(1, boneMass / 10f);
        info.boneMassLevel = boneMassLevel;
        info.boneMassMaxLevel = boneMassMaxLevel;
        info.muscle = JWUtils.parserRound(1, muscle / 10f);
        info.muscleLevel = muscleLevel;
        info.muscleMaxLevel = muscleMaxLevel;
    }

    @Override
    protected void bindValues(DatabaseStatement stmt, JWBodyFatInfo info) {

    }

    @Override
    protected void bindValues(SQLiteStatement stmt, JWBodyFatInfo info) {
        stmt.clearBindings();

        stmt.bindLong(Properties.time.ordinal + 1, info.time);
        stmt.bindString(Properties.userID.ordinal + 1, TextUtils.isEmpty(info.userID) ? "" : info.userID);
        stmt.bindString(Properties.mac.ordinal + 1, TextUtils.isEmpty(info.deviceMac) ? "" : info.deviceMac);
        stmt.bindString(Properties.date.ordinal + 1, DateUtil.toTime2(info.time));
        stmt.bindLong(Properties.weight.ordinal + 1, (long) (info.weight * 10));
        stmt.bindLong(Properties.weightLevel.ordinal + 1, info.weightLevel);
        stmt.bindLong(Properties.weightMaxLevel.ordinal + 1, info.weightMaxLevel);
        stmt.bindLong(Properties.bmi.ordinal + 1, (long) (info.bmi * 10));
        stmt.bindLong(Properties.bmiLevel.ordinal + 1, info.bmiLevel);
        stmt.bindLong(Properties.bmiMaxLevel.ordinal + 1, info.bmiMaxLevel);
        stmt.bindLong(Properties.bmr.ordinal + 1, (long) (info.bmr * 10));
        stmt.bindLong(Properties.bmrLevel.ordinal + 1, info.bmrLevel);
        stmt.bindLong(Properties.bmrMaxLevel.ordinal + 1, info.bmrMaxLevel);
        stmt.bindLong(Properties.bodyFat.ordinal + 1, (long) (info.bodyFat * 10));
        stmt.bindLong(Properties.bodyFatLevel.ordinal + 1, info.bodyFatLevel);
        stmt.bindLong(Properties.bodyFatMaxLevel.ordinal + 1, info.bodyFatMaxLevel);
        stmt.bindLong(Properties.bodyWater.ordinal + 1, (long) (info.bodyWater * 10));
        stmt.bindLong(Properties.bodyWaterLevel.ordinal + 1, info.bodyWaterLevel);
        stmt.bindLong(Properties.bodyWaterMaxLevel.ordinal + 1, info.bodyWaterMaxLevel);
        stmt.bindLong(Properties.protein.ordinal + 1, (long) (info.protein * 10));
        stmt.bindLong(Properties.proteinLevel.ordinal + 1, info.proteinLevel);
        stmt.bindLong(Properties.proteinMaxLevel.ordinal + 1, info.proteinMaxLevel);
        stmt.bindLong(Properties.boneMass.ordinal + 1, (long) (info.boneMass * 10));
        stmt.bindLong(Properties.boneMassLevel.ordinal + 1, info.boneMassLevel);
        stmt.bindLong(Properties.boneMassMaxLevel.ordinal + 1, info.boneMassMaxLevel);
        stmt.bindLong(Properties.muscle.ordinal + 1, (long) (info.muscle * 10));
        stmt.bindLong(Properties.muscleLevel.ordinal + 1, info.muscleLevel);
        stmt.bindLong(Properties.muscleMaxLevel.ordinal + 1, info.muscleMaxLevel);
    }

    @Override
    protected Long updateKeyAfterInsert(JWBodyFatInfo info, long rowID) {
        return info.time;
    }

    @Override
    protected Long getKey(JWBodyFatInfo info) {
        return info.time;
    }

    @Override
    protected boolean hasKey(JWBodyFatInfo info) {
        return false;
    }

    @Override
    protected boolean isEntityUpdateable() {
        return true;
    }
}
