package com.wosmart.ukprotocollibary.model.sleep.filter;

import android.text.format.Time;

import java.util.Calendar;

public class SleepTimeData {
    public int year;
    public int day;
    public int month;
    public int hour;
    public int minute;
    public int second;
    public int weekDay;

    public SleepTimeData() {
    }

    public SleepTimeData(int var1, int var2) {
        this.hour = var1;
        this.minute = var2;
    }

    public SleepTimeData(int var1, int var2, int var3) {
        this.year = var1;
        this.month = var2;
        this.day = var3;
    }

    public SleepTimeData(int var1, int var2, int var3, int var4) {
        this(Calendar.getInstance().get(1), var1, var2, var3, var4);
    }

    public SleepTimeData(int var1, int var2, int var3, int var4, int var5) {
        this.year = var1;
        this.month = var2;
        this.day = var3;
        this.hour = var4;
        this.minute = var5;
    }

    public SleepTimeData(int var1, int var2, int var3, int var4, int var5, int var6) {
        this.year = var1;
        this.month = var2;
        this.day = var3;
        this.hour = var4;
        this.minute = var5;
        this.second = var6;
    }

    public SleepTimeData(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
        this(var1, var2, var3, var4, var5);
        this.second = var6;
        this.weekDay = var7;
    }

    public int getSecond() {
        return this.second;
    }

    public void setSecond(int var1) {
        this.second = var1;
    }

    public int getWeekDay() {
        return this.weekDay;
    }

    public void setWeekDay(int var1) {
        this.weekDay = var1;
    }

    public int getYear() {
        return this.year;
    }

    public void setYear(int var1) {
        this.year = var1;
    }

    public int getDay() {
        return this.day;
    }

    public void setDay(int var1) {
        this.day = var1;
    }

    public int getMonth() {
        return this.month;
    }

    public void setMonth(int var1) {
        this.month = var1;
    }

    public int getHour() {
        return this.hour;
    }

    public void setHour(int var1) {
        this.hour = var1;
    }

    public int getMinute() {
        return this.minute;
    }

    public void setMinute(int var1) {
        this.minute = var1;
    }

    public String getColck() {
        return getTwoStr(this.getHour()) + ":" + getTwoStr(this.getMinute());
    }

    public String getColckAndSecond() {
        return getTwoStr(this.getHour()) + ":" + getTwoStr(this.getMinute()) + ":" + getTwoStr(this.getSecond());
    }

    public String getColck12() {
        int var1 = this.getHour();
        String var2 = "am";
        if (this.getHour() < 12) {
            var2 = "am";
        } else {
            var2 = "pm";
        }

        if (this.getHour() == 0) {
            var1 = 12;
        }

        if (this.getHour() > 12) {
            var1 %= 12;
        }

        return getTwoStr(var1) + ":" + getTwoStr(this.getMinute()) + var2;
    }

    public String getColckForADC() {
        return getTwoStr(this.getHour()) + "_" + getTwoStr(this.getMinute());
    }

    public String getDate() {
        return getTwoStr(this.getMonth()) + "-" + getTwoStr(this.getDay());
    }

    public String getDateADC() {
        return getTwoStr(this.getMonth()) + "_" + getTwoStr(this.getDay());
    }

    public static String getTwoStr(int var0) {
        String var1 = var0 + "";
        if (var1.length() < 2) {
            var1 = "0" + var1;
        }

        return var1;
    }

    public int getHMValue() {
        boolean var1 = false;
        int var2 = this.hour * 60 + this.minute;
        return var2;
    }

    public String getDateForSleepshow() {
        return this.getDate() + " " + this.getColck();
    }

    public String getDateForSleepshow12() {
        return this.getDate() + " " + this.getColck12();
    }

    public String getDateForDb() {
        int var1 = this.getYear();
        if (var1 == 0) {
            var1 = Calendar.getInstance().get(1);
        }

        return var1 + "-" + this.getDate();
    }

    public String getDateForADC() {
        int var1 = this.getYear();
        if (var1 == 0) {
            var1 = Calendar.getInstance().get(1);
        }

        return var1 + "_" + this.getDateADC();
    }

    public String getNullDateForDb() {
        return Calendar.getInstance().get(1) + "-255-255";
    }

    public String getDateAndClockForDb() {
        return this.getDateForDb() + "-" + this.getColck();
    }

    public String getDateAndClockAndSecondForDb() {
        return this.getDateForDb() + "-" + this.getColckAndSecond();
    }

    public String getDateAndClockForADC() {
        return this.getDateForADC() + "_" + this.getColckForADC();
    }

    public String getDateAndClockForSleep() {
        return this.getDateForDb() + " " + this.getColck();
    }

    public String getDateAndClockForSleepSecond() {
        return this.getDateForDb() + " " + this.getColckAndSecond();
    }

    public static int getSysMonth() {
        Time var0 = new Time();
        var0.setToNow();
        int var1 = var0.month + 1;
        return var1;
    }

    public static int getSysYear() {
        Time var0 = new Time();
        var0.setToNow();
        int var1 = var0.year;
        return var1;
    }

    public static int getSysDay() {
        Time var0 = new Time();
        var0.setToNow();
        int var1 = var0.monthDay;
        return var1;
    }

    public static int getSysHour() {
        Time var0 = new Time();
        var0.setToNow();
        int var1 = var0.hour;
        return var1;
    }

    public static int getSysMiute() {
        Time var0 = new Time();
        var0.setToNow();
        int var1 = var0.minute;
        return var1;
    }

    public static int getSysSecond() {
        Time var0 = new Time();
        var0.setToNow();
        int var1 = var0.second;
        return var1;
    }

    public void setCurrentTime() {
        Calendar var1 = Calendar.getInstance();
        this.year = var1.get(1);
        this.month = var1.get(2) + 1;
        this.day = var1.get(5);
        this.hour = var1.get(11);
        this.minute = var1.get(12);
        this.second = var1.get(13);
    }

    public String toString() {
        return "TimeData [" + this.getDateAndClockForSleepSecond() + "]";
    }
}
