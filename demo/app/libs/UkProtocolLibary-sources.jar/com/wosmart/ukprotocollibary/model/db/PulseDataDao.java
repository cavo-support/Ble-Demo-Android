package com.wosmart.ukprotocollibary.model.db;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.entity.JWPulseInfo;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.AbstractDaoSession;
import org.greenrobot.greendao.Property;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseStatement;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.List;

public class PulseDataDao extends AbstractDao<JWPulseInfo, Long> {

    public static final String TABLENAME = "PULSE_DATA";


    public static class Properties {
        public final static Property startTime = new Property(0, Long.class, "startTime", true, "START_TIME");
        public final static Property userID = new Property(1, String.class, "userID", true, "USER_ID");
        public final static Property mac = new Property(2, String.class, "mac", false, "MAC");
        public final static Property date = new Property(3, java.util.Date.class, "date", false, "DATE");
        public final static Property duration = new Property(4, int.class, "duration", false, "MODE");
    }

    public PulseDataDao(DaoConfig config) {
        super(config);
    }

    public PulseDataDao(DaoConfig config, AbstractDaoSession daoSession) {
        super(config, daoSession);
    }








    public List<JWPulseInfo> queryDataList(long timeBegin, long timePeriod) {
        String startTimeColName = Properties.startTime.columnName;
        String dateColName = Properties.date.columnName;

        String whereStr = "where ("
                + startTimeColName + ">=?"
                + " and " + startTimeColName + "<=?)";
        String orderBy = " ORDER BY " + dateColName + " ASC ";
        String[] selectionArg = {String.valueOf(timeBegin), String.valueOf(timeBegin + timePeriod)};
        return queryRaw(whereStr + " " + orderBy, selectionArg);
    }

    public List<JWPulseInfo> queryDataList(String userID, String mac, long timeBegin, long timePeriod, int count) {
        String timeColName = Properties.startTime.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;
        String dateColName = Properties.date.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition;
        if (timeBegin == 0) {
            // 从当前时间
            timeCondition = timeColName + " <= " + System.currentTimeMillis();
        } else {
            timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));
        }
        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");
        String macCondition = TextUtils.isEmpty(mac) ? "" : (" " + macColName + " = '" + mac + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        if (!TextUtils.isEmpty(macCondition)) {
            sb.append(" and ").append(macCondition);
        }
        sb.append(")");

        String orderBy = " ORDER BY " + dateColName + " ASC ";
        String limit = count == 0 ? "" : (" LIMIT " + count);

        sb.append(orderBy);
        sb.append(limit);

        return queryRaw(sb.toString());
    }




    public void deleteByTime(String userID, String mac, long timeBegin, long timePeriod) {
        String timeColName = Properties.startTime.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;

        String timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));

        StringBuilder sb = new StringBuilder();

        sb.append("DELETE FROM " + TABLENAME + " WHERE ");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userID)) {
            sb.append(" and ").append(userIDColName).append(" = '").append(userID).append("' ");
        }
        if (!TextUtils.isEmpty(mac)) {
            sb.append(" and ").append(macColName).append(" = '").append(mac).append("' ");
        }

        GlobalGreenDAO.getInstance().getSQLDatabase().execSQL(sb.toString());
    }






    public static void createTable(Database db) {
        db.execSQL("create table IF NOT EXISTS " + TABLENAME + "\n" +
                "(\n" +
                Properties.startTime.columnName + " bigint not null ,\n" +
                Properties.userID.columnName + " varchar(256) not null ,\n" +
                Properties.mac.columnName + " varchar(256) ,\n" +
                Properties.date.columnName + " varchar(50) not null ,\n" +
                Properties.duration.columnName + " int not null ,\n" +
                " primary key (" + Properties.startTime.columnName + ", " + Properties.userID.columnName + ")\n" +
                ");");
    }

    public static void dropTable(Database db) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
    }

    public static void addMacAddressCol(Database db) {
        try {
            String sql = "AlTER TABLE " + TABLENAME + " Add COLUMN " + Properties.mac.columnName + " varchar(256)";
            db.execSQL(sql);
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
    }

    @Override
    protected JWPulseInfo readEntity(Cursor cursor, int offset) {
        long startTime = cursor.getLong(offset + Properties.startTime.ordinal);
        String userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        String mac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        int mode = cursor.getInt(offset + Properties.duration.ordinal);
        return new JWPulseInfo(userID, mac, startTime, mode);
    }

    @Override
    protected Long readKey(Cursor cursor, int offset) {
        return cursor.getLong(offset);
    }

    @Override
    protected void readEntity(Cursor cursor, JWPulseInfo info, int offset) {
        info.startTime = cursor.getLong(offset + Properties.startTime.ordinal);
        info.userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        info.deviceMac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        info.duration = cursor.getInt(offset + Properties.duration.ordinal);
    }

    @Override
    protected void bindValues(DatabaseStatement stmt, JWPulseInfo info) {

    }

    @Override
    protected void bindValues(SQLiteStatement stmt, JWPulseInfo info) {
        stmt.clearBindings();

        stmt.bindLong(Properties.startTime.ordinal + 1, info.startTime);
        stmt.bindString(Properties.userID.ordinal + 1, TextUtils.isEmpty(info.userID) ? "" : info.userID);
        stmt.bindString(Properties.mac.ordinal + 1, TextUtils.isEmpty(info.deviceMac) ? "" : info.deviceMac);
        stmt.bindString(Properties.date.ordinal + 1, DateUtil.toTime2(info.startTime));
        stmt.bindLong(Properties.duration.ordinal + 1, info.duration);
    }

    @Override
    protected Long updateKeyAfterInsert(JWPulseInfo info, long rowID) {
        return info.startTime;
    }

    @Override
    protected Long getKey(JWPulseInfo info) {
        return info.startTime;
    }

    @Override
    protected boolean hasKey(JWPulseInfo info) {
        return false;
    }

    @Override
    protected boolean isEntityUpdateable() {
        return true;
    }
}
