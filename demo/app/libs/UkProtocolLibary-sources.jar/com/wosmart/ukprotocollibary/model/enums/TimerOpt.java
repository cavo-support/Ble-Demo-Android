package com.wosmart.ukprotocollibary.model.enums;

public enum TimerOpt {

    /**
     * setting timer
     */
    SETTING,

    /**
     * start timer
     */
    BEGIN,

    /**
     * step timer
     */
    END

}
