package com.wosmart.ukprotocollibary.model.sport;


import java.util.Date;

/**
 * step data
 * use for save step data into database，not for sport exercise data
 */
public class SportData implements Comparable<SportData> {

    /**
     * id
     */
    private Long id;

    /**
     * year
     */
    private int year;

    /**
     * month
     */
    private int month;

    /**
     * day
     */
    private int day;

    /**
     * offset id
     * The device calculates the step data every 15 minutes，offset ID is （minutes of day） / 15
     */
    private int offset;

    /**
     * step model
     * not used ,always is 0
     */
    private int mode;

    /**
     * step count
     */
    private int stepCount;

    /**
     * active time
     * not used, always is 0
     */
    private int activeTime;

    /**
     * calories unit calc
     */
    private int calory;

    /**
     * distance unit m
     */
    private int distance;

    /**
     * date
     */
    private java.util.Date date;

    private String userID;

    public SportData() {
    }

    public SportData(Long id) {
        this.id = id;
    }

//    public SportData(Long id, int year, int month, int day, int offset, int mode, int stepCount, int activeTime, int calory, int distance, java.util.Date date) {
//        this.id = id;
//        this.year = year;
//        this.month = month;
//        this.day = day;
//        this.offset = offset;
//        this.mode = mode;
//        this.stepCount = stepCount;
//        this.activeTime = activeTime;
//        this.calory = calory;
//        this.distance = distance;
//        this.date = date;
//    }

    public SportData(Long id, int year, int month, int day, int offset, int mode, int stepCount, int activeTime, int calory, int distance, Date date, String userID) {
        this.id = id;
        this.year = year;
        this.month = month;
        this.day = day;
        this.offset = offset;
        this.mode = mode;
        this.stepCount = stepCount;
        this.activeTime = activeTime;
        this.calory = calory;
        this.distance = distance;
        this.date = date;
        this.userID = userID;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

    public int getStepCount() {
        return stepCount;
    }

    public void setStepCount(int stepCount) {
        this.stepCount = stepCount;
    }

    public int getActiveTime() {
        return activeTime;
    }

    public void setActiveTime(int activeTime) {
        this.activeTime = activeTime;
    }

    public int getCalory() {
        return calory;
    }

    public void setCalory(int calory) {
        this.calory = calory;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public java.util.Date getDate() {
        return date;
    }

    public void setDate(java.util.Date date) {
        this.date = date;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    @Override
    public String toString() {
        return "SportData{" +
                "id=" + id +
                ", year=" + year +
                ", month=" + month +
                ", day=" + day +
                ", offset=" + offset +
                ", mode=" + mode +
                ", stepCount=" + stepCount +
                ", activeTime=" + activeTime +
                ", calory=" + calory +
                ", distance=" + distance +
                ", date=" + date +
                ", userID=" + userID +
                '}';
    }

    @Override
    public int compareTo(SportData o) {
        return Integer.compare(this.offset, o.offset);
    }
}
