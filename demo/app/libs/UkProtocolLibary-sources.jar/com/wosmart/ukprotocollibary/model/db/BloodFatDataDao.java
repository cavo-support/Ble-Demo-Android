package com.wosmart.ukprotocollibary.model.db;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidInfo;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.AbstractDaoSession;
import org.greenrobot.greendao.Property;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseStatement;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.ArrayList;
import java.util.List;

public class BloodFatDataDao extends AbstractDao<BloodFatInfo, Long> {

    public static final String TABLENAME = "BLOOD_FAT_DATA";

    public static class Properties {
        public final static Property cycleStartTime = new Property(0, Long.class, "cycleStartTime", true, "CYCLE_START_TIME");
        public final static Property userID = new Property(1, String.class, "userID", true, "USER_ID");
        public final static Property mac = new Property(2, String.class, "mac", false, "MAC");
        public final static Property date = new Property(3, java.util.Date.class, "date", false, "DATE");
        public final static Property valueTime = new Property(4, Long.class, "valueTime", false, "VALUE_TIME");
        public final static Property cycleEndTime = new Property(5, Long.class, "cycleEndTime", false, "CYCLE_END_TIME");
        public final static Property evaluationResult = new Property(6, int.class, "evaluationResult", false, "EVALUATION_RESULT");
        public final static Property dayStatusList = new Property(7, int.class, "dayStatusList", false, "DAY_STATUS_LIST");
    }

    public BloodFatDataDao(DaoConfig config) {
        super(config);
    }

    public BloodFatDataDao(DaoConfig config, AbstractDaoSession daoSession) {
        super(config, daoSession);
    }

    public void clearInvalidData(String deviceMac) {
        if (TextUtils.isEmpty(deviceMac)) {
            return;
        }
        long curTime = System.currentTimeMillis();

        String valueTimeColName = Properties.valueTime.columnName;
        String macColName = Properties.mac.columnName;

        String sql = "UPDATE " + TABLENAME + " SET " +
                Properties.valueTime.columnName + " = -1, " +
                Properties.cycleEndTime.columnName + " = " + curTime + ", " +
                Properties.evaluationResult.columnName + " = " + JWUricAcidInfo.RESULT_CODE_INSUFFICIENT_WEARING_TIME +
                " WHERE " +
                macColName + " = '" + deviceMac + "' " +
                " and " + valueTimeColName + " = 0";
        GlobalGreenDAO.getInstance().getSQLDatabase().execSQL(sql);
    }

    public BloodFatInfo queryRecentData(String userID, String mac, long timeBegin) {
        String endTimeColName = Properties.cycleEndTime.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;
        String dateColName = Properties.date.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition = (endTimeColName + " >= " + timeBegin);
        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");
        String macCondition = TextUtils.isEmpty(mac) ? "" : (" " + macColName + " = '" + mac + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        if (!TextUtils.isEmpty(macCondition)) {
            sb.append(" and ").append(macCondition);
        }
        sb.append(")");

        String orderBy = " ORDER BY " + dateColName + " ASC ";

        sb.append(orderBy);

        List<BloodFatInfo> bloodFatInfoList = queryRaw(sb.toString());
        if (bloodFatInfoList == null || bloodFatInfoList.isEmpty()) {
            return null;
        }
        BloodFatInfo recentBloodFat = null;
        for (BloodFatInfo bloodFatInfo : bloodFatInfoList) {
            if (recentBloodFat == null || bloodFatInfo.cycleStartTime > recentBloodFat.cycleStartTime) {
                recentBloodFat = bloodFatInfo;
            }
        }

        return recentBloodFat;
    }

    private BloodFatInfo queryData(String userID, String mac, long timeBegin) {
        String startTimeColName = Properties.cycleStartTime.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;
        String dateColName = Properties.date.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition = (startTimeColName + " = " + timeBegin);
        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");
        String macCondition = TextUtils.isEmpty(mac) ? "" : (" " + macColName + " = '" + mac + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        if (!TextUtils.isEmpty(macCondition)) {
            sb.append(" and ").append(macCondition);
        }
        sb.append(")");

        String orderBy = " ORDER BY " + dateColName + " ASC ";

        sb.append(orderBy);

        List<BloodFatInfo> bloodFatInfoList = queryRaw(sb.toString());
        if (bloodFatInfoList == null || bloodFatInfoList.isEmpty()) {
            return null;
        }
        BloodFatInfo recentBloodFat = null;
        for (BloodFatInfo bloodFatInfo : bloodFatInfoList) {
            if (recentBloodFat == null || bloodFatInfo.cycleStartTime > recentBloodFat.cycleStartTime) {
                recentBloodFat = bloodFatInfo;
            }
        }

        return recentBloodFat;
    }

    public void saveDataList(List<BloodFatInfo> dataList) {
        if (dataList == null || dataList.isEmpty()) {
            return;
        }

        List<BloodFatInfo> saveDataList = new ArrayList<>();
        for (BloodFatInfo info : dataList) {
            BloodFatInfo dbInfo = queryData(info.userID, info.deviceMac, info.cycleStartTime);
            if (dbInfo == null || dbInfo.dayStatusList <= info.dayStatusList) {
                // 本地无或者本地周期比当前周期小
                saveDataList.add(info);
            }
        }
        insertOrReplaceInTx(saveDataList);
    }


    public List<BloodFatInfo> queryDataList(String userID, String mac, long timeBegin, long timePeriod, int count) {
        String timeColName = Properties.cycleStartTime.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;
        String dateColName = Properties.date.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition;
        if (timeBegin == 0) {
            // 从当前时间
            timeCondition = timeColName + " <= " + System.currentTimeMillis();
        } else {
            timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));
        }
        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");
        String macCondition = TextUtils.isEmpty(mac) ? "" : (" " + macColName + " = '" + mac + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        if (!TextUtils.isEmpty(macCondition)) {
            sb.append(" and ").append(macCondition);
        }
        sb.append(")");

        String orderBy = " ORDER BY " + dateColName + " ASC ";
        String limit = count == 0 ? "" : (" LIMIT " + count);

        sb.append(orderBy);
        sb.append(limit);

        return queryRaw(sb.toString());
    }


    public void deleteByTime(String userID, String mac, long timeBegin, long timePeriod) {
        String timeColName = Properties.cycleStartTime.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;

        String timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));

        StringBuilder sb = new StringBuilder();

        sb.append("DELETE FROM " + TABLENAME + " WHERE ");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userID)) {
            sb.append(" and ").append(userIDColName).append(" = '").append(userID).append("' ");
        }
        if (!TextUtils.isEmpty(mac)) {
            sb.append(" and ").append(macColName).append(" = '").append(mac).append("' ");
        }

        GlobalGreenDAO.getInstance().getSQLDatabase().execSQL(sb.toString());
    }

    
    public static void createTable(Database db) {
        db.execSQL("create table IF NOT EXISTS " + TABLENAME + "\n" +
                "(\n" +
                Properties.cycleStartTime.columnName + " bigint not null ,\n" +
                Properties.userID.columnName + " varchar(256) not null ,\n" +
                Properties.mac.columnName + " varchar(256) ,\n" +
                Properties.date.columnName + " varchar(50) not null ,\n" +
                Properties.valueTime.columnName + " bigint ,\n" +
                Properties.cycleEndTime.columnName + " bigint not null ,\n" +
                Properties.evaluationResult.columnName + " int not null ,\n" +
                Properties.dayStatusList.columnName + " int not null ,\n" +
                " primary key (" + Properties.cycleStartTime.columnName + ", " + Properties.userID.columnName + ")\n" +
                ");");
    }

    public static void dropTable(Database db) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
    }




    @Override
    protected BloodFatInfo readEntity(Cursor cursor, int offset) {
        BloodFatInfo info = new BloodFatInfo();

        info.cycleStartTime = cursor.getLong(offset + Properties.cycleStartTime.ordinal);
        info.userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        info.deviceMac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        info.valueTime = cursor.getLong(offset + Properties.valueTime.ordinal);
        info.cycleEndTime = cursor.getLong(offset + Properties.cycleEndTime.ordinal);
        info.evaluationResult = cursor.getInt(offset + Properties.evaluationResult.ordinal);
        info.dayStatusList = cursor.getInt(offset + Properties.dayStatusList.ordinal);

        return info;
    }


    @Override
    protected Long readKey(Cursor cursor, int offset) {
        return cursor.getLong(offset);
    }

    @Override
    protected void readEntity(Cursor cursor, BloodFatInfo info, int offset) {
        info.cycleStartTime = cursor.getLong(offset + Properties.cycleStartTime.ordinal);
        info.userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        info.deviceMac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        info.valueTime = cursor.getLong(offset + Properties.valueTime.ordinal);
        info.cycleEndTime = cursor.getLong(offset + Properties.cycleEndTime.ordinal);
        info.evaluationResult = cursor.getInt(offset + Properties.evaluationResult.ordinal);
        info.dayStatusList = cursor.getInt(offset + Properties.dayStatusList.ordinal);
    }

    @Override
    protected void bindValues(DatabaseStatement stmt, BloodFatInfo info) {

    }

    @Override
    protected void bindValues(SQLiteStatement stmt, BloodFatInfo info) {
        stmt.clearBindings();

        stmt.bindLong(Properties.cycleStartTime.ordinal + 1, info.cycleStartTime);
        stmt.bindString(Properties.userID.ordinal + 1, TextUtils.isEmpty(info.userID) ? "" : info.userID);
        stmt.bindString(Properties.mac.ordinal + 1, TextUtils.isEmpty(info.deviceMac) ? "" : info.deviceMac);
        stmt.bindString(Properties.date.ordinal + 1, DateUtil.toTime2(info.cycleStartTime));
        stmt.bindLong(Properties.valueTime.ordinal + 1, info.valueTime);
        stmt.bindLong(Properties.cycleEndTime.ordinal + 1, info.cycleEndTime);
        stmt.bindLong(Properties.evaluationResult.ordinal + 1, info.evaluationResult);
        stmt.bindLong(Properties.dayStatusList.ordinal + 1, info.dayStatusList);
    }

    @Override
    protected Long updateKeyAfterInsert(BloodFatInfo info, long rowID) {
        return info.cycleStartTime;
    }

    @Override
    protected Long getKey(BloodFatInfo info) {
        return info.cycleStartTime;
    }

    @Override
    protected boolean hasKey(BloodFatInfo info) {
        return false;
    }

    @Override
    protected boolean isEntityUpdateable() {
        return true;
    }


}
