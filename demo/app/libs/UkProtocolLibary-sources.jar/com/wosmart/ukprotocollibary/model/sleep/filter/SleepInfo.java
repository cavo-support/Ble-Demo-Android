package com.wosmart.ukprotocollibary.model.sleep.filter;


public class SleepInfo {

    /**
     * 睡眠类型 1精准睡眠 默认0 深浅睡眠
     * 1 precise sleep
     * 0 depp or light sleep
     */
    private int sleepType;

    /**
     * 日期 date
     */
    private String date;

    /**
     * 无用 never use
     */
    private int cali_flag;

    /**
     * 睡眠质量 sleep quality
     */
    private int sleepQuality;

    /**
     * 苏醒次数 times of awakening
     */
    private int wakeCount;

    /**
     * 深睡时长，单位分钟 deep sleep time, unit min
     */
    private int deepSleepTime;

    /**
     * 浅睡时长，单位分钟 light sleep time, unit min
     */
    private int lowSleepTime;

    /**
     * 睡眠总时长，单位分钟,  unit min
     */
    private int allSleepTime;

    /**
     * 睡眠监测时间
     */
    private int span;

    /**
     * 入睡时间 sleep latency
     */
    private SleepTimeData sleepDown;

    /**
     * 起床时间 wake up time
     */
    private SleepTimeData sleepUp;

    /**
     * 睡眠标志
     */
    private int sleepTag;

    /**
     * 起夜得分
     */
    private int getUpScore;

    /**
     * 深睡夜得分
     */
    private int deepScore;

    /**
     * 睡眠效率得分，起夜到深睡的效率得分
     */
    private int sleepEfficiencyScore;

    /**
     * 入睡效率得分，从开始睡眠到第一次进入深睡的效率
     */
    private int fallAsleepScore;

    /**
     * 睡眠时长得分
     */
    private int sleepTimeScore;

    /**
     * 退出睡眠得分
     */
    private int exitSleepScore;

    /**
     * 退出睡眠的模式
     */
    private int exitSleepMode;

    /**
     * 深浅睡眠模式
     */
    private int deepAndLightMode;

    /**
     * 起夜总时长，单位分钟
     */
    private int getUpDuration;

    /**
     * 其他睡眠时间长，单位分钟
     */
    private int otherDuration;

    /**
     * 第一次进入深睡时间
     */
    private int firstDeepDuration;

    /**
     * 起夜到深睡时间的平均值
     */
    private int getUpToDeepAvg;

    /**
     * 曲线上一个点代表的时间，单位秒，现在是60s
     */
    private int onePointDuration;

    /**
     * 睡眠类型 1精准睡眠 0深浅睡眠
     */
    private int accurateType;

    /**
     * 失眠标志
     */
    private int insomniaTag;

    /**
     * 失眠得分
     */
    private int insomniaScore;

    /**
     * 失眠次数
     */
    private int insomniaTimes;

    /**
     * 失眠长度
     */
    private int insomniaLength;

    /**
     * 失眠开始时间
     */
    private String startInsomniaTime;

    /**
     * 失眠结束时间
     */
    private String stopInsomniaTime;

    /**
     * 失眠时长
     */
    private int insomniaDuration;

    public SleepInfo() {

    }


    public int getSleepType() {
        return sleepType;
    }

    public void setSleepType(int sleepType) {
        this.sleepType = sleepType;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getCali_flag() {
        return cali_flag;
    }

    public void setCali_flag(int cali_flag) {
        this.cali_flag = cali_flag;
    }

    public int getSleepQuality() {
        return sleepQuality;
    }

    public void setSleepQuality(int sleepQuality) {
        this.sleepQuality = sleepQuality;
    }

    public int getWakeCount() {
        return wakeCount;
    }

    public void setWakeCount(int wakeCount) {
        this.wakeCount = wakeCount;
    }

    public int getDeepSleepTime() {
        return deepSleepTime;
    }

    public void setDeepSleepTime(int deepSleepTime) {
        this.deepSleepTime = deepSleepTime;
    }

    public int getLowSleepTime() {
        return lowSleepTime;
    }

    public void setLowSleepTime(int lowSleepTime) {
        this.lowSleepTime = lowSleepTime;
    }

    public int getAllSleepTime() {
        return allSleepTime;
    }

    public void setAllSleepTime(int allSleepTime) {
        this.allSleepTime = allSleepTime;
    }

    public SleepTimeData getSleepDown() {
        return sleepDown;
    }

    public void setSleepDown(SleepTimeData sleepDown) {
        this.sleepDown = sleepDown;
    }

    public SleepTimeData getSleepUp() {
        return sleepUp;
    }

    public void setSleepUp(SleepTimeData sleepUp) {
        this.sleepUp = sleepUp;
    }

    public int getSpan() {
        return span;
    }

    public void setSpan(int span) {
        this.span = span;
    }

    public int getSleepTag() {
        return sleepTag;
    }

    public void setSleepTag(int sleepTag) {
        this.sleepTag = sleepTag;
    }

    public int getGetUpScore() {
        return getUpScore;
    }

    public void setGetUpScore(int getUpScore) {
        this.getUpScore = getUpScore;
    }

    public int getDeepScore() {
        return deepScore;
    }

    public void setDeepScore(int deepScore) {
        this.deepScore = deepScore;
    }

    public int getSleepEfficiencyScore() {
        return sleepEfficiencyScore;
    }

    public void setSleepEfficiencyScore(int sleepEfficiencyScore) {
        this.sleepEfficiencyScore = sleepEfficiencyScore;
    }

    public int getFallAsleepScore() {
        return fallAsleepScore;
    }

    public void setFallAsleepScore(int fallAsleepScore) {
        this.fallAsleepScore = fallAsleepScore;
    }

    public int getSleepTimeScore() {
        return sleepTimeScore;
    }

    public void setSleepTimeScore(int sleepTimeScore) {
        this.sleepTimeScore = sleepTimeScore;
    }

    public int getExitSleepScore() {
        return exitSleepScore;
    }

    public void setExitSleepScore(int exitSleepScore) {
        this.exitSleepScore = exitSleepScore;
    }

    public int getExitSleepMode() {
        return exitSleepMode;
    }

    public void setExitSleepMode(int exitSleepMode) {
        this.exitSleepMode = exitSleepMode;
    }

    public int getDeepAndLightMode() {
        return deepAndLightMode;
    }

    public void setDeepAndLightMode(int deepAndLightMode) {
        this.deepAndLightMode = deepAndLightMode;
    }

    public int getGetUpDuration() {
        return getUpDuration;
    }

    public void setGetUpDuration(int getUpDuration) {
        this.getUpDuration = getUpDuration;
    }

    public int getOtherDuration() {
        return otherDuration;
    }

    public void setOtherDuration(int otherDuration) {
        this.otherDuration = otherDuration;
    }

    public int getFirstDeepDuration() {
        return firstDeepDuration;
    }

    public void setFirstDeepDuration(int firstDeepDuration) {
        this.firstDeepDuration = firstDeepDuration;
    }

    public int getGetUpToDeepAvg() {
        return getUpToDeepAvg;
    }

    public void setGetUpToDeepAvg(int getUpToDeepAvg) {
        this.getUpToDeepAvg = getUpToDeepAvg;
    }

    public int getOnePointDuration() {
        return onePointDuration;
    }

    public void setOnePointDuration(int onePointDuration) {
        this.onePointDuration = onePointDuration;
    }

    public int getAccurateType() {
        return accurateType;
    }

    public void setAccurateType(int accurateType) {
        this.accurateType = accurateType;
    }

    public int getInsomniaTag() {
        return insomniaTag;
    }

    public void setInsomniaTag(int insomniaTag) {
        this.insomniaTag = insomniaTag;
    }

    public int getInsomniaScore() {
        return insomniaScore;
    }

    public void setInsomniaScore(int insomniaScore) {
        this.insomniaScore = insomniaScore;
    }

    public int getInsomniaTimes() {
        return insomniaTimes;
    }

    public void setInsomniaTimes(int insomniaTimes) {
        this.insomniaTimes = insomniaTimes;
    }

    public int getInsomniaLength() {
        return insomniaLength;
    }

    public void setInsomniaLength(int insomniaLength) {
        this.insomniaLength = insomniaLength;
    }

    public String getStartInsomniaTime() {
        return startInsomniaTime;
    }

    public void setStartInsomniaTime(String startInsomniaTime) {
        this.startInsomniaTime = startInsomniaTime;
    }

    public String getStopInsomniaTime() {
        return stopInsomniaTime;
    }

    public void setStopInsomniaTime(String stopInsomniaTime) {
        this.stopInsomniaTime = stopInsomniaTime;
    }

    public int getInsomniaDuration() {
        return insomniaDuration;
    }

    public void setInsomniaDuration(int insomniaDuration) {
        this.insomniaDuration = insomniaDuration;
    }

    @Override
    public String toString() {
        return "SleepInfo{" +
                "sleepType=" + sleepType +
                ", date='" + date + '\'' +
                ", cali_flag=" + cali_flag +
                ", sleepQuality=" + sleepQuality +
                ", wakeCount=" + wakeCount +
                ", deepSleepTime=" + deepSleepTime +
                ", lowSleepTime=" + lowSleepTime +
                ", allSleepTime=" + allSleepTime +
                ", span=" + span +
                ", sleepDown=" + sleepDown +
                ", sleepUp=" + sleepUp +
                ", sleepTag=" + sleepTag +
                ", getUpScore=" + getUpScore +
                ", deepScore=" + deepScore +
                ", sleepEfficiencyScore=" + sleepEfficiencyScore +
                ", fallAsleepScore=" + fallAsleepScore +
                ", sleepTimeScore=" + sleepTimeScore +
                ", exitSleepScore=" + exitSleepScore +
                ", exitSleepMode=" + exitSleepMode +
                ", deepAndLightMode=" + deepAndLightMode +
                ", getUpDuration=" + getUpDuration +
                ", otherDuration=" + otherDuration +
                ", firstDeepDuration=" + firstDeepDuration +
                ", getUpToDeepAvg=" + getUpToDeepAvg +
                ", onePointDuration=" + onePointDuration +
                ", accurateType=" + accurateType +
                ", insomniaTag=" + insomniaTag +
                ", insomniaScore=" + insomniaScore +
                ", insomniaTimes=" + insomniaTimes +
                ", insomniaLength=" + insomniaLength +
                ", startInsomniaTime='" + startInsomniaTime + '\'' +
                ", stopInsomniaTime='" + stopInsomniaTime + '\'' +
                ", insomniaDuration=" + insomniaDuration +
                '}';
    }
}
