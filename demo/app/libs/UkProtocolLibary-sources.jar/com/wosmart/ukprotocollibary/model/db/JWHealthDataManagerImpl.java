package com.wosmart.ukprotocollibary.model.db;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.BaseConstants;
import com.wosmart.ukprotocollibary.v2.JWCallback;
import com.wosmart.ukprotocollibary.v2.JWHealthDataDeleteParams;
import com.wosmart.ukprotocollibary.v2.JWHealthDataSearchParams;
import com.wosmart.ukprotocollibary.v2.JWValueCallback;
import com.wosmart.ukprotocollibary.v2.common.JWLog;
import com.wosmart.ukprotocollibary.v2.common.executor.JWArchTaskExecutor;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRMovementInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHealthData;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateVariabilityInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPulseInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSaunaInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSleepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSpO2Info;
import com.wosmart.ukprotocollibary.v2.entity.JWSportInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWStepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWearingTimeInfo;

import java.util.List;

public class JWHealthDataManagerImpl extends JWHealthDataManager {

    private static final String TAG = "JWHealthDataManagerImpl";

    public static JWHealthDataManagerImpl getInstance() {
        return JWHealthDataManagerImplHolder.dataManagerImpl;
    }

    @Override
    public void deleteAllHealthDataByDate(String userID, String deviceMac, int year, int month, int day, final JWCallback callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                GlobalGreenDAO.getInstance().deleteAllHealthDataByDate(userID, deviceMac, year, month, day);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess();
                    }
                });
            }
        });
    }

    @Override
    public void deleteHealthData(JWHealthDataDeleteParams params, JWCallback callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params.getDataType() == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "data type cannot be null");
            return;
        }
        if (params.getTimeBegin() == 0) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "begin time cannot be zero");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                GlobalGreenDAO.getInstance().deleteHealthData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess();
                    }
                });
            }
        });
    }


    @Override
    public void getHistoryStepListByDate(int year, int month, int day, JWValueCallback<List<JWStepInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.Step);

        getHistoryStepList(params, callback);
    }

    @Override
    public void getHistoryStepList(JWHealthDataSearchParams params, JWValueCallback<List<JWStepInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.Step);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWStepInfo> dataList = GlobalGreenDAO.getInstance().loadStepData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getHistorySleepListByDate(int year, int month, int day, JWValueCallback<List<JWSleepInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);// 当天 0 点
        timeBegin -= 4 * 3600000;// 从昨晚 8 点开始计算
        long timePeriod = 14 * 3600000;// 持续 14 小时

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.Sleep);

        getHistorySleepList(params, callback);
    }

    @Override
    public void getHistorySleepList(JWHealthDataSearchParams params, JWValueCallback<List<JWSleepInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.Sleep);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWSleepInfo> dataList = GlobalGreenDAO.getInstance().loadSleepData2(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getHistoryBloodPressureListByDate(int year, int month, int day, JWValueCallback<List<JWBloodPressureInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.BloodPressure);

        getHistoryBloodPressureList(params, callback);
    }

    @Override
    public void getHistoryBloodPressureList(JWHealthDataSearchParams params, JWValueCallback<List<JWBloodPressureInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.BloodPressure);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWBloodPressureInfo> dataList = GlobalGreenDAO.getInstance().loadBloodPressureData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getHistoryBloodSugarListByDate(int year, int month, int day, JWValueCallback<List<JWBloodSugarInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.BloodSugar);

        getHistoryBloodSugarList(params, callback);
    }

    @Override
    public void getHistoryBloodSugarList(JWHealthDataSearchParams params, JWValueCallback<List<JWBloodSugarInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.BloodSugar);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWBloodSugarInfo> dataList = GlobalGreenDAO.getInstance().loadBloodSugarData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getHistoryHeartRateListByDate(int year, int month, int day, JWValueCallback<List<JWHeartRateInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.HeartRate);

        getHistoryHeartRateList(params, callback);
    }

    @Override
    public void getHistoryHeartRateList(JWHealthDataSearchParams params, JWValueCallback<List<JWHeartRateInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.HeartRate);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWHeartRateInfo> dataList = GlobalGreenDAO.getInstance().loadHeartRateData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getHistoryHeartRateVariabilityListByDate(int year, int month, int day, JWValueCallback<List<JWHeartRateVariabilityInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.HeartRateVariability);

        getHistoryHeartRateVariabilityList(params, callback);
    }

    @Override
    public void getHistoryHeartRateVariabilityList(JWHealthDataSearchParams params, JWValueCallback<List<JWHeartRateVariabilityInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.HeartRateVariability);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWHeartRateVariabilityInfo> dataList = GlobalGreenDAO.getInstance().loadHeartRateVariabilityData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getHistoryPulseListByDate(int year, int month, int day, JWValueCallback<List<JWPulseInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.Pulse);

        getHistoryPulseList(params, callback);
    }

    @Override
    public void getHistoryPulseList(JWHealthDataSearchParams params, JWValueCallback<List<JWPulseInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.Pulse);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWPulseInfo> dataList = GlobalGreenDAO.getInstance().loadPulseData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getHistorySaunaListByDate(int year, int month, int day, JWValueCallback<List<JWSaunaInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.Sauna);

        getHistorySaunaList(params, callback);
    }

    @Override
    public void getHistorySaunaList(JWHealthDataSearchParams params, JWValueCallback<List<JWSaunaInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.Sauna);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWSaunaInfo> dataList = GlobalGreenDAO.getInstance().loadSaunaData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getHistoryHRMovementListByDate(int year, int month, int day, JWValueCallback<List<JWHRMovementInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.HRMovement);

        getHistoryHRMovementList(params, callback);
    }

    @Override
    public void getHistoryHRMovementList(JWHealthDataSearchParams params, JWValueCallback<List<JWHRMovementInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.HRMovement);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWHRMovementInfo> dataList = GlobalGreenDAO.getInstance().loadHRMovementData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getHistorySpO2ListByDate(int year, int month, int day, JWValueCallback<List<JWSpO2Info>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.SpO2);

        getHistorySpO2List(params, callback);
    }

    @Override
    public void getHistorySpO2List(JWHealthDataSearchParams params, JWValueCallback<List<JWSpO2Info>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.SpO2);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWSpO2Info> dataList = GlobalGreenDAO.getInstance().loadSpO2Data(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getHistorySportListByDate(int year, int month, int day, JWValueCallback<List<JWSportInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.Sport);

        getHistorySportList(params, callback);
    }

    @Override
    public void getHistorySportList(JWHealthDataSearchParams params, JWValueCallback<List<JWSportInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.Sport);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWSportInfo> dataList = GlobalGreenDAO.getInstance().loadSportData2(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getHistoryTemperatureListByDate(int year, int month, int day, JWValueCallback<List<JWTemperatureInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.Temperature);

        getHistoryTemperatureList(params, callback);
    }

    @Override
    public void getHistoryTemperatureList(JWHealthDataSearchParams params, JWValueCallback<List<JWTemperatureInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.Temperature);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWTemperatureInfo> dataList = GlobalGreenDAO.getInstance().loadTemperatureData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getHistoryWearingTimeListByDate(int year, int month, int day, JWValueCallback<List<JWWearingTimeInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.WearingTime);

        getHistoryWearingTimeList(params, callback);
    }

    @Override
    public void getHistoryWearingTimeList(JWHealthDataSearchParams params, JWValueCallback<List<JWWearingTimeInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.WearingTime);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWWearingTimeInfo> dataList = GlobalGreenDAO.getInstance().loadWearingTimeData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getRecentUricAcid(JWHealthDataSearchParams params, JWValueCallback<JWUricAcidInfo> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.UricAcid);

        long timeBegin = params.getTimeBegin();
        if (timeBegin == 0) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                JWUricAcidInfo uricAcidInfo = GlobalGreenDAO.getInstance().loadRecentUricAcidData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(uricAcidInfo);
                    }
                });
            }
        });
    }

    @Override
    public void getRecentBloodFat(JWHealthDataSearchParams params, JWValueCallback<JWBloodFatInfo> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.BloodFat);

        long timeBegin = params.getTimeBegin();
        if (timeBegin == 0) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                JWBloodFatInfo bloodFatInfo = GlobalGreenDAO.getInstance().loadRecentBloodFatData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(bloodFatInfo);
                    }
                });
            }
        });
    }

    @Override
    public void getRecentBloodSugarCycle(JWHealthDataSearchParams params, JWValueCallback<JWBloodSugarCycleInfo> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.BloodSugarCycle);

        long timeBegin = params.getTimeBegin();
        if (timeBegin == 0) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                JWBloodSugarCycleInfo bloodSugarCycleInfo = GlobalGreenDAO.getInstance().loadRecentBloodSugarCycleData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(bloodSugarCycleInfo);
                    }
                });
            }
        });
    }


    @Override
    public void getHistoryUricAcidContinuousMonitoringListByDate(int year, int month, int day, JWValueCallback<List<JWUricAcidContinuousMonitoringInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.UricAcidContinuousMonitoring);

        getHistoryUricAcidContinuousMonitoringList(params, callback);
    }

    @Override
    public void getHistoryUricAcidContinuousMonitoringList(JWHealthDataSearchParams params, JWValueCallback<List<JWUricAcidContinuousMonitoringInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.UricAcidContinuousMonitoring);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWUricAcidContinuousMonitoringInfo> dataList = GlobalGreenDAO.getInstance().loadUricAcidContinuousMonitoringData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getHistoryBloodFatContinuousMonitoringListByDate(int year, int month, int day, JWValueCallback<List<JWBloodFatContinuousMonitoringInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.BloodFatContinuousMonitoring);

        getHistoryBloodFatContinuousMonitoringList(params, callback);
    }

    @Override
    public void getHistoryBloodFatContinuousMonitoringList(JWHealthDataSearchParams params, JWValueCallback<List<JWBloodFatContinuousMonitoringInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.BloodFatContinuousMonitoring);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWBloodFatContinuousMonitoringInfo> dataList = GlobalGreenDAO.getInstance().loadBloodFatContinuousMonitoringData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getRecentBodyFat(JWHealthDataSearchParams params, JWValueCallback<JWBodyFatInfo> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.BodyFat);

        long timeBegin = params.getTimeBegin();
        if (timeBegin == 0) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                JWBodyFatInfo bodyFat = GlobalGreenDAO.getInstance().loadRecentBodyFatData(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(bodyFat);
                    }
                });
            }
        });
    }

    @Override
    public void getHistoryBodyFatListByDate(int year, int month, int day, JWValueCallback<List<JWBodyFatInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.BodyFat);

        getHistoryBodyFatListByDate(params, callback);
    }

    @Override
    public void getHistoryBodyFatListByDate(JWHealthDataSearchParams params, JWValueCallback<List<JWBodyFatInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.BodyFat);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWBodyFatInfo> dataList = GlobalGreenDAO.getInstance().loadBloodFatDataList(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }

    @Override
    public void getHistoryHRVRmssdListByDate(int year, int month, int day, JWValueCallback<List<JWHRVRmssdInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.HRVRmssd);

        getHistoryHRVRmssdList(params, callback);
    }

    @Override
    public void getHistoryHRVRmssdList(JWHealthDataSearchParams params, JWValueCallback<List<JWHRVRmssdInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (GlobalGreenDAO.getInstance() == null) {
            callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init, please call WristbandManager.getInstance().initSDK()");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.HRVRmssd);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                List<JWHRVRmssdInfo> dataList = GlobalGreenDAO.getInstance().loadHRVRmssdDataList(params);
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onSuccess(dataList);
                    }
                });
            }
        });
    }


    private static class JWHealthDataManagerImplHolder {
        private static final JWHealthDataManagerImpl dataManagerImpl = new JWHealthDataManagerImpl();
    }

}
