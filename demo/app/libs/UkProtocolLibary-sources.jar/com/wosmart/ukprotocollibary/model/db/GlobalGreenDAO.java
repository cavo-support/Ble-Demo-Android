package com.wosmart.ukprotocollibary.model.db;

import android.content.Context;
import android.util.Log;

import com.wosmart.ukprotocollibary.model.hrp.HrpData;
import com.wosmart.ukprotocollibary.model.sleep.SleepData;
import com.wosmart.ukprotocollibary.model.sport.SportData;
import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.util.SDKLogger;
import com.wosmart.ukprotocollibary.util.SPWristbandConfigInfo;
import com.wosmart.ukprotocollibary.v2.JWHealthDataDeleteParams;
import com.wosmart.ukprotocollibary.v2.JWHealthDataSearchParams;
import com.wosmart.ukprotocollibary.v2.JWSDKConfig;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodFatInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.UricAcidInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRMovementInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHealthData;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateVariabilityInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPulseInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSaunaInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSleepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSpO2Info;
import com.wosmart.ukprotocollibary.v2.entity.JWSportInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWStepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUltravioletInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWearingTimeInfo;

import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.query.QueryBuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class GlobalGreenDAO {
    // Log
    private static final String TAG = GlobalGreenDAO.class.getSimpleName();
    private static final boolean D = true;

    // object
    private static GlobalGreenDAO mInstance;
    private static Context mAppContext;

    // data base object
    private static DaoMaster mDaoMaster;
    private static DaoSession mDaoSession;
    private static Database mSqlDb;
    private static String DB_NAME = "UkProtocol-db";

    // table object
    private SportDataDao mSportDataDao;
    private SleepDataDao mSleepDataDao;
    private HrpDataDao mHrpDataDao;
    private PulseDataDao mPulseDataDao;
    private SaunaDataDao mSaunaDataDao;
    private HRMovementDataDao mHRMovementDataDao;
    private BloodPressureDataDao mBloodPressureDataDao;
    private BloodSugarDataDao mBloodSugarDataDao;
    private HeartRateDataDao mHeartRateDataDao;
    private HeartRateVariabilityDataDao mHeartRateVariabilityDataDao;
    private SpO2DataDao mSpO2DataDao;
    private TemperatureDataDao mTemperatureDataDao;
    private StepDataDao mStepDataDao;
    private SleepData2Dao mSleepData2Dao;
    private SportData2Dao mSportData2Dao;
    private WearingTimeDataDao mWearingTimeDataDao;
    private UricAcidDataDao mUricAcidDataDao;
    private BloodFatDataDao mBloodFatDataDao;
    private BloodSugarCycleDataDao mBloodSugarCycleDataDao;
    private UricAcidContinuousMonitoringDataDao mUricAcidContinuousMonitoringDataDao;
    private BloodFatContinuousMonitoringDataDao mBloodFatContinuousMonitoringDataDao;
    private BodyFatDataDao mBodyFatDataDao;
    private PhysicalExamDataDao mPhysicalDataDao;
    private HRVRmssdDataDao mHRVRmssdDao;
    private UltravioletDataDao mUltravioletDao;
    private PressureDataDao mPressureDao;


    /**
     * get DaoMaster
     *
     * @param context
     * @return
     */
    public static DaoMaster getDaoMaster(Context context) {
        if (mDaoMaster == null) {
            DaoMaster.OpenHelper helper = new DaoMaster.DevOpenHelper(context, DB_NAME, null);
            mDaoMaster = new DaoMaster(helper.getWritableDb());
        }
        return mDaoMaster;
    }

    /**
     * get DaoSession
     *
     * @param context
     * @return
     */
    public static DaoSession getDaoSession(Context context) {
        if (mDaoSession == null) {
            if (mDaoMaster == null) {
                mDaoMaster = getDaoMaster(context);
            }
            mDaoSession = mDaoMaster.newSession();
        }
        return mDaoSession;
    }

    public static Database getSQLDatebase(Context context) {
        if (mSqlDb == null) {
            if (mDaoMaster == null) {
                mDaoMaster = getDaoMaster(context);
            }
            mSqlDb = mDaoMaster.getDatabase();
        }
        return mSqlDb;
    }

    public Database getSQLDatabase() {
        return mSqlDb;
    }

    public static Database getSQLDatebase() {
        return mSqlDb;
    }

    // Global Green Dao only create one times
    public static void initial(Context context, JWSDKConfig config) {
        if (mInstance == null) {
            mInstance = new GlobalGreenDAO();
            if (mAppContext == null) {
                mAppContext = context.getApplicationContext();
            }
            mInstance.mSqlDb = getSQLDatebase(context);
            mInstance.mDaoSession = getDaoSession(context);

            mInstance.mSportDataDao = mInstance.mDaoSession.getSportDataDao();
            mInstance.mSleepDataDao = mInstance.mDaoSession.getSleepDataDao();
            mInstance.mHrpDataDao = mInstance.mDaoSession.getHrpDataDao();
            mInstance.mPulseDataDao = mInstance.mDaoSession.getPulseDataDao();
            mInstance.mSaunaDataDao = mInstance.mDaoSession.getSaunaDataDao();
            mInstance.mHRMovementDataDao = mInstance.mDaoSession.getHRMovementDataDao();
            mInstance.mBloodPressureDataDao = mInstance.mDaoSession.getBloodPressureDataDao();
            mInstance.mBloodSugarDataDao = mInstance.mDaoSession.getBloodSugarDataDao();
            mInstance.mHeartRateDataDao = mInstance.mDaoSession.getHeartRateDataDao();
            mInstance.mHeartRateVariabilityDataDao = mInstance.mDaoSession.getHeartRateVariabilityDataDao();
            mInstance.mSpO2DataDao = mInstance.mDaoSession.getSpo2DataDao();
            mInstance.mTemperatureDataDao = mInstance.mDaoSession.getTemperatureDataDao();
            mInstance.mStepDataDao = mInstance.mDaoSession.getStepDataDao();
            mInstance.mSleepData2Dao = mInstance.mDaoSession.getSleepData2Dao();
            mInstance.mSportData2Dao = mInstance.mDaoSession.getSportData2Dao();
            mInstance.mWearingTimeDataDao = mInstance.mDaoSession.getWearingTimeDataDao();
            mInstance.mUricAcidDataDao = mInstance.mDaoSession.getUricAcidDataDao();
            mInstance.mBloodFatDataDao = mInstance.mDaoSession.getBloodFatDataDao();
            mInstance.mBloodSugarCycleDataDao = mInstance.mDaoSession.getBloodSugarCycleDataDao();
            mInstance.mUricAcidContinuousMonitoringDataDao = mInstance.mDaoSession.getUricAcidContinuousMonitoringDataDao();
            mInstance.mBloodFatContinuousMonitoringDataDao = mInstance.mDaoSession.getBloodFatContinuousMonitoringDataDao();
            mInstance.mBodyFatDataDao = mInstance.mDaoSession.getBodyFatDataDao();
            mInstance.mPhysicalDataDao = mInstance.mDaoSession.getPhysicalExamDataDao();
            mInstance.mHRVRmssdDao = mInstance.mDaoSession.getHRVRmssdDataDao();
            mInstance.mUltravioletDao = mInstance.mDaoSession.getUltravioletDataDao();
            mInstance.mPressureDao = mInstance.mDaoSession.getPressureDataDao();
        }
    }

    public static GlobalGreenDAO getInstance() {
        return mInstance;
    }

    /*
     * Sport Data Operator
     * */

    /**
     * insert or update sport data
     *
     * @param sportData SportData object
     * @return insert or update
     */
    public synchronized long saveSportData(SportData sportData) {
        Long id = getSportDataIdByDateAndOffset(sportData.getYear(), sportData.getMonth(), sportData.getDay(), sportData.getOffset(), sportData.getStepCount());
        if (id == -2) {
            // 数据库有同一时段更大的记录，不能覆盖
            SDKLogger.i(true, "onTodayAdjust", "数据库有同一时段更大的记录，不能覆盖, offset = " + sportData.getOffset() + ", step = " + sportData.getStepCount());
            return -1;
        }
        if (id != -1) {
            // 数据有相同记录且比当前值更小，可以更新
            sportData.setId(id);
        }
        SDKLogger.i(true, "onTodayAdjust", "新增或更新当前时段步数, id = " + sportData.getId() + ", time = " + sportData.getYear() + "-" + sportData.getMonth() + "-" + sportData.getDay() + ", offset = " + sportData.getOffset() + ", step = " + sportData.getStepCount());
//        SDKLogger.d(D, "saveSportData");
        long result = mSportDataDao.insertOrReplace(sportData);
        Log.d("UkOptManager", "GlobalGreenDAO saveSportData() id=" + id + "\tresult=" + result + "\tsportData=" + sportData.toString());
        return result;
    }

    /**
     * update sport data
     *
     * @param sportData SportData object
     */
    public void updateSportData(SportData sportData) {
        mSportDataDao.update(sportData);
    }

    /**
     * load all sport data
     *
     * @return all the sport data in table
     */
    public List<SportData> loadAllSportData() {
        List<SportData> sports = new ArrayList<>();
        List<SportData> tmpSports = mSportDataDao.loadAll();
        int len = tmpSports.size();
        for (int i = len - 1; i >= 0; i--) {
            sports.add(tmpSports.get(i));
        }
        return sports;
    }

    /**
     * load sport data by id
     *
     * @return the sport data in table
     */
    public SportData loadSportData(long id) {
        return mSportDataDao.load(id);
    }

    /**
     * delete note
     *
     * @param sportData SportData object
     * @return insert or update
     */
    public void deleteSportData(SportData sportData) {
        mSportDataDao.delete(sportData);
    }

    /**
     * delete all sport data
     */
    public void deleteAllSportData() {
        mSportDataDao.deleteAll();
    }

    /**
     * load special sport data by date
     *
     * @return all the sport data in table
     */
    public List<SportData> loadSportDataByDate(int y, int m) {
        //List<SportData> sports = new ArrayList<SportData>();
        String userColName = SportDataDao.Properties.UserID.columnName;
        String yearColName = SportDataDao.Properties.Year.columnName;
        String monthColName = SportDataDao.Properties.Month.columnName;
        String dayColName = SportDataDao.Properties.Day.columnName;
        String dateColName = SportDataDao.Properties.Date.columnName;
        // Add offset check
        String offsetName = SportDataDao.Properties.Offset.columnName;

        String whereStr = "where "
                + userColName + "=?"
                + " and " + yearColName + "=?"
                + " and " + monthColName + "=?"
                + " and " + offsetName + ">=?"
                + " and " + offsetName + "<=?";
        String orderBy = "ORDER BY " + dateColName + " ASC";
        String[] selectionArg = {
                "\"" + SPWristbandConfigInfo.getUserId(mAppContext) + "\""
                , String.valueOf(y)
                , String.valueOf(m)
                , String.valueOf(0)
                , String.valueOf(95)};
        List<SportData> tmpSports = mSportDataDao.queryRaw(whereStr + " " + orderBy, selectionArg);

        return tmpSports;
    }


    /**
     * load special sport data by date
     *
     * @return all the sport data in table
     */
    public List<SportData> loadSportDataByDate(int y, int m, int d) {
        //List<SportData> sports = new ArrayList<SportData>();
        String userColName = SportDataDao.Properties.UserID.columnName;
        String yearColName = SportDataDao.Properties.Year.columnName;
        String monthColName = SportDataDao.Properties.Month.columnName;
        String dayColName = SportDataDao.Properties.Day.columnName;
        String dateColName = SportDataDao.Properties.Date.columnName;
        // Add offset check
        String offsetName = SportDataDao.Properties.Offset.columnName;

        String whereStr = "where "
                + yearColName + "=?"
                + " and " + monthColName + "=?"
                + " and " + dayColName + "=?"
                + " and " + offsetName + ">=?"
                + " and " + offsetName + "<=?"
                + " and " + userColName + "=?";
        String orderBy = "ORDER BY " + dateColName + " ASC";

        String[] selectionArg = {
                String.valueOf(y)
                , String.valueOf(m)
                , String.valueOf(d)
                , String.valueOf(0)
                , String.valueOf(95)
                , SPWristbandConfigInfo.getUserId(mAppContext)};
        SDKLogger.d(D, "whereStr=" + whereStr + "\torderBy=" + orderBy + "\tselectionArg=" + selectionArg.toString());
        Log.d("UkOptManager", "whereStr=" + whereStr + "\torderBy=" + orderBy + "\tselectionArg=" + Arrays.toString(selectionArg));
        List<SportData> tmpSports = mSportDataDao.queryRaw(whereStr + " " + orderBy, selectionArg);

        return tmpSports;
    }

    /**
     * load special sport data by date
     *
     * @return all the sport data in table
     */
    public Long getSportDataIdByDateAndOffset(int y, int m, int d, int offset, int targetStep) {
        //List<SportData> sports = new ArrayList<SportData>();
        String userColName = SportDataDao.Properties.UserID.columnName;
        String yearColName = SportDataDao.Properties.Year.columnName;
        String monthColName = SportDataDao.Properties.Month.columnName;
        String dayColName = SportDataDao.Properties.Day.columnName;
        // Add offset check
        String offsetName = SportDataDao.Properties.Offset.columnName;

        String whereStr = "where "
                + userColName + "=?"
                + " and " + yearColName + "=?"
                + " and " + monthColName + "=?"
                + " and " + dayColName + "=?"
                + " and " + offsetName + "=?";
        String[] selectionArg = {
                SPWristbandConfigInfo.getUserId(mAppContext)
                , String.valueOf(y)
                , String.valueOf(m)
                , String.valueOf(d)
                , String.valueOf(offset)};
        List<SportData> tmpSports = mSportDataDao.queryRaw(whereStr, selectionArg);

        if (tmpSports == null || tmpSports.size() == 0) {
            return -1L;
        }
        SportData sportDataFromDB = tmpSports.get(0);

        SDKLogger.i(true, "onTodayAdjust", "数据库有同一时段记录, id =  " + sportDataFromDB.getId() + ", step = " + sportDataFromDB.getStepCount() + ", target = " + targetStep);

        if (sportDataFromDB.getStepCount() > targetStep) {
            // 数据库存储的数据在同一个时段更大，不能覆盖
            return -2L;
        }

        return tmpSports.get(0).getId();
    }

    /**
     * load special sleep data by date
     * This method is use to calculate the 18:00 PM - 10:00 AM
     *
     * @return all the sleep data in table
     */
    public List<SportData> loadSportDataByDate(Date date) {
        QueryBuilder qb = mSportDataDao.queryBuilder();
        qb.where(SportDataDao.Properties.Date.ge(date));
        qb.orderAsc(SportDataDao.Properties.Date);
        List<SportData> tmpSports = qb.list();

        return tmpSports;
    }

    /*
     * Sleep Data Operator
     * */

    /**
     * insert or update sleep data
     *
     * @param sleepData SleepData object
     * @return insert or update
     */
    public long saveSleepData(SleepData sleepData) {
        Long id = getSleepDataIdByDateAndMintues(sleepData.getYear(), sleepData.getMonth(), sleepData.getDay(), sleepData.getMinutes());
        if (id != -1) {
            sleepData.setId(id);
            SDKLogger.w(D, "have same offset date, only update.");
        }
        SDKLogger.d(D, "saveSleepData");
        return mSleepDataDao.insertOrReplace(sleepData);
    }

    /**
     * load all sleep data
     *
     * @return all the sleep data in table
     */
    public List<SleepData> loadAllSleepData() {
        List<SleepData> sleeps = new ArrayList<>();
        List<SleepData> tmpSleeps = mSleepDataDao.loadAll();
        int len = tmpSleeps.size();
        for (int i = len - 1; i >= 0; i--) {
            sleeps.add(tmpSleeps.get(i));
        }
        return sleeps;
    }

    /**
     * load sleep data by id
     *
     * @return the sleep data in table
     */
    public SleepData loadSleepData(long id) {
        return mSleepDataDao.load(id);
    }

    /**
     * delete note
     *
     * @param sleepData SleepData object
     * @return insert or update
     */
    public void deleteSleepData(SleepData sleepData) {
        mSleepDataDao.delete(sleepData);
    }

    /**
     * delete all note
     *
     * @return insert or update
     */
    public void deleteAllSleepData() {
        mSleepDataDao.deleteAll();
    }

    /**
     * load special sleep data by date
     * This method is use to calculate the 18:00 PM - 10:00 AM
     *
     * @return all the sleep data in table
     */
    public List<SleepData> loadSleepDataByDateSpec(int y, int m, int d) {
        Calendar c1 = Calendar.getInstance();
        c1.set(y, m - 1, d);// here need decrease 1 of month
        c1.add(Calendar.DATE, -1);
        int yesterdayYear = c1.get(Calendar.YEAR);
        int yesterdayMonth = c1.get(Calendar.MONTH) + 1;
        int yesterdayDay = c1.get(Calendar.DATE);
        SDKLogger.d(D, String.format("%d/%d/%d ~ %d/%d/%d",
                yesterdayYear, yesterdayMonth, yesterdayDay,
                y, m, d));

        String userColName = SleepDataDao.Properties.UserID.columnName;
        String yearColName = SleepDataDao.Properties.Year.columnName;
        String monthColName = SleepDataDao.Properties.Month.columnName;
        String dayColName = SleepDataDao.Properties.Day.columnName;
        String dateColName = SleepDataDao.Properties.Date.columnName;

        String whereStr = "where ("
                + userColName + "=?"
                + " and " + yearColName + "=?"
                + " and " + monthColName + "=?"
                + " and " + dayColName + "=?)"
                + " or ("
                + userColName + "=?"
                + " and " + yearColName + "=?"
                + " and " + monthColName + "=?"
                + " and " + dayColName + "=?)";
        String orderBy = "ORDER BY " + dateColName + " ASC";
        String[] selectionArg = {
                SPWristbandConfigInfo.getUserId(mAppContext)
                , String.valueOf(y)
                , String.valueOf(m)
                , String.valueOf(d)
                , SPWristbandConfigInfo.getUserId(mAppContext)
                , String.valueOf(yesterdayYear)
                , String.valueOf(yesterdayMonth)
                , String.valueOf(yesterdayDay)};

        return mSleepDataDao.queryRaw(whereStr + " " + orderBy, selectionArg);
    }

    /**
     * load special sleep data by date
     * This method is use to calculate the 18:00 PM - 10:00 AM
     *
     * @return all the sleep data in table
     */
    public List<SleepData> loadSleepDataByDate(Date date) {
        QueryBuilder qb = mSleepDataDao.queryBuilder();
        qb.where(SleepDataDao.Properties.Date.ge(date));
        qb.orderAsc(SleepDataDao.Properties.Date);
        List<SleepData> tmpSleeps = qb.list();

        return tmpSleeps;
    }

    /**
     * load special sleep data by date
     *
     * @return all the sleep data in table
     */
    public List<SleepData> loadSleepDataByDate(int y, int m, int d) {
        //List<SleepData> sleeps = new ArrayList<SleepData>();
        String userColName = SleepDataDao.Properties.UserID.columnName;
        String yearColName = SleepDataDao.Properties.Year.columnName;
        String monthColName = SleepDataDao.Properties.Month.columnName;
        String dayColName = SleepDataDao.Properties.Day.columnName;
        String dateColName = SleepDataDao.Properties.Date.columnName;

        String whereStr = "where "
                + userColName + "=?"
                + " and " + yearColName + "=?"
                + " and " + monthColName + "=?"
                + " and " + dayColName + "=?";
        String orderBy = "ORDER BY " + dateColName + " ASC";
        String[] selectionArg = {
                SPWristbandConfigInfo.getUserId(mAppContext)
                , String.valueOf(y)
                , String.valueOf(m)
                , String.valueOf(d)};
        List<SleepData> tmpSleeps = mSleepDataDao.queryRaw(whereStr + " " + orderBy, selectionArg);

        return tmpSleeps;
    }

    /**
     * load special sleep data by date
     *
     * @return all the sleep data in table
     */
    public Long getSleepDataIdByDateAndMintues(int y, int m, int d, int min) {
        //List<SleepData> sleeps = new ArrayList<SleepData>();
        String userColName = SleepDataDao.Properties.UserID.columnName;
        String yearColName = SleepDataDao.Properties.Year.columnName;
        String monthColName = SleepDataDao.Properties.Month.columnName;
        String dayColName = SleepDataDao.Properties.Day.columnName;
        String minutesColName = SleepDataDao.Properties.Minutes.columnName;

        String whereStr = "where "
                + userColName + "=?"
                + " and " + yearColName + "=?"
                + " and " + monthColName + "=?"
                + " and " + dayColName + "=?"
                + " and " + minutesColName + "=?";
        String[] selectionArg = {
                SPWristbandConfigInfo.getUserId(mAppContext)
                , String.valueOf(y)
                , String.valueOf(m)
                , String.valueOf(d)
                , String.valueOf(min)};
        List<SleepData> tmpSleeps = mSleepDataDao.queryRaw(whereStr, selectionArg);

        if (tmpSleeps == null
                || tmpSleeps.size() == 0) {
            return -1L;
        }

        return tmpSleeps.get(0).getId();
    }

    /**
     * load special sleep data by date
     *
     * @return all the sleepdata in table
     */
    public List<SleepData> loadSleepDataByDate(int y, int m) {
        String userColName = SleepDataDao.Properties.UserID.columnName;
        String yearColName = SleepDataDao.Properties.Year.columnName;
        String monthColName = SleepDataDao.Properties.Month.columnName;
        String dayColName = SleepDataDao.Properties.Day.columnName;
        String dateColName = SleepDataDao.Properties.Date.columnName;

        String whereStr = "where "
                + userColName + "=?"
                + " and " + yearColName + "=?"
                + " and " + monthColName + "=?";
        String orderBy = "ORDER BY " + dateColName + " ASC";
        String[] selectionArg = {
                SPWristbandConfigInfo.getUserId(mAppContext)
                , String.valueOf(y)
                , String.valueOf(m)};

        return mSleepDataDao.queryRaw(whereStr + " " + orderBy, selectionArg);
    }

    /*
     * Hrp Data Operator
     * */

    /**
     * insert or update Hrp data
     *
     * @param hrpData HrpData object
     * @return insert or update
     */
    public long saveHrpData(HrpData hrpData) {

        Long id = getHrpDataIdByDateAndMintues(hrpData.getYear(), hrpData.getMonth(), hrpData.getDay(), hrpData.getMinutes(), hrpData.getDateStampByRealSample());
        if (id != -1) {
            hrpData.setId(id);
//            SDKLogger.d(D, "have same offset date, only update.");
        }
        SDKLogger.d(D, "saveHrpData" + hrpData.toString());

        return mHrpDataDao.insertOrReplace(hrpData);
    }

    /**
     * load all Hrp data
     *
     * @return all the Hrp data in table
     */
    public List<HrpData> loadAllHrpData() {
        List<HrpData> hrps = new ArrayList<HrpData>();
//        List<HrpData> tmpHrps = mHrpDataDao.loadAll();
        String dateStampByRealSampleColName = HrpDataDao.Properties.DateStampByRealSample.columnName;

        String orderBy = "ORDER BY " + dateStampByRealSampleColName + " DESC";
        String[] selectionArg = null;

        hrps = mHrpDataDao.queryRaw(orderBy, selectionArg);

        /*
        int len = tmpHrps.size();
        for (int i = len-1; i >=0; i--) {
            hrps.add(tmpHrps.get(i));
        }
        */
//        for (int i = 0; i < hrps.size(); i++) {
//            SDKLogger.d(D,"心率数据：loadAllHrpData()-->"+hrps.get(i).toString());
//        }
        return hrps;
    }

    /**
     * load Hrp data by id
     *
     * @return the Hrp data in table
     */
    public HrpData loadHrpData(long id) {
        return mHrpDataDao.load(id);
    }

    /**
     * delete note
     *
     * @param hrpData HrpData object
     * @return insert or update
     */
    public void deleteHrpData(HrpData hrpData) {
        mHrpDataDao.delete(hrpData);
    }

    /**
     * delete all Hrp data
     */
    public void deleteAllHrpData() {
        mHrpDataDao.deleteAll();
    }


    /**
     * load special hrp data by date
     * This method is use to calculate the 18:00 PM - 10:00 AM
     *
     * @return all the hrp data in table
     */
    public List<HrpData> loadHrpDataByDateSpec(int y, int m, int d) {
        Calendar c1 = Calendar.getInstance();
        c1.set(y, m - 1, d);// here need decrease 1 of month
        c1.add(Calendar.DATE, -1);
        int yesterdayYear = c1.get(Calendar.YEAR);
        int yesterdayMonth = c1.get(Calendar.MONTH) + 1;
        int yesterdayDay = c1.get(Calendar.DATE);
        SDKLogger.d(D, "y: " + y + ", m: " + m + ", d: " + d
                + ", yesterdayYear: " + yesterdayYear + ", yesterdayMonth: " + yesterdayMonth
                + ", yesterdayDay: " + yesterdayDay);

        String userColName = HrpDataDao.Properties.UserID.columnName;
        String yearColName = HrpDataDao.Properties.Year.columnName;
        String monthColName = HrpDataDao.Properties.Month.columnName;
        String dayColName = HrpDataDao.Properties.Day.columnName;
        String dateColName = HrpDataDao.Properties.Date.columnName;

        String whereStr = "where ("
                + userColName + "=?"
                + " and " + yearColName + "=?"
                + " and " + monthColName + "=?"
                + " and " + dayColName + "=?)"
                + " or (" + yearColName + "=?"
                + " and " + monthColName + "=?"
                + " and " + dayColName + "=?)";
        String orderBy = "ORDER BY " + dateColName + " ASC";
        String[] selectionArg = {
                SPWristbandConfigInfo.getUserId(mAppContext)
                , String.valueOf(y)
                , String.valueOf(m)
                , String.valueOf(d)
                , String.valueOf(yesterdayYear)
                , String.valueOf(yesterdayMonth)
                , String.valueOf(yesterdayDay)};
        List<HrpData> tmpHrps = mHrpDataDao.queryRaw(whereStr + " " + orderBy, selectionArg);

        return tmpHrps;
    }

    /**
     * load special hrp data by date
     *
     * @return all the hrp data in table
     */
    public List<HrpData> loadHrpDataByDate(int y, int m, int d) {
        SDKLogger.d(D, "y: " + y + ", m: " + m + ", d: " + d);
        String userColName = HrpDataDao.Properties.UserID.columnName;
        String yearColName = HrpDataDao.Properties.Year.columnName;
        String monthColName = HrpDataDao.Properties.Month.columnName;
        String dayColName = HrpDataDao.Properties.Day.columnName;
        String dateColName = HrpDataDao.Properties.DateStampByRealSample.columnName;

        String whereStr = "where ("
                + userColName + "=?"
                + " and " + yearColName + "=?"
                + " and " + monthColName + "=?"
                + " and " + dayColName + "=?)";
        String orderBy = "ORDER BY " + dateColName + " ASC";
        String[] selectionArg = {
                SPWristbandConfigInfo.getUserId(mAppContext)
                , String.valueOf(y)
                , String.valueOf(m)
                , String.valueOf(d)};
        List<HrpData> tmpHrps = mHrpDataDao.queryRaw(whereStr + " " + orderBy, selectionArg);

        return tmpHrps;
    }

    /**
     * load special hrp data by date
     *
     * @return all the hrp data in table
     */
    public Long getHrpDataIdByDateAndMintues(int y, int m, int d, int min, long dateStamp) {
        String userColName = HrpDataDao.Properties.UserID.columnName;
        String yearColName = HrpDataDao.Properties.Year.columnName;
        String monthColName = HrpDataDao.Properties.Month.columnName;
        String dayColName = HrpDataDao.Properties.Day.columnName;
        String minutesColName = HrpDataDao.Properties.Minutes.columnName;
        String dateStampColName = HrpDataDao.Properties.DateStampByRealSample.columnName;

        String whereStr = "where "
                + userColName + "=?"
                + " and " + yearColName + "=?"
                + " and " + monthColName + "=?"
                + " and " + dayColName + "=?"
                + " and " + minutesColName + "=?"
                + " and " + dateStampColName + "=?";
        String[] selectionArg = {
                SPWristbandConfigInfo.getUserId(mAppContext)
                , String.valueOf(y)
                , String.valueOf(m)
                , String.valueOf(d)
                , String.valueOf(min)
                , String.valueOf(dateStamp)};
        List<HrpData> tmpHrps = mHrpDataDao.queryRaw(whereStr, selectionArg);

        if (tmpHrps == null
                || tmpHrps.size() == 0) {
            return -1L;
        }

        return tmpHrps.get(0).getId();
    }

    /**
     * load special Hrp data by date
     * This method is use to calculate the 18:00 PM - 10:00 AM
     *
     * @return all the Hrp data in table
     */
    public List<HrpData> loadHrpDataByDate(Date date) {
        QueryBuilder qb = mHrpDataDao.queryBuilder();
        qb.where(HrpDataDao.Properties.Date.ge(date));
        qb.orderAsc(HrpDataDao.Properties.Date);
        List<HrpData> tmpHrps = qb.list();

        return tmpHrps;
    }

    public void deleteErrorHrpData() {
        String valueColName = HrpDataDao.Properties.Value.columnName;

        String whereStr = "where " + valueColName + " = ?";

        String[] selectionArg = {String.valueOf(0)};
        List<HrpData> errorData = mHrpDataDao.queryRaw(whereStr, selectionArg);
        if (errorData != null) {
            mHrpDataDao.deleteInTx(errorData);
        }
    }

    public void deleteAllHealthDataByDate(String userID, String mac, int year, int month, int day) {
        // 先删除老版数据库
        mSleepDataDao.deleteByTime(userID, year, month, day);
        mSportDataDao.deleteByTime(userID, year, month, day);
        mHrpDataDao.deleteByTime(userID, year, month, day);

        // 再删除新版数据库
        long timeBegin = DateUtil.getDate(year, month, day);// 当天 0 点
        long timePeriod = 24 * 3600000 - 1;// 当天 24 点

        mPulseDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mSaunaDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mHRMovementDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mBloodPressureDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mBloodSugarDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mHeartRateDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mHeartRateVariabilityDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mSpO2DataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mTemperatureDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mStepDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mSportData2Dao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mWearingTimeDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mUricAcidDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mBloodFatDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mBloodSugarCycleDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mUricAcidContinuousMonitoringDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mBloodFatContinuousMonitoringDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mBodyFatDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mPhysicalDataDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mHRVRmssdDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mUltravioletDao.deleteByTime(userID, mac, timeBegin, timePeriod);
        mPressureDao.deleteByTime(userID, mac, timeBegin, timePeriod);

        // 睡眠需要删除 2 天数据
        long sleepTimeBegin = timeBegin - 4 * 3600000;// 从昨晚 8 点开始计算
        long sleepTimePeriod = 14 * 3600000;// 持续 14 小时
        mSleepData2Dao.deleteByTime(userID, mac, sleepTimeBegin, sleepTimePeriod);
    }

    public void deleteHealthData(JWHealthDataDeleteParams params) {
        if (params.getDataType() == null) {
            return;
        }
        switch (params.getDataType()) {
            case Step:
                mStepDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case Sleep:
                mSleepData2Dao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case Sport:
                mSportData2Dao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case BloodPressure:
                mBloodPressureDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case BloodSugar:
                mBloodSugarDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case HeartRate:
                mHeartRateDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case HeartRateVariability:
                mHeartRateVariabilityDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case SpO2:
                mSpO2DataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case Temperature:
                mTemperatureDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case Pulse:
                mPulseDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case Sauna:
                mSaunaDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case HRMovement:
                mHRMovementDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case WearingTime:
                mWearingTimeDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case UricAcid:
                mUricAcidDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case BloodFat:
                mBloodFatDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case BloodSugarCycle:
                mBloodSugarCycleDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case UricAcidContinuousMonitoring:
                mUricAcidContinuousMonitoringDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case BloodFatContinuousMonitoring:
                mBloodFatContinuousMonitoringDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case BodyFat:
                mBodyFatDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case PhysicalExam:
                mPhysicalDataDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case HRVRmssd:
                mHRVRmssdDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case ULTRAVIOLET:
                mUltravioletDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
            case PRESSURE:
                mPressureDao.deleteByTime(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod());
                break;
        }
    }

    public void saveHealthData(JWHealthData healthData) {
        if (healthData instanceof JWPulseInfo) {
            mPulseDataDao.insertOrReplace((JWPulseInfo) healthData);
        } else if (healthData instanceof JWSaunaInfo) {
            mSaunaDataDao.insertOrReplace((JWSaunaInfo) healthData);
        } else if (healthData instanceof JWHRMovementInfo) {
            mHRMovementDataDao.insertOrReplace((JWHRMovementInfo) healthData);
        } else if (healthData instanceof JWBloodSugarInfo) {
            mBloodSugarDataDao.insertOrReplace((JWBloodSugarInfo) healthData);
        } else if (healthData instanceof JWHeartRateInfo) {
            mHeartRateDataDao.insertOrReplace((JWHeartRateInfo) healthData);
        } else if (healthData instanceof JWHeartRateVariabilityInfo) {
            mHeartRateVariabilityDataDao.insertOrReplace((JWHeartRateVariabilityInfo) healthData);
        } else if (healthData instanceof JWSpO2Info) {
            mSpO2DataDao.insertOrReplace((JWSpO2Info) healthData);
        } else if (healthData instanceof JWTemperatureInfo) {
            mTemperatureDataDao.insertOrReplace((JWTemperatureInfo) healthData);
        } else if (healthData instanceof JWStepInfo) {
            mStepDataDao.insertOrReplace((JWStepInfo) healthData);
        } else if (healthData instanceof JWSleepInfo) {
            mSleepData2Dao.insertOrReplace((JWSleepInfo) healthData);
        } else if (healthData instanceof JWSportInfo) {
            mSportData2Dao.insertOrReplace((JWSportInfo) healthData);
        } else if (healthData instanceof JWWearingTimeInfo) {
            mWearingTimeDataDao.insertOrReplace((JWWearingTimeInfo) healthData);
        } else if (healthData instanceof JWUricAcidInfo) {
            JWUricAcidInfo uricAcidInfo = (JWUricAcidInfo) healthData;
            mUricAcidDataDao.insertOrReplace(new UricAcidInfo(uricAcidInfo));
        } else if (healthData instanceof JWBloodFatInfo) {
            JWBloodFatInfo bloodFatInfo = (JWBloodFatInfo) healthData;
            mBloodFatDataDao.insertOrReplace(new BloodFatInfo(bloodFatInfo));
        } else if (healthData instanceof JWBloodSugarCycleInfo) {
            JWBloodSugarCycleInfo bloodSugarCycleInfo = (JWBloodSugarCycleInfo) healthData;
            mBloodSugarCycleDataDao.insertOrReplace(new BloodSugarCycleInfo(bloodSugarCycleInfo));
        } else if (healthData instanceof JWUricAcidContinuousMonitoringInfo) {
            mUricAcidContinuousMonitoringDataDao.insertOrReplace((JWUricAcidContinuousMonitoringInfo) healthData);
        } else if (healthData instanceof JWBloodFatContinuousMonitoringInfo) {
            mBloodFatContinuousMonitoringDataDao.insertOrReplace((JWBloodFatContinuousMonitoringInfo) healthData);
        } else if (healthData instanceof JWBodyFatInfo) {
            mBodyFatDataDao.insertOrReplace((JWBodyFatInfo) healthData);
        } else if (healthData instanceof JWPhysicalExamInfo) {
            mPhysicalDataDao.insertOrReplace((JWPhysicalExamInfo) healthData);
        } else if (healthData instanceof JWHRVRmssdInfo) {
            mHRVRmssdDao.insertOrReplace((JWHRVRmssdInfo) healthData);
        } else if (healthData instanceof JWUltravioletInfo) {
            mUltravioletDao.insertOrReplace((JWUltravioletInfo) healthData);
        }  else if (healthData instanceof JWPressureInfo) {
            mPressureDao.insertOrReplace((JWPressureInfo) healthData);
        } else if (healthData instanceof JWBloodPressureInfo) {
            // 2.0 血压从心率转化且带随机值数据，此处需先查询数据无记录才能插入
            JWBloodPressureInfo bloodPressureInfo = (JWBloodPressureInfo) healthData;
            JWBloodPressureInfo dbInfo = mBloodPressureDataDao.queryData(bloodPressureInfo.userID, bloodPressureInfo.time);
            if (dbInfo == null) {
                mBloodPressureDataDao.insertOrReplace(bloodPressureInfo);
            }
        }
    }

    public void savePulseList(List<JWPulseInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mPulseDataDao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveSaunaList(List<JWSaunaInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mSaunaDataDao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveHRMovementList(List<JWHRMovementInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mHRMovementDataDao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveBloodPressureList(List<JWBloodPressureInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            // 2.0 血压从心率转化且带随机值数据，此处需先查询数据无记录才能插入
            List<JWBloodPressureInfo> bloodPressureInfoList = new ArrayList<>();
            for (JWBloodPressureInfo bloodPressureInfo : dataList) {
                JWBloodPressureInfo dbInfo = mBloodPressureDataDao.queryData(bloodPressureInfo.userID, bloodPressureInfo.time);
                if (dbInfo == null) {
                    bloodPressureInfoList.add(bloodPressureInfo);
                }
            }
            if (!bloodPressureInfoList.isEmpty()) {
                mBloodPressureDataDao.insertOrReplaceInTx(bloodPressureInfoList);
            }
        }
    }

    public void saveBloodSugarList(List<JWBloodSugarInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mBloodSugarDataDao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveHeartRateList(List<JWHeartRateInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mHeartRateDataDao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveHeartRateVariabilityList(List<JWHeartRateVariabilityInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mHeartRateVariabilityDataDao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveSpO2List(List<JWSpO2Info> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mSpO2DataDao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveTemperatureList(List<JWTemperatureInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mTemperatureDataDao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveStepList(List<JWStepInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mStepDataDao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveSleepList(List<JWSleepInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mSleepData2Dao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveSportList(List<JWSportInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mSportData2Dao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveWearingTimeList(List<JWWearingTimeInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mWearingTimeDataDao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveUricAcidList(List<JWUricAcidInfo> dataList) {
        if (dataList == null || dataList.isEmpty()) {
            return;
        }
        List<UricAcidInfo> uricAcidInfoList = new ArrayList<>();
        for (JWUricAcidInfo info : dataList) {
            uricAcidInfoList.add(new UricAcidInfo(info));
        }
        mUricAcidDataDao.saveDataList(uricAcidInfoList);
    }

    public void saveBloodFatList(List<JWBloodFatInfo> dataList) {
        if (dataList == null || dataList.isEmpty()) {
            return;
        }
        List<BloodFatInfo> bloodFatInfoList = new ArrayList<>();
        for (JWBloodFatInfo info : dataList) {
            bloodFatInfoList.add(new BloodFatInfo(info));
        }
        mBloodFatDataDao.saveDataList(bloodFatInfoList);
    }

    public void saveBloodSugarCycleList(List<JWBloodSugarCycleInfo> dataList) {
        if (dataList == null || dataList.isEmpty()) {
            return;
        }
        List<BloodSugarCycleInfo> bloodFatInfoList = new ArrayList<>();
        for (JWBloodSugarCycleInfo info : dataList) {
            bloodFatInfoList.add(new BloodSugarCycleInfo(info));
        }
        mBloodSugarCycleDataDao.saveDataList(bloodFatInfoList);
    }

    public void saveUricAcidContinuousMonitoringList(List<JWUricAcidContinuousMonitoringInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mUricAcidContinuousMonitoringDataDao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveBloodFatContinuousMonitoringList(List<JWBloodFatContinuousMonitoringInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mBloodFatContinuousMonitoringDataDao.insertOrReplaceInTx(dataList);
        }
    }

    public void savePhysicalExamList(List<JWPhysicalExamInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mPhysicalDataDao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveHRVRmssdList(List<JWHRVRmssdInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mHRVRmssdDao.insertOrReplaceInTx(dataList);
        }
    }

    public void saveUltravioletList(List<JWUltravioletInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mUltravioletDao.insertOrReplaceInTx(dataList);
        }
    }

    public void savePressureList(List<JWPressureInfo> dataList) {
        if (dataList != null && !dataList.isEmpty()) {
            mPressureDao.insertOrReplaceInTx(dataList);
        }
    }

    /**
     * load special pulse data by date
     *
     * @return all the pulse data in table
     */
    public List<JWPulseInfo> loadPulseDataByDate(int year, int month, int day) {
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;
        return mPulseDataDao.queryDataList(timeBegin, timePeriod);
    }

    public List<JWPulseInfo> loadPulseData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mPulseDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    /**
     * load special sauna data by date
     *
     * @return all the sauna data in table
     */
    public List<JWSaunaInfo> loadSaunaDataByDate(int year, int month, int day) {
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;
        return mSaunaDataDao.queryDataList(timeBegin, timePeriod);
    }

    public List<JWSaunaInfo> loadSaunaData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mSaunaDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    /**
     * load special hr movement data by date
     *
     * @return all the hr movement data in table
     */
    public List<JWHRMovementInfo> loadHRMovementDataByDate(int year, int month, int day) {
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;
        return mHRMovementDataDao.queryDataList(timeBegin, timePeriod);
    }

    public List<JWHRMovementInfo> loadHRMovementData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mHRMovementDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public List<JWBloodPressureInfo> loadBloodPressureData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mBloodPressureDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public List<JWBloodSugarInfo> loadBloodSugarData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mBloodSugarDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public List<JWHeartRateInfo> loadHeartRateData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mHeartRateDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public List<JWHeartRateVariabilityInfo> loadHeartRateVariabilityData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mHeartRateVariabilityDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public List<JWSpO2Info> loadSpO2Data(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mSpO2DataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }


    public List<JWTemperatureInfo> loadTemperatureData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mTemperatureDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public List<JWStepInfo> loadStepData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mStepDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public List<JWSleepInfo> loadSleepData2(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mSleepData2Dao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public List<JWSportInfo> loadSportData2(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mSportData2Dao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public List<JWWearingTimeInfo> loadWearingTimeData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mWearingTimeDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public JWUricAcidInfo loadRecentUricAcidData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        UricAcidInfo uricAcidInfo = mUricAcidDataDao.queryRecentData(userID, mac, timeBegin);

        return uricAcidInfo == null ? null : uricAcidInfo.convertToJWUricAcidInfo();
    }

    public List<JWUricAcidInfo> loadUricAcidData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        List<UricAcidInfo> uricAcidInfoList = mUricAcidDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);

        List<JWUricAcidInfo> dataList = new ArrayList<>();
        if (uricAcidInfoList == null || uricAcidInfoList.isEmpty()) {
            return dataList;
        }

        for (UricAcidInfo uricAcidInfo : uricAcidInfoList) {
            dataList.add(uricAcidInfo.convertToJWUricAcidInfo());
        }
        return dataList;
    }

    public JWBloodFatInfo loadRecentBloodFatData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        BloodFatInfo bloodFatInfo = mBloodFatDataDao.queryRecentData(userID, mac, timeBegin);

        return bloodFatInfo == null ? null : bloodFatInfo.convertToJWBloodFatInfo();
    }

    public List<JWBloodFatInfo> loadBloodFatData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        List<BloodFatInfo> bloodFatInfoList = mBloodFatDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);

        List<JWBloodFatInfo> dataList = new ArrayList<>();
        if (bloodFatInfoList == null || bloodFatInfoList.isEmpty()) {
            return dataList;
        }

        for (BloodFatInfo bloodFatInfo : bloodFatInfoList) {
            dataList.add(bloodFatInfo.convertToJWBloodFatInfo());
        }
        return dataList;
    }

    public JWBloodSugarCycleInfo loadRecentBloodSugarCycleData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        BloodSugarCycleInfo bloodSugarCycleInfo = mBloodSugarCycleDataDao.queryRecentData(userID, mac, timeBegin);

        return bloodSugarCycleInfo == null ? null : bloodSugarCycleInfo.convertToJWBloodSugarCycleInfo();
    }

    public List<JWBloodSugarCycleInfo> loadBloodSugarCycleData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        List<BloodSugarCycleInfo> bloodSugarCycleInfoList = mBloodSugarCycleDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);

        List<JWBloodSugarCycleInfo> dataList = new ArrayList<>();
        if (bloodSugarCycleInfoList == null || bloodSugarCycleInfoList.isEmpty()) {
            return dataList;
        }

        for (BloodSugarCycleInfo bloodSugarCycleInfo : bloodSugarCycleInfoList) {
            dataList.add(bloodSugarCycleInfo.convertToJWBloodSugarCycleInfo());
        }
        return dataList;
    }

    public List<JWUricAcidContinuousMonitoringInfo> loadUricAcidContinuousMonitoringData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mUricAcidContinuousMonitoringDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public List<JWBloodFatContinuousMonitoringInfo> loadBloodFatContinuousMonitoringData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mBloodFatContinuousMonitoringDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public JWBodyFatInfo loadRecentBodyFatData(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();

        return mBodyFatDataDao.queryRecentData(userID, mac, timeBegin);
    }

    public List<JWBodyFatInfo> loadBloodFatDataList(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mBodyFatDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public List<JWPhysicalExamInfo> loadPhysicalExamDataList(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mPhysicalDataDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public List<JWHRVRmssdInfo> loadHRVRmssdDataList(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mHRVRmssdDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public List<JWUltravioletInfo> loadUltravioletDataList(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mUltravioletDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public List<JWPressureInfo> loadPressureDataList(JWHealthDataSearchParams params) {
        String userID = params.getUserID();
        String mac = params.getDeviceMac();
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        int count = params.getCount();
        return mPressureDao.queryDataList(userID, mac, timeBegin, timePeriod, count);
    }

    public void clearUricAcidInvalidData(String deviceMac) {
        mUricAcidDataDao.clearInvalidData(deviceMac);
    }

    public void clearBloodFatInvalidData(String deviceMac) {
        mBloodFatDataDao.clearInvalidData(deviceMac);
    }

    public void clearBloodSugarCycleInvalidData(String deviceMac) {
        mBloodSugarCycleDataDao.clearInvalidData(deviceMac);
    }

}
