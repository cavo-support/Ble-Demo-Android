package com.wosmart.ukprotocollibary.model.db;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.entity.JWSaunaInfo;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.AbstractDaoSession;
import org.greenrobot.greendao.Property;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseStatement;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.List;

public class SaunaDataDao extends AbstractDao<JWSaunaInfo, Long> {

    public static final String TABLENAME = "SAUNA_DATA";

    public static class Properties {
        public final static Property time = new Property(0, Long.class, "time", true, "TIME");
        public final static Property userID = new Property(1, String.class, "userID", true, "USER_ID");
        public final static Property mac = new Property(2, String.class, "mac", false, "MAC");
        public final static Property date = new Property(3, java.util.Date.class, "date", false, "DATE");
        public final static Property heartRateValue = new Property(4, int.class, "heartRateValue", false, "HEART_RATE_VALUE");
        public final static Property temperature = new Property(5, int.class, "temperature", false, "TEMPERATURE");
        public final static Property label = new Property(6, int.class, "label", false, "LABEL");
        public final static Property movement = new Property(7, int.class, "movement", false, "MOVEMENT");
    }

    public SaunaDataDao(DaoConfig config) {
        super(config);
    }

    public SaunaDataDao(DaoConfig config, AbstractDaoSession daoSession) {
        super(config, daoSession);
    }



    public List<JWSaunaInfo> queryDataList(long timeBegin, long timePeriod) {
        String timeColName = Properties.time.columnName;
        String dateColName = Properties.date.columnName;

        String whereStr = "where ("
                + timeColName + ">=?"
                + " and " + timeColName + "<=?)";
        String orderBy = " ORDER BY " + dateColName + " ASC ";
        String[] selectionArg = {String.valueOf(timeBegin), String.valueOf(timeBegin + timePeriod)};
        return queryRaw(whereStr + " " + orderBy, selectionArg);
    }


    public List<JWSaunaInfo> queryDataList(String userID, String mac, long timeBegin, long timePeriod, int count) {
        String timeColName = Properties.time.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;
        String dateColName = Properties.date.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition;
        if (timeBegin == 0) {
            // 从当前时间
            timeCondition = timeColName + " <= " + System.currentTimeMillis();
        } else {
            timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));
        }
        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");
        String macCondition = TextUtils.isEmpty(mac) ? "" : (" " + macColName + " = '" + mac + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        if (!TextUtils.isEmpty(macCondition)) {
            sb.append(" and ").append(macCondition);
        }
        sb.append(")");

        String orderBy = " ORDER BY " + dateColName + " ASC ";
        String limit = count == 0 ? "" : (" LIMIT " + count);

        sb.append(orderBy);
        sb.append(limit);

        return queryRaw(sb.toString());
    }

    public void deleteByTime(String userID, String mac, long timeBegin, long timePeriod) {
        String timeColName = Properties.time.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;

        String timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));

        StringBuilder sb = new StringBuilder();

        sb.append("DELETE FROM " + TABLENAME + " WHERE ");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userID)) {
            sb.append(" and ").append(userIDColName).append(" = '").append(userID).append("' ");
        }
        if (!TextUtils.isEmpty(mac)) {
            sb.append(" and ").append(macColName).append(" = '").append(mac).append("' ");
        }

        GlobalGreenDAO.getInstance().getSQLDatabase().execSQL(sb.toString());
    }

    public static void createTable(Database db) {
        db.execSQL("create table IF NOT EXISTS " + TABLENAME + "\n" +
                "(\n" +
                Properties.time.columnName + " bigint not null ,\n" +
                Properties.userID.columnName + " varchar(256) not null ,\n" +
                Properties.mac.columnName + " varchar(256) ,\n" +
                Properties.date.columnName + " varchar(50) not null ,\n" +
                Properties.heartRateValue.columnName + " int not null ,\n" +
                Properties.temperature.columnName + " int not null ,\n" +
                Properties.label.columnName + " int not null ,\n" +
                Properties.movement.columnName + " int not null ,\n" +
                " primary key (" + Properties.time.columnName + ", " + Properties.userID.columnName + ")\n" +
                ");");
    }

    public static void dropTable(Database db) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
    }

    public static void addMacAddressCol(Database db) {
        try {
            String sql = "AlTER TABLE " + TABLENAME + " Add COLUMN " + Properties.mac.columnName + " varchar(256)";
            db.execSQL(sql);
        } catch (Exception ignored) {
        }
    }

    @Override
    protected JWSaunaInfo readEntity(Cursor cursor, int offset) {
        JWSaunaInfo info = new JWSaunaInfo();

        info.time = cursor.getLong(offset + Properties.time.ordinal);
        info.userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        info.deviceMac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        info.heartRateValue = cursor.getInt(offset + Properties.heartRateValue.ordinal);
        info.temperature = JWUtils.parserRound(1, cursor.getInt(offset + Properties.temperature.ordinal) / 10f);
        info.label = cursor.getInt(offset + Properties.label.ordinal);
        info.movement = cursor.getInt(offset + Properties.movement.ordinal);

        return info;
    }

    @Override
    protected Long readKey(Cursor cursor, int offset) {
        return cursor.getLong(offset);
    }

    @Override
    protected void readEntity(Cursor cursor, JWSaunaInfo info, int offset) {
        info.time = cursor.getLong(offset + Properties.time.ordinal);
        info.userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        info.deviceMac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        info.heartRateValue = cursor.getInt(offset + Properties.heartRateValue.ordinal);
        info.temperature = JWUtils.parserRound(1, cursor.getInt(offset + Properties.temperature.ordinal) / 10f);
        info.label = cursor.getInt(offset + Properties.label.ordinal);
        info.movement = cursor.getInt(offset + Properties.movement.ordinal);
    }

    @Override
    protected void bindValues(DatabaseStatement stmt, JWSaunaInfo info) {

    }

    @Override
    protected void bindValues(SQLiteStatement stmt, JWSaunaInfo info) {
        stmt.clearBindings();

        stmt.bindLong(Properties.time.ordinal + 1, info.time);
        stmt.bindString(Properties.userID.ordinal + 1, TextUtils.isEmpty(info.userID) ? "" : info.userID);
        stmt.bindString(Properties.mac.ordinal + 1, TextUtils.isEmpty(info.deviceMac) ? "" : info.deviceMac);
        stmt.bindString(Properties.date.ordinal + 1, DateUtil.toTime2(info.time));
        stmt.bindLong(Properties.heartRateValue.ordinal + 1, info.heartRateValue);
        stmt.bindLong( Properties.temperature.ordinal + 1, (long) (info.temperature * 10));
        stmt.bindLong(Properties.label.ordinal + 1, info.label);
        stmt.bindLong(Properties.movement.ordinal + 1, info.movement);
    }

    @Override
    protected Long updateKeyAfterInsert(JWSaunaInfo info, long rowID) {
        return info.time;
    }

    @Override
    protected Long getKey(JWSaunaInfo info) {
        return info.time;
    }

    @Override
    protected boolean hasKey(JWSaunaInfo info) {
        return false;
    }

    @Override
    protected boolean isEntityUpdateable() {
        return true;
    }
}
