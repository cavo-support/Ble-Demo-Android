package com.wosmart.ukprotocollibary.model.db;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.model.sleep.SleepData;
import com.wosmart.ukprotocollibary.model.sport.SportData;
import com.wosmart.ukprotocollibary.util.DateUtil;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.Property;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseStatement;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.Calendar;
import java.util.List;


public class SleepDataDao extends AbstractDao<SleepData, Long> {

    public static final String TABLENAME = "SLEEP_DATA";

    /**
     * Properties of entity SleepData.<br/>
     * Can be used for QueryBuilder and for referencing column names.
     */
    public static class Properties {
        public final static Property Id = new Property(0, Long.class, "id", true, "_id");
        public final static Property Year = new Property(1, int.class, "year", false, "YEAR");
        public final static Property Month = new Property(2, int.class, "month", false, "MONTH");
        public final static Property Day = new Property(3, int.class, "day", false, "DAY");
        public final static Property Minutes = new Property(4, int.class, "minutes", false, "MINUTES");
        public final static Property Mode = new Property(5, int.class, "mode", false, "MODE");
        public final static Property Date = new Property(6, java.util.Date.class, "date", false, "DATE");
        public final static Property UserID = new Property(7, String.class, "userID", false, "USERID");
    }




    public SleepDataDao(DaoConfig config) {
        super(config);
    }

    public SleepDataDao(DaoConfig config, DaoSession daoSession) {
        super(config, daoSession);
    }


    public void deleteByTime(String userID, int year, int month, int day) {
        String yearColName = Properties.Year.columnName;
        String monthColName = Properties.Month.columnName;
        String dayColName = Properties.Day.columnName;
        String userIDColName = Properties.UserID.columnName;

        long time = DateUtil.getDate(year, month, day);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(time - 100000);

        int yesterdayYear = calendar.get(Calendar.YEAR);
        int yesterdayMonth = calendar.get(Calendar.MONTH) + 1;
        int yesterdayDay = calendar.get(Calendar.DAY_OF_MONTH);

        StringBuilder sb = new StringBuilder();

        String timeCondition = (yearColName + " = " + year) + " and " + (monthColName + " = " + month) + " and " + (dayColName + " = " + day);

        String yesterdayTimeCondition = (yearColName + " = " + yesterdayYear) + " and " + (monthColName + " = " + yesterdayMonth) + " and " + (dayColName + " = " + yesterdayDay);

        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");

        sb.append(" where (");
        // 睡眠需要删除 2 天的数据
        sb.append("((").append(timeCondition).append(") or (").append(yesterdayTimeCondition).append("))");
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        sb.append(")");

        List<SleepData> dataList = queryRaw(sb.toString());

        if (dataList != null && !dataList.isEmpty()) {
            deleteInTx(dataList);
        }
    }

    /**
     * Creates the underlying database table.
     */
    public static void createTable(Database db, boolean ifNotExists) {
        String constraint = ifNotExists ? "IF NOT EXISTS " : "";
        db.execSQL("CREATE TABLE " + constraint + "\"SLEEP_DATA\" (" + //
                "\"_id\" INTEGER PRIMARY KEY AUTOINCREMENT ," + // 0: id
                "\"YEAR\" INTEGER NOT NULL ," + // 1: year
                "\"MONTH\" INTEGER NOT NULL ," + // 2: month
                "\"DAY\" INTEGER NOT NULL ," + // 3: day
                "\"MINUTES\" INTEGER NOT NULL ," + // 4: minutes
                "\"MODE\" INTEGER NOT NULL ," + // 5: mode
                "\"DATE\" INTEGER ," + //6: date
                "\"USERID\" VARCHAR);"); // 7: userID
    }

    /**
     * Drops the underlying database table.
     */
    public static void dropTable(Database db, boolean ifExists) {
        String sql = "DROP TABLE " + (ifExists ? "IF EXISTS " : "") + "\"SLEEP_DATA\"";
        db.execSQL(sql);
    }

    /**
     * Drops the underlying database table.
     */
    public static void addUserID(Database db) {
        try {
            String sql = "AlTer TABLE  \"SLEEP_DATA\" Add COLUMN \"USERID\" VARCHAR";
            db.execSQL(sql);
        } catch (Exception ignored) {
        }
    }

    /**
     * @inheritdoc
     */
    @Override
    protected void bindValues(SQLiteStatement stmt, SleepData entity) {
        stmt.clearBindings();

        Long id = entity.getId();
        if (id != null) {
            stmt.bindLong(1, id);
        }
        stmt.bindLong(2, entity.getYear());
        stmt.bindLong(3, entity.getMonth());
        stmt.bindLong(4, entity.getDay());
        stmt.bindLong(5, entity.getMinutes());
        stmt.bindLong(6, entity.getMode());

        java.util.Date date = entity.getDate();
        if (date != null) {
            stmt.bindLong(7, date.getTime());
        }

        String userID = entity.getUserID();
        if (userID != null) {
            stmt.bindString(8, userID);
        }
    }

    /**
     * @inheritdoc
     */
    @Override
    public Long readKey(Cursor cursor, int offset) {
        return cursor.isNull(offset + 0) ? null : cursor.getLong(offset + 0);
    }

    /**
     * @inheritdoc
     */
    @Override
    public SleepData readEntity(Cursor cursor, int offset) {
        SleepData entity = new SleepData( //
                cursor.isNull(offset + 0) ? null : cursor.getLong(offset + 0), // id
                cursor.getInt(offset + 1), // year
                cursor.getInt(offset + 2), // month
                cursor.getInt(offset + 3), // day
                cursor.getInt(offset + 4), // minutes
                cursor.getInt(offset + 5), // mode
                cursor.isNull(offset + 6) ? null : new java.util.Date(cursor.getLong(offset + 6)), // date
                cursor.isNull(offset + 7) ? null : cursor.getString(offset + 7)// distance
        );
        return entity;
    }

    /**
     * @inheritdoc
     */
    @Override
    public void readEntity(Cursor cursor, SleepData entity, int offset) {
        entity.setId(cursor.isNull(offset + 0) ? null : cursor.getLong(offset + 0));
        entity.setYear(cursor.getInt(offset + 1));
        entity.setMonth(cursor.getInt(offset + 2));
        entity.setDay(cursor.getInt(offset + 3));
        entity.setMinutes(cursor.getInt(offset + 4));
        entity.setMode(cursor.getInt(offset + 5));
        entity.setDate(cursor.isNull(offset + 6) ? null : new java.util.Date(cursor.getLong(offset + 6)));
        entity.setUserID(cursor.isNull(offset + 7) ? null : cursor.getString(offset + 7));
    }

    @Override
    protected void bindValues(DatabaseStatement stmt, SleepData entity) {

    }

    /**
     * @inheritdoc
     */
    @Override
    protected Long updateKeyAfterInsert(SleepData entity, long rowId) {
        entity.setId(rowId);
        return rowId;
    }

    /**
     * @inheritdoc
     */
    @Override
    public Long getKey(SleepData entity) {
        if (entity != null) {
            return entity.getId();
        } else {
            return null;
        }
    }

    @Override
    protected boolean hasKey(SleepData entity) {
        return false;
    }

    /**
     * @inheritdoc
     */
    @Override
    protected boolean isEntityUpdateable() {
        return true;
    }

}
