package com.wosmart.ukprotocollibary.model.db;

import com.wosmart.ukprotocollibary.model.hrp.HrpData;
import com.wosmart.ukprotocollibary.model.sleep.SleepData;
import com.wosmart.ukprotocollibary.model.sport.SportData;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodFatInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.UricAcidInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRMovementInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateVariabilityInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPulseInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSaunaInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSleepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSpO2Info;
import com.wosmart.ukprotocollibary.v2.entity.JWSportInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWStepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUltravioletInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWearingTimeInfo;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.AbstractDaoSession;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.identityscope.IdentityScopeType;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.Map;


public class DaoSession extends AbstractDaoSession {

    private final DaoConfig sportDataDaoConfig;
    private final DaoConfig sleepDataDaoConfig;
    private final DaoConfig hrpDataDaoConfig;
    private final DaoConfig pulseDataDaoConfig;
    private final DaoConfig saunaDataDaoConfig;
    private final DaoConfig hrMovementDataDaoConfig;
    private final DaoConfig bloodPressureDataDaoConfig;
    private final DaoConfig bloodSugarDataDaoConfig;
    private final DaoConfig heartRateDataDaoConfig;
    private final DaoConfig heartRateVariabilityDataDaoConfig;
    private final DaoConfig spo2DataDaoConfig;
    private final DaoConfig temperatureDataDaoConfig;
    private final DaoConfig stepDataDaoConfig;
    private final DaoConfig sleepData2DaoConfig;
    private final DaoConfig sportData2DaoConfig;
    private final DaoConfig wearingTimeDataDaoConfig;
    private final DaoConfig uricAcidDataDaoConfig;
    private final DaoConfig bloodFatDataDaoConfig;
    private final DaoConfig bloodSugarCycleDataDaoConfig;
    private final DaoConfig uricAcidContinuousMonitoringDataDaoConfig;
    private final DaoConfig bloodFatContinuousMonitoringDataDaoConfig;
    private final DaoConfig bodyFatDataDaoConfig;
    private final DaoConfig physicalExamDataDaoConfig;
    private final DaoConfig hrvRmssdDataDaoConfig;
    private final DaoConfig ultravioletDataDaoConfig;
    private final DaoConfig pressureDataDaoConfig;

    private final SportDataDao sportDataDao;
    private final SleepDataDao sleepDataDao;
    private final HrpDataDao hrpDataDao;
    private final PulseDataDao pulseDataDao;
    private final SaunaDataDao saunaDataDao;
    private final HRMovementDataDao hrMovementDataDao;
    private final BloodPressureDataDao bloodPressureDataDao;
    private final BloodSugarDataDao bloodSugarDataDao;
    private final HeartRateDataDao heartRateDataDao;
    private final HeartRateVariabilityDataDao heartRateVariabilityDataDao;
    private final SpO2DataDao spo2DataDao;
    private final TemperatureDataDao temperatureDataDao;
    private final StepDataDao stepDataDao;
    private final SleepData2Dao sleepData2Dao;
    private final SportData2Dao sportData2Dao;
    private final WearingTimeDataDao wearingTimeDataDao;
    private final UricAcidDataDao uricAcidDataDao;
    private final BloodFatDataDao bloodFatDataDao;
    private final BloodSugarCycleDataDao bloodSugarCycleDataDao;
    private final UricAcidContinuousMonitoringDataDao uricAcidContinuousMonitoringDataDao;
    private final BloodFatContinuousMonitoringDataDao bloodFatContinuousMonitoringDataDao;
    private final BodyFatDataDao bodyFatDataDao;
    private final PhysicalExamDataDao physicalExamDataDao;
    private final HRVRmssdDataDao hrvRmssdDataDao;
    private final UltravioletDataDao ultravioletDataDao;
    private final PressureDataDao pressureDataDao;

    public DaoSession(Database db, IdentityScopeType type, Map<Class<? extends AbstractDao<?, ?>>, DaoConfig>
            daoConfigMap) {
        super(db);

        sportDataDaoConfig = daoConfigMap.get(SportDataDao.class).clone();
        sportDataDaoConfig.initIdentityScope(type);

        sleepDataDaoConfig = daoConfigMap.get(SleepDataDao.class).clone();
        sleepDataDaoConfig.initIdentityScope(type);

        hrpDataDaoConfig = daoConfigMap.get(HrpDataDao.class).clone();
        hrpDataDaoConfig.initIdentityScope(type);

        pulseDataDaoConfig = daoConfigMap.get(PulseDataDao.class).clone();
        pulseDataDaoConfig.initIdentityScope(type);

        saunaDataDaoConfig = daoConfigMap.get(SaunaDataDao.class).clone();
        saunaDataDaoConfig.initIdentityScope(type);

        hrMovementDataDaoConfig = daoConfigMap.get(HRMovementDataDao.class).clone();
        hrMovementDataDaoConfig.initIdentityScope(type);

        bloodPressureDataDaoConfig = daoConfigMap.get(BloodPressureDataDao.class).clone();
        bloodPressureDataDaoConfig.initIdentityScope(type);

        bloodSugarDataDaoConfig = daoConfigMap.get(BloodSugarDataDao.class).clone();
        bloodSugarDataDaoConfig.initIdentityScope(type);

        heartRateDataDaoConfig = daoConfigMap.get(HeartRateDataDao.class).clone();
        heartRateDataDaoConfig.initIdentityScope(type);

        heartRateVariabilityDataDaoConfig = daoConfigMap.get(HeartRateVariabilityDataDao.class).clone();
        heartRateVariabilityDataDaoConfig.initIdentityScope(type);

        spo2DataDaoConfig = daoConfigMap.get(SpO2DataDao.class).clone();
        spo2DataDaoConfig.initIdentityScope(type);

        temperatureDataDaoConfig = daoConfigMap.get(TemperatureDataDao.class).clone();
        temperatureDataDaoConfig.initIdentityScope(type);

        stepDataDaoConfig = daoConfigMap.get(StepDataDao.class).clone();
        stepDataDaoConfig.initIdentityScope(type);

        sleepData2DaoConfig = daoConfigMap.get(SleepData2Dao.class).clone();
        sleepData2DaoConfig.initIdentityScope(type);

        sportData2DaoConfig = daoConfigMap.get(SportData2Dao.class).clone();
        sportData2DaoConfig.initIdentityScope(type);

        wearingTimeDataDaoConfig = daoConfigMap.get(WearingTimeDataDao.class).clone();
        wearingTimeDataDaoConfig.initIdentityScope(type);

        uricAcidDataDaoConfig = daoConfigMap.get(UricAcidDataDao.class).clone();
        uricAcidDataDaoConfig.initIdentityScope(type);

        bloodFatDataDaoConfig = daoConfigMap.get(BloodFatDataDao.class).clone();
        bloodFatDataDaoConfig.initIdentityScope(type);

        bloodSugarCycleDataDaoConfig = daoConfigMap.get(BloodSugarCycleDataDao.class).clone();
        bloodSugarCycleDataDaoConfig.initIdentityScope(type);

        uricAcidContinuousMonitoringDataDaoConfig = daoConfigMap.get(UricAcidContinuousMonitoringDataDao.class).clone();
        uricAcidContinuousMonitoringDataDaoConfig.initIdentityScope(type);

        bloodFatContinuousMonitoringDataDaoConfig = daoConfigMap.get(BloodFatContinuousMonitoringDataDao.class).clone();
        bloodFatContinuousMonitoringDataDaoConfig.initIdentityScope(type);

        bodyFatDataDaoConfig = daoConfigMap.get(BodyFatDataDao.class).clone();
        bodyFatDataDaoConfig.initIdentityScope(type);

        physicalExamDataDaoConfig = daoConfigMap.get(PhysicalExamDataDao.class).clone();
        physicalExamDataDaoConfig.initIdentityScope(type);

        hrvRmssdDataDaoConfig = daoConfigMap.get(HRVRmssdDataDao.class).clone();
        hrvRmssdDataDaoConfig.initIdentityScope(type);

        ultravioletDataDaoConfig = daoConfigMap.get(UltravioletDataDao.class).clone();
        ultravioletDataDaoConfig.initIdentityScope(type);

        pressureDataDaoConfig = daoConfigMap.get(PressureDataDao.class).clone();
        pressureDataDaoConfig.initIdentityScope(type);

        sportDataDao = new SportDataDao(sportDataDaoConfig, this);
        sleepDataDao = new SleepDataDao(sleepDataDaoConfig, this);
        hrpDataDao = new HrpDataDao(hrpDataDaoConfig, this);
        pulseDataDao = new PulseDataDao(pulseDataDaoConfig, this);
        saunaDataDao = new SaunaDataDao(saunaDataDaoConfig, this);
        hrMovementDataDao = new HRMovementDataDao(hrMovementDataDaoConfig, this);
        bloodPressureDataDao = new BloodPressureDataDao(bloodPressureDataDaoConfig, this);
        bloodSugarDataDao = new BloodSugarDataDao(bloodSugarDataDaoConfig, this);
        heartRateDataDao = new HeartRateDataDao(heartRateDataDaoConfig, this);
        heartRateVariabilityDataDao = new HeartRateVariabilityDataDao(heartRateVariabilityDataDaoConfig, this);
        spo2DataDao = new SpO2DataDao(spo2DataDaoConfig, this);
        temperatureDataDao = new TemperatureDataDao(temperatureDataDaoConfig, this);
        stepDataDao = new StepDataDao(stepDataDaoConfig, this);
        sleepData2Dao = new SleepData2Dao(sleepData2DaoConfig, this);
        sportData2Dao = new SportData2Dao(sportData2DaoConfig, this);
        wearingTimeDataDao = new WearingTimeDataDao(wearingTimeDataDaoConfig, this);
        uricAcidDataDao = new UricAcidDataDao(uricAcidDataDaoConfig, this);
        bloodFatDataDao = new BloodFatDataDao(bloodFatDataDaoConfig, this);
        bloodSugarCycleDataDao = new BloodSugarCycleDataDao(bloodSugarCycleDataDaoConfig, this);
        uricAcidContinuousMonitoringDataDao = new UricAcidContinuousMonitoringDataDao(uricAcidContinuousMonitoringDataDaoConfig, this);
        bloodFatContinuousMonitoringDataDao = new BloodFatContinuousMonitoringDataDao(bloodFatContinuousMonitoringDataDaoConfig, this);
        bodyFatDataDao = new BodyFatDataDao(bodyFatDataDaoConfig, this);
        physicalExamDataDao = new PhysicalExamDataDao(physicalExamDataDaoConfig, this);
        hrvRmssdDataDao = new HRVRmssdDataDao(hrvRmssdDataDaoConfig, this);
        ultravioletDataDao = new UltravioletDataDao(ultravioletDataDaoConfig, this);
        pressureDataDao = new PressureDataDao(pressureDataDaoConfig, this);

        registerDao(SportData.class, sportDataDao);
        registerDao(SleepData.class, sleepDataDao);
        registerDao(HrpData.class, hrpDataDao);
        registerDao(JWPulseInfo.class, pulseDataDao);
        registerDao(JWSaunaInfo.class, saunaDataDao);
        registerDao(JWHRMovementInfo.class, hrMovementDataDao);
        registerDao(JWBloodPressureInfo.class, bloodPressureDataDao);
        registerDao(JWBloodSugarInfo.class, bloodSugarDataDao);
        registerDao(JWHeartRateInfo.class, heartRateDataDao);
        registerDao(JWHeartRateVariabilityInfo.class, heartRateVariabilityDataDao);
        registerDao(JWSpO2Info.class, spo2DataDao);
        registerDao(JWTemperatureInfo.class, temperatureDataDao);
        registerDao(JWStepInfo.class, stepDataDao);
        registerDao(JWSleepInfo.class, sleepData2Dao);
        registerDao(JWSportInfo.class, sportData2Dao);
        registerDao(JWWearingTimeInfo.class, wearingTimeDataDao);
        registerDao(UricAcidInfo.class, uricAcidDataDao);
        registerDao(BloodFatInfo.class, bloodFatDataDao);
        registerDao(BloodSugarCycleInfo.class, bloodSugarCycleDataDao);
        registerDao(JWUricAcidContinuousMonitoringInfo.class, uricAcidContinuousMonitoringDataDao);
        registerDao(JWBloodFatContinuousMonitoringInfo.class, bloodFatContinuousMonitoringDataDao);
        registerDao(JWBodyFatInfo.class, bodyFatDataDao);
        registerDao(JWPhysicalExamInfo.class, physicalExamDataDao);
        registerDao(JWHRVRmssdInfo.class, hrvRmssdDataDao);
        registerDao(JWUltravioletInfo.class, ultravioletDataDao);
        registerDao(JWPressureInfo.class, pressureDataDao);
    }
    
    public void clear() {
        sportDataDaoConfig.getIdentityScope().clear();
        sleepDataDaoConfig.getIdentityScope().clear();
        hrpDataDaoConfig.getIdentityScope().clear();
        pulseDataDaoConfig.getIdentityScope().clear();
        saunaDataDaoConfig.getIdentityScope().clear();
        hrMovementDataDaoConfig.getIdentityScope().clear();
        bloodPressureDataDaoConfig.getIdentityScope().clear();
        bloodSugarDataDaoConfig.getIdentityScope().clear();
        heartRateDataDaoConfig.getIdentityScope().clear();
        heartRateVariabilityDataDaoConfig.getIdentityScope().clear();
        spo2DataDaoConfig.getIdentityScope().clear();
        temperatureDataDaoConfig.getIdentityScope().clear();
        stepDataDaoConfig.getIdentityScope().clear();
        sleepData2DaoConfig.getIdentityScope().clear();
        sportData2DaoConfig.getIdentityScope().clear();
        wearingTimeDataDaoConfig.getIdentityScope().clear();
        uricAcidDataDaoConfig.getIdentityScope().clear();
        bloodFatDataDaoConfig.getIdentityScope().clear();
        bloodSugarCycleDataDaoConfig.getIdentityScope().clear();
        uricAcidContinuousMonitoringDataDaoConfig.getIdentityScope().clear();
        bloodFatContinuousMonitoringDataDaoConfig.getIdentityScope().clear();
        bodyFatDataDaoConfig.getIdentityScope().clear();
        physicalExamDataDaoConfig.getIdentityScope().clear();
        hrvRmssdDataDaoConfig.getIdentityScope().clear();
        ultravioletDataDaoConfig.getIdentityScope().clear();
        pressureDataDaoConfig.getIdentityScope().clear();
    }

    public SportDataDao getSportDataDao() {
        return sportDataDao;
    }

    public SleepDataDao getSleepDataDao() {
        return sleepDataDao;
    }

    public HrpDataDao getHrpDataDao() {
        return hrpDataDao;
    }

    public PulseDataDao getPulseDataDao() {
        return pulseDataDao;
    }

    public SaunaDataDao getSaunaDataDao() {
        return saunaDataDao;
    }

    public HRMovementDataDao getHRMovementDataDao() {
        return hrMovementDataDao;
    }

    public BloodPressureDataDao getBloodPressureDataDao() {
        return bloodPressureDataDao;
    }

    public BloodSugarDataDao getBloodSugarDataDao() {
        return bloodSugarDataDao;
    }

    public HeartRateDataDao getHeartRateDataDao() {
        return heartRateDataDao;
    }

    public HeartRateVariabilityDataDao getHeartRateVariabilityDataDao() {
        return heartRateVariabilityDataDao;
    }

    public SpO2DataDao getSpo2DataDao() {
        return spo2DataDao;
    }

    public TemperatureDataDao getTemperatureDataDao() {
        return temperatureDataDao;
    }

    public StepDataDao getStepDataDao() {
        return stepDataDao;
    }

    public SleepData2Dao getSleepData2Dao() {
        return sleepData2Dao;
    }

    public SportData2Dao getSportData2Dao() {
        return sportData2Dao;
    }

    public WearingTimeDataDao getWearingTimeDataDao() {
        return wearingTimeDataDao;
    }

    public UricAcidDataDao getUricAcidDataDao() {
        return uricAcidDataDao;
    }

    public BloodFatDataDao getBloodFatDataDao() {
        return bloodFatDataDao;
    }

    public BloodSugarCycleDataDao getBloodSugarCycleDataDao() {
        return bloodSugarCycleDataDao;
    }

    public UricAcidContinuousMonitoringDataDao getUricAcidContinuousMonitoringDataDao() {
        return uricAcidContinuousMonitoringDataDao;
    }

    public BloodFatContinuousMonitoringDataDao getBloodFatContinuousMonitoringDataDao() {
        return bloodFatContinuousMonitoringDataDao;
    }

    public BodyFatDataDao getBodyFatDataDao() {
        return bodyFatDataDao;
    }

    public PhysicalExamDataDao getPhysicalExamDataDao() {
        return physicalExamDataDao;
    }

    public HRVRmssdDataDao getHRVRmssdDataDao() {
        return hrvRmssdDataDao;
    }

    public UltravioletDataDao getUltravioletDataDao() {
        return ultravioletDataDao;
    }

    public PressureDataDao getPressureDataDao() {
        return pressureDataDao;
    }

}
