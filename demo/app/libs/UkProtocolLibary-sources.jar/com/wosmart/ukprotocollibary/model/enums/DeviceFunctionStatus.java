package com.wosmart.ukprotocollibary.model.enums;

/**
 * enums of support function
 */
public enum DeviceFunctionStatus {
    /**
     * 不支持
     */
    UN_SUPPORT,

    /**
     * 支持
     */
    SUPPORT,

    /**
     * 支持关闭
     */
    SUPPORT_CLOSE,

    /**
     * 支持打开
     */
    SUPPORT_OPEN
}
