package com.wosmart.ukprotocollibary.model.sleep;

import com.wosmart.ukprotocollibary.v2.entity.JWSleepInfo;

import java.util.Calendar;
import java.util.Date;

public class SleepData {

    /**
     * id
     */
    private Long id;

    /**
     * year
     */
    private int year;

    /**
     * month
     */
    private int month;

    /**
     * day
     */
    private int day;

    /**
     * minutes of day
     */
    private int minutes;

    /**
     * sleep mode
     * 1:light sleep  2:deep sleep  3:awake sleep
     */
    private int mode;

    /**
     * sleep date
     */
    private java.util.Date date;

    private String userID;

    public SleepData() {
    }

    public SleepData(Long id) {
        this.id = id;
    }

//    public SleepData(Long id, int year, int month, int day, int minutes, int mode, java.util.Date date) {
//        this.id = id;
//        this.year = year;
//        this.month = month;
//        this.day = day;
//        this.minutes = minutes;
//        this.mode = mode;
//        this.date = date;
//    }

    public SleepData(JWSleepInfo sleepInfo) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(sleepInfo.getTime());

        this.year = calendar.get(Calendar.YEAR);
        this.month = calendar.get(Calendar.MONTH) + 1;
        this.day = calendar.get(Calendar.DAY_OF_MONTH);
        this.minutes = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE);
        this.mode = sleepInfo.getMode();
        this.userID = sleepInfo.getUserID();
        this.date = calendar.getTime();
    }

    public SleepData(Long id, int year, int month, int day, int minutes, int mode, Date date, String userID) {
        this.id = id;
        this.year = year;
        this.month = month;
        this.day = day;
        this.minutes = minutes;
        this.mode = mode;
        this.date = date;
        this.userID = userID;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMinutes() {
        return minutes;
    }

    public void setMinutes(int minutes) {
        this.minutes = minutes;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

    public java.util.Date getDate() {
        return date;
    }

    public void setDate(java.util.Date date) {
        this.date = date;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    @Override
    public String toString() {
        return "SleepData{" +
                "id=" + id +
                ", year=" + year +
                ", month=" + month +
                ", day=" + day +
                ", minutes=" + minutes +
                ", mode=" + mode +
                ", date=" + date +
                ", userID=" + userID +
                '}';
    }
}
