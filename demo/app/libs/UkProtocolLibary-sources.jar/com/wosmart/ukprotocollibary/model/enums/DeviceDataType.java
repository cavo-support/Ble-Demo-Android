package com.wosmart.ukprotocollibary.model.enums;

public enum DeviceDataType {

    /**
     * 步数
     */
    STEP,

    /**
     * 睡眠
     */
    SLEEP,

    /**
     * 心率
     */
    HEART_RATE,

    /**
     * 血压
     */
    BLOOD_PRESSURE,

    /**
     * 运动
     */
    EXERCISE,

    /**
     * 血压
     */
    BO,

    /**
     * 心率变异性
     */
    HRV,

    /**
     * 血糖
     */
    GLU,

    /**
     * 佩戴时间
     */
    WEARING_TIME,

    /**
     * 尿酸
     */
    URIC_ACID,

    /**
     * 血脂
     */
    BLOOD_FAT,

    /**
     * 血糖周期
     */
    BLOOD_SUGAR_CYCLE,

    /**
     * 尿酸连续监测
     */
    URIC_ACID_CONTINUOUS_MONITORING,

    /**
     * 血脂连续监测
     */
    BLOOD_FAT_CONTINUOUS_MONITORING,

    /**
     * 未定义
     */
    UN_KNOW
}
