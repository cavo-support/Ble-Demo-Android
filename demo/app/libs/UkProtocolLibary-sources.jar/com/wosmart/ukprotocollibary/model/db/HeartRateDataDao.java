package com.wosmart.ukprotocollibary.model.db;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateInfo;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.AbstractDaoSession;
import org.greenrobot.greendao.Property;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseStatement;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.List;

public class HeartRateDataDao extends AbstractDao<JWHeartRateInfo, Long> {

    public static final String TABLENAME = "HEART_RATE_DATA";

    public static class Properties {
        public final static Property time = new Property(0, Long.class, "time", true, "TIME");
        public final static Property userID = new Property(1, String.class, "userID", true, "USER_ID");
        public final static Property mac = new Property(2, String.class, "mac", false, "MAC");
        public final static Property date = new Property(3, java.util.Date.class, "date", false, "DATE");
        public final static Property value = new Property(4, int.class, "value", false, "VALUE");
    }

    public HeartRateDataDao(DaoConfig config) {
        super(config);
    }

    public HeartRateDataDao(DaoConfig config, AbstractDaoSession daoSession) {
        super(config, daoSession);
    }



    public List<JWHeartRateInfo> queryDataList(String userID, String mac, long timeBegin, long timePeriod, int count) {
        String timeColName = Properties.time.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;
        String dateColName = Properties.date.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition;
        if (timeBegin == 0) {
            // 从当前时间
            timeCondition = timeColName + " <= " + System.currentTimeMillis();
        } else {
            timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));
        }
        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");
        String macCondition = TextUtils.isEmpty(mac) ? "" : (" " + macColName + " = '" + mac + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        if (!TextUtils.isEmpty(macCondition)) {
            sb.append(" and ").append(macCondition);
        }
        sb.append(")");

        String orderBy = " ORDER BY " + dateColName + " ASC ";
        String limit = count == 0 ? "" : (" LIMIT " + count);

        sb.append(orderBy);
        sb.append(limit);

        return queryRaw(sb.toString());
    }

    public void deleteByTime(String userID, String mac, long timeBegin, long timePeriod) {
        String timeColName = Properties.time.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;

        String timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));

        StringBuilder sb = new StringBuilder();

        sb.append("DELETE FROM " + TABLENAME + " WHERE ");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userID)) {
            sb.append(" and ").append(userIDColName).append(" = '").append(userID).append("' ");
        }
        if (!TextUtils.isEmpty(mac)) {
            sb.append(" and ").append(macColName).append(" = '").append(mac).append("' ");
        }

        GlobalGreenDAO.getInstance().getSQLDatabase().execSQL(sb.toString());
    }

    public static void createTable(Database db) {
        db.execSQL("create table IF NOT EXISTS " + TABLENAME + "\n" +
                "(\n" +
                Properties.time.columnName + " bigint not null ,\n" +
                Properties.userID.columnName + " varchar(256) not null ,\n" +
                Properties.mac.columnName + " varchar(256) ,\n" +
                Properties.date.columnName + " varchar(50) not null ,\n" +
                Properties.value.columnName + " int not null ,\n" +
                " primary key (" + Properties.time.columnName + ", " + Properties.userID.columnName + ")\n" +
                ");");
    }

    public static void dropTable(Database db) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
    }

    public static void addMacAddressCol(Database db) {
        try {
            String sql = "AlTER TABLE " + TABLENAME + " Add COLUMN " + Properties.mac.columnName + " varchar(256)";
            db.execSQL(sql);
        } catch (Exception ignored) {
        }
    }

    @Override
    protected JWHeartRateInfo readEntity(Cursor cursor, int offset) {
        JWHeartRateInfo info = new JWHeartRateInfo();
        info.time = cursor.getLong(offset + Properties.time.ordinal);
        info.userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        info.deviceMac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        info.value = cursor.getInt(offset + Properties.value.ordinal);
        return info;
    }

    @Override
    protected Long readKey(Cursor cursor, int offset) {
        return cursor.getLong(offset);
    }

    @Override
    protected void readEntity(Cursor cursor, JWHeartRateInfo info, int offset) {
        info.time = cursor.getLong(offset + Properties.time.ordinal);
        info.userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        info.deviceMac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        info.value = cursor.getInt(offset + Properties.value.ordinal);
    }

    @Override
    protected void bindValues(DatabaseStatement stmt, JWHeartRateInfo info) {

    }

    @Override
    protected void bindValues(SQLiteStatement stmt, JWHeartRateInfo info) {
        stmt.clearBindings();

        stmt.bindLong(Properties.time.ordinal + 1, info.time);
        stmt.bindString(Properties.userID.ordinal + 1, TextUtils.isEmpty(info.userID) ? "" : info.userID);
        stmt.bindString(Properties.mac.ordinal + 1, TextUtils.isEmpty(info.deviceMac) ? "" : info.deviceMac);
        stmt.bindString(Properties.date.ordinal + 1, DateUtil.toTime2(info.time));
        stmt.bindLong(Properties.value.ordinal + 1, info.value);
    }

    @Override
    protected Long updateKeyAfterInsert(JWHeartRateInfo info, long rowID) {
        return info.time;
    }

    @Override
    protected Long getKey(JWHeartRateInfo info) {
        return info.time;
    }

    @Override
    protected boolean hasKey(JWHeartRateInfo info) {
        return false;
    }

    @Override
    protected boolean isEntityUpdateable() {
        return true;
    }
}
