package com.wosmart.ukprotocollibary.model.sleep.filter;

import com.wosmart.ukprotocollibary.WristbandManager;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayer;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerFunctionPacket;
import com.wosmart.ukprotocollibary.v2.JWHealthDataSearchParams;
import com.wosmart.ukprotocollibary.v2.common.JWContext;
import com.wosmart.ukprotocollibary.model.db.GlobalGreenDAO;
import com.wosmart.ukprotocollibary.model.enums.DeviceFunctionStatus;
import com.wosmart.ukprotocollibary.model.sleep.SleepData;
import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.util.SDKLogger;
import com.wosmart.ukprotocollibary.v2.entity.JWHealthData;
import com.wosmart.ukprotocollibary.v2.entity.JWSleepInfo;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 睡眠数据过滤机制
 * <ol>
 * Updated on 22/08/2017.
 * <li>在01:00点前出现清醒时间，且清醒时间（整体在01：00之前）大于等于20min，则删除之前的睡眠数据。(考虑到早睡情况，这条待确认，考虑目前的测试群体)</li>
 * <li>早上05:00点之后（整体在05：00之后），出现清醒时间超过30min，则之后的数据全部清除 </li>
 * <li>01:00之前最晚的一次清醒，如果之前只有清醒和浅睡，则删除该清醒状态以前的睡眠数据</li>
 * <li>05:00之后最早的一次清醒，如果之后只有清醒和浅睡，则删除该清醒状态以后的睡眠数据</li>
 * <li>01:00之前到05:00之后，为清醒状态，所有睡眠数据清除（核心区处于清醒状态）</li>
 *
 * <li>01:00点之前深睡超过1.5小时（整体在01：00之前），则之前的睡眠数据全部清除</li>
 * <li>05:00之后（整体在05：00之后），深睡超过1.5小时，则之后的睡眠数据全部清除</li>
 * <li>01:00和05:00之间(可包含1点或者5点)，深睡超过2.5小时，所有睡眠数据清除</li>
 *
 * <li>什么时候show UI，如何show:
 * ①当前阶段不show，show之前完整的阶段，并按照 1，2，3，4，5，6，7过滤；
 * ②总睡眠（清醒前后的 深睡 + 浅睡 ）时间小于2个小时不show；</li>
 * </ol>
 * Created by bingshanguxue on 22/08/2017.
 */

public class SleepFilter {
    private static final boolean D = true;

    public static final int HALF_AN_HOUR = 30;
    public static final int MINUTES_OF_HOUR = 60;
    public static final int MINUTES_OF_DAY = 24 * MINUTES_OF_HOUR;

    public static final int START_SLEEP_TIME_MINUTE = 18 * MINUTES_OF_HOUR;
    public static final int END_SLEEP_TIME_MINUTE = 18 * MINUTES_OF_HOUR - 1;// Change to 17:59

    public static final int START_AWAKE_CHECK_TIME_MINUTE = MINUTES_OF_HOUR + MINUTES_OF_DAY;
    public static final int END_AWAKE_CHECK_TIME_MINUTE = 5 * MINUTES_OF_HOUR + MINUTES_OF_DAY;

    public static final int START_AWAKE_ARRAY_CHECK_TIME_MINUTE_ADJUST = MINUTES_OF_HOUR + MINUTES_OF_DAY;

    public static final int ALLOW_AWAKE_CHECK_TIME_MINUTE_PRE = 20;
    public static final int ALLOW_AWAKE_CHECK_TIME_MINUTE_BEH = MINUTES_OF_HOUR;
    public static final int ALLOW_AWAKE_CHECK_TIME_MINUTE = ALLOW_AWAKE_CHECK_TIME_MINUTE_PRE;

    public static final int START_DEEP_CHECK_TIME_MINUTE = MINUTES_OF_HOUR + MINUTES_OF_DAY;
    public static final int END_DEEP_CHECK_TIME_MINUTE = 5 * MINUTES_OF_HOUR + MINUTES_OF_DAY;

    public static final int ALLOW_DEEP_CHECK_TIME_MINUTE_PRE = (int) (1.5 * MINUTES_OF_HOUR);
    public static final int ALLOW_DEEP_CHECK_TIME_MINUTE_BEH = (int) (2.5 * MINUTES_OF_HOUR);
    public static final int ALLOW_DEEP_CHECK_TIME_MINUTE = ALLOW_DEEP_CHECK_TIME_MINUTE_PRE;

    public static final int CHECK_NO_ERROR = 0;
    public static final int CHECK_DROP_FRONT = 1;
    public static final int CHECK_DROP_BEHIND = 2;
    public static final int CHECK_DROP_ALL = 3;

    private static final int INDEX_NA = -1;//初始化

    /**
     * filter sleep data by specified date
     */
    public static SleepInfo filterByData(String deviceMac, int year, int month, int day) {
        if (GlobalGreenDAO.getInstance() == null) {
            SDKLogger.e("sdk not init, please call WristbandManager.getInstance(context).initSDK()");
            return null;
        }

        long timeBegin = DateUtil.getDate(year, month, day);// 当天 0 点
        timeBegin -= 4 * 3600000;// 从昨晚 8 点开始计算
        long timePeriod = 14 * 3600000;// 持续 14 小时

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setDeviceMac(deviceMac);
        params.setDataType(JWHealthData.DateType.Sleep);
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);

        List<JWSleepInfo> sleepInfoList = GlobalGreenDAO.getInstance().loadSleepData2(params);
        if (sleepInfoList == null || sleepInfoList.isEmpty()) {
            return null;
        }
        List<SleepData> sleepDataList = new ArrayList<>();

        for (JWSleepInfo sleepInfo : sleepInfoList) {
            sleepDataList.add(new SleepData(sleepInfo));
        }

        //过滤
        List<SleepFilterData> sleepFilterDataList = SleepFilter.filter(year, month, day, sleepDataList);
        //过滤头尾
        List<SleepFilterData> sleepFilterDataList2 = SleepFilter.filterBeginAndEnd(sleepFilterDataList);

        SleepInfo sleep = null;
        if (null != sleepFilterDataList2 && sleepFilterDataList2.size() > 2) {
            SDKLogger.i(D, "sleep size = " + sleepFilterDataList2.size());

            sleep = new SleepInfo();

            int wakeNum = 0;
            int firstTime = 0;
            int deepTime = 0;
            int lowTime = 0;
            int awakeTime = 0;
            int allTime = 0;
            String sleepDown = "";
            String sleepUp = "";
            for (int k = 0; k < sleepFilterDataList2.size(); k++) {
                SleepFilterData sleepData = sleepFilterDataList2.get(k);
                SDKLogger.i(D,  "不过滤数据：sleep data  = " + sleepData.toString());
                int mode = sleepData.getMode();
                int minutes = sleepData.getMinutes();
                int startH = (minutes / 60) % 24;
                int startM = minutes % 60;

                int dur = sleepData.getMinutesAxes();
                int duration = 0;
                if (k == 0) {
                    String startTime = getTwoStr(sleepData.getYear()) + "-" + getTwoStr(sleepData.getMonth()) + "-" + getTwoStr(sleepData.getDay()) + " " + getTwoStr(startH) + ":" + getTwoStr(startM);
                    sleepDown = startTime;

                    SleepFilterData sleepData2 = sleepFilterDataList2.get(k + 1);
                    int dur2 = sleepData2.getMinutesAxes();
                    duration = dur2 - dur;
                    firstTime = duration;
                } else if (k == sleepFilterDataList2.size() - 1) {
                    int lastAwakeIndex = SleepFilter.getFirstAwakeIndex(sleepFilterDataList, sleepData.getMinutes());
                    if (lastAwakeIndex >= 0 && lastAwakeIndex < sleepFilterDataList.size()) {
                        SleepFilterData lastAwake = sleepFilterDataList.get(lastAwakeIndex);
                        duration = lastAwake.getMinutesAxes() - dur;

                        int minutes2 = lastAwake.getMinutes();
                        int startH2 = (minutes2 / 60) % 24;
                        int startM2 = minutes2 % 60;

                        String endTime = getTwoStr(lastAwake.getYear()) + "-" + getTwoStr(lastAwake.getMonth()) + "-" + getTwoStr(lastAwake.getDay()) + " " + getTwoStr(startH2) + ":" + getTwoStr(startM2);
                        sleepUp = endTime;
                    } else {
                        String endTime = getTwoStr(sleepData.getYear()) + "-" + getTwoStr(sleepData.getMonth()) + "-" + getTwoStr(sleepData.getDay()) + " " + getTwoStr(startH) + ":" + getTwoStr(startM);
                        sleepUp = endTime;
                        duration = 0;
                    }
                } else {
                    SleepFilterData sleepData2 = sleepFilterDataList2.get(k + 1);
                    int dur2 = sleepData2.getMinutesAxes();
                    duration = dur2 - dur;
                }

                if (mode == 1) {
                    allTime += duration;
                    lowTime += duration;
                } else if (mode == 2) {
                    allTime += duration;
                    deepTime += duration;
                } else if (mode == 3) {
                    awakeTime += duration;
                    wakeNum += 1;
                }
            }
            sleep.setDate(year + "-" + month + "-" + day);
            sleep.setCali_flag(0);
            sleep.setWakeCount(wakeNum);//苏醒次数 times of awakening
            sleep.setDeepSleepTime(deepTime);//沉睡时长（分钟） deep sleep time
            sleep.setLowSleepTime(lowTime);//浅睡时长（分钟）light sleep time
            sleep.setAllSleepTime(allTime);//睡眠总时长
            sleep.setSpan(1);//睡眠监测间隔

            SDKLogger.i(D,  "sleepDown = " + sleepDown + "sleepUp = " + sleepUp);
            long sleepDownT = DateUtil.getTime(sleepDown);
            //入睡时间 sleep latency
            sleep.setSleepDown(new SleepTimeData(DateUtil.getYear(sleepDownT), DateUtil.getMonth(sleepDownT), DateUtil.getDay(sleepDownT), DateUtil.getHour(sleepDownT), DateUtil.getMinute(sleepDownT)));
            long sleepUpT = DateUtil.getTime(sleepUp);
            //起床时间 wake up time
            sleep.setSleepUp(new SleepTimeData(DateUtil.getYear(sleepUpT), DateUtil.getMonth(sleepUpT), DateUtil.getDay(sleepUpT), DateUtil.getHour(sleepUpT), DateUtil.getMinute(sleepUpT)));

            boolean sleepQuality2 = false;
            if (JWContext.getInstance().getApplicationContext() != null) {
                ApplicationLayerFunctionPacket functionPacket = WristbandManager.getInstance(JWContext.getInstance().getApplicationContext()).getFunctionPacket();
                if (null != functionPacket) {
                    sleepQuality2 = DeviceFunctionStatus.SUPPORT == functionPacket.getSleepQuality2();

                }
            }

            int quality = 5;
            if (sleepQuality2) {
                quality = getSleepQuality2(deepTime + lowTime, deepTime, wakeNum);
            } else {
                quality = getSleepQuality(firstTime, deepTime, deepTime + lowTime, wakeNum);
            }
            //睡眠质量 sleep quality
            sleep.setSleepQuality(quality);
            SDKLogger.i(D,  "sleep data = " + sleep.toString());
        } else {
            SDKLogger.i(D,  "不过滤数据：sleep size = 0 ");
        }

        return sleep;
    }

    /**
     * filter sleep data by specified date
     */
    public static SleepInfo filterByData(int year, int month, int day) {
        if (GlobalGreenDAO.getInstance() == null) {
            SDKLogger.e("sdk not init, please call WristbandManager.getInstance(context).initSDK()");
            return null;
        }
        //睡眠
        List<SleepData> sleepDataList = GlobalGreenDAO.getInstance().loadSleepDataByDateSpec(year, month, day);
        //过滤
        List<SleepFilterData> sleepFilterDataList = SleepFilter.filter(year, month, day, sleepDataList);
        //过滤头尾
        List<SleepFilterData> sleepFilterDataList2 = SleepFilter.filterBeginAndEnd(sleepFilterDataList);

        SleepInfo sleep = null;
        if (null != sleepFilterDataList2 && sleepFilterDataList2.size() > 2) {
            SDKLogger.i(D, "sleep size = " + sleepFilterDataList2.size());

            sleep = new SleepInfo();

            int wakeNum = 0;
            int firstTime = 0;
            int deepTime = 0;
            int lowTime = 0;
            int awakeTime = 0;
            int allTime = 0;
            String sleepDown = "";
            String sleepUp = "";
            for (int k = 0; k < sleepFilterDataList2.size(); k++) {
                SleepFilterData sleepData = sleepFilterDataList2.get(k);
                SDKLogger.i(D,  "不过滤数据：sleep data  = " + sleepData.toString());
                int mode = sleepData.getMode();
                int minutes = sleepData.getMinutes();
                int startH = (minutes / 60) % 24;
                int startM = minutes % 60;

                int dur = sleepData.getMinutesAxes();
                int duration = 0;
                if (k == 0) {
                    String startTime = getTwoStr(sleepData.getYear()) + "-" + getTwoStr(sleepData.getMonth()) + "-" + getTwoStr(sleepData.getDay()) + " " + getTwoStr(startH) + ":" + getTwoStr(startM);
                    sleepDown = startTime;

                    SleepFilterData sleepData2 = sleepFilterDataList2.get(k + 1);
                    int dur2 = sleepData2.getMinutesAxes();
                    duration = dur2 - dur;
                    firstTime = duration;
                } else if (k == sleepFilterDataList2.size() - 1) {
                    int lastAwakeIndex = SleepFilter.getFirstAwakeIndex(sleepFilterDataList, sleepData.getMinutes());
                    if (lastAwakeIndex >= 0 && lastAwakeIndex < sleepFilterDataList.size()) {
                        SleepFilterData lastAwake = sleepFilterDataList.get(lastAwakeIndex);
                        duration = lastAwake.getMinutesAxes() - dur;

                        int minutes2 = lastAwake.getMinutes();
                        int startH2 = (minutes2 / 60) % 24;
                        int startM2 = minutes2 % 60;

                        String endTime = getTwoStr(lastAwake.getYear()) + "-" + getTwoStr(lastAwake.getMonth()) + "-" + getTwoStr(lastAwake.getDay()) + " " + getTwoStr(startH2) + ":" + getTwoStr(startM2);
                        sleepUp = endTime;
                    } else {
                        String endTime = getTwoStr(sleepData.getYear()) + "-" + getTwoStr(sleepData.getMonth()) + "-" + getTwoStr(sleepData.getDay()) + " " + getTwoStr(startH) + ":" + getTwoStr(startM);
                        sleepUp = endTime;
                        duration = 0;
                    }
                } else {
                    SleepFilterData sleepData2 = sleepFilterDataList2.get(k + 1);
                    int dur2 = sleepData2.getMinutesAxes();
                    duration = dur2 - dur;
                }

                if (mode == 1) {
                    allTime += duration;
                    lowTime += duration;
                } else if (mode == 2) {
                    allTime += duration;
                    deepTime += duration;
                } else if (mode == 3) {
                    awakeTime += duration;
                    wakeNum += 1;
                }
            }
            sleep.setDate(year + "-" + month + "-" + day);
            sleep.setCali_flag(0);
            sleep.setWakeCount(wakeNum);//苏醒次数 times of awakening
            sleep.setDeepSleepTime(deepTime);//沉睡时长（分钟） deep sleep time
            sleep.setLowSleepTime(lowTime);//浅睡时长（分钟）light sleep time
            sleep.setAllSleepTime(allTime);//睡眠总时长
            sleep.setSpan(1);//睡眠监测间隔

            SDKLogger.i(D,  "sleepDown = " + sleepDown + "sleepUp = " + sleepUp);
            long sleepDownT = DateUtil.getTime(sleepDown);
            //入睡时间 sleep latency
            sleep.setSleepDown(new SleepTimeData(DateUtil.getYear(sleepDownT), DateUtil.getMonth(sleepDownT), DateUtil.getDay(sleepDownT), DateUtil.getHour(sleepDownT), DateUtil.getMinute(sleepDownT)));
            long sleepUpT = DateUtil.getTime(sleepUp);
            //起床时间 wake up time
            sleep.setSleepUp(new SleepTimeData(DateUtil.getYear(sleepUpT), DateUtil.getMonth(sleepUpT), DateUtil.getDay(sleepUpT), DateUtil.getHour(sleepUpT), DateUtil.getMinute(sleepUpT)));

            boolean sleepQuality2 = false;
            if (JWContext.getInstance().getApplicationContext() != null) {
                ApplicationLayerFunctionPacket functionPacket = WristbandManager.getInstance(JWContext.getInstance().getApplicationContext()).getFunctionPacket();
                if (null != functionPacket) {
                    sleepQuality2 = DeviceFunctionStatus.SUPPORT == functionPacket.getSleepQuality2();

                }
            }

            int quality = 5;
            if (sleepQuality2) {
                quality = getSleepQuality2(deepTime + lowTime, deepTime, wakeNum);
            } else {
                quality = getSleepQuality(firstTime, deepTime, deepTime + lowTime, wakeNum);
            }
            //睡眠质量 sleep quality
            sleep.setSleepQuality(quality);
            SDKLogger.i(D,  "sleep data = " + sleep.toString());
        } else {
            SDKLogger.i(D,  "不过滤数据：sleep size = 0 ");
        }

        return sleep;
    }




    /**
     * 获取<前一天晚上到今天白天区间>睡眠数据
     * 按升序排序并删除时间重复的数据
     */
    public static ArrayList<SleepFilterData> filter(int y, int m, int d, List<SleepData> sleeps) {
        ArrayList<SleepFilterData> sls = new ArrayList<>();

        Calendar c1 = Calendar.getInstance();
        c1.set(y, m - 1, d);// here need decrease 1 of month
        c1.add(Calendar.DATE, -1);
        int yesterdayYear = c1.get(Calendar.YEAR);
        int yesterdayMonth = c1.get(Calendar.MONTH) + 1;
        int yesterdayDay = c1.get(Calendar.DATE);
        SDKLogger.d(D, String.format("%d/%d/%d ~ %d/%d/%d",
                yesterdayYear, yesterdayMonth, yesterdayDay,
                y, m, d));

        List<SleepData> d1 = getSubSleepDataByDate(yesterdayYear, yesterdayMonth, yesterdayDay, sleeps);
        if (d1 != null && d1.size() > 0) {
            for (SleepData sl : d1) {
                if (sl.getMinutes() >= SleepFilter.START_SLEEP_TIME_MINUTE
                        && sl.getMinutes() <= SleepFilter.MINUTES_OF_DAY) {
                    SleepFilterData tmp = new SleepFilterData(sl.getId(), sl.getYear(), sl.getMonth(), sl.getDay(),
                            sl.getMinutes(), sl.getMode(), sl.getDate());
                    tmp.setMinutesAxes(tmp.getMinutes() - SleepFilter.START_SLEEP_TIME_MINUTE);
                    sls.add(tmp);
                }
            }
        }
        List<SleepData> d2 = getSubSleepDataByDate(y, m, d, sleeps);
        if (d2 != null && d2.size() > 0) {
            for (SleepData sl : d2) {
                if (sl.getMinutes() >= 0
                        && sl.getMinutes() <= SleepFilter.END_SLEEP_TIME_MINUTE) {
                    SleepFilterData tmp = new SleepFilterData(sl.getId(), sl.getYear(), sl.getMonth(), sl.getDay(),
                            sl.getMinutes(), sl.getMode(), sl.getDate());
                    tmp.setMinutes(tmp.getMinutes() + SleepFilter.MINUTES_OF_DAY);
                    tmp.setMinutesAxes(tmp.getMinutes() - SleepFilter.START_SLEEP_TIME_MINUTE);
                    sls.add(tmp);
                }
            }
        }

        // increase sort the sleep data by minutes
        Collections.sort(sls, new SleepFilterData.IncreaseComparator());

        // Remove the error minute data
        removeSameMinuteSleepData(sls);

        return sls;
    }

    /**
     * @param sleepDataList
     * @return
     */
    public static ArrayList<SleepFilterData> filterAll(List<SleepFilterData> sleepDataList) {
        ArrayList<SleepFilterData> filter = filterAwake(sleepDataList);
        if (filter == null || filter.size() <= 0) {
            return null;
        }

        ArrayList<SleepFilterData> filterDataList = new ArrayList<>();

        SleepFilterData lastSleepData = null;
        boolean dropBeh = false;
        for (int i = 0; i < filter.size(); i++) {
            if (dropBeh) {
                SDKLogger.e(D, "dropBeh, lastMode: " + lastSleepData.toString());
                break;
            }
            SleepFilterData sl = filter.get(i);
            int mode = sl.getMode();
            int minutesAxes = sl.getMinutesAxes();
            SDKLogger.d(D, sl.toString());

            if (lastSleepData == null) {
                // initial first value
                //deepSleepValues.add(new PointValue(0, 0));
                //lightSleepValues.add(new PointValue(0, 0));
                //awakeValues.add(new PointValue(0, 0));
                if (filter.size() != 1) {
                    // if start with first minutes
                    switch (mode) {
                        case ApplicationLayer.SLEEP_MODE_START_WAKE:
                            filterDataList.add(sl);
                            break;
                        case ApplicationLayer.SLEEP_MODE_START_SLEEP:
                            filterDataList.add(sl);
                            break;
                        case ApplicationLayer.SLEEP_MODE_START_DEEP_SLEEP:
                            filterDataList.add(sl);
                            break;
                    }
                }

                lastSleepData = sl;
                continue;
            }
            SDKLogger.d(D, "lastMode: " + lastSleepData.toString());

            boolean needUpdateLast = true;
            switch (lastSleepData.getMode()) {
                case ApplicationLayer.SLEEP_MODE_START_WAKE:
                    int checkResult = SleepFilter.checkAwakeData(lastSleepData.getMinutes(), sl.getMinutes());
                    SDKLogger.i(D, "checkResult: " + checkResult);
                    switch (mode) {
                        case ApplicationLayer.SLEEP_MODE_START_SLEEP:
                            // Check the wake time
                            if (checkResult == SleepFilter.CHECK_DROP_ALL) {
                                return null;
                            } else if (checkResult == SleepFilter.CHECK_DROP_FRONT) {
                                // Clear pre-info
                                filterDataList.clear();
                            } else if (checkResult == SleepFilter.CHECK_DROP_BEHIND) {
                                dropBeh = true;
                                break;
                            }
                            filterDataList.add(lastSleepData);
                            break;
                        case ApplicationLayer.SLEEP_MODE_START_DEEP_SLEEP:
                            SDKLogger.e(D, "The input data may be is error, Error mode, Just show"
                                    + ", lastMode: " + lastSleepData.getMode()
                                    + ", mode: " + mode);

                            // Check the wake time
                            if (checkResult == SleepFilter.CHECK_DROP_ALL) {
                                return null;
                            } else if (checkResult == SleepFilter.CHECK_DROP_FRONT) {
                                // Clear pre-info
                                filterDataList.clear();
                            } else if (checkResult == SleepFilter.CHECK_DROP_BEHIND) {
                                dropBeh = true;
                                break;
                            }
                            filterDataList.add(lastSleepData);
                            break;
                        default:
                            SDKLogger.e(D, "The input data may be is error, Mode not special. Do nothing"
                                    + ", lastMode: " + lastSleepData.getMode()
                                    + ", mode: " + mode);
                            needUpdateLast = false;
                            break;
                    }
                    break;

                case ApplicationLayer.SLEEP_MODE_START_SLEEP:
                    switch (mode) {
                        case ApplicationLayer.SLEEP_MODE_START_DEEP_SLEEP:
                            filterDataList.add(lastSleepData);
                            break;
                        case ApplicationLayer.SLEEP_MODE_START_WAKE:
                            filterDataList.add(lastSleepData);
                            break;
                        default:
                            SDKLogger.e(D, "The input data may be is error, Mode not special. Do nothing"
                                    + ", lastMode: " + lastSleepData.getMode()
                                    + ", mode: " + mode);
                            needUpdateLast = false;
                            break;
                    }
                    break;
                case ApplicationLayer.SLEEP_MODE_START_DEEP_SLEEP:
                    if (mode != ApplicationLayer.SLEEP_MODE_START_DEEP_SLEEP) {
                        // Check the deep sleep time
                        int checkResultDeep = SleepFilter.checkDeepSleep(lastSleepData.getMinutes()
                                , sl.getMinutes());
                        SDKLogger.i(D, "checkResultDeep: " + checkResultDeep);
                        if (checkResultDeep == SleepFilter.CHECK_DROP_ALL) {
                            return null;
                        } else if (checkResultDeep == SleepFilter.CHECK_DROP_FRONT) {
                            // Clear pre-info
                            filterDataList.clear();
                        } else if (checkResultDeep == SleepFilter.CHECK_DROP_BEHIND) {
                            dropBeh = true;
                            break;
                        }
                    }
                    switch (mode) {
                        case ApplicationLayer.SLEEP_MODE_START_SLEEP:
                            filterDataList.add(lastSleepData);
                            break;
                        case ApplicationLayer.SLEEP_MODE_START_WAKE:
                            filterDataList.add(lastSleepData);
                            break;
                        default:
                            SDKLogger.e(D, "The input data may be is error, Mode not special. Do nothing"
                                    + ", lastMode: " + lastSleepData.getMode()
                                    + ", mode: " + mode);
                            needUpdateLast = false;
                            break;
                    }
                    break;
            }
            if (needUpdateLast) {
                lastSleepData = sl;
            }
        }
        return filterDataList;
    }

    /**
     * 获取指定时间点前最晚的一次清醒
     */
    private static int getLastAwakeIndex(List<SleepFilterData> sleepDatas, int flagTime) {
        int ret = INDEX_NA;
        int len = sleepDatas.size();
        for (int i = 0; i < len; i++) {
            SleepFilterData sleepData = sleepDatas.get(i);
            if (sleepData.getMinutes() < flagTime) {
                if (sleepData.getMode() == ApplicationLayer.SLEEP_MODE_START_WAKE) {
                    ret = i;
                }
            } else {
                break;
            }
        }

        return ret;
    }

    /**
     * 获取指定时间点后最早的一次清醒
     */
    public static int getFirstAwakeIndex(List<SleepFilterData> sleepDatas, int flagTime) {
        int ret = INDEX_NA;
        int len = sleepDatas.size();
        for (int i = len - 1; i >= 0; i--) {
            SleepFilterData sleepData = sleepDatas.get(i);
            if (sleepData.getMinutes() > flagTime) {
                if (sleepData.getMode() == ApplicationLayer.SLEEP_MODE_START_WAKE) {
                    ret = i;
                }
            } else {
                break;
            }
        }
        return ret;
    }

    /**
     * 去掉头尾的连续苏醒
     *
     * @param sleepDatas
     * @return
     */
    public static ArrayList<SleepFilterData> filterBeginAndEnd(List<SleepFilterData> sleepDatas) {
        if (sleepDatas == null || sleepDatas.size() <= 0) {
            return null;
        }
        ArrayList<SleepFilterData> filter = new ArrayList<>();
        int len = sleepDatas.size();
        int begin = -1;
        int end = -1;

        for (int i = 0; i < len; i++) {
            SleepFilterData data = sleepDatas.get(i);
            if (data.getMode() == ApplicationLayer.SLEEP_MODE_START_WAKE) {
                begin = i;
            } else {
                begin = i;
                break;
            }
        }

        boolean flag = true;
        for (int i = 0; i < len; i++) {
            SleepFilterData data = sleepDatas.get(i);
            if (data.getMode() == ApplicationLayer.SLEEP_MODE_START_WAKE) {
                if (flag) {
                    end = i;
                }
                flag = false;
            } else {
                flag = true;
            }
        }

        int index1 = 0;
        int index2 = 0;
        if (begin > 0) {
            index1 = begin;
        }

        if (!flag && end > 0) {
            index2 = end;
        } else {
            index2 = len;
        }

        for (int j = index1; j < index2; j++) {
            SleepFilterData item = sleepDatas.get(j);
            filter.add(item);
        }
        return filter;
    }

    /**
     * <ol>
     * <li>一点之前最晚的一次清醒，如果之前只有清醒和浅睡，则删除该清醒状态以前的睡眠数据</li>
     * <li>5点之后最早的一次清醒，如果之后只有清醒和浅睡，则删除该清醒状态以后的睡眠数据</li>
     * </ol>
     */
    public static ArrayList<SleepFilterData> filterAwake(List<SleepFilterData> sleepDatas) {
        if (sleepDatas == null || sleepDatas.size() <= 0) {
            return null;
        }

        ArrayList<SleepFilterData> filter1 = new ArrayList<>();
        int len = sleepDatas.size();
        int lastWakeIndex1 = getLastAwakeIndex(sleepDatas, START_AWAKE_CHECK_TIME_MINUTE);
        if (lastWakeIndex1 != INDEX_NA) {
            boolean flag = true;
            for (int i = 0; i < lastWakeIndex1; i++) {
                SleepFilterData sleepData = sleepDatas.get(i);
                if (sleepData.getMode() == ApplicationLayer.SLEEP_MODE_START_DEEP_SLEEP) {
                    flag = false;
                    break;
                }
            }
            if (flag) {
                SDKLogger.d("一点之前最晚的一次清醒，如果之前只有清醒和浅睡，则删除该清醒状态以前的睡眠数据");
                for (int i = lastWakeIndex1; i < len; i++) {
                    filter1.add(sleepDatas.get(i));
                }
            } else {
                filter1.addAll(sleepDatas);
            }
        } else {
            filter1.addAll(sleepDatas);
        }


        ArrayList<SleepFilterData> filter2 = new ArrayList<>();
        len = filter1.size();
        int firstWakeIndex1 = getFirstAwakeIndex(filter1, END_AWAKE_CHECK_TIME_MINUTE);
        if (firstWakeIndex1 != INDEX_NA) {
            boolean flag = true;
            for (int i = lastWakeIndex1 + 1; i < len; i++) {
                SleepFilterData sleepData = sleepDatas.get(i);
                if (sleepData.getMode() == ApplicationLayer.SLEEP_MODE_START_DEEP_SLEEP) {
                    flag = false;
                    break;
                }
            }
            if (flag) {
                SDKLogger.d("5点之后最早的一次清醒，如果之后只有清醒和浅睡，则删除该清醒状态以后的睡眠数据");
                for (int i = 0; i <= firstWakeIndex1; i++) {
                    filter2.add(sleepDatas.get(i));
                }
            } else {
                filter2.addAll(filter1);
            }
        } else {
            filter2.addAll(filter1);
        }

        return filter2;
    }

    /**
     * 清醒数据过滤
     * <ol>
     * <li>在01:00点前出现清醒时间，且清醒时间（整体在01：00之前）大于等于20min，则删除之前的睡眠数据。(考虑到早睡情况，这条待确认，考虑目前的测试群体)</li>
     * <li>早上05:00点之后（整体在05：00之后），出现清醒时间超过30min，则之后的数据全部清除</li>
     * <li>凌晨01：00点之前到早晨05：00点之后，为清醒状态，所有睡眠数据清除（核心区处于清醒状态）</li>
     * </ol>
     */
    public static int checkAwakeData(int lastMinutes, int curMinutes) {
        int diffMinutes;
        //凌晨1点之前出现清醒时间
        if (lastMinutes < START_AWAKE_CHECK_TIME_MINUTE) {
            //清醒时段在凌晨1点之前
            if (curMinutes < START_AWAKE_CHECK_TIME_MINUTE) {
                diffMinutes = curMinutes - lastMinutes;
                //清醒时间大于等于20min
                if (diffMinutes >= ALLOW_AWAKE_CHECK_TIME_MINUTE_PRE) {
                    SDKLogger.d("在01:00点前出现清醒时间，且清醒时间（整体在01：00之前）大于等于20min，则删除之前的睡眠数据");
                    return CHECK_DROP_FRONT;
                }
            } else if (curMinutes > END_AWAKE_CHECK_TIME_MINUTE) {
                SDKLogger.d("凌晨01：00点之前到早晨05：00点之后，为清醒状态，所有睡眠数据清除");
                return CHECK_DROP_ALL;
            }
        }
        //凌晨5点之后出现清醒时间
        else if (lastMinutes > END_AWAKE_CHECK_TIME_MINUTE) {
            //清醒时段在凌晨5点之后
            if (curMinutes > END_AWAKE_CHECK_TIME_MINUTE) {
                //清醒时间超过30min
                diffMinutes = curMinutes - lastMinutes;
                if (diffMinutes > HALF_AN_HOUR) {
                    SDKLogger.d("早上05:00点之后（整体在05：00之后），出现清醒时间超过30min，则之后的数据全部清除");
                    return CHECK_DROP_BEHIND;
                }
            }
        }

        return CHECK_NO_ERROR;
    }


    /**
     * 清醒数据过滤
     * <ol>
     * <li>01:00点之前深睡超过1.5小时（整体在01：00之前），则之前的睡眠数据全部清除</li>
     * <li>05:00之后（整体在05：00之后），深睡超过1.5小时，则之后的睡眠数据全部清除</li>
     * <li>01:00和05:00之间(可包含1点或者5点)，深睡超过2.5小时，所有睡眠数据清除</li>
     * </ol>
     */
    public static int checkDeepSleep(int lastMinutes, int curMinutes) {
        int diffMinutes;
        //凌晨1点之前出现深睡时间
        if (lastMinutes < START_DEEP_CHECK_TIME_MINUTE) {
            //深睡时段在凌晨1点之前
            if (curMinutes < START_DEEP_CHECK_TIME_MINUTE) {
                diffMinutes = curMinutes - lastMinutes;
                if (diffMinutes >= ALLOW_DEEP_CHECK_TIME_MINUTE_PRE) {
                    SDKLogger.d("01:00点之前深睡超过1.5小时（整体在01：00之前），则之前的睡眠数据全部清除");
                    return CHECK_DROP_FRONT;
                }
            } else {
                diffMinutes = Math.min(curMinutes, END_DEEP_CHECK_TIME_MINUTE) - START_DEEP_CHECK_TIME_MINUTE;
                if (diffMinutes >= ALLOW_DEEP_CHECK_TIME_MINUTE_BEH) {
                    SDKLogger.d("01:00和05:00之间(可包含1点或者5点)，深睡超过2.5小时，所有睡眠数据清除");
                    return CHECK_DROP_ALL;
                }
            }
        }
        //凌晨5点之后出现深睡时间
        else if (lastMinutes > END_DEEP_CHECK_TIME_MINUTE) {
            //深睡时段在凌晨5点之后
            if (curMinutes > END_DEEP_CHECK_TIME_MINUTE) {
                diffMinutes = curMinutes - lastMinutes;
                if (diffMinutes >= ALLOW_DEEP_CHECK_TIME_MINUTE_PRE) {
                    SDKLogger.d("05:00之后（整体在05：00之后），深睡超过1.5小时，则之后的睡眠数据全部清除");
                    return CHECK_DROP_BEHIND;
                }
            }
        } else {
            diffMinutes = Math.min(curMinutes, END_DEEP_CHECK_TIME_MINUTE) - lastMinutes;
            if (diffMinutes >= ALLOW_DEEP_CHECK_TIME_MINUTE_BEH) {
                SDKLogger.d("01:00和05:00之间(可包含1点或者5点)，深睡超过2.5小时，所有睡眠数据清除");
                return CHECK_DROP_ALL;
            }
        }

        return CHECK_NO_ERROR;
    }

    /**
     * 判断是否显示睡眠数据
     * <ol>
     * <li>当前阶段不show，show之前完整的阶段，并按照 1，2，3，4，5，6，7过滤</li>
     * <li>总睡眠（清醒前后的 深睡 + 浅睡 ）时间小于2个小时不show</li>
     * </ol>
     */
    public static boolean isNeedShowUi() {
        return true;
    }

    /**
     * Remove some minute data.
     * You must make sure the data have be sort.
     */
    public static void removeSameMinuteSleepData(List<SleepFilterData> sleeps) {
        int lastMinute = -1;
        SleepFilterData sl;
        if (sleeps != null) {
            for (int i = 0; i < sleeps.size(); i++) {
                sl = sleeps.get(i);
                if (lastMinute != -1) {
                    if (sl.getMinutes() == lastMinute) {
                        sleeps.remove(sl);
                        SDKLogger.d(D, "lastMinute: " + lastMinute
                                + ", same date: " + sl.toString());
                        i = i - 1;
                        continue;
                    }
                }
                lastMinute = sl.getMinutes();
            }
        }
    }

    /**
     * Get the sub SleepData list by the special date, if didn't find, it will return
     * null.
     *
     * @param sleeps the input data
     * @return Sub data list of the special date.
     */
    public static List<SleepData> getSubSleepDataByDate(
            int y, int m, int d,
            List<SleepData> sleeps) {
        ArrayList<SleepData> sls = new ArrayList<>();
        for (SleepData sl : sleeps) {
            if (sl.getYear() == y
                    && sl.getMonth() == m
                    && sl.getDay() == d) {
                sls.add(sl);
            }
        }
        return sls;
    }

    public static String getTwoStr(int var0) {
        String var1 = var0 + "";
        if (var1.length() < 2) {
            var1 = "0" + var1;
        }

        return var1;
    }

    /**
     * @param fall    入睡分钟数
     * @param deep    深睡分钟数
     * @param all     总睡眠分钟数
     * @param wakeNum 苏醒次数
     * @return
     */
    public static int getSleepQuality(float fall, float deep, float all, int wakeNum) {
        if (all < 2 * 60) {
            return 0;
        } else {
            int quality = 5;
            if (fall > 60) {
                quality -= 1;
            }
            if (all < 4 * 60) {
                quality -= 1;
            }
            if (deep / all < 0.3f) {
                quality -= 1;
            }
            if (wakeNum > 2) {
                quality -= 1;
            }
            return quality;
        }
    }

    /**
     * @param all      全部睡眠分钟数
     * @param deep     深睡分钟数
     * @param awakeNum 苏醒次数
     * @return
     */
    public static int getSleepQuality2(float all, float deep, int awakeNum) {
        float durationParams;
        float deepLowParams;
        float awakeParams;

        if (all >= 14 * 60f) {
            durationParams = 0.7f;
        } else if (all >= 13 * 60f) {
            durationParams = 0.8f;
        } else if (all >= 12 * 60f) {
            durationParams = 0.5f;
        } else if (all >= 11 * 60f) {
            durationParams = 0.9f;
        } else if (all >= 10 * 60f) {
            durationParams = 0.95f;
        } else if (all >= 7 * 60f) {
            durationParams = 1f;
        } else if (all >= 6 * 60f) {
            durationParams = 0.9f;
        } else if (all >= 5 * 60f) {
            durationParams = 0.7f;
        } else if (all >= 4 * 60f) {
            durationParams = 0.6f;
        } else if (all >= 3 * 60f) {
            durationParams = 0.5f;
        } else if (all >= 2 * 60f) {
            durationParams = 0.2f;
        } else {
            durationParams = 0f;
        }

        float deepPercent = deep / all;
        if (deepPercent >= 0.6f) {
            deepLowParams = 0.5f;
        } else if (deepPercent >= 0.5f) {
            deepLowParams = 0.9f;
        } else if (deepPercent >= 0.2f) {
            deepLowParams = 1f;
        } else if (deepPercent >= 0.1f) {
            deepLowParams = 0.7f;
        } else {
            deepLowParams = 0.5f;
        }

        if (awakeNum >= 10) {
            awakeParams = 0.1f;
        } else if (awakeNum >= 9) {
            awakeParams = 0.2f;
        } else if (awakeNum >= 8) {
            awakeParams = 0.3f;
        } else if (awakeNum >= 7) {
            awakeParams = 0.4f;
        } else if (awakeNum >= 6) {
            awakeParams = 0.5f;
        } else if (awakeNum >= 5) {
            awakeParams = 0.6f;
        } else if (awakeNum >= 4) {
            awakeParams = 0.7f;
        } else if (awakeNum >= 3) {
            awakeParams = 0.8f;
        } else {
            awakeParams = 1f;
        }

        return (int) (durationParams * deepLowParams * awakeParams * 5f);
    }

    /**
     * Sleep data list Increase Comparator class, sort by the minutes.
     */
    public static class IncreaseComparator implements Comparator {

        public int compare(Object arg0, Object arg1) {
            return compareSleep((SleepData) arg0, (SleepData) arg1);
        }

        public int compareSleep(SleepData o1, SleepData o2) {
            return Integer.compare(o1.getMinutes(), o2.getMinutes());
        }
    }
}
