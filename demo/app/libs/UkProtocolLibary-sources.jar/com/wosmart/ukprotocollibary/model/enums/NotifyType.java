package com.wosmart.ukprotocollibary.model.enums;

/**
 * notify type enums
 */
public enum NotifyType {
    /**
     * phone call
     */
    CALL,

    /**
     * phone message
     */
    SMS,

    /**
     * qq notify
     */
    QQ,

    /**
     * wechat notify
     */
    WECHAT,

    /**
     * line notify
     */
    LINE,

    /**
     * twitter notify
     */
    TWITTER,

    /**
     * facebook notify
     */
    FACEBOOK,

    /**
     * messenger notify
     */
    MESSENGER,

    /**
     * whatsapp notify
     */
    WHATSAPP,

    /**
     * linkedin notify
     */
    LINKEDIN,

    /**
     * instagram notify
     */
    INSTAGRAM,

    /**
     * skype notify
     */
    SKYPE,

    /**
     * viber notify
     */
    VIBER,

    /**
     * kakaotalk notify
     */
    KAKAOTALK,

    /**
     * vkontakte notify
     */
    VKONTAKTE,

    /**
     * tim notify
     */
    TIM,

    /**
     * gmail notify
     */
    GMAIL,

    /**
     * ding talk notify
     */
    DINGTALK,


    /**
     * weWork notify
     */
    WORKWECHAT,

    /**
     * other notify
     */
    OTHER

}
