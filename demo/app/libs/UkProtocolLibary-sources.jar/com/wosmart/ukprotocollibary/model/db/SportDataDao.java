package com.wosmart.ukprotocollibary.model.db;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.model.sport.SportData;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.Property;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseStatement;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.List;


public class SportDataDao extends AbstractDao<SportData, Long> {

    public static final String TABLENAME = "SPORT_DATA";

    /**
     * Properties of entity SportData.<br/>
     * Can be used for QueryBuilder and for referencing column names.
     */
    public static class Properties {
        public final static Property Id = new Property(0, Long.class, "id", true, "_id");
        public final static Property Year = new Property(1, int.class, "year", false, "YEAR");
        public final static Property Month = new Property(2, int.class, "month", false, "MONTH");
        public final static Property Day = new Property(3, int.class, "day", false, "DAY");
        public final static Property Offset = new Property(4, int.class, "offset", false, "OFFSET");
        public final static Property Mode = new Property(5, int.class, "mode", false, "MODE");
        public final static Property StepCount = new Property(6, int.class, "stepCount", false, "STEP_COUNT");
        public final static Property ActiveTime = new Property(7, int.class, "activeTime", false, "ACTIVE_TIME");
        public final static Property Calory = new Property(8, int.class, "calory", false, "CALORY");
        public final static Property Distance = new Property(9, int.class, "distance", false, "DISTANCE");
        public final static Property Date = new Property(10, java.util.Date.class, "date", false, "DATE");
        public final static Property UserID = new Property(11, String.class, "userID", false, "USERID");
    }




    public SportDataDao(DaoConfig config) {
        super(config);
    }

    public SportDataDao(DaoConfig config, DaoSession daoSession) {
        super(config, daoSession);
    }

    public void deleteByTime(String userID, int year, int month, int day) {
        String yearColName = Properties.Year.columnName;
        String monthColName = Properties.Month.columnName;
        String dayColName = Properties.Day.columnName;
        String userIDColName = Properties.UserID.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition = (yearColName + " = " + year) + " and " + (monthColName + " = " + month) + " and " + (dayColName + " = " + day);

        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        sb.append(")");

        List<SportData> dataList = queryRaw(sb.toString());

        if (dataList != null && !dataList.isEmpty()) {
            deleteInTx(dataList);
        }
    }

    /**
     * Creates the underlying database table.
     */
    public static void createTable(Database db, boolean ifNotExists) {
        String constraint = ifNotExists ? "IF NOT EXISTS " : "";
        db.execSQL("CREATE TABLE " + constraint + "\"SPORT_DATA\" (" + //
                "\"_id\" INTEGER PRIMARY KEY AUTOINCREMENT ," + // 0: id
                "\"YEAR\" INTEGER NOT NULL ," + // 1: year
                "\"MONTH\" INTEGER NOT NULL ," + // 2: month
                "\"DAY\" INTEGER NOT NULL ," + // 3: day
                "\"OFFSET\" INTEGER NOT NULL ," + // 4: offset
                "\"MODE\" INTEGER NOT NULL ," + // 5: mode
                "\"STEP_COUNT\" INTEGER NOT NULL ," + // 6: stepCount
                "\"ACTIVE_TIME\" INTEGER NOT NULL ," + // 7: activeTime
                "\"CALORY\" INTEGER NOT NULL ," + // 8: calory
                "\"DISTANCE\" INTEGER NOT NULL ," + // 9: distance
                "\"DATE\" INTEGER ," + //10: date
                "\"USERID\" VARCHAR);"); // 11: userID
    }

    /**
     * Drops the underlying database table.
     */
    public static void dropTable(Database db, boolean ifExists) {
        String sql = "DROP TABLE " + (ifExists ? "IF EXISTS " : "") + "\"SPORT_DATA\"";
        db.execSQL(sql);
    }


    /**
     * Drops the underlying database table.
     */
    public static void addUserID(Database db) {
//        String sql = "alter table devFunc add column userID varchar default '" + userID + "'";
        try {
            String sql = "AlTer TABLE  \"SPORT_DATA\" Add COLUMN \"USERID\" VARCHAR";
            db.execSQL(sql);
        } catch (Exception ignored) {
        }
    }


    /**
     * @inheritdoc
     */
    @Override
    protected void bindValues(SQLiteStatement stmt, SportData entity) {
        stmt.clearBindings();

        Long id = entity.getId();
        if (id != null) {
            stmt.bindLong(1, id);
        }
        stmt.bindLong(2, entity.getYear());
        stmt.bindLong(3, entity.getMonth());
        stmt.bindLong(4, entity.getDay());
        stmt.bindLong(5, entity.getOffset());
        stmt.bindLong(6, entity.getMode());
        stmt.bindLong(7, entity.getStepCount());
        stmt.bindLong(8, entity.getActiveTime());
        stmt.bindLong(9, entity.getCalory());
        stmt.bindLong(10, entity.getDistance());

        java.util.Date date = entity.getDate();
        if (date != null) {
            stmt.bindLong(11, date.getTime());
        }

        String userID = entity.getUserID();
        if (userID != null) {
            stmt.bindString(12, userID);
        }
    }

    /**
     * @inheritdoc
     */
    @Override
    public Long readKey(Cursor cursor, int offset) {
        return cursor.isNull(offset + 0) ? null : cursor.getLong(offset + 0);
    }

    /**
     * @inheritdoc
     */
    @Override
    public SportData readEntity(Cursor cursor, int offset) {
        SportData entity = new SportData( //
                cursor.isNull(offset + 0) ? null : cursor.getLong(offset + 0), // id
                cursor.getInt(offset + 1), // year
                cursor.getInt(offset + 2), // month
                cursor.getInt(offset + 3), // day
                cursor.getInt(offset + 4), // offset
                cursor.getInt(offset + 5), // mode
                cursor.getInt(offset + 6), // stepCount
                cursor.getInt(offset + 7), // activeTime
                cursor.getInt(offset + 8), // calory
                cursor.getInt(offset + 9), // distance
                cursor.isNull(offset + 10) ? null : new java.util.Date(cursor.getLong(offset + 10)), // date
                cursor.isNull(offset + 11) ? null : cursor.getString(offset + 11)// distance
        );
        return entity;
    }

    /**
     * @inheritdoc
     */
    @Override
    public void readEntity(Cursor cursor, SportData entity, int offset) {
        entity.setId(cursor.isNull(offset + 0) ? null : cursor.getLong(offset + 0));
        entity.setYear(cursor.getInt(offset + 1));
        entity.setMonth(cursor.getInt(offset + 2));
        entity.setDay(cursor.getInt(offset + 3));
        entity.setOffset(cursor.getInt(offset + 4));
        entity.setMode(cursor.getInt(offset + 5));
        entity.setStepCount(cursor.getInt(offset + 6));
        entity.setActiveTime(cursor.getInt(offset + 7));
        entity.setCalory(cursor.getInt(offset + 8));
        entity.setDistance(cursor.getInt(offset + 9));
        entity.setDate(cursor.isNull(offset + 10) ? null : new java.util.Date(cursor.getLong(offset + 10)));
        entity.setUserID(cursor.isNull(offset + 11) ? null : cursor.getString(offset + 11));
    }

    @Override
    protected void bindValues(DatabaseStatement stmt, SportData entity) {

    }

    /**
     * @inheritdoc
     */
    @Override
    protected Long updateKeyAfterInsert(SportData entity, long rowId) {
        entity.setId(rowId);
        return rowId;
    }

    /**
     * @inheritdoc
     */
    @Override
    public Long getKey(SportData entity) {
        if (entity != null) {
            return entity.getId();
        } else {
            return null;
        }
    }

    @Override
    protected boolean hasKey(SportData entity) {
        return false;
    }

    /**
     * @inheritdoc
     */
    @Override
    protected boolean isEntityUpdateable() {
        return true;
    }

}
