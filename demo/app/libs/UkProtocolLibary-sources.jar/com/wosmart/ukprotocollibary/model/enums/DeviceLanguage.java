package com.wosmart.ukprotocollibary.model.enums;

/**
 * enums of lanugage
 */
public enum DeviceLanguage {
    /**
     * chinese
     */
    LANGUAGE_SAMPLE_CHINESE,

    /**
     * traditional chinese
     */
    LANGUAGE_TRADITIONAL_CHINESE,

    /**
     * english
     */
    LANGUAGE_ENGLISH,

    /**
     * spanish
     */
    LANGUAGE_SPANISH,

    /**
     * french
     */
    LANGUAGE_FRENCH,

    /**
     * german
     */
    LANGUAGE_GERMAN,

    /**
     * italian
     */
    LANGUAGE_ITALIAN,

    /**
     * japanese
     */
    LANGUAGE_JAPANESE,

    /**
     * Swedish
     */
    LANGUAGE_SWEDISH,

    /**
     * korean
     */
    LANGUAGE_KOREAN,

    /**
     * portuguese
     */
    LANGUAGE_PORTUGUESE,

    /**
     * russian
     */
    LANGUAGE_RUSSIAN,

    /**
     * turkish
     */
    LANGUAGE_TURKISH,

    /**
     * poland
     */
    LANGUAGE_POLAND,

    /**
     * Mongolia
     */
    LANGUAGE_MONGOLIA,

    /**
     * Vietnam
     */
    LANGUAGE_VIETNAM,

    /**
     * Thai
     */
    LANGUAGE_THAI

}
