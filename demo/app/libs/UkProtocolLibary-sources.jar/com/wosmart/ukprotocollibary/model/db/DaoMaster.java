package com.wosmart.ukprotocollibary.model.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.util.Log;

import org.greenrobot.greendao.AbstractDaoMaster;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseOpenHelper;
import org.greenrobot.greendao.identityscope.IdentityScopeType;

public class DaoMaster extends AbstractDaoMaster {

    public static final int SCHEMA_VERSION = 14;

    /**
     * Creates underlying database table using DAOs.
     */
    public static void createAllTables(Database db, boolean ifNotExists) {
        SportDataDao.createTable(db, ifNotExists);
        SleepDataDao.createTable(db, ifNotExists);
        HrpDataDao.createTable(db, ifNotExists);
        PulseDataDao.createTable(db);
        SaunaDataDao.createTable(db);
        HRMovementDataDao.createTable(db);
        BloodPressureDataDao.createTable(db);
        BloodSugarDataDao.createTable(db);
        HeartRateDataDao.createTable(db);
        HeartRateVariabilityDataDao.createTable(db);
        SpO2DataDao.createTable(db);
        TemperatureDataDao.createTable(db);
        StepDataDao.createTable(db);
        SleepData2Dao.createTable(db);
        SportData2Dao.createTable(db);
        WearingTimeDataDao.createTable(db);
        UricAcidDataDao.createTable(db);
        BloodFatDataDao.createTable(db);
        BloodSugarCycleDataDao.createTable(db);
        UricAcidContinuousMonitoringDataDao.createTable(db);
        BloodFatContinuousMonitoringDataDao.createTable(db);
        BodyFatDataDao.createTable(db);
        PhysicalExamDataDao.createTable(db);
        HRVRmssdDataDao.createTable(db);
        UltravioletDataDao.createTable(db);
        PressureDataDao.createTable(db);
    }

    /**
     * Drops underlying database table using DAOs.
     */
    public static void dropAllTables(Database db, boolean ifExists) {
        SportDataDao.dropTable(db, ifExists);
        SleepDataDao.dropTable(db, ifExists);
        HrpDataDao.dropTable(db, ifExists);
        PulseDataDao.dropTable(db);
        SaunaDataDao.dropTable(db);
        HRMovementDataDao.dropTable(db);
        BloodPressureDataDao.dropTable(db);
        BloodSugarDataDao.dropTable(db);
        HeartRateDataDao.dropTable(db);
        HeartRateVariabilityDataDao.dropTable(db);
        SpO2DataDao.dropTable(db);
        TemperatureDataDao.dropTable(db);
        StepDataDao.dropTable(db);
        SleepData2Dao.dropTable(db);
        SportData2Dao.dropTable(db);
        WearingTimeDataDao.dropTable(db);
        UricAcidDataDao.dropTable(db);
        BloodFatDataDao.dropTable(db);
        BloodSugarCycleDataDao.dropTable(db);
        UricAcidContinuousMonitoringDataDao.dropTable(db);
        BloodFatContinuousMonitoringDataDao.dropTable(db);
        BodyFatDataDao.dropTable(db);
        PhysicalExamDataDao.dropTable(db);
        HRVRmssdDataDao.dropTable(db);
        UltravioletDataDao.dropTable(db);
        PressureDataDao.dropTable(db);
    }

    /**
     * Drops underlying database table using DAOs.
     */
    public static void addUserID(Database db) {
        SportDataDao.addUserID(db);
        SleepDataDao.addUserID(db);
        HrpDataDao.addUserID(db);
    }

    private static void migration_3_5(Database db) {
        PulseDataDao.createTable(db);
        SaunaDataDao.createTable(db);
    }

    private static void migration_5_6(Database db) {
        BloodPressureDataDao.createTable(db);
        BloodSugarDataDao.createTable(db);
        HeartRateDataDao.createTable(db);
        HeartRateVariabilityDataDao.createTable(db);
        SpO2DataDao.createTable(db);
        TemperatureDataDao.createTable(db);
        StepDataDao.createTable(db);
        SleepData2Dao.createTable(db);
        SportData2Dao.createTable(db);
    }

    private static void migration_6_7(Database db) {
        WearingTimeDataDao.createTable(db);
        UricAcidDataDao.createTable(db);
        BloodFatDataDao.createTable(db);
        BloodSugarCycleDataDao.createTable(db);
        // 增加 mac 地址存储
        PulseDataDao.addMacAddressCol(db);
        SaunaDataDao.addMacAddressCol(db);
        BloodPressureDataDao.addMacAddressCol(db);
        BloodSugarDataDao.addMacAddressCol(db);
        HeartRateDataDao.addMacAddressCol(db);
        HeartRateVariabilityDataDao.addMacAddressCol(db);
        SpO2DataDao.addMacAddressCol(db);
        TemperatureDataDao.addMacAddressCol(db);
        StepDataDao.addMacAddressCol(db);
        SleepData2Dao.addMacAddressCol(db);
        SportData2Dao.addMacAddressCol(db);
    }

    private static void migration_7_8(Database db) {
        UricAcidContinuousMonitoringDataDao.createTable(db);
        BloodFatContinuousMonitoringDataDao.createTable(db);
    }

    private static void migration_8_9(Database db) {
        BodyFatDataDao.createTable(db);
    }

    private static void migration_9_10(Database db) {
        PhysicalExamDataDao.createTable(db);
    }

    private static void migration_10_11(Database db) {
        HRVRmssdDataDao.createTable(db);
    }

    private static void migration_11_12(Database db) {
        HRMovementDataDao.createTable(db);
    }

    private static void migration_12_13(Database db) {
        UltravioletDataDao.createTable(db);
    }

    private static void migration_13_14(Database db) {
        PressureDataDao.createTable(db);
    }

    public static abstract class OpenHelper extends DatabaseOpenHelper {

        public OpenHelper(Context context, String name, CursorFactory factory) {
            super(context, name, factory, SCHEMA_VERSION);
        }

        @Override
        public void onCreate(Database db) {
            Log.i("greenDAO", "Creating tables for schema version " + SCHEMA_VERSION);
            dropAllTables(db, true);
            createAllTables(db, false);
        }
    }

    /**
     * WARNING: Drops all table on Upgrade! Use only during development.
     */
    public static class DevOpenHelper extends OpenHelper {
        public DevOpenHelper(Context context, String name, CursorFactory factory) {
            super(context, name, factory);
        }

        @Override
        public void onUpgrade(Database db, int oldVersion, int newVersion) {
            Log.i("greenDAO", "Upgrading schema from version " + oldVersion + " to " + newVersion + " by dropping all tables");
            if (oldVersion == 2) {
                addUserID(db);
            }
            if (oldVersion < 5) {
                migration_3_5(db);
            }
            if (oldVersion < 6) {
                migration_5_6(db);
            }
            if (oldVersion < 7) {
                migration_6_7(db);
            }
            if (oldVersion < 8) {
                migration_7_8(db);
            }
            if (oldVersion < 9) {
                migration_8_9(db);
            }
            if (oldVersion < 10) {
                migration_9_10(db);
            }
            if (oldVersion < 11) {
                migration_10_11(db);
            }
            if (oldVersion < 12) {
                migration_11_12(db);
            }
            if (oldVersion < 13) {
                migration_12_13(db);
            }
            if (oldVersion < 14) {
                migration_13_14(db);
            }
        }
    }

    public DaoMaster(Database db) {
        super(db, SCHEMA_VERSION);
        registerDaoClass(SportDataDao.class);
        registerDaoClass(SleepDataDao.class);
        registerDaoClass(HrpDataDao.class);
        registerDaoClass(PulseDataDao.class);
        registerDaoClass(SaunaDataDao.class);
        registerDaoClass(HRMovementDataDao.class);
        registerDaoClass(BloodPressureDataDao.class);
        registerDaoClass(BloodSugarDataDao.class);
        registerDaoClass(HeartRateDataDao.class);
        registerDaoClass(HeartRateVariabilityDataDao.class);
        registerDaoClass(SpO2DataDao.class);
        registerDaoClass(TemperatureDataDao.class);
        registerDaoClass(StepDataDao.class);
        registerDaoClass(SleepData2Dao.class);
        registerDaoClass(SportData2Dao.class);
        registerDaoClass(WearingTimeDataDao.class);
        registerDaoClass(UricAcidDataDao.class);
        registerDaoClass(BloodFatDataDao.class);
        registerDaoClass(BloodSugarCycleDataDao.class);
        registerDaoClass(UricAcidContinuousMonitoringDataDao.class);
        registerDaoClass(BloodFatContinuousMonitoringDataDao.class);
        registerDaoClass(BodyFatDataDao.class);
        registerDaoClass(PhysicalExamDataDao.class);
        registerDaoClass(HRVRmssdDataDao.class);
        registerDaoClass(UltravioletDataDao.class);
        registerDaoClass(PressureDataDao.class);
    }

    @Override
    public DaoSession newSession() {
        return new DaoSession(db, IdentityScopeType.Session, daoConfigMap);
    }

    @Override
    public DaoSession newSession(IdentityScopeType type) {
        return new DaoSession(db, type, daoConfigMap);
    }

}
