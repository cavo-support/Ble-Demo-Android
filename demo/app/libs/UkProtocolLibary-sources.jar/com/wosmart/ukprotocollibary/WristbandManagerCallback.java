package com.wosmart.ukprotocollibary;


import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerAlarm2Packet;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerAlarmsPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerBeginPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerBp2ControlPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerBp3ContinuousPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerBpListPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerBpPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerCustomNotifyPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerCustomUiPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerDeviceInfoPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerDeviceStatusPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerDisturbPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerECGPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerEarMacPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerEarStatusPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerEcgBeltToDevicePacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerEcgToDevicePacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerFacSensorPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerFunctionPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerGLUPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerHighHeartRatePacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerHrpPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerHrpParamsPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerLogResponsePacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMedicationReminderListPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMulBloodFatPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMulBloodSugarCyclePacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMulPrivateBpPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMulUricAcidPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerMultiSportPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerNotifyPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerRateListPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerReadHealthPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerRtkHrvPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerScreenStylePacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSitPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSleepPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSpo2Packet;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSportPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerStepPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSwitchPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSyncSwitchPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerTemperatureControlPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerTimerPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerTodayAdjustPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerTodaySleepPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerTodaySumSportPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerUnitPacket;
import com.wosmart.ukprotocollibary.model.enums.DeviceLanguage;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRMovementInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPulseInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSaunaInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUltravioletInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWearingTimeInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWDefaultFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWHealthRiskAssessmentInfo;

import java.util.List;

public class WristbandManagerCallback {

    /**
     * 新增回调，与 onConnectionStateChange 同时触发
     * 连接状态变化
     *
     * @param isConnect true 已连接
     * @param code      错误码 {@link com.wosmart.ukprotocollibary.v2.BaseConstants#ERR_CONNECT_DEVICE_FAILED}
     * @param msg       错误信息
     */
    public void onConnectionStateChange(final boolean isConnect, final int code, final String msg) {
    }

    /**
     * Callback indicating when gatt connected/disconnected to/from a remote device
     * 连接状态改变
     *
     * @param status status
     */
    public void onConnectionStateChange(final boolean status) {
    }

    /**
     * 连接设备成功
     *
     * @param status
     */
    public void onConnectionSuccess(final boolean status) {

    }

    /**
     * Callback indicating when login in to a wristband
     * 登录状态改变
     *
     * @param state state
     */
    public void onLoginStateChange(final int state) {
    }

    /**
     * Callback indicating something error
     *
     * @param error error code
     */
    public void onError(final int error) {
    }

    /**
     * Callback indicating a sport data receive.
     */
    public void onStepDataReceiveIndication(ApplicationLayerStepPacket packet) {
    }

    /**
     * Callback indicating a sport data receive.
     */
    public void onSportDataReceiveIndication(ApplicationLayerSportPacket packet) {
    }

    /**
     * Callback indicating a sleep data receive.
     */
    public void onSleepDataReceiveIndication(ApplicationLayerSleepPacket packet) {
    }

    /**
     * Callback indicating a hrp data receive.
     */
    public void onHrpDataReceiveIndication(ApplicationLayerHrpPacket packet) {
    }

    /**
     * Callback indicating a device cancel hrp measure.
     */
    public void onDeviceCancelSingleHrpRead() {
    }

    /**
     * Callback indicating a bp data receive.
     */
    public void onBpDataReceiveIndication(ApplicationLayerBpPacket packet) {
    }

    /**
     * Callback indicating a device cancel bp measure.
     */
    public void onDeviceCancelSingleBpRead() {
    }

    /**
     * 自动监测心率配置返回
     *
     * @param enable   true 打开
     * @param interval 间隔，单位 分钟
     */
    public void onHrpContinueParamRsp(boolean enable, int interval) {
    }

    /**
     * Callback indicating alarm list data receive.
     *
     * @param data the receive alarm data packet
     */
    public void onAlarmsDataReceive(ApplicationLayerAlarmsPacket data) {
    }

    /**
     * Callback indicate remote alarm2 list.
     *
     * @param alarm2
     */
    public void onAlarm2(final ApplicationLayerAlarm2Packet alarm2) {
    }

    /**
     * Callback indicating reminder list data receive.
     *
     * @param data the receive reminder data packet
     */
    public void onMedicationReminderList(ApplicationLayerMedicationReminderListPacket data) {
    }

    /**
     * Callback indicating notify mode setting receive.
     *
     * @param applicationLayerNotifyPacket notify switch setting
     */
    public void onNotifyModeSettingReceive(ApplicationLayerNotifyPacket applicationLayerNotifyPacket) {
    }

    /**
     * Callback indicating long sit setting receive.
     *
     * @param packet the current long sit setting
     */
    public void onLongSitSettingReceive(ApplicationLayerSitPacket packet) {
    }

    /**
     * Callback indicate remote Turn Over Wrist setting.
     *
     * @param mode the long sit mode setting
     */
    public void onTurnOverWristSettingReceive(final boolean mode) {
    }

    /**
     * Callback indicate remote shack device
     */
    public void onTakePhotoRsp() {
    }

    /**
     * Callback indicating a fac sensor data receive.
     *
     * @param data the receive sensor data
     */
    public void onFacSensorDataReceive(ApplicationLayerFacSensorPacket data) {
    }

    /**
     * Callback indicating version read.
     *
     * @param appVersion   app Version value
     * @param patchVersion patch Version value
     */
    public void onVersionRead(int appVersion, int patchVersion) {
    }

    /**
     * Callback indicating name receive.
     *
     * @param data the receive data
     */
    public void onNameRead(final String data) {
    }

    /**
     * Callback indicating battery read.
     *
     * @param value battery level value 0 - 100
     */
    public void onBatteryRead(int value) {
    }

    /**
     * Callback indicating battery change.
     *
     * @param value battery level value 0 - 100
     */
    public void onBatteryChange(int value) {
    }

    /**
     * Callback indicate log sync start.
     *
     * @param logLength the log total length
     */
    public void onLogCmdStart(final long logLength) {
    }

    /**
     * Callback indicate log sync end.
     */
    public void onLogCmdEnd() {
    }

    /**
     * Callback indicate log data.
     *
     * @param packet receive log data
     */
    public void onLogCmdRsp(final ApplicationLayerLogResponsePacket packet) {
    }

    /**
     * callback indicate end call
     */
    public void onEndCall() {
    }

    /**
     * Callback indicate accept call.
     */
    public void onAcceptCall() {
    }

    /**
     * Callback indicating device support sport function receiver
     *
     * @param applicationLayerMultiSportPacket
     */
    public void onSportFunction(final ApplicationLayerMultiSportPacket applicationLayerMultiSportPacket) {
    }


    /**
     * Callback indicating device support function receiver
     *
     * @param applicationLayerFunctionPacket
     */
    public void onDeviceFunction(final ApplicationLayerFunctionPacket applicationLayerFunctionPacket) {

    }

    /**
     * callback indicating request hour model
     *
     * @param is24Model is 24 model
     */
    public void onHour(boolean is24Model) {

    }

    /**
     * callabck indicating request unit model
     *
     * @param isMetricSystem is metric model
     */
    public void onUnit(boolean isMetricSystem) {

    }

    /**
     * callback indicating request disturb setting
     *
     * @param packet
     */
    public void onDisturb(ApplicationLayerDisturbPacket packet) {

    }


    /**
     * callback indicating request screen light duration setting
     * 亮屏时长返回
     *
     * @param currentDuration 当前时长，单位 秒, current duration, unit seconds
     */
    public void onScreenLightDuration(int currentDuration) {
    }

    /**
     * callback indicating request screen duration setting
     * 亮屏时长返回
     *
     * @param currentDuration 当前时长，单位 秒, current duration, unit seconds
     * @param defaultDuration 默认时长
     */
    public void onScreenLightDuration(int currentDuration, int defaultDuration) {
    }

    /**
     * callback indicating request device language
     *
     * @param language
     */
    public void onLanguage(DeviceLanguage language) {
    }

    /**
     * Call back indicating when receiver earphone mac
     *
     * @param packet
     */
    public void onEarMac(ApplicationLayerEarMacPacket packet) {

    }

    /**
     * callback indicating when receiver earphone connect status
     *
     * @param status
     */
    public void onEarConnectStatus(int status) {

    }

    /**
     * callback indicating when receiver earphone status
     *
     * @param packet
     */
    public void onEarStatus(ApplicationLayerEarStatusPacket packet) {

    }

    /**
     * call back indicating when start sync data
     */
    public void onSyncDataBegin(ApplicationLayerBeginPacket packet) {

    }

    /**
     * call back indicating when  sync data finish
     *
     * @param packet
     */
    public void onSyncDataEnd(ApplicationLayerTodaySumSportPacket packet) {

    }

    /**
     * callback indicating when receiver current screen index
     */
    public void onHomePager(ApplicationLayerScreenStylePacket packet) {

    }

    /**
     * callback indicating when charge status changed
     *
     * @param status
     */
    public void onChargeStatus(int status) {

    }

    /**
     * callback indicating when receiver device information
     *
     * @param packet
     */
    public void onDeviceInfo(ApplicationLayerDeviceInfoPacket packet) {

    }

    /**
     * callback indicating when receiver device status information
     *
     * @param packet
     */
    public void onDeviceStatus(ApplicationLayerDeviceStatusPacket packet) {

    }

    public void onSpo2DataReceive(ApplicationLayerSpo2Packet packet) {

    }

    /**
     * callback indicating when receiver support hrp params
     *
     * @param paramsPacket
     */
    public void onHrpParams(ApplicationLayerHrpParamsPacket paramsPacket) {

    }

    /**
     * callback indicating when receiver remote device screen light percent
     *
     * @param lightPercent
     */
    public void onScreenLight(int lightPercent) {

    }

    /**
     * callback indicating when receiver base switch information
     *
     * @param switchPacket
     */
    public void onSwitch(ApplicationLayerSwitchPacket switchPacket) {

    }

    /**
     * callback indicating when receiver find phone command
     */
    public void onFindPhone() {

    }

    /**
     * callback indicating timer setting
     *
     * @param packet
     */
    public void onTimerInfo(ApplicationLayerTimerPacket packet) {

    }

    /**
     * callback indicating when receiver sport rate status
     *
     * @param status
     */
    public void onSportRateStatus(int status) {

    }

    /**
     * callback indicating when receiver rate data list
     *
     * @param packet
     */
    public void onRateList(ApplicationLayerRateListPacket packet) {

    }

    /**
     * callback indicating when receiver today total step and adjust information
     *
     * @param packet
     */
    public void onTodayAdjust(ApplicationLayerTodayAdjustPacket packet) {

    }

    /**
     * callback indicating when receiver langco translate
     *
     * @param model
     */
    public void onLangcoTranslate(int model) {

    }


    /**
     * callback indicating when receiver temp data list
     *
     * @param packet
     */
    public void onTemperatureList(ApplicationLayerRateListPacket packet) {

    }

    /**
     * callback indicating when receiver temp data
     *
     * @param packet
     */
    public void onTemperatureData(ApplicationLayerHrpPacket packet) {

    }

    /**
     * callback indicating when receiver bp auto Detect data
     *
     * @param packet
     */
    public void onBpList(ApplicationLayerBpListPacket packet) {

    }

    /**
     * 开启温度检测时应该先检查是否可以开启温度检测
     * 0 温度检测结束
     * 1 温度检测开始
     * 2 连续心率没有开启 温度检测不能开始
     * 3 连续心率开启了，温度检测可以开始
     * <p>
     * When turning on temperature detection, you should first check whether it can be turned on
     * 0 End of temperature detection
     * 1 Start of temperature detection
     * 2 Continuous heart rate is not turned on, temperature detection cannot be started
     * 3 Continuous heart rate is turned on, temperature detection can start
     *
     * @param status
     */
    public void onTemperatureMeasureStatus(int status) {

    }

    /**
     * 0 血氧测试关闭返回
     * 1 血氧测试开启返回
     * 2 设备正忙，血氧测试不可以开启
     * 3 血氧测试可以开启
     */
    public void onSpo2MeasureStatus(int status) {

    }

    /**
     * callback indicate when receiver temperature setting data
     *
     * @param packet
     */
    public void onTemperatureMeasureSetting(ApplicationLayerTemperatureControlPacket packet) {

    }

    /**
     * Callback indicate request today sleep
     *
     * @param packet
     */
    public void onFacCmdTodaySleep(ApplicationLayerTodaySleepPacket packet) {

    }

    /**
     * @param hrValue
     */
    public void onHeartRateValue(int hrValue) {
    }


    public void onDebugDataReceiver(byte[] data) {

    }

    /**
     * Callback indicate request today sleep
     *
     * @param data
     */
    public void onFacCmdHistoryIndex(byte[] data) {

    }


    /**
     * callback indicate request bp2 setting
     *
     * @param packet
     */
    public void onBp2Control(ApplicationLayerBp2ControlPacket packet) {

    }

    /**
     * callback indicate request SleepALlSwitch setting
     *
     * @param enable
     */
    public void onSleepAllSwitch(boolean enable) {

    }


    /**
     * callback indicate request HypoxiaSwitch setting
     *
     * @param enable
     */
    public void onHypoxiaSwitch(boolean enable) {

    }

    /**
     * callback indicate request HighHeartRateSwitch setting
     *
     * @param packet
     */
    public void onHighHeartRateSwitch(ApplicationLayerHighHeartRatePacket packet) {

    }

    /**
     * callback indicate request DateFormat setting
     *
     * @param format
     */
    public void onDeviceDateFormat(int format) {

    }

    public void onMusicPlay() {

    }

    public void onMusicPause() {

    }


    public void onMusicToggle() {

    }

    /**
     * callback indicating when device send pre music command
     */
    public void onMusicPre() {

    }

    /**
     * callback indicating when device send next music command
     */
    public void onMusicNext() {

    }

    /**
     * callback indicating when device send volume up command
     */
    public void onMusicVolumeUp() {

    }

    /**
     * callback indicating when device send volume down command
     */
    public void onMusicVolumeDown() {

    }

    public void onSilenceUpgradeModel(int model) {

    }

    /**
     * callback indicating when request custom ui
     *
     * @param packet
     */
    public void onCustomUiSetting(ApplicationLayerCustomUiPacket packet) {

    }

    /**
     * callback indicating when request silence ota status
     *
     * @param status
     */
    public void onSilenceOtaStatus(int status) {

    }

    /**
     * callback indicating when request custom notify
     *
     * @param packet
     */
    public void onCustomNotify(ApplicationLayerCustomNotifyPacket packet) {

    }

    public void onCusStatus(int status) {

    }

    /**
     * 查找手机2.0
     *
     * @param status 0--关闭；1--打开
     */
    public void onFindPhone(int status) {

    }

    /**
     * 自动监测血氧配置
     *
     * @param enable   true 打开 false 关闭
     * @param interval 间隔，单位 分钟
     */
    public void requestSpo2Continuous(boolean enable, int interval) {

    }

    /**
     * 绑定成功后返回芯片类型
     *
     * @param type 0--C  1--D
     */
    public void onBondReqChipType(int type) {

    }

    /**
     * 心电数据采集状态返回
     *
     * @param status 1.采集开始-2.采集结束-3.采集中断-4.采集失败
     */
    public void onEcgTestStatus(int status) {

    }

    public void onEcgTestData(byte[] data) {

    }

    public void onEcgTestDataPacket(ApplicationLayerECGPacket ecgPacket) {

    }

    public void onReadHealthDataPacket(ApplicationLayerReadHealthPacket readHealthPacket) {

    }

    /**
     * 设置设备通讯录返回
     */
    public void onAddressBookToDevice(int state) {

    }

    /**
     * 设置设备 SOS 通讯录返回
     */
    public void onSOSNumberToDevice(int state) {

    }

    /**
     * rtkHrv数据返回
     *
     * @param rtkHrvPacket
     */
    public void onRtkHrvDataRsp(ApplicationLayerRtkHrvPacket rtkHrvPacket) {

    }

    /**
     * Audio switch back
     * 音频开关返回
     *
     * @param switchState
     */
    public void onAudioSwitchRsp(int switchState) {

    }

    /**
     * 设备测试Ecg数据返回
     *
     * @param packet
     */
    public void onEcgToDeviceRsp(ApplicationLayerEcgToDevicePacket packet) {

    }

    /**
     * 设备测试Ecg belt数据返回
     *
     * @param packet
     */
    public void onEcgBeltToDeviceRsp(ApplicationLayerEcgBeltToDevicePacket packet) {

    }

    public void onBondDeviceFail() {

    }

    public void onBondDeviceTimeout() {

    }

    public void onBondDeviceConfirm() {

    }

    /**
     * 同步设备可以控制的开关
     *
     * @param packet
     */
    public void onSyncSwitch(ApplicationLayerSyncSwitchPacket packet) {

    }

    /**
     * 连续血压采集参数返回
     *
     * @param bp3ContinuousPacket
     */
    public void onBp3Continuous(ApplicationLayerBp3ContinuousPacket bp3ContinuousPacket) {

    }

    /**
     * 连续血糖采集参数返回
     *
     * @param enable   是否开启
     * @param interval 间隔，单位分钟
     */
    public void onGluContinuous(boolean enable, int interval) {

    }

    /**
     * 血糖数据返回
     *
     * @param gluPacket
     */
    public void onGluDataRes(ApplicationLayerGLUPacket gluPacket) {

    }

    /**
     * 测试血糖中断返回
     */
    public void onGluTestDis() {

    }

    /**
     * 私人血糖参数返回
     *
     * @param height
     * @param low
     */
    public void onPrivateGlu(int height, int low) {

    }

    /**
     * 单位返回
     *
     * @param unitPacket
     */
    public void onUnitRes(ApplicationLayerUnitPacket unitPacket) {

    }

    /**
     * 多命令模式下私人血压
     *
     * @param packet 私人血压
     */
    public void onMulPrivateBp(ApplicationLayerMulPrivateBpPacket packet) {

    }

    /**
     * sync pulse data started
     * 同步脉冲开始
     */
    public void onSyncPulseDataStart(int totalCount) {

    }

    /**
     * sync pulse data received
     * 同步接收到脉冲数据
     */
    public void onSyncPulseDataReceived(List<JWPulseInfo> pulseInfoList) {

    }

    /**
     * sync pulse data finished
     * 同步脉冲结束
     */
    public void onSyncPulseDataFinished() {

    }

    /**
     * after pulse finished, this callback will be trigger
     * 脉冲理疗结束
     *
     * @param duration the pulse duration 时长
     */
    public void onPulseFinished(int duration) {

    }

    /**
     * sync sauna data started
     */
    public void onSyncSaunaDataStart(int totalCount) {

    }

    /**
     * sync sauna data received
     */
    public void onSyncSaunaDataReceived(List<JWSaunaInfo> saunaInfoList) {

    }

    /**
     * sync sauna data finished
     */
    public void onSyncSaunaDataFinished() {

    }

    /**
     * sync hr movement data received
     */
    public void onSyncHRMovementDataReceived(List<JWHRMovementInfo> hrMovementInfoList) {

    }

    /**
     * 佩戴时间数据返回
     */
    public void onWearingTimeDataRes(List<JWWearingTimeInfo> wearingTimeInfoList) {

    }

    /**
     * 尿酸数据返回
     */
    public void onUricAcidDataRes(List<JWUricAcidInfo> uricAcidInfoList) {

    }

    /**
     * 血脂数据返回
     */
    public void onBloodFatDataRes(List<JWBloodFatInfo> bloodFatInfoList) {

    }

    /**
     * 血糖周期数据返回
     */
    public void onBloodSugarCycleDataRes(List<JWBloodSugarCycleInfo> bloodSugarCycleInfoList) {

    }

    /**
     * 尿酸改变
     * uric acid changed
     *
     * @param packet 尿酸功能信息
     */
    public void onUricAcidFunctionChanged(ApplicationLayerMulUricAcidPacket packet) {

    }

    /**
     * 血脂改变
     * blood fat changed
     *
     * @param packet 血脂功能信息
     */
    public void onBloodFatFunctionChanged(ApplicationLayerMulBloodFatPacket packet) {

    }

    /**
     * 血糖周期改变
     * blood sugar cycle changed
     *
     * @param packet 血糖周期功能信息
     */
    public void onBloodSugarCycleFunctionChanged(ApplicationLayerMulBloodSugarCyclePacket packet) {

    }

    /**
     * 尿酸持续监测数据返回
     */
    public void onUricAcidContinuousMonitoringDataRes(List<JWUricAcidContinuousMonitoringInfo> uricAcidContinuousMonitoringInfoList) {

    }

    /**
     * 血脂持续监测数据返回
     */
    public void onBloodFatContinuousMonitoringDataRes(List<JWBloodFatContinuousMonitoringInfo> bloodFatContinuousMonitoringInfoList) {

    }

    /**
     * 设备测试状态改变
     *
     * @param status 0 取消测试 canceled
     *               1 测试失败 failed
     *               2 测试成功 success
     */
    public void onDeviceMeasureStatusUpdated(int status) {

    }

    /**
     * 体脂监测数据返回
     */
    public void onBodyFatDataRes(JWBodyFatInfo bodyFat) {

    }

    /**
     * 体检数据返回
     */
    public void onPhysicalDataRes(JWPhysicalExamInfo physicalExam) {

    }

    /**
     * 开启睡眠辅助返回
     * @param status 0(close) 1(open) 2(busy)
     */
    public void onSetSleepHelpRsp(int status) {

    }


    /**
     * return read hrv rmssd config rsp
     *
     * @param enable   true open false close
     * @param interval only support 5 min/times 10 min/times 15 min/times
     */
    public void onReadHRVRmssdConfigRsp(boolean enable, int interval) {

    }

    /**
     * sync hrv rmssd data received
     */
    public void onSyncHRVRmssdDataReceived(List<JWHRVRmssdInfo> dataList) {

    }

    /**
     * sync ultraviolet data received
     */
    public void onSyncUltravioletDataReceived(List<JWUltravioletInfo> dataList) {

    }

    /**
     * sync ultraviolet data end
     */
    public void onSyncUltravioletDataEnd() {

    }

    /**
     * sync pressure data received
     */
    public void onSyncPressureDataReceived(List<JWPressureInfo> dataList) {

    }

    /**
     * sync pressure data end
     */
    public void onSyncPressureDataEnd() {

    }

    /**
     * return read health risk assessment rsp
     */
    public void onReadHealthRiskAssessmentRsp(JWHealthRiskAssessmentInfo info) {

    }

    /**
     * return read default function rsp
     */
    public void onReadDefaultFunctionRsp(JWDefaultFunctionInfo defaultFunctionInfo) {

    }


    public void onOTADeviceInfoRead(byte[] data) {

    }

}
