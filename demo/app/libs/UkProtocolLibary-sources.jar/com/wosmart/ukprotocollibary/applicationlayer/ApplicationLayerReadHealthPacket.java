package com.wosmart.ukprotocollibary.applicationlayer;

import android.util.Log;

import com.wosmart.ukprotocollibary.util.DataConverter;
import com.wosmart.ukprotocollibary.model.enums.DeviceFunctionStatus;

import java.util.Arrays;

public class ApplicationLayerReadHealthPacket {

    /**
     * 血糖手动测量中
     */
    private int gluTestIng1;

    /**
     * 血糖静默测量中
     */
    private int gluTestIng2;

    /**
     * ecg测试中
     */
    private int ecgTestIng;

    /**
     * 运动中
     */
    private int sportIng;

    /**
     * 压力静默测量
     */
    private int pressureSilentIng;

    /**
     * 压力手动测量
     */
    private int pressureManualIng;

    /**
     * 血氧静默测量
     */
    private int spo2SilentIng;

    /**
     * 血氧手动测量
     */
    private int spo2ManualIng;

    /**
     * 血压静默测量
     */
    private int bpSilentIng;

    /**
     * 血压手动测量
     */
    private int bpManualIng;

    /**
     * 心率静默测量
     */
    private int hrpSilentIng;

    /**
     * 心率手动测量
     */
    private int hrpManualIng;

    /**
     * 脉冲理疗中
     */
    private int pulseIng;

    /**
     * 体脂测试中
     */
    private int bodyFatIng;

    public ApplicationLayerReadHealthPacket() {
    }

    public int getGluTestIng1() {
        return gluTestIng1;
    }

    public void setGluTestIng1(int gluTestIng1) {
        this.gluTestIng1 = gluTestIng1;
    }

    public int getGluTestIng2() {
        return gluTestIng2;
    }

    public void setGluTestIng2(int gluTestIng2) {
        this.gluTestIng2 = gluTestIng2;
    }

    public int getPressureSilentIng() {
        return pressureSilentIng;
    }

    public void setPressureSilentIng(int pressureSilentIng) {
        this.pressureSilentIng = pressureSilentIng;
    }

    public int getPressureManualIng() {
        return pressureManualIng;
    }

    public void setPressureManualIng(int pressureManualIng) {
        this.pressureManualIng = pressureManualIng;
    }

    public int getEcgTestIng() {
        return ecgTestIng;
    }

    public void setEcgTestIng(int ecgTestIng) {
        this.ecgTestIng = ecgTestIng;
    }

    public int getSportIng() {
        return sportIng;
    }

    public void setSportIng(int sportIng) {
        this.sportIng = sportIng;
    }

    public int getSpo2SilentIng() {
        return spo2SilentIng;
    }

    public void setSpo2SilentIng(int spo2SilentIng) {
        this.spo2SilentIng = spo2SilentIng;
    }

    public int getSpo2ManualIng() {
        return spo2ManualIng;
    }

    public void setSpo2ManualIng(int spo2ManualIng) {
        this.spo2ManualIng = spo2ManualIng;
    }

    public int getBpSilentIng() {
        return bpSilentIng;
    }

    public void setBpSilentIng(int bpSilentIng) {
        this.bpSilentIng = bpSilentIng;
    }

    public int getBpManualIng() {
        return bpManualIng;
    }

    public void setBpManualIng(int bpManualIng) {
        this.bpManualIng = bpManualIng;
    }

    public int getHrpSilentIng() {
        return hrpSilentIng;
    }

    public void setHrpSilentIng(int hrpSilentIng) {
        this.hrpSilentIng = hrpSilentIng;
    }

    public int getHrpManualIng() {
        return hrpManualIng;
    }

    public void setHrpManualIng(int hrpManualIng) {
        this.hrpManualIng = hrpManualIng;
    }

    public int getPulseIng() {
        return pulseIng;
    }

    public int getBodyFatIng() {
        return bodyFatIng;
    }

    public boolean parseData(byte[] data) {
        Log.d("UkOptManager5.3B","data.length="+data.length+"\tdata="+ Arrays.toString(data)+"\ndataHex="+ DataConverter.bytes2Hex(data));
        if (data.length >= 7) {
            sportIng = data[6] & 0x01;
            ecgTestIng = (data[6] >> 1) & 0x01;
            gluTestIng1 = (data[6] >> 2) & 0x01;
            gluTestIng2 = (data[6] >> 3) & 0x01;
            pulseIng = (data[6] >> 4) & 0x01;
            bodyFatIng = (data[6] >> 5) & 0x01;
            hrpManualIng = data[7] & 0x01;
            hrpSilentIng = (data[7] >> 1) & 0x01;
            bpManualIng = (data[7] >> 2) & 0x01;
            bpSilentIng = (data[7] >> 3) & 0x01;
            spo2ManualIng = (data[7] >> 4) & 0x01;
            spo2SilentIng = (data[7] >> 5) & 0x01;
            pressureManualIng = (data[7] >> 6) & 0x01;
            pressureSilentIng = (data[7] >> 7) & 0x01;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerReadHealthPacket{" +
                "gluTestIng1=" + gluTestIng1 +
                ", gluTestIng2=" + gluTestIng2 +
                ", pulseIng=" + pulseIng +
                ", bodyFatIng=" + bodyFatIng +
                ", ecgTestIng=" + ecgTestIng +
                ", sportIng=" + sportIng +
                ", pressureSilentIng=" + pressureSilentIng +
                ", pressureManualIng=" + pressureManualIng +
                ", spo2SilentIng=" + spo2SilentIng +
                ", spo2ManualIng=" + spo2ManualIng +
                ", bpSilentIng=" + bpSilentIng +
                ", bpManualIng=" + bpManualIng +
                ", hrpSilentIng=" + hrpSilentIng +
                ", hrpManualIng=" + hrpManualIng +
                '}';
    }
}
