package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerECGPacket {

    /**
     * bpm心率
     */
    private int bpmNumber;

    /**
     * QT间期
     */
    private int qtNumber;

    /**
     * HRV数据
     */
    private int hrvNumber;

    private int rriNumber;

    /**
     * 进度百分比
     */
    private int progress = 0;

    public int getBpmNumber() {
        return bpmNumber;
    }

    public void setBpmNumber(int bpmNumber) {
        this.bpmNumber = bpmNumber;
    }

    public int getQtNumber() {
        return qtNumber;
    }

    public void setQtNumber(int qtNumber) {
        this.qtNumber = qtNumber;
    }

    public int getHrvNumber() {
        return hrvNumber;
    }

    public void setHrvNumber(int hrvNumber) {
        this.hrvNumber = hrvNumber;
    }

    public int getRriNumber() {
        return rriNumber;
    }

    public void setRriNumber(int rriNumber) {
        this.rriNumber = rriNumber;
    }

    public int getProgress() {
        return progress;
    }

    public void setProgress(int progress) {
        this.progress = progress;
    }

    public boolean parseData(byte[] data){
        if(data.length >= 7){
            bpmNumber = data[0] & 0xff;
            qtNumber = (((data[1] & 0xff) << 8) | (data[2] & 0xff));
            hrvNumber = (((data[3] & 0xff) << 8) | (data[4] & 0xff));
            rriNumber = (((data[5] & 0xff) << 8) | (data[6] & 0xff));
            if(data.length > 7) {
                progress = data[7] & 0xff;
            }
        }else{
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerECGPacket{" +
                "bpmNumber=" + bpmNumber +
                ", qtNumber=" + qtNumber +
                ", hrvNumber=" + hrvNumber +
                ", rriNumber=" + rriNumber +
                '}';
    }
}
