package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.util.SDKLogger;

public class ApplicationLayerAlarm2Packet {
    // Parameters

    private boolean enable;  //  1bits

    /**
     * id
     */
    private int mId;        // 5bits

    /**
     * year
     */
    private int mYear;        // 6bits

    /**
     * month
     */
    private int mMonth;        // 4bits

    /**
     * day
     */
    private int mDay;        // 5bits

    /**
     * hour
     */
    private int mHour;        // 5bits

    /**
     * minute
     */
    private int mMinute;    // 6bits


    /**
     * repeat day flag 7bits
     */
    private byte mDayFlags;


    /**
     * alarm content
     */
    private String content;

    /**
     * current index of total alarm
     */
    private int curIndex;

    /**
     * alarm count;
     */
    private int count;

    /**
     * Packet Length
     */
    public final static int ALARM_HEADER_LENGTH = 5;


    public ApplicationLayerAlarm2Packet() {

    }

    public boolean isEnable() {
        return enable;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }

    public int getmId() {
        return mId;
    }

    public void setmId(int mId) {
        this.mId = mId;
    }

    public int getmYear() {
        return mYear + 2000;
    }

    public void setmYear(int mYear) {
        this.mYear = mYear - 2000;
    }

    public int getmMonth() {
        return mMonth;
    }

    public void setmMonth(int mMonth) {
        this.mMonth = mMonth;
    }

    public int getmDay() {
        return mDay;
    }

    public void setmDay(int mDay) {
        this.mDay = mDay;
    }

    public int getmHour() {
        return mHour;
    }

    public void setmHour(int mHour) {
        this.mHour = mHour;
    }

    public int getmMinute() {
        return mMinute;
    }

    public void setmMinute(int mMinute) {
        this.mMinute = mMinute;
    }

    public byte getmDayFlags() {
        return mDayFlags;
    }

    public void setmDayFlags(byte mDayFlags) {
        this.mDayFlags = mDayFlags;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getCurIndex() {
        return curIndex;
    }

    public void setCurIndex(int curIndex) {
        this.curIndex = curIndex;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public byte[] getPacket() {
        int contentLen = 0;
        byte[] contentData = null;
        if (null != content) {
            try {
                contentData = content.getBytes("UTF-8");
                contentLen = contentData.length;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (contentLen > 15) {
            contentLen = 15;
        }

        byte[] data = new byte[ALARM_HEADER_LENGTH + contentLen];
        data[0] = (byte) ((enable ? (byte) 0x80 : (byte) 0x00) | (mId << 2) | (mYear >> 4));
        data[1] = (byte) ((mYear << 4) | mMonth);
        data[2] = (byte) ((mDay << 3) | (mHour >> 2));
        data[3] = (byte) ((mHour << 6) | (mMinute));
        data[4] = (byte) (mDayFlags << 1);
        SDKLogger.i(
                "enable: " + enable +
                        "mYear: " + mYear +
                        ", mMonth: " + mMonth +
                        ", mDay: " + mDay +
                        ", mHour: " + mHour +
                        ", mMinute: " + mMinute +
                        ", mId: " + mId +
                        ", mDayFlags: " + mDayFlags +
                        ", content: " + content);
        if (contentLen > 0) {
            System.arraycopy(contentData, 0, data, 5, contentLen);
        }
        return data;
    }

    public boolean parseData(byte[] data) {
        int len = data.length;
        enable = ((data[0] & 0xff) >> 7) == 1 ? true : false;
        mId = (data[0] >> 2) & 0x1f;
        mYear = ((data[0] & 0x03) << 4) | ((data[1] & 0xf0) >> 4);
        mMonth = (data[1] & 0x0f);
        mDay = (data[2] >> 3) & 0x1f;
        mHour = ((data[2] & 0x07) << 2) | ((data[3] >> 6) & 0x03);
        mMinute = (data[3] & 0x3f);
        mDayFlags = (byte) ((data[4] >> 1) & 0xff);
        SDKLogger.i(
                "enable: " + enable +
                        "mYear: " + mYear +
                        ", mMonth: " + mMonth +
                        ", mDay: " + mDay +
                        ", mHour: " + mHour +
                        ", mMinute: " + mMinute +
                        ", mId: " + mId +
                        ", mDayFlags: " + mDayFlags);
        int diff = len - 7;
        if (diff > 0) {
            if (diff > 15) {
                diff = 15;
            }
            byte[] contentData = new byte[diff];
            System.arraycopy(data, 5, contentData, 0, diff);
            try {
                content = new String(contentData, "UTF-8");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        curIndex = data[5 + diff] & 0xff;
        count = data[6 + diff] & 0xff;
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerAlarm2Packet{" +
                "enable=" + enable +
                ", mId=" + mId +
                ", mYear=" + mYear +
                ", mMonth=" + mMonth +
                ", mDay=" + mDay +
                ", mHour=" + mHour +
                ", mMinute=" + mMinute +
                ", mDayFlags=" + mDayFlags +
                ", content='" + content +
                ", curIndex='" + curIndex +
                ", count='" + count + '\'' +
                '}';
    }
}
