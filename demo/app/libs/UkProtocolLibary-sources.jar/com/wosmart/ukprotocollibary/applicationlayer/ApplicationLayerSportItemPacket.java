package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.util.DataConverter;
import com.wosmart.ukprotocollibary.util.SDKLogger;

public class ApplicationLayerSportItemPacket {
    /**
     * sport start minutes
     * minutes of day
     */
    private int minutes;            // 11bits

    /**
     * sport start  seconds
     * seconds of minute
     */
    private int seconds;                // 2bits

    /**
     * sport model
     * 0x00	Run	跑步
     * 0x01	Climb	登山
     * 0x02	Football	足球
     * 0x03	Cycle	骑行
     * 0x04	Rope	跳绳
     * 0x05	RunOutDoor	户外跑步
     * 0x06	RideOutDoor	户外骑车
     * 0x07	WalkOutDoor	户外健走
     * 0x08	RunInDoor	室内跑步
     * 0x09	FreeTrain	自由训练
     * 0x0A	Plank	平板支撑
     * 0x0B walk  健走
     * 0x0C pranayama  呼吸训练
     * 0x0D yoga  瑜伽
     * 0x0E hiking  徒步
     * 0x0F spining  动感单车
     * 0x10 rowing  划船机
     * 0x11 stepper  踏步机
     * 0x12 elliptical  椭圆机
     * 0x13 basketball  篮球
     * 0x14 tennis  网球
     * 0x15 badminton  羽毛球
     * 0x16 baseball  棒球
     * 0x17 rugby  橄榄球
     */
    private int sportModel;            // 12bits

    /**
     * sport duration minutes
     */
    private int sportMinute;            // 19bits

    /**
     * sport duration seconds
     */
    private int sportSecond;            // 16bits

    /**
     * sport pause count
     */
    private int pauseCount;

    /**
     * sport pause minutes
     */
    private int pauseMinute;

    /**
     * sport pause seconds
     */
    private int pauseSecond;

    /**
     * sport total step
     */
    private int steps;

    /**
     * sport total distance
     */
    private int distance;

    /**
     * sport total calories
     */
    private int calories;

    /**
     * Respiration rate
     * Breath training only
     */
    private int respirationRate;

    /**
     * Respiration rate minute
     * Breath training only
     */
    private int respirationRateMinute;

    /**
     * sport high rate
     */
    private int rateHigh = 0;

    /**
     * sport avg rate
     */
    private int rateAvg = 0;

    /**
     * sport low rate
     */
    private int rateLow = 0;


    /**
     * Packet Length
     */
    public final static int SPORT_ITEM_LENGTH = 24;
    public final static int SPORT_ITEM_LENGTH_NEW = 28;

    public boolean parseData(byte[] data) {
        SDKLogger.i("SportItem.length=" + data.length + "\t" + DataConverter.bytes2Hex(data));
        // check header length
        if (data.length < SPORT_ITEM_LENGTH) {
            return false;
        }
        minutes = ((data[1] & 0xff) << 8) | (data[2] & 0xff);
        seconds = data[3] & 0xff;
        sportModel = data[4] & 0xff;
        sportMinute = ((data[5] & 0xff) << 8) | (data[6] & 0xff);
        sportSecond = data[7] & 0xff;
        pauseCount = data[8] & 0xff;
        pauseMinute = ((data[9] & 0xff) << 8) | (data[10] & 0xff);
        pauseSecond = data[11] & 0xff;
        steps = ((data[12] & 0xff) << 24) | ((data[13] & 0xff) << 16) | ((data[14] & 0xff) << 8) | ((data[15] & 0xff));
        distance = ((data[16] & 0xff) << 24) | ((data[17] & 0xff) << 16) | ((data[18] & 0xff) << 8) | ((data[19] & 0xff));
        calories = ((data[20] & 0xff) << 24) | ((data[21] & 0xff) << 16) | ((data[22] & 0xff) << 8) | ((data[23] & 0xff));

        if (data.length == SPORT_ITEM_LENGTH_NEW) {
            rateHigh = data[24] & 0xff;
            rateAvg = data[25] & 0xff;
            rateLow = data[26] & 0xff;
        }
        //呼吸训练时 呼吸率存储到步数中
        if (sportModel == 12) {
            respirationRate = steps;
            respirationRateMinute = distance;
        }

        SDKLogger.i("minutes: " + minutes +
                ", seconds:" + seconds +
                ", sportModel:" + sportModel +
                ", sportMinute:" + sportMinute +
                ", sportSecond:" + sportSecond +
                ", steps:" + steps +
                ", distance:" + distance +
                ", calories:" + calories +
                ", respirationRate=" + respirationRate +
                ", rateHigh=" + rateHigh +
                ", rateAvg=" + rateAvg +
                ", rateLow=" + rateLow);
        return true;
    }

    public int getMinutes() {
        return minutes;
    }

    public int getSeconds() {
        return seconds;
    }

    public int getSportModel() {
        return sportModel;
    }

    public int getSportMinute() {
        return sportMinute;
    }

    public int getSportSecond() {
        return sportSecond;
    }

    public int getPauseCount() {
        return pauseCount;
    }

    public int getPauseMinute() {
        return pauseMinute;
    }

    public int getPauseSecond() {
        return pauseSecond;
    }

    public int getSteps() {
        return steps;
    }

    public int getDistance() {
        return distance;
    }

    public int getCalories() {
        return calories;
    }

    public int getRespirationRate() {
        return respirationRate;
    }

    public int getRespirationRateMinute() {
        return respirationRateMinute;
    }

    public int getRateHigh() {
        return rateHigh;
    }

    public int getRateAvg() {
        return rateAvg;
    }

    public int getRateLow() {
        return rateLow;
    }

    @Override
    public String toString() {
        return "ApplicationLayerSportItemPacket{" +
                "minutes=" + minutes +
                ", seconds=" + seconds +
                ", sportModel=" + sportModel +
                ", sportMinute=" + sportMinute +
                ", sportSecond=" + sportSecond +
                ", pauseCount=" + pauseCount +
                ", pauseMinute=" + pauseMinute +
                ", pauseSecond=" + pauseSecond +
                ", steps=" + steps +
                ", distance=" + distance +
                ", calories=" + calories +
                ", respirationRate=" + respirationRate +
                ", respirationRateMinute=" + respirationRateMinute +
                ", rateHigh=" + rateHigh +
                ", rateAvg=" + rateAvg +
                ", rateLow=" + rateLow +
                '}';
    }
}
