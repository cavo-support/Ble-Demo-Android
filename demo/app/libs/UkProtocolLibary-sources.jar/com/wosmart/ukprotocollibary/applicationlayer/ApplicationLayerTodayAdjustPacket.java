package com.wosmart.ukprotocollibary.applicationlayer;

import android.util.Log;

import com.wosmart.ukprotocollibary.util.DataConverter;

import java.util.Arrays;

public class ApplicationLayerTodayAdjustPacket {

    /**
     * offset id
     */
    private int offset;

    /**
     * step count
     */
    private int stepCount;

    /**
     * step calories count
     */
    private int caloryCount;

    /**
     * step distance count
     */
    private int distanceCount;

    /**
     * cur offset step count
     */
    private int curPosStep;

    /**
     * cur offset step calories
     */
    private int curPosCalory;

    /**
     * current offset step distance
     */
    private int curPosDistance;

    /**
     * Packet Length
     */
    public final static int SPORT_ITEM_LENGTH = 17;

    public boolean parseData(byte[] data) {
        // check header length
        Log.d("UkOptManager","\ndata.length="+data.length+"\ndata="+ Arrays.toString(data)+"\ndataHex="+ DataConverter.bytes2Hex(data));
        if (data.length >= 17) {
            offset = data[0] & 0xff;
            stepCount = ((data[1] & 0xff) << 16) | ((data[2] & 0xff) << 8) | (data[3] & 0xff);
            caloryCount = ((data[4] & 0xff) << 16) | ((data[5] & 0xff) << 8) | (data[6] & 0xff);
            distanceCount = ((data[7] & 0xff) << 16) | ((data[8] & 0xff) << 8) | (data[9] & 0xff);
            curPosStep = ((data[10] & 0xff) << 8) | (data[11] & 0xff);
            curPosCalory = ((data[12] & 0xff) << 16) | ((data[13] & 0xff) << 8) | (data[14] & 0xff);
            curPosDistance = ((data[15] & 0xff) << 8) | (data[16] & 0xff);
        } else if (data.length == 16) {
            offset = data[0] & 0xff;
            stepCount = ((data[1] & 0xff) << 16) | ((data[2] & 0xff) << 8) | (data[3] & 0xff);
            caloryCount = ((data[4] & 0xff) << 16) | ((data[5] & 0xff) << 8) | (data[6] & 0xff);
            distanceCount = ((data[7] & 0xff) << 16) | ((data[8] & 0xff) << 8) | (data[9] & 0xff);
            curPosStep = ((data[10] & 0xff) << 8) | (data[11] & 0xff);
            curPosCalory = ((data[12] & 0xff) << 8) | (data[13] & 0xff);
            curPosDistance = ((data[14] & 0xff) << 8) | (data[15] & 0xff);
        }
        Log.d("UkOptManager",toString());
        return true;
    }

    public ApplicationLayerTodayAdjustPacket() {

    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public int getStepCount() {
        return stepCount;
    }

    public void setStepCount(int stepCount) {
        this.stepCount = stepCount;
    }

    public int getCaloryCount() {
        return caloryCount;
    }

    public void setCaloryCount(int caloryCount) {
        this.caloryCount = caloryCount;
    }

    public int getDistanceCount() {
        return distanceCount;
    }

    public void setDistanceCount(int distanceCount) {
        this.distanceCount = distanceCount;
    }

    public int getCurPosStep() {
        return curPosStep;
    }

    public void setCurPosStep(int curPosStep) {
        this.curPosStep = curPosStep;
    }

    public int getCurPosCalory() {
        return curPosCalory;
    }

    public void setCurPosCalory(int curPosCalory) {
        this.curPosCalory = curPosCalory;
    }

    public int getCurPosDistance() {
        return curPosDistance;
    }

    public void setCurPosDistance(int curPosDistance) {
        this.curPosDistance = curPosDistance;
    }

    @Override
    public String toString() {
        return "ApplicationLayerTodayAdjustPacket{" +
                "offset=" + offset +
                ", stepCount=" + stepCount +
                ", caloryCount=" + caloryCount +
                ", distanceCount=" + distanceCount +
                ", curPosStep=" + curPosStep +
                ", curPosCalory=" + curPosCalory +
                ", curPosDistance=" + curPosDistance +
                '}';
    }
}
