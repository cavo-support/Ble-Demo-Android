package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.v2.entity.JWPulseInfo;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class ApplicationLayerPulseDataPacket {

    public List<JWPulseInfo> pulseInfoList = new ArrayList<>();

    public boolean parseData(byte[] data) {
        if ((data.length < 8) || (data.length % 8) != 0) {
            return false;
        }
        Calendar calendar = Calendar.getInstance();
        byte[] subData = new byte[8];
        for (int i = 0; i < data.length / 8; i++) {
            System.arraycopy(data, i * 8, subData, 0, 8);

            int year = (subData[0] & 0x7e) >> 1;
            int month = ((subData[0] & 0x01) << 3) | (subData[1] >> 5) & 0x07;
            int day = subData[1] & 0x1f;
            int minute = ((subData[2] << 8) | (subData[3] & 0xff)) & 0xffff;
            int second = (subData[4] & 0xff);
            int duration = (((subData[5] & 0xff) << 16) | ((subData[6] & 0xff) << 8) | (subData[7] & 0xff));

            calendar.clear();
            calendar.set(2000 + year, month - 1, day);

            long time = calendar.getTimeInMillis();

            time += minute * 60000;
            time += second * 1000;

            JWPulseInfo info = new JWPulseInfo();
            info.startTime = time;
            info.duration = duration;

            pulseInfoList.add(info);
        }
        return true;
    }


}
