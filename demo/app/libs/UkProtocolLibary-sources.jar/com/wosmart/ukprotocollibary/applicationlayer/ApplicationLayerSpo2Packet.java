package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerSpo2Packet {

    /**
     * year
     */
    private int mYear;            // 6bits

    /**
     * month
     */
    private int mMonth;            // 4bits

    /**
     * day
     */
    private int mDay;            // 5bits

    /**
     * minute
     */
    private int mMinutes;             // 16bits

    /**
     * id
     */
    private int mSequenceNum;        //8 bits

    /**
     * current value 8bit
     */
    private int mCurValue;

    /**
     * low value 8bits
     */
    private int mHighValue;

    /**
     * high value 8bits
     */
    private int mLowValue;

    // Packet Length
    public final static int ITEM_LENGTH = 8;


    public int getmYear() {
        return mYear;
    }

    public void setmYear(int mYear) {
        this.mYear = mYear;
    }

    public int getmMonth() {
        return mMonth;
    }

    public void setmMonth(int mMonth) {
        this.mMonth = mMonth;
    }

    public int getmDay() {
        return mDay;
    }

    public void setmDay(int mDay) {
        this.mDay = mDay;
    }

    public int getmMinutes() {
        return mMinutes;
    }

    public void setmMinutes(int mMinutes) {
        this.mMinutes = mMinutes;
    }

    public int getmSequenceNum() {
        return mSequenceNum;
    }

    public void setmSequenceNum(int mSequenceNum) {
        this.mSequenceNum = mSequenceNum;
    }

    public int getmCurValue() {
        return mCurValue;
    }

    public void setmCurValue(int mCurValue) {
        this.mCurValue = mCurValue;
    }

    public int getmHighValue() {
        return mHighValue;
    }

    public void setmHighValue(int mHighValue) {
        this.mHighValue = mHighValue;
    }

    public int getmLowValue() {
        return mLowValue;
    }

    public void setmLowValue(int mLowValue) {
        this.mLowValue = mLowValue;
    }

    public boolean parseData(byte[] data) {
        if (data.length >= ITEM_LENGTH) {
            mYear = (data[0] & 0x7e) >> 1;// here must be care shift operation of negative
            mMonth = ((data[0] & 0x01) << 3) | (data[1] >> 5) & 0x07;//here must be care shift operation of negative
            mDay = data[1] & 0x1f;//here must be care shift operation of negative
            mMinutes = ((data[2] << 8) | (data[3] & 0xff)) & 0xffff;// here must be care shift operation of negative
            mSequenceNum = (data[4] & 0xff);
            mCurValue = (data[5] & 0xff);
            mHighValue = (data[6] & 0xff);
            mLowValue = (data[7] & 0xff);
        }
        return true;
    }


    @Override
    public String toString() {
        return "ApplicationLayerSpo2Packet{" +
                "mYear=" + mYear +
                ", mMonth=" + mMonth +
                ", mDay=" + mDay +
                ", mMinutes=" + mMinutes +
                ", mSequenceNum=" + mSequenceNum +
                ", mCurValue=" + mCurValue +
                ", mHighValue=" + mHighValue +
                ", mLowValue=" + mLowValue +
                '}';
    }
}
