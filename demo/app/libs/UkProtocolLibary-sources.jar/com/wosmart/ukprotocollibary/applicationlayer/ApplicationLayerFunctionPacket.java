package com.wosmart.ukprotocollibary.applicationlayer;

import android.util.Log;

import com.wosmart.ukprotocollibary.util.DataConverter;
import com.wosmart.ukprotocollibary.model.enums.DeviceFunctionStatus;

import java.util.Arrays;

public class ApplicationLayerFunctionPacket {

    /**
     * earphone--通话耳机
     */
    private DeviceFunctionStatus EarPhone;

    /**
     * bp measure--血压手动测试
     */
    private DeviceFunctionStatus BpDetection;

    /**
     * rate auto detection--心率
     */
    private DeviceFunctionStatus Rate;

    /**
     * disturb mode setting--勿扰模式
     */
    private DeviceFunctionStatus Disturb;

    /**
     * step recorder--计步
     */
    private DeviceFunctionStatus Step;

    /**
     * sleep detection--睡眠
     */
    private DeviceFunctionStatus Sleep;

    /**
     * werun--微信运动
     */
    private DeviceFunctionStatus WeRun;

    /**
     * light duration setting--亮屏时长
     */
    private DeviceFunctionStatus LightDuration;

    /**
     * notify reminder setting--消息提醒
     */
    private DeviceFunctionStatus NotifyReminder;

    /**
     * screen theme setting--主界面切换
     */
    private DeviceFunctionStatus ScreenTheme;

    /**
     * turn wrist light display setting--转腕亮屏
     */
    private DeviceFunctionStatus TurnLight;

    /**
     * multi language--多国语言
     */
    private DeviceFunctionStatus MultiLanguage;

    /**
     * hour system setting--小时制
     */
    private DeviceFunctionStatus HourSystem;

    /**
     * unit system setting--公英制
     */
    private DeviceFunctionStatus UnitSystem;

    /**
     * ota
     */
    private DeviceFunctionStatus OTA;

    /**
     * nfc
     */
    private DeviceFunctionStatus NFC;

    /**
     * multi sport--多运动模式
     */
    private DeviceFunctionStatus MultiSport;

    /**
     * step watch setting--秒表
     */
    private DeviceFunctionStatus StepWatch;

    /**
     * count down setting--倒计时
     */
    private DeviceFunctionStatus CountDown;

    /**
     * rate reminder setting--心率提醒
     */
    private DeviceFunctionStatus RateReminder;

    /**
     * camera control--遥控拍照
     */
    private DeviceFunctionStatus CameraControl;

    /**
     * find phone--查找手机
     */
    private DeviceFunctionStatus FindPhone;

    /**
     * find device--查找手环
     */
    private DeviceFunctionStatus FindDevice;

    /**
     * screen light percent setting--亮度控制
     */
    private DeviceFunctionStatus LightControl;

    /**
     * control phone music--音乐控制
     */
    private DeviceFunctionStatus MusicControl;

    /**
     * control phone volume--音量控制
     */
    private DeviceFunctionStatus VolumeControl;

    /**
     * alarm setting--智能闹钟
     */
    private DeviceFunctionStatus Alarm;

    /**
     * long sit reminder--久坐提醒
     */
    private DeviceFunctionStatus LongSitReminder;

    /**
     * event reminder--事件提醒
     */
    private DeviceFunctionStatus EventReminder;

    /**
     * auto lock screen--锁屏防触
     */
    private DeviceFunctionStatus AutoLock;


    /**
     * measure rate every seconds--实时心率上传
     * App运动时心率检测
     */
    private DeviceFunctionStatus AppSportRateDetect;

    /**
     * base switch--隐藏功能菜单
     * 基础开关
     */
    private DeviceFunctionStatus BaseSwitch;

    /**
     * today total step and step adjust--当天计步校准
     * 今日数据校准
     */
    private DeviceFunctionStatus TodayAdjust;


    /**
     * today sleep adjust
     * 睡眠数据校准
     */
    private DeviceFunctionStatus SleepAdjust;


    /**
     * temperature
     * 温度检测
     */
    private DeviceFunctionStatus Temperature;

    /**
     * 2.0 版本血压
     */
    private DeviceFunctionStatus Bp2;

    /**
     * 闹钟 2.0
     */
    private DeviceFunctionStatus Alarm2;


    /**
     * 自定义主界面
     */
    private DeviceFunctionStatus CustomUi;

    /**
     * 下载主界面
     */
    private DeviceFunctionStatus DownloadUi;

    /**
     * 血氧测量
     */
    private DeviceFunctionStatus Spo2Measure;

    /**
     * mode1 mode3 升级--显示字库升级
     */
    private DeviceFunctionStatus ModeUpgrade;

    /**
     * 第二版本睡眠质量判断
     */
    private DeviceFunctionStatus SleepQuality2;

    /**
     * App运动心率2.0
     */
    private DeviceFunctionStatus SportRate2;

    /**
     * 心率温度压力数据返回
     */
    private DeviceFunctionStatus RateTempPressure;
    /**
     * 连续血氧
     */
    private DeviceFunctionStatus Spo2Continuous;

    /**
     * 心电功能
     */
    private DeviceFunctionStatus EcgFunction;

    /**
     * 同步设备状态
     */
    private DeviceFunctionStatus DeviceStateSync;

    /**
     * 通讯录功能
     */
    private DeviceFunctionStatus AddressBook;

    /**
     * Hrv功能
     */
    private DeviceFunctionStatus RtkHrv;

    /**
     * 血压3.0
     */
    private DeviceFunctionStatus RtkBp3;

    /**
     * 血糖功能
     */
    private DeviceFunctionStatus GLU;

    /**
     * 低氧提醒功能
     */
    private DeviceFunctionStatus Hypoxia;

    /**
     * 心率过高功能
     */
    private DeviceFunctionStatus HighHrv;

    /**
     * 全天睡眠功能
     */
    private DeviceFunctionStatus SleepAll;

    /**
     * 日期格式功能
     */
    private DeviceFunctionStatus DeviceDateFormat;

    /**
     * 私人血压(3.0 血压下接收到 0801 功能才支持)
     */
    private DeviceFunctionStatus privateBloodPressure;

    /**
     * SOS
     */
    private DeviceFunctionStatus sosNumber;

    /**
     * 体温提醒
     */
    private DeviceFunctionStatus temperatureReminder;


    /**
     * 喝水提醒
     */
    private DeviceFunctionStatus drinkWaterReminder;

    /**
     * 吃药提醒
     */
    private DeviceFunctionStatus medicationReminder;

    /**
     * 脉冲
     */
    private DeviceFunctionStatus pulse;

    /**
     * 睡眠辅助
     */
    private DeviceFunctionStatus sleepHelp;

    /**
     * 桑拿
     */
    private DeviceFunctionStatus sauna;

    /**
     * 女性健康
     */
    private DeviceFunctionStatus femaleHealth;

    /**
     * 天气
     */
    private DeviceFunctionStatus weather;

    /**
     * 穿戴时间
     */
    private DeviceFunctionStatus wearingTime;

    /**
     * 体脂
     */
    private DeviceFunctionStatus bodyFat;

    /**
     * 体检
     */
    private DeviceFunctionStatus physicalExam;

    /**
     * 紫外线
     */
    private DeviceFunctionStatus ultraviolet;

    /**
     * 尿酸
     */
    private DeviceFunctionStatus uricAcid;

    /**
     * 血脂
     */
    private DeviceFunctionStatus bloodFat;

    /**
     * 血糖周期
     */
    private DeviceFunctionStatus bloodSugarCycle;

    /**
     * 尿酸连续监测功能
     */
    public DeviceFunctionStatus uricAcidContinuousMonitoring;

    /**
     * 血脂连续监测功能
     */
    public DeviceFunctionStatus bloodFatContinuousMonitoring;

    /**
     * ecg 隐藏 qt 和 hrv
     */
    public DeviceFunctionStatus hideQTAndHrv;

    /**
     * 心电带
     */
    public DeviceFunctionStatus EcgBelt;

    /**
     * 隐藏健康功能
     */
    public DeviceFunctionStatus HideHealthFunction;

    /**
     * 压力
     */
    public DeviceFunctionStatus Pressure;

    public ApplicationLayerFunctionPacket() {
    }

    public DeviceFunctionStatus getEarPhone() {
        return EarPhone;
    }

    public void setEarPhone(DeviceFunctionStatus earPhone) {
        EarPhone = earPhone;
    }

    public DeviceFunctionStatus getBpDetection() {
        return BpDetection;
    }

    public void setBpDetection(DeviceFunctionStatus bpDetection) {
        BpDetection = bpDetection;
    }

    public DeviceFunctionStatus getRate() {
        return Rate;
    }

    public void setRate(DeviceFunctionStatus rate) {
        Rate = rate;
    }

    public DeviceFunctionStatus getDisturb() {
        return Disturb;
    }

    public void setDisturb(DeviceFunctionStatus disturb) {
        Disturb = disturb;
    }

    public DeviceFunctionStatus getStep() {
        return Step;
    }

    public void setStep(DeviceFunctionStatus step) {
        Step = step;
    }

    public DeviceFunctionStatus getSleep() {
        return Sleep;
    }

    public void setSleep(DeviceFunctionStatus sleep) {
        Sleep = sleep;
    }

    public DeviceFunctionStatus getWeRun() {
        return WeRun;
    }

    public void setWeRun(DeviceFunctionStatus weRun) {
        WeRun = weRun;
    }

    public DeviceFunctionStatus getLightDuration() {
        return LightDuration;
    }

    public void setLightDuration(DeviceFunctionStatus lightDuration) {
        LightDuration = lightDuration;
    }

    public DeviceFunctionStatus getNotifyReminder() {
        return NotifyReminder;
    }

    public void setNotifyReminder(DeviceFunctionStatus notifyReminder) {
        NotifyReminder = notifyReminder;
    }

    public DeviceFunctionStatus getScreenTheme() {
        return ScreenTheme;
    }

    public void setScreenTheme(DeviceFunctionStatus screenTheme) {
        ScreenTheme = screenTheme;
    }

    public DeviceFunctionStatus getTurnLight() {
        return TurnLight;
    }

    public void setTurnLight(DeviceFunctionStatus turnLight) {
        TurnLight = turnLight;
    }

    public DeviceFunctionStatus getMultiLanguage() {
        return MultiLanguage;
    }

    public void setMultiLanguage(DeviceFunctionStatus multiLanguage) {
        MultiLanguage = multiLanguage;
    }

    public DeviceFunctionStatus getHourSystem() {
        return HourSystem;
    }

    public void setHourSystem(DeviceFunctionStatus hourSystem) {
        HourSystem = hourSystem;
    }

    public DeviceFunctionStatus getUnitSystem() {
        return UnitSystem;
    }

    public void setUnitSystem(DeviceFunctionStatus unitSystem) {
        UnitSystem = unitSystem;
    }

    public DeviceFunctionStatus getOTA() {
        return OTA;
    }

    public void setOTA(DeviceFunctionStatus OTA) {
        this.OTA = OTA;
    }

    public DeviceFunctionStatus getNFC() {
        return NFC;
    }

    public void setNFC(DeviceFunctionStatus NFC) {
        this.NFC = NFC;
    }

    public DeviceFunctionStatus getMultiSport() {
        return MultiSport;
    }

    public void setMultiSport(DeviceFunctionStatus multiSport) {
        MultiSport = multiSport;
    }

    public DeviceFunctionStatus getStepWatch() {
        return StepWatch;
    }

    public void setStepWatch(DeviceFunctionStatus stepWatch) {
        StepWatch = stepWatch;
    }

    public DeviceFunctionStatus getCountDown() {
        return CountDown;
    }

    public void setCountDown(DeviceFunctionStatus countDown) {
        CountDown = countDown;
    }

    public DeviceFunctionStatus getRateReminder() {
        return RateReminder;
    }

    public void setRateReminder(DeviceFunctionStatus rateReminder) {
        RateReminder = rateReminder;
    }

    public DeviceFunctionStatus getCameraControl() {
        return CameraControl;
    }

    public void setCameraControl(DeviceFunctionStatus cameraControl) {
        CameraControl = cameraControl;
    }

    public DeviceFunctionStatus getFindPhone() {
        return FindPhone;
    }

    public void setFindPhone(DeviceFunctionStatus findPhone) {
        FindPhone = findPhone;
    }

    public DeviceFunctionStatus getFindDevice() {
        return FindDevice;
    }

    public void setFindDevice(DeviceFunctionStatus findDevice) {
        FindDevice = findDevice;
    }

    public DeviceFunctionStatus getLightControl() {
        return LightControl;
    }

    public void setLightControl(DeviceFunctionStatus lightControl) {
        LightControl = lightControl;
    }

    public DeviceFunctionStatus getMusicControl() {
        return MusicControl;
    }

    public void setMusicControl(DeviceFunctionStatus musicControl) {
        MusicControl = musicControl;
    }

    public DeviceFunctionStatus getVolumeControl() {
        return VolumeControl;
    }

    public void setVolumeControl(DeviceFunctionStatus volumeControl) {
        VolumeControl = volumeControl;
    }

    public DeviceFunctionStatus getAlarm() {
        return Alarm;
    }

    public void setAlarm(DeviceFunctionStatus alarm) {
        Alarm = alarm;
    }

    public DeviceFunctionStatus getLongSitReminder() {
        return LongSitReminder;
    }

    public void setLongSitReminder(DeviceFunctionStatus longSitReminder) {
        LongSitReminder = longSitReminder;
    }

    public DeviceFunctionStatus getEventReminder() {
        return EventReminder;
    }

    public void setEventReminder(DeviceFunctionStatus eventReminder) {
        EventReminder = eventReminder;
    }

    public DeviceFunctionStatus getAutoLock() {
        return AutoLock;
    }

    public void setAutoLock(DeviceFunctionStatus autoLock) {
        AutoLock = autoLock;
    }

    public DeviceFunctionStatus getAppSportRateDetect() {
        return AppSportRateDetect;
    }

    public void setAppSportRateDetect(DeviceFunctionStatus appSportRateDetect) {
        AppSportRateDetect = appSportRateDetect;
    }

    public DeviceFunctionStatus getBaseSwitch() {
        return BaseSwitch;
    }

    public void setBaseSwitch(DeviceFunctionStatus baseSwitch) {
        BaseSwitch = baseSwitch;
    }

    public DeviceFunctionStatus getTodayAdjust() {
        return TodayAdjust;
    }

    public void setTodayAdjust(DeviceFunctionStatus todayAdjust) {
        TodayAdjust = todayAdjust;
    }

    public DeviceFunctionStatus getSleepAdjust() {
        return SleepAdjust;
    }

    public void setSleepAdjust(DeviceFunctionStatus sleepAdjust) {
        SleepAdjust = sleepAdjust;
    }

    public DeviceFunctionStatus getTemperature() {
        return Temperature;
    }

    public void setTemperature(DeviceFunctionStatus temperature) {
        Temperature = temperature;
    }

    public DeviceFunctionStatus getBp2() {
        return Bp2;
    }

    public void setBp2(DeviceFunctionStatus bp2) {
        Bp2 = bp2;
    }

    public DeviceFunctionStatus getAlarm2() {
        return Alarm2;
    }

    public void setAlarm2(DeviceFunctionStatus alarm2) {
        this.Alarm2 = alarm2;
    }

    public DeviceFunctionStatus getCustomUi() {
        return CustomUi;
    }

    public void setCustomUi(DeviceFunctionStatus customUi) {
        CustomUi = customUi;
    }

    public DeviceFunctionStatus getDownloadUi() {
        return DownloadUi;
    }

    public void setDownloadUi(DeviceFunctionStatus downloadUi) {
        DownloadUi = downloadUi;
    }

    public DeviceFunctionStatus getSpo2Measure() {
        return Spo2Measure;
    }

    public void setSpo2Measure(DeviceFunctionStatus spo2Measure) {
        Spo2Measure = spo2Measure;
    }

    public DeviceFunctionStatus getModeUpgrade() {
        return ModeUpgrade;
    }

    public void setModeUpgrade(DeviceFunctionStatus modeUpgrade) {
        this.ModeUpgrade = modeUpgrade;
    }

    public DeviceFunctionStatus getSleepQuality2() {
        return SleepQuality2;
    }

    public void setSleepQuality2(DeviceFunctionStatus sleepQuality2) {
        this.SleepQuality2 = sleepQuality2;
    }

    public DeviceFunctionStatus getSpo2Continuous() {
        return Spo2Continuous;
    }

    public void setSpo2Continuous(DeviceFunctionStatus spo2Continuous) {
        Spo2Continuous = spo2Continuous;
    }

    public DeviceFunctionStatus getEcgFunction() {
        return EcgFunction;
    }

    public void setEcgFunction(DeviceFunctionStatus ecgFunction) {
        EcgFunction = ecgFunction;
    }

    public DeviceFunctionStatus getDeviceStateSync() {
        return DeviceStateSync;
    }

    public void setDeviceStateSync(DeviceFunctionStatus deviceStateSync) {
        DeviceStateSync = deviceStateSync;
    }

    public DeviceFunctionStatus getRtkHrv() {
        return RtkHrv;
    }

    public void setRtkHrv(DeviceFunctionStatus rtkHrv) {
        RtkHrv = rtkHrv;
    }

    public DeviceFunctionStatus getAddressBook() {
        return AddressBook;
    }

    public void setAddressBook(DeviceFunctionStatus addressBook) {
        AddressBook = addressBook;
    }

    public DeviceFunctionStatus getSportRate2() {
        return SportRate2;
    }

    public void setSportRate2(DeviceFunctionStatus sportRate2) {
        SportRate2 = sportRate2;
    }

    public DeviceFunctionStatus getRateTempPressure() {
        return RateTempPressure;
    }

    public void setRateTempPressure(DeviceFunctionStatus rateTempPressure) {
        RateTempPressure = rateTempPressure;
    }

    public DeviceFunctionStatus getRtkBp3() {
        return RtkBp3;
    }

    public void setRtkBp3(DeviceFunctionStatus rtkBp3) {
        RtkBp3 = rtkBp3;
    }

    public DeviceFunctionStatus getGLU() {
        return GLU;
    }

    public void setGLU(DeviceFunctionStatus GLU) {
        this.GLU = GLU;
    }

    public DeviceFunctionStatus getHypoxia() {
        return Hypoxia;
    }

    public void setHypoxia(DeviceFunctionStatus hypoxia) {
        Hypoxia = hypoxia;
    }

    public DeviceFunctionStatus getHighHrv() {
        return HighHrv;
    }

    public void setHighHrv(DeviceFunctionStatus highHrv) {
        HighHrv = highHrv;
    }

    public DeviceFunctionStatus getSleepAll() {
        return SleepAll;
    }

    public void setSleepAll(DeviceFunctionStatus sleepAll) {
        SleepAll = sleepAll;
    }

    public DeviceFunctionStatus getDateFormat() {
        return DeviceDateFormat;
    }

    public void setDateFormat(DeviceFunctionStatus dateFormat) {
        DeviceDateFormat = dateFormat;
    }

    public boolean parseData(byte[] data) {
        Log.d("UkOptManager2.37","data.length="+data.length+"\tdata="+ Arrays.toString(data)+"\ndataHex="+ DataConverter.bytes2Hex(data));
        if (data.length >= 4) {
            int earPhone = data[3] & 0x01;
            int bpDetection = (data[3] >> 1) & 0x01;
            int rate = (data[3] >> 2) & 0x01;
            int disturb = (data[3] >> 3) & 0x01;
            int step = (data[3] >> 4) & 0x01;
            int sleep = (data[3] >> 5) & 0x01;
            int weRun = (data[3] >> 6) & 0x01;
            int lightDuration = (data[3] >> 7) & 0x01;

            int notifyReminder = data[2] & 0x01;
            int screenTheme = (data[2] >> 1) & 0x01;
            int turnLight = (data[2] >> 2) & 0x01;
            int multiLanguage = (data[2] >> 3) & 0x01;
            int hourSystem = (data[2] >> 4) & 0x01;
            int unitSystem = (data[2] >> 5) & 0x01;
            int ota = (data[2] >> 6) & 0x01;
            int nfc = (data[2] >> 7) & 0x01;

            int multiSport = data[1] & 0x01;
            int stepWatch = (data[1] >> 1) & 0x01;
            int countDown = (data[1] >> 2) & 0x01;
            int rateReminder = (data[1] >> 3) & 0x01;
            int cameraControl = (data[1] >> 4) & 0x01;
            int findPhone = (data[1] >> 5) & 0x01;
            int findDevice = (data[1] >> 6) & 0x01;
            int lightControl = (data[1] >> 7) & 0x01;

            int musicControl = data[0] & 0x01;
            int volumeControl = (data[0] >> 1) & 0x01;
            int alarm = (data[0] >> 2) & 0x01;
            int longSitReminder = (data[0] >> 3) & 0x01;
            int eventReminder = (data[0] >> 4) & 0x01;
            int autoLock = (data[0] >> 5) & 0x01;
            int appSportRateDetect = (data[0] >> 6) & 0x01;
            int baseSwitch = (data[0] >> 7) & 0x01;

            if (earPhone == 1) {
                EarPhone = DeviceFunctionStatus.SUPPORT;
            } else {
                EarPhone = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (bpDetection == 1) {
                BpDetection = DeviceFunctionStatus.SUPPORT;
            } else {
                BpDetection = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (rate == 1) {
                Rate = DeviceFunctionStatus.SUPPORT;
            } else {
                Rate = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (disturb == 1) {
                Disturb = DeviceFunctionStatus.SUPPORT;
            } else {
                Disturb = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (step == 1) {
                Step = DeviceFunctionStatus.SUPPORT;
            } else {
                Step = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (sleep == 1) {
                Sleep = DeviceFunctionStatus.SUPPORT;
            } else {
                Sleep = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (weRun == 1) {
                WeRun = DeviceFunctionStatus.SUPPORT;
            } else {
                WeRun = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (lightDuration == 1) {
                LightDuration = DeviceFunctionStatus.SUPPORT;
            } else {
                LightDuration = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (notifyReminder == 1) {
                NotifyReminder = DeviceFunctionStatus.SUPPORT;
            } else {
                NotifyReminder = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (screenTheme == 1) {
                ScreenTheme = DeviceFunctionStatus.SUPPORT;
            } else {
                ScreenTheme = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (turnLight == 1) {
                TurnLight = DeviceFunctionStatus.SUPPORT;
            } else {
                TurnLight = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (multiLanguage == 1) {
                MultiLanguage = DeviceFunctionStatus.SUPPORT;
            } else {
                MultiLanguage = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (hourSystem == 1) {
                HourSystem = DeviceFunctionStatus.SUPPORT;
            } else {
                HourSystem = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (unitSystem == 1) {
                UnitSystem = DeviceFunctionStatus.SUPPORT;
            } else {
                UnitSystem = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (ota == 1) {
                OTA = DeviceFunctionStatus.SUPPORT;
            } else {
                OTA = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (nfc == 1) {
                NFC = DeviceFunctionStatus.SUPPORT;
            } else {
                NFC = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (multiSport == 1) {
                MultiSport = DeviceFunctionStatus.SUPPORT;
            } else {
                MultiSport = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (stepWatch == 1) {
                StepWatch = DeviceFunctionStatus.SUPPORT;
            } else {
                StepWatch = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (countDown == 1) {
                CountDown = DeviceFunctionStatus.SUPPORT;
            } else {
                CountDown = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (rateReminder == 1) {
                RateReminder = DeviceFunctionStatus.SUPPORT;
            } else {
                RateReminder = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (cameraControl == 1) {
                CameraControl = DeviceFunctionStatus.SUPPORT;
            } else {
                CameraControl = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (findPhone == 1) {
                FindPhone = DeviceFunctionStatus.SUPPORT;
            } else {
                FindPhone = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (findDevice == 1) {
                FindDevice = DeviceFunctionStatus.SUPPORT;
            } else {
                FindDevice = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (lightControl == 1) {
                LightControl = DeviceFunctionStatus.SUPPORT;
            } else {
                LightControl = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (musicControl == 1) {
                MusicControl = DeviceFunctionStatus.SUPPORT;
            } else {
                MusicControl = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (volumeControl == 1) {
                VolumeControl = DeviceFunctionStatus.SUPPORT;
            } else {
                VolumeControl = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (alarm == 1) {
                Alarm = DeviceFunctionStatus.SUPPORT;
            } else {
                Alarm = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (longSitReminder == 1) {
                LongSitReminder = DeviceFunctionStatus.SUPPORT;
            } else {
                LongSitReminder = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (eventReminder == 1) {
                EventReminder = DeviceFunctionStatus.SUPPORT;
            } else {
                EventReminder = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (autoLock == 1) {
                AutoLock = DeviceFunctionStatus.SUPPORT;
            } else {
                AutoLock = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (appSportRateDetect == 1) {
                AppSportRateDetect = DeviceFunctionStatus.SUPPORT;
            } else {
                AppSportRateDetect = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (baseSwitch == 1) {
                BaseSwitch = DeviceFunctionStatus.SUPPORT;
            } else {
                BaseSwitch = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (data.length >= 8) {
                int todayAdjust = (data[4] >> 7) & 0x01;
                int sleepAdjust = (data[4] >> 6) & 0x01;
                int temperature = (data[4] >> 5) & 0x01;
                int bp2 = (data[4] >> 4) & 0x01;
                int alarm2 = (data[4] >> 3) & 0x01;
                int customUi = (data[4] >> 2) & 0x01;
                int downloadUi = (data[4] >> 1) & 0x01;
                int spo2Measure = (data[4]) & 0x01;

                int modeUpgrade = (data[5] >> 7) & 0x01;
                int sleepQuality2 = (data[5] >> 6) & 0x01;
                int sportRate2 = (data[5] >> 5) & 0x01;
                int rateTempPressure = (data[5] >> 4) & 0x01;
                int spo2Contin = (data[5] >> 3) & 0x01;
                int ecg = (data[5] >> 2) & 0x01;
                int deviceState = (data[5] >> 1) & 0x01;
                int addressBook = (data[5]) & 0x01;

                int rtkHrv = (data[6] >> 7) & 0x01;
                int rtkBp3 = (data[6] >> 6) & 0x01;
                int glu = (data[6] >> 5) & 0x01;
                int hypoxia = (data[6] >> 4) & 0x01;
                int highHrv = (data[6] >> 3) & 0x01;
                int sleepAll = (data[6] >> 2) & 0x01;
                int dateFormat = (data[6] >> 1) & 0x01;
                int hideQT = (data[6]) & 0x01;

                int ecgBelt = (data[7] >> 7) & 0x01;
                int hideHealthFunction = (data[7] >> 6) & 0x01;
                int pressure = (data[7] >> 5) & 0x01;

                if (todayAdjust == 1) {
                    TodayAdjust = DeviceFunctionStatus.SUPPORT;
                } else {
                    TodayAdjust = DeviceFunctionStatus.UN_SUPPORT;
                }

                if (sleepAdjust == 1) {
                    SleepAdjust = DeviceFunctionStatus.SUPPORT;
                } else {
                    SleepAdjust = DeviceFunctionStatus.UN_SUPPORT;
                }

                if (temperature == 1) {
                    Temperature = DeviceFunctionStatus.SUPPORT;
                } else {
                    Temperature = DeviceFunctionStatus.UN_SUPPORT;
                }

                if (bp2 == 1) {
                    Bp2 = DeviceFunctionStatus.SUPPORT;
                } else {
                    Bp2 = DeviceFunctionStatus.UN_SUPPORT;
                }

                if (alarm2 == 1) {
                    Alarm2 = DeviceFunctionStatus.SUPPORT;
                } else {
                    Alarm2 = DeviceFunctionStatus.UN_SUPPORT;
                }

                if (customUi == 1) {
                    CustomUi = DeviceFunctionStatus.SUPPORT;
                } else {
                    CustomUi = DeviceFunctionStatus.UN_SUPPORT;
                }

                if (downloadUi == 1) {
                    DownloadUi = DeviceFunctionStatus.SUPPORT;
                } else {
                    DownloadUi = DeviceFunctionStatus.UN_SUPPORT;
                }

                if (spo2Measure == 1) {
                    Spo2Measure = DeviceFunctionStatus.SUPPORT;
                } else {
                    Spo2Measure = DeviceFunctionStatus.UN_SUPPORT;
                }

                if (modeUpgrade == 1) {
                    ModeUpgrade = DeviceFunctionStatus.SUPPORT;
                } else {
                    ModeUpgrade = DeviceFunctionStatus.UN_SUPPORT;
                }

                if (sleepQuality2 == 1) {
                    SleepQuality2 = DeviceFunctionStatus.SUPPORT;
                } else {
                    SleepQuality2 = DeviceFunctionStatus.UN_SUPPORT;
                }

                if(sportRate2 == 1){
                    SportRate2 = DeviceFunctionStatus.SUPPORT;
                }else{
                    SportRate2 = DeviceFunctionStatus.UN_SUPPORT;
                }

                if(rateTempPressure == 1){
                    RateTempPressure = DeviceFunctionStatus.SUPPORT;
                }else{
                    RateTempPressure = DeviceFunctionStatus.UN_SUPPORT;
                }

                if(spo2Contin == 1){
                    Spo2Continuous = DeviceFunctionStatus.SUPPORT;
                }else{
                    Spo2Continuous = DeviceFunctionStatus.UN_SUPPORT;
                }

                if(ecg == 1){
                    EcgFunction = DeviceFunctionStatus.SUPPORT;
                }else{
                    EcgFunction = DeviceFunctionStatus.UN_SUPPORT;
                }

                if(deviceState == 1){
                    DeviceStateSync = DeviceFunctionStatus.SUPPORT;
                }else{
                    DeviceStateSync = DeviceFunctionStatus.UN_SUPPORT;
                }

                if(addressBook == 1){
                    AddressBook = DeviceFunctionStatus.SUPPORT;
                }else{
                    AddressBook = DeviceFunctionStatus.UN_SUPPORT;
                }

                if(rtkHrv == 1){
                    RtkHrv = DeviceFunctionStatus.SUPPORT;
                }else{
                    RtkHrv = DeviceFunctionStatus.UN_SUPPORT;
                }

                if(rtkBp3 == 1){
                    RtkBp3 = DeviceFunctionStatus.SUPPORT;
                }else{
                    RtkBp3 = DeviceFunctionStatus.UN_SUPPORT;
                }

                if(glu == 1){
                    GLU = DeviceFunctionStatus.SUPPORT;
                }else{
                    GLU = DeviceFunctionStatus.UN_SUPPORT;
                }

                Hypoxia = hypoxia == 1 ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT;
                HighHrv = highHrv == 1 ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT;
                SleepAll = sleepAll == 1 ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT;
                DeviceDateFormat = dateFormat == 1 ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT;
                hideQTAndHrv = hideQT == 1 ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT;
                EcgBelt = ecgBelt == 1 ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT;
                HideHealthFunction = hideHealthFunction == 1 ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT;
                Pressure = pressure == 1 ? DeviceFunctionStatus.SUPPORT : DeviceFunctionStatus.UN_SUPPORT;
            }
        }
        return true;
    }

    public DeviceFunctionStatus getPrivateBloodPressure() {
        return privateBloodPressure == null ? DeviceFunctionStatus.UN_SUPPORT : privateBloodPressure;
    }

    public void setPrivateBloodPressure(DeviceFunctionStatus privateBloodPressure) {
        this.privateBloodPressure = privateBloodPressure;
    }

    public DeviceFunctionStatus getSOSNumber() {
        return sosNumber == null ? DeviceFunctionStatus.UN_SUPPORT : sosNumber;
    }

    public void setSOSNumber(DeviceFunctionStatus sosNumber) {
        this.sosNumber = sosNumber;
    }

    public DeviceFunctionStatus getTemperatureReminder() {
        return temperatureReminder;
    }

    public void setTemperatureReminder(DeviceFunctionStatus temperatureReminder) {
        this.temperatureReminder = temperatureReminder;
    }

    public DeviceFunctionStatus getDrinkWaterReminder() {
        return drinkWaterReminder;
    }

    public void setDrinkWaterReminder(DeviceFunctionStatus drinkWaterReminder) {
        this.drinkWaterReminder = drinkWaterReminder;
    }

    public DeviceFunctionStatus getMedicationReminder() {
        return medicationReminder;
    }

    public void setMedicationReminder(DeviceFunctionStatus medicationReminder) {
        this.medicationReminder = medicationReminder;
    }

    public void setPulse(DeviceFunctionStatus pulse) {
        this.pulse = pulse;
    }

    public DeviceFunctionStatus getPulse() {
        return pulse == null ? DeviceFunctionStatus.UN_SUPPORT : pulse;
    }

    public DeviceFunctionStatus getSleepHelp() {
        return sleepHelp == null ? DeviceFunctionStatus.UN_SUPPORT : sleepHelp;
    }

    public void setSleepHelp(DeviceFunctionStatus sleepHelp) {
        this.sleepHelp = sleepHelp;
    }

    public DeviceFunctionStatus getSauna() {
        return sauna == null ? DeviceFunctionStatus.UN_SUPPORT : sauna;
    }

    public void setSauna(DeviceFunctionStatus sauna) {
        this.sauna = sauna;
    }

    public DeviceFunctionStatus getFemaleHealth() {
        return femaleHealth == null ? DeviceFunctionStatus.UN_SUPPORT : femaleHealth;
    }

    public void setFemaleHealth(DeviceFunctionStatus femaleHealth) {
        this.femaleHealth = femaleHealth;
    }

    public DeviceFunctionStatus getWeather() {
        return weather == null ? DeviceFunctionStatus.UN_SUPPORT : weather;
    }

    public void setWeather(DeviceFunctionStatus weather) {
        this.weather = weather;
    }

    public DeviceFunctionStatus getWearingTime() {
        return wearingTime == null ? DeviceFunctionStatus.UN_SUPPORT : wearingTime;
    }

    public void setWearingTime(DeviceFunctionStatus wearingTime) {
        this.wearingTime = wearingTime;
    }

    public DeviceFunctionStatus getBodyFat() {
        return bodyFat;
    }

    public void setBodyFat(DeviceFunctionStatus bodyFat) {
        this.bodyFat = bodyFat;
    }

    public DeviceFunctionStatus getPhysicalExam() {
        return physicalExam;
    }

    public void setPhysicalExam(DeviceFunctionStatus physicalExam) {
        this.physicalExam = physicalExam;
    }

    public DeviceFunctionStatus getUltraviolet() {
        return ultraviolet;
    }

    public void setUltraviolet(DeviceFunctionStatus ultraviolet) {
        this.ultraviolet = ultraviolet;
    }

    public DeviceFunctionStatus getUricAcid() {
        return uricAcid == null ? DeviceFunctionStatus.UN_SUPPORT : uricAcid;
    }

    public void setUricAcid(DeviceFunctionStatus uricAcid) {
        this.uricAcid = uricAcid;
    }

    public DeviceFunctionStatus getBloodFat() {
        return bloodFat == null ? DeviceFunctionStatus.UN_SUPPORT : bloodFat;
    }

    public void setBloodFat(DeviceFunctionStatus bloodFat) {
        this.bloodFat = bloodFat;
    }

    public DeviceFunctionStatus getBloodSugarCycle() {
        return bloodSugarCycle;
    }

    public void setBloodSugarCycle(DeviceFunctionStatus bloodSugarCycle) {
        this.bloodSugarCycle = bloodSugarCycle;
    }

    public DeviceFunctionStatus getUricAcidContinuousMonitoring() {
        return uricAcidContinuousMonitoring;
    }

    public void setUricAcidContinuousMonitoring(DeviceFunctionStatus uricAcidContinuousMonitoring) {
        this.uricAcidContinuousMonitoring = uricAcidContinuousMonitoring;
    }

    public DeviceFunctionStatus getBloodFatContinuousMonitoring() {
        return bloodFatContinuousMonitoring;
    }

    public void setBloodFatContinuousMonitoring(DeviceFunctionStatus bloodFatContinuousMonitoring) {
        this.bloodFatContinuousMonitoring = bloodFatContinuousMonitoring;
    }

    public DeviceFunctionStatus getHideQTAndHrv() {
        return hideQTAndHrv;
    }

    public DeviceFunctionStatus getEcgBelt() {
        return EcgBelt;
    }

    public DeviceFunctionStatus getHideHealthFunction() {
        return HideHealthFunction;
    }

    public DeviceFunctionStatus getPressure() {
        return Pressure;
    }

    @Override
    public String toString() {
        return "ApplicationLayerFunctionPacket{" +
                "EarPhone=" + EarPhone +
                ", BpDetection=" + BpDetection +
                ", Rate=" + Rate +
                ", Disturb=" + Disturb +
                ", Step=" + Step +
                ", Sleep=" + Sleep +
                ", WeRun=" + WeRun +
                ", LightDuration=" + LightDuration +
                ", NotifyReminder=" + NotifyReminder +
                ", ScreenTheme=" + ScreenTheme +
                ", TurnLight=" + TurnLight +
                ", MultiLanguage=" + MultiLanguage +
                ", HourSystem=" + HourSystem +
                ", UnitSystem=" + UnitSystem +
                ", OTA=" + OTA +
                ", NFC=" + NFC +
                ", MultiSport=" + MultiSport +
                ", StepWatch=" + StepWatch +
                ", CountDown=" + CountDown +
                ", RateReminder=" + RateReminder +
                ", CameraControl=" + CameraControl +
                ", FindPhone=" + FindPhone +
                ", FindDevice=" + FindDevice +
                ", LightControl=" + LightControl +
                ", MusicControl=" + MusicControl +
                ", VolumeControl=" + VolumeControl +
                ", Alarm=" + Alarm +
                ", LongSitReminder=" + LongSitReminder +
                ", EventReminder=" + EventReminder +
                ", AutoLock=" + AutoLock +
                ", AppSportRateDetect=" + AppSportRateDetect +
                ", BaseSwitch=" + BaseSwitch +
                ", TodayAdjust=" + TodayAdjust +
                ", SleepAdjust=" + SleepAdjust +
                ", Temperature=" + Temperature +
                ", Bp2=" + Bp2 +
                ", Alarm2=" + Alarm2 +
                ", CustomUi=" + CustomUi +
                ", DownloadUi=" + DownloadUi +
                ", Spo2Measure=" + Spo2Measure +
                ", ModeUpgrade=" + ModeUpgrade +
                ", SleepQuality2=" + SleepQuality2 +
                ", SportRate2=" + SportRate2 +
                ", RateTempPressure=" + RateTempPressure +
                ", Spo2Continuous=" + Spo2Continuous +
                ", EcgFunction=" + EcgFunction +
                ", DeviceStateSync=" + DeviceStateSync +
                ", AddressBook=" + AddressBook +
                ", RtkHrv=" + RtkHrv +
                ", RtkBp3=" + RtkBp3 +
                ", GLU=" + GLU +
                ", Hypoxia=" + Hypoxia +
                ", HighHrv=" + HighHrv +
                ", SleepAll=" + SleepAll +
                ", DeviceDateFormat=" + DeviceDateFormat +
                ", privateBloodPressure=" + privateBloodPressure +
                ", sosNumber=" + sosNumber +
                ", temperatureReminder=" + temperatureReminder +
                ", drinkWaterReminder=" + drinkWaterReminder +
                ", medicationReminder=" + medicationReminder +
                ", pulse=" + pulse +
                ", sauna=" + sauna +
                ", femaleHealth=" + femaleHealth +
                ", weather=" + weather +
                ", wearingTime=" + wearingTime +
                ", bodyFat=" + bodyFat +
                ", physicalExam=" + physicalExam +
                ", ultraviolet=" + ultraviolet +
                ", uricAcid=" + uricAcid +
                ", bloodFat=" + bloodFat +
                ", bloodSugarCycle=" + bloodSugarCycle +
                ", uricAcidContinuousMonitoring=" + uricAcidContinuousMonitoring +
                ", bloodFatContinuousMonitoring=" + bloodFatContinuousMonitoring +
                ", hideQTAndHrv=" + hideQTAndHrv +
                ", sleepHelp=" + sleepHelp +
                ", ecgBelt=" + EcgBelt +
                ", hideHealthFunction=" + HideHealthFunction +
                ", pressure=" + Pressure +
                '}';
    }
}
