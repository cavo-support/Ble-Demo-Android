package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.v2.entity.JWFemaleHealthInfo;

public class ApplicationLayerFemaleHealthPacket {

    public boolean isOpen;

    public int mode;

    /**
     * unit day
     */
    public int periodTime;

    /**
     * unit day
     */
    public int menstrualPeriodTime;

    public int year;

    public int month;

    public int day;


    public ApplicationLayerFemaleHealthPacket(JWFemaleHealthInfo healthInfo) {
        this.isOpen = healthInfo.enable;
        this.mode = healthInfo.mode;
        this.periodTime = healthInfo.periodTime;
        this.menstrualPeriodTime = healthInfo.menstrualPeriodTime;
        this.year = healthInfo.year;
        this.month = healthInfo.month;
        this.day = healthInfo.day;
    }



    public byte[] getPacket(){
        byte[] data = new byte[8];
        data[0] = (byte) (isOpen ? 0x01 : 0x00);
        data[1] = (byte) (mode & 0xFF);
        data[2] = (byte) (periodTime & 0xFF);
        data[3] = (byte) (menstrualPeriodTime & 0xFF);
        data[4] = (byte) ((year >> 8) & 0xFF);
        data[5] = (byte) (year & 0xFF);
        data[6] = (byte) (month & 0xFF);
        data[7] = (byte) (day & 0xFF);
        return data;
    }

}
