package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.model.enums.DeviceLanguage;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUltravioletInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWearingTimeInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWDefaultFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWHealthRiskAssessmentInfo;

import java.util.List;

public class ApplicationLayerCallback {

    /**
     * 新增回调，与 onConnectionStateChange 同时触发
     * 连接状态变化
     *
     * @param isConnect true 已连接
     * @param code      错误码
     * @param msg       错误信息
     */
    public void onConnectionStateChange(final boolean isConnect, final int code, final String msg) {
    }

    /**
     * Callback indicate when gatt connected/disconnected to/from a remote device
     *
     * @param status   status
     * @param newState the new connection State
     */
    public void onConnectionStateChange(final boolean status, final boolean newState) {
    }

    /**
     * Callback indicate remote enter OTA mode ok or not.
     *
     * @param status
     * @param errorcode the error code
     */
    public void onUpdateCmdRequestEnterOtaMode(final byte status, final byte errorcode) {
    }

    /**
     * Callback indicate remote alarm list.
     *
     * @param alarms
     */
    public void onSettingCmdRequestAlarmList(final ApplicationLayerAlarmsPacket alarms) {
    }

    /**
     * Callback indicate remote alarm2 list.
     *
     * @param alarm2
     */
    public void onAlarm2(final ApplicationLayerAlarm2Packet alarm2) {
    }

    public void onMedicationReminderList(ApplicationLayerMedicationReminderListPacket packet) {
    }

    /**
     * Callback indicate remote other notify switch setting.
     *
     * @param applicationLayerNotifyPacket the other notify switch setting
     */
    public void onSettingCmdRequestNotifySwitch(ApplicationLayerNotifyPacket applicationLayerNotifyPacket) {
    }

    /**
     * Callback indicate remote long sit mode setting.
     *
     * @param packet the long sit setting
     */
    public void onSettingCmdRequestLongSit(ApplicationLayerSitPacket packet) {
    }

    /**
     * Callback indicate remote Turn Over Wristsetting.
     *
     * @param mode the long sit mode setting
     */
    public void onTurnOverWristSettingReceive(final boolean mode) {
    }

    /**
     * Callback indicate remote bond response.
     *
     * @param status
     */
    public void onBondCmdRequestBond(final byte status) {
    }

    /**
     * Callback indicate remote login response.
     *
     * @param status
     */
    public void onBondCmdRequestLogin(final byte status) {
    }

    public void onBondConfirmRequest(final byte status){

    }

    /**
     * Callback chip type
     * @param type 0-C type;1-D type
     */
    public void onBondReqChipType(int type){

    }

    /**
     * Callback indicate end call.
     */
    public void onEndCallReceived() {
    }

    /**
     * Callback indicate accept call.
     */
    public void onAcceptCallReceived() {
    }

    /**
     * Callback indicate remote send sport data.
     *
     * @param step
     */
    public void onSportDataCmdStepData(final List<ApplicationLayerStepPacket> packetList) {
    }


    /**
     * Callback indicate remote send sleep data.
     *
     * @param packetList sleep data packet
     */
    public void onSportDataCmdSleepData(final List<ApplicationLayerSleepPacket> packetList) {
    }

    /**
     * Callback indicate remote send sport data.
     *
     * @param packetList
     */
    public void onSportDataCmdSportData(ApplicationLayerSportPacket packet) {
    }

    /**
     * Callback indicate remote have more data to send.
     */
    public void onSportDataCmdMoreData() {
    }

    /**
     * Callback indicate remote send sleep set data.
     *
     * @param sleep sleep data packet
     */
    public void onSportDataCmdSleepSetData(final ApplicationLayerSleepPacket sleep) {
    }

    /**
     * Callback indicate history sync begin.
     */
    public void onSportDataCmdHistorySyncBegin(ApplicationLayerBeginPacket packet) {

    }

    /**
     * Callback indicate history sync end.
     */
    public void onSportDataCmdHistorySyncEnd(ApplicationLayerTodaySumSportPacket packet) {
    }

    /**
     * Callback indicate hrp data received.
     */
    public void onSportDataCmdHrpData(ApplicationLayerHrpPacket packet) {
    }

    /**
     * Callback indicate hrp data received.
     */
    public void onSportDataCmdBpData(List<ApplicationLayerBpPacket> packetList) {
    }

    /**
     * Callback indicate device cancel single hrp read.
     */
    public void onSportDataCmdDeviceCancelSingleHrpRead() {
    }

    /**
     * Callback indicate device cancel single bp read.
     */
    public void onSportDataCmdDeviceCancelSingleBpRead() {
    }

    /**
     * Callback indicate device current continue param.
     */
    public void onSportDataCmdHrpContinueParamRsp(boolean enable, int interval) {
    }

    /**
     * Callback indicate take a photo.
     */
    public void onTakePhotoRsp() {
    }

    /**
     * Callback indicate history sync end.
     *
     * @param sensor sensor data packet
     */
    public void onFACCmdSensorData(final ApplicationLayerFacSensorPacket sensor) {
    }

    /**
     * Callback indicate request read default function
     */
    public void onFacCmdDefaultFunction(JWDefaultFunctionInfo defaultFunctionInfo) {

    }

    /**
     * Callback indicate request today sleep
     *
     * @param packet
     */
    public void onFacCmdTodaySleep(ApplicationLayerTodaySleepPacket packet) {

    }

    /**
     * Callback indicate request today sleep
     *
     * @param data
     */
    public void onFacCmdHistoryIndex(byte[] data) {

    }

    /**
     * Callback indicate log sync start.
     *
     * @param logLength the log total length
     */
    public void onLogCmdStart(final long logLength) {
    }

    /**
     * Callback indicate log sync end.
     */
    public void onLogCmdEnd() {
    }

    /**
     * Callback indicate log data.
     *
     * @param packet receive log data
     */
    public void onLogCmdRsp(final ApplicationLayerLogResponsePacket packet) {
    }

    /**
     * Callback indicate a command send.
     *
     * @param status  the send result.
     * @param command the send data's command id
     * @param key     the send data's key id
     */
    public void onCommandSend(final boolean status, byte command, byte key) {
    }

    /**
     * Callback indicating name receive.
     *
     * @param data the receive data
     */
    public void onNameReceive(final String data) {
    }

    /**
     * Callback indicating device support sport function receiver
     *
     * @param applicationLayerMultiSportPacket
     */
    public void onSportFunction(final ApplicationLayerMultiSportPacket applicationLayerMultiSportPacket) {
    }

    /**
     * Callback indicating device support function receiver
     */
    public void onDeviceFunction(final ApplicationLayerFunctionPacket applicationLayerFunctionPacket) {

    }

    /**
     * callback indicating request hour model
     *
     * @param is24Model is 24 model
     */
    public void onHour(boolean is24Model) {

    }

    /**
     * callabck indicating request unit model
     *
     * @param isMetricSystem is metric model
     */
    public void onUnit(boolean isMetricSystem) {

    }

    /**
     * callback indicating request disturb setting
     *
     * @param packet
     */
    public void onDisturb(ApplicationLayerDisturbPacket packet) {

    }


    /**
     * callback indicating request screen duration setting
     * 亮屏时长返回
     * @param currentDuration 当前时长，单位 秒, current duration, unit seconds
     * @param defaultDuration 默认时长
     */
    public void onScreenLightDuration(int currentDuration, int defaultDuration) {
    }

    /**
     * callback indicating request device language
     *
     * @param language
     */
    public void onLanguage(DeviceLanguage language) {
    }

    /**
     * callback indicating request ear address
     *
     * @param packet
     */
    public void onEarMac(ApplicationLayerEarMacPacket packet) {
    }

    /**
     * callback indicating request ear connect status
     *
     * @param status
     */
    public void onEarConnectStatus(int status) {

    }

    /**
     * @param packet
     */
    public void onEarStatus(ApplicationLayerEarStatusPacket packet) {

    }


    /**
     * callback indicating request home pager index
     *
     * @param packet
     */
    public void onHomePager(ApplicationLayerScreenStylePacket packet) {

    }

    /**
     * callback indicating request classic bt status
     *
     * @param status
     */
    public void onChargeStatus(int status) {

    }

    /**
     * @param packet
     */
    public void onDeviceInfo(ApplicationLayerDeviceInfoPacket packet) {

    }

    public void onDeviceStatus(ApplicationLayerDeviceStatusPacket packet) {

    }

    public void onSpo2DataReceive(List<ApplicationLayerSpo2Packet> packetList) {

    }

    public void onHrpParams(ApplicationLayerHrpParamsPacket paramsPacket) {

    }

    public void onScreenLight(int lightPercent) {

    }

    public void onSwitch(ApplicationLayerSwitchPacket switchPacket) {

    }

    public void onFindPhone() {

    }

    public void onTimerInfo(ApplicationLayerTimerPacket packet) {

    }

    public void onSportRateStatus(int status) {

    }

    public void onRateList(ApplicationLayerRateListPacket packet) {

    }

    public void onTodayAdjust(ApplicationLayerTodayAdjustPacket packet) {

    }

    public void onLangcoTranslate(int model) {

    }

    public void onTemperatureMeasureStatus(int status) {

    }

    public void onSpo2MeasureStatus(int status) {

    }

    public void onTemperatureControl(ApplicationLayerTemperatureControlPacket packet) {

    }

    public void onBp2Control(ApplicationLayerBp2ControlPacket packet) {

    }

    public void onSleepAllSwitch(boolean enable) {

    }

    public void onHypoxiaSwitch(boolean enable) {

    }

    public void onHighHeartRateSwitch(ApplicationLayerHighHeartRatePacket packet) {

    }

    public void onDeviceDateFormat(int format) {

    }

    public void onMusicPlay() {

    }

    public void onMusicPause() {

    }

    public void onMusicToggle() {

    }

    public void onMusicPre() {

    }

    public void onMusicNext() {

    }

    public void onMusicVolumeUp() {

    }

    public void onMusicVolumeDown() {

    }

    public void onSilenceUpgradeModel(int model) {

    }

    public void onCustomUiSetting(ApplicationLayerCustomUiPacket packet) {

    }

    public void onSilenceOtaStatus(int status) {

    }

    public void onCustomNotify(ApplicationLayerCustomNotifyPacket packet) {

    }

    public void onCusStatus(int status) {

    }

    public void onFindPhone(int status){

    }

    /**
     * 连续血氧参数返回
     * @param enable true 连续采集
     * @param interval  默认间隔10分钟测一次
     */
    public void onSpo2Continuous(boolean enable,int interval){

    }

    /**
     * 心电数据采集状态
     * @param status 1.采集开始-2.采集结束-3.采集中断
     */
    public void onEcgTestStatus(int status){

    }

    /**
     * 测试心电数据返回
     * @param ecgPacket
     */
    public void onEcgTestData(ApplicationLayerECGPacket ecgPacket){

    }

    /**
     * 返回设备正在运行功能列表
     * @param readHealthPacket
     */
    public void onReadHealth(ApplicationLayerReadHealthPacket readHealthPacket){

    }

    /**
     * 设置设备通讯录返回
     */
    public void onAddressBookToDevice(int state){

    }

    /**
     * 设置设备 SOS 通讯录返回
     */
    public void onSOSNumberToDevice(int state){

    }

    public void onRtkHrvData(List<ApplicationLayerRtkHrvPacket> packetList){

    }

    /**
     * Audio switch back
     * 音频开关返回
     * @param state
     */
    public void onAudioSwitch(int state){

    }

    public void onDeviceEcgData(ApplicationLayerEcgToDevicePacket packet){

    }

    public void onDeviceEcgBeltData(ApplicationLayerEcgBeltToDevicePacket packet){

    }

    public void onSyncSwitch(ApplicationLayerSyncSwitchPacket packet){

    }

    public void onBp3Continuous(ApplicationLayerBp3ContinuousPacket bp3ContinuousPacket){

    }

    public void onGluContinuous(boolean enable, int interval){

    }

    public void onGluDataRsp(List<ApplicationLayerGLUPacket> packetList){

    }

    public void onTestGluDis(){

    }

    public void onPrivateGlu(int height,int low){

    }

    public void onUnitRes(ApplicationLayerUnitPacket unitPacket){

    }

    public void onMulPrivateBp(ApplicationLayerMulPrivateBpPacket packet) {

    }

    public void onMulSupportSOSNumber() {

    }

    public void onMulDrinkWaterReminder(ApplicationLayerMulDrinkWaterReminderPacket packet) {

    }

    public void onMulTemperatureReminder(ApplicationLayerMulTemperatureReminderPacket packet) {

    }

    public void onMulSupportMedicationReminder() {

    }

    public void onSupportPulse() {

    }

    public void onSetPulseRsp(boolean isSuccess) {

    }

    public void onSupportSleepHelp() {

    }

    public void onSetSleepHelpRsp(int status) {

    }

    public void onSyncPulseDataRsp(ApplicationLayerPulseDataPacket packet) {

    }

    public void onSyncPulseStatusRsp(int status, int count) {

    }

    public void onPulseFinishedRsp(int duration) {

    }

    public void onSupportSauna() {

    }

    public void onSyncSaunaDataRsp(ApplicationLayerSaunaDataPacket packet) {

    }

    public void onSyncSaunaStatusRsp(int status, int count) {

    }

    public void onSyncHRMovementDataRsp(ApplicationLayerHRMovementDataPacket packet) {

    }

    public void onSupportFemaleHealth() {

    }

    public void onSupportWeather() {

    }

    public void onSupportWearingTime() {

    }

    public void onSupportBodyFat() {

    }

    public void onSupportPhysicalExam() {

    }

    public void onSupportUltraviolet() {

    }

    public void onSupportUricAcid(ApplicationLayerMulUricAcidPacket packet) {

    }

    public void onSupportBloodFat(ApplicationLayerMulBloodFatPacket packet) {

    }

    public void onSupportBloodSugarCycle(ApplicationLayerMulBloodSugarCyclePacket packet) {

    }

    public void onSupportPrivateUricAcid(ApplicationLayerMulPrivateUricAcidPacket packet) {

    }

    public void onSupportPrivateBloodFat(ApplicationLayerMulPrivateBloodFatPacket packet) {

    }

    public void onSetFemaleHealthSuccess() {

    }

    public void onSetWeatherSuccess() {

    }

    public void onWearingTimeDataRsp(List<JWWearingTimeInfo> packetList){

    }

    public void onUricAcidDataRsp(List<JWUricAcidInfo> packetList) {

    }

    public void onBloodFatDataRsp(List<JWBloodFatInfo> packetList) {

    }

    public void onBloodSugarCycleDataRsp(List<JWBloodSugarCycleInfo> packetList) {

    }

    public void onUricAcidContinuousMonitoringDataRsp(List<JWUricAcidContinuousMonitoringInfo> packetList) {

    }

    public void onBloodFatContinuousMonitoringDataRsp(List<JWBloodFatContinuousMonitoringInfo> packetList) {

    }

    public void onDeviceMeasureStatusUpdated(int status) {

    }

    public void onBodyFatDataRsp(JWBodyFatInfo bodyFat) {

    }

    public void onPhysicalExamDataRsp(JWPhysicalExamInfo physicalExam) {

    }

    public void onReadHRVRmssdConfigRsp(boolean enable, int interval) {

    }

    public void onHRVRmssdDataRsp(List<JWHRVRmssdInfo> dataList) {

    }

    public void onUltravioletDataRsp(List<JWUltravioletInfo> dataList) {

    }

    public void onPressureDataRsp(List<JWPressureInfo> dataList) {

    }

    public void onReadHealthRiskAssessmentRsp(JWHealthRiskAssessmentInfo info) {

    }

}
