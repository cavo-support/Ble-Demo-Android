package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerBp2ControlPacket {

    private boolean open;

    /**
     * Packet Length
     */
    public final static int PACKAGE_HEADER_LENGTH = 4;

    public ApplicationLayerBp2ControlPacket() {
    }

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }

    public byte[] getPacket() {
        byte[] data = new byte[PACKAGE_HEADER_LENGTH];
        data[0] = open ? (byte) 0x80 : (byte) 0x00;
        return data;
    }

    public boolean parseData(byte[] data) {
        open = (((data[0] >> 7) & 0x01) == 0x01) ? true : false;
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerBp2ControlPacket{" +
                "open=" + open +
                '}';
    }
}
