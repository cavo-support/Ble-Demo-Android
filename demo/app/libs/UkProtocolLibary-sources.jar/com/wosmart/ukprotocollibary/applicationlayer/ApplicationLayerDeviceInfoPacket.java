package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerDeviceInfoPacket {

    /**
     * device number
     * use to different device software
     */
    private int deviceNumber;

    /**
     * device name
     */
    private String deviceName;

    /**
     * device version code example 40043
     */
    private int versionCode;

    /**
     * device version name example 4.4.3
     */
    private String versionName;

    /**
     * font version code
     */
    private int fontVersionCode;

    /**
     * font version name
     */
    private String fontVersionName;

    /**
     * 平台
     */
    private int platform;

    /**
     * 设备蓝牙地址
     */
    private String deviceMac;

    /**
     * Packet Length
     */
    private final static int DEVICE_HEADER_LENGTH = 5;

    public ApplicationLayerDeviceInfoPacket() {
    }

    public int getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public int getVersionCode() {
        return versionCode;
    }

    public String getVersionName() {
        return versionName;
    }

    public int getFontVersionCode() {
        return fontVersionCode;
    }

    public String getFontVersionName() {
        return fontVersionName;
    }


    public int getPlatform() {
        return platform;
    }

    public String getDeviceMac() {
        return deviceMac;
    }

    public boolean parseData(byte[] data) {
        if (data.length >= DEVICE_HEADER_LENGTH) {
            if (data.length >= 19) {
                deviceNumber = ((data[0] & 0xff) << 8) | (data[1] & 0xff);
                int buildNum = (data[7] & 0xF8) >> 3;
                int reversion = ((data[7] & 0x07) << 12) | (data[8] << 4) | ((data[9] & 0xF0) >> 4);
                int minorVersion = ((data[9] & 0x0F) << 4) | ((data[10] & 0xF0) >> 4);
                int majorVersion = data[10] & 0x0F;

                versionCode = minorVersion * 10000 + reversion * 100 + buildNum;
                versionName = majorVersion + "." + minorVersion + "." + reversion + "." + buildNum;
//                int mode11 = data[11] & 0x0F;
//                int mode12 = data[12] & 0x0F;
//                int mode13 = data[13] & 0x0F;
//                int mode14 = data[14] & 0x0F;
//
//                displayVersionCode = mode11 * 1000000 + mode12 * 10000 + mode13 * 100 + mode14;
//                displayVersionName = mode11 + "." + mode12 + "." + mode13 + "." + mode14;

                int mode31 = data[15] & 0x0F;
                int mode32 = data[16] & 0x0F;
                int mode33 = data[17] & 0x0F;
                int mode34 = data[18] & 0x0F;
                fontVersionCode = mode31 * 1000000 + mode32 * 10000 + mode33 * 100 + mode34;
                fontVersionName = mode31 + "." + mode32 + "." + mode33 + "." + mode34;

                if (data.length >= 27) {
                    platform = ((data[19] & 0xff) << 8) | (data[20] & 0xff);

                    byte[] subData = new byte[6];
                    System.arraycopy(data, 21, subData, 0, 6);

                    try {
                        deviceMac = new String(subData, "UTF-8");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }

            } else if (data.length >= 11) {
                deviceNumber = ((data[0] & 0xff) << 8) | (data[1] & 0xff);
                int buildNum = (data[7] & 0xF8) >> 3;
                int reversion = ((data[7] & 0x07) << 12) | (data[8] << 4) | ((data[9] & 0xF0) >> 4);
                int minorVersion = ((data[9] & 0x0F) << 4) | ((data[10] & 0xF0) >> 4);
                int majorVersion = data[10] & 0x0F;

                versionCode = minorVersion * 10000 + reversion * 100 + buildNum;
                versionName = majorVersion + "." + minorVersion + "." + reversion + "." + buildNum;
            } else {
                deviceNumber = ((data[0] & 0xff) << 8) | (data[1] & 0xff);
                int majorVersion = data[2] & 0xff;
                int minorVersion = data[3] & 0xff;
                int reversion = data[4] & 0xff;
                versionCode = majorVersion * 10000 + minorVersion * 100 + reversion;
                versionName = majorVersion + "." + minorVersion + "." + reversion;

                int protocolVersion = 0;
                if (data.length >= DEVICE_HEADER_LENGTH + 2) {
                    protocolVersion = ((data[5] & 0xff) << 8) | (data[6] & 0xff);
                }
            }
        }
        return true;
    }


    @Override
    public String toString() {
        return "ApplicationLayerDeviceInfoPacket{" +
                "deviceNumber=" + deviceNumber +
                ", deviceName='" + deviceName + '\'' +
                ", versionCode=" + versionCode +
                ", versionName='" + versionName + '\'' +
                ", fontVersionCode=" + fontVersionCode +
                ", fontVersionName='" + fontVersionName + '\'' +
                ", platform=" + platform +
                ", deviceMac='" + deviceMac + '\'' +
                '}';
    }
}
