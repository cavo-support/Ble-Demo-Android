package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.util.StringByteTrans;

public class ApplicationLayerEarStatusPacket {

    /**
     * ear paired flah
     * 耳机成功配对过标志
     * 0 not pair success
     * 没有成功配对过
     * 1 paired success
     * 成功配对过
     */
    private int bindState;

    /**
     * earphone current pair status
     * 耳机设备当前状态
     * 0 关闭 closed
     * 1 配对中 pairing
     * 2 准备就绪 stand by
     * 3 已连接 paired
     * 4 耳机被手机连接中 connected
     */
    private int pairState;

    private final static int CLASSIC_HEADER_LENGTH = 2;

    public ApplicationLayerEarStatusPacket() {

    }


    public boolean parseData(byte[] data) {
        if (data.length < CLASSIC_HEADER_LENGTH) {
            return false;
        }
        byte[] mac = new byte[2];
        this.bindState = data[0] & 0xff;
        this.pairState = data[1] & 0xff;
        return true;
    }

    public int getBindState() {
        return bindState;
    }

    public void setBindState(int bindState) {
        this.bindState = bindState;
    }

    public int getPairState() {
        return pairState;
    }

    public void setPairState(int pairState) {
        this.pairState = pairState;
    }

    @Override
    public String toString() {
        return "ApplicationLayerEarMacPacket{" +
                ", bindState=" + bindState +
                ", pairState=" + pairState +
                '}';
    }
}
