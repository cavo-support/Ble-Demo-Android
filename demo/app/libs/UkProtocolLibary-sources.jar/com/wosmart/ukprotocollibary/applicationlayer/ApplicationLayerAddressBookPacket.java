package com.wosmart.ukprotocollibary.applicationlayer;

import android.text.TextUtils;

import com.wosmart.ukprotocollibary.util.SDKLogger;

import java.io.UnsupportedEncodingException;

public class ApplicationLayerAddressBookPacket {

    /**
     * 0：开始发送（要发送的通讯录数据条数）
     * 1：发送结束（要发送的通讯录数据条数）
     * 2：开始发送数据（逐条发送）
     */
    private int sendState;
    /**
     * 需要发送的通讯录数据条数
     * 2bytes
     */
    private int addressLen;
    private int nameLen;
    private String addressName;
    private int phoneLen;
    private String addressPhone;

    public ApplicationLayerAddressBookPacket() {
    }


    public int getAddressLen() {
        return addressLen;
    }

    public void setAddressLen(int addressLen) {
        this.addressLen = addressLen;
    }

    public int getSendState() {
        return sendState;
    }

    public void setSendState(int sendState) {
        this.sendState = sendState;
    }

    public int getNameLen() {
        return nameLen;
    }

    public void setNameLen(int nameLen) {
        this.nameLen = nameLen;
    }

    public String getAddressName() {
        return addressName;
    }

    public void setAddressName(String addressName) {
        this.addressName = addressName;
    }

    public int getPhoneLen() {
        return phoneLen;
    }

    public void setPhoneLen(int phoneLen) {
        this.phoneLen = phoneLen;
    }

    public String getAddressPhone() {
        return addressPhone;
    }

    public void setAddressPhone(String addressPhone) {
        this.addressPhone = addressPhone;
    }

    public byte[] getPacket() {
        byte[] data = new byte[0];
        if (sendState == 0) {
            data = new byte[3];
            data[0] = 0x00;
            if (addressLen > 0) {
                data[1] = (byte) ((addressLen >> 8) & 0xff);
                data[2] = (byte) (addressLen & 0xff);
            } else {
                data[1] = 0x00;
                data[2] = 0x00;
            }
        } else if (sendState == 1) {
            data = new byte[3];
            data[0] = 0x01;
            if (addressLen > 0) {
                data[1] = (byte) ((addressLen >> 8) & 0xff);
                data[2] = (byte) (addressLen & 0xff);
            } else {
                data[1] = 0x00;
                data[2] = 0x00;
            }
        } else if (sendState == 2) {
            nameLen = 0;
            phoneLen = 0;
            byte[] nameData = null;
//            byte[] nameDataFormat = null;
            if (!TextUtils.isEmpty(addressName.trim())) {
                try {
                    nameData = addressName.getBytes("UTF-8");
                    nameLen = nameData.length;
//                    if(nameLen > 15){
//                        nameDataFormat = new byte[15];
//                        for (int i = 0; i < nameData.length; i++) {
//                            if(i < 15){
//                                nameDataFormat[i] = nameData[i];
//                            }
//                        }
//                    }else{
//                        nameDataFormat = new byte[nameData.length];
//                        for (int i = 0; i < nameData.length; i++) {
//                            nameDataFormat[i] = nameData[i];
//                        }
//                    }
//                    nameLen = nameDataFormat.length;
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }else{
                nameData = new byte[0];
            }
            byte[] phoneData = null;
//            byte[] phoneDataFormat = null;
            if (!TextUtils.isEmpty(addressPhone.trim())) {
                try {
                    phoneData = addressPhone.getBytes("UTF-8");
                    phoneLen = phoneData.length;
//                    if(phoneLen > 19){
//                        phoneDataFormat = new byte[19];
//                        for (int i = 0; i < phoneData.length; i++) {
//                            if(i < 19){
//                                phoneDataFormat[i] = phoneData[i];
//                            }
//                        }
//                    }else{
//                        phoneDataFormat = new byte[phoneData.length];
//                        for (int i = 0; i < phoneData.length; i++) {
//                            phoneDataFormat[i] = phoneData[i];
//                        }
//                    }
//                    phoneLen = phoneDataFormat.length;
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }else{
                phoneData = new byte[0];
            }
            SDKLogger.i("发送-->nameLen="+nameLen+"\tphoneLen="+phoneLen);
            data = new byte[2 + nameLen + 1 + phoneLen];
            data[0] = 0x02;
            data[1] = (byte) (nameLen & 0xff);
            if (nameLen > 0) {
                System.arraycopy(nameData, 0, data, 2, nameLen);
            }
            data[nameLen + 2] = (byte) (phoneLen & 0xff);
            if (phoneLen > 0) {
                System.arraycopy(phoneData, 0, data, nameLen + 3, phoneLen);
            }
        }
        SDKLogger.i("发送-->sendState=" + sendState +
                ", addressLen=" + addressLen +
                ", nameLen=" + nameLen +
                ", addressName=" + addressName +
                ", phoneLen=" + phoneLen +
                ", addressPhone=" + addressPhone);
        return data;
    }

    public boolean parseData(byte[] data) {
        if (data.length > 0) {
            sendState = data[0] & 0xff;
            nameLen = data[1] & 0xff;
            phoneLen = data[2 + nameLen] & 0xff;
            byte[] nameByte = new byte[nameLen];
            System.arraycopy(data, 2, nameByte, 0, nameLen);
            byte[] phoneByte = new byte[phoneLen];
            System.arraycopy(data, 2 + nameLen, phoneByte, 0, phoneLen);
            try {
                addressName = new String(nameByte, "UTF-8");
                addressPhone = new String(phoneByte, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            SDKLogger.i("返回-->sendState=" + sendState +
                    ", addressLen=" + addressLen +
                    ", nameLen=" + nameLen +
                    ", addressName=" + addressName +
                    ", phoneLen=" + phoneLen +
                    ", addressPhone=" + addressPhone);
            return true;
        } else {
            SDKLogger.i("ApplicationLayerAddressBookPacket data=null");
            return false;
        }
    }

    @Override
    public String toString() {
        return "ApplicationLayerAddressBookPacket{" +
                "sendState=" + sendState +
                ", addressLen=" + addressLen +
                ", nameLen=" + nameLen +
                ", addressName='" + addressName + '\'' +
                ", phoneLen=" + phoneLen +
                ", addressPhone='" + addressPhone + '\'' +
                '}';
    }
}
