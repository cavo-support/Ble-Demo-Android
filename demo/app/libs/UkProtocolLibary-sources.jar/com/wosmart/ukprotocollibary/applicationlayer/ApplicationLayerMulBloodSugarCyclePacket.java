package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

public class ApplicationLayerMulBloodSugarCyclePacket {

    private boolean isOpen;
    private float privateValue;
    private int privateRtcTime;

    // Packet Length
    private final static int HEADER_LENGTH = 7;

    public ApplicationLayerMulBloodSugarCyclePacket() {

    }

    public boolean parseData(byte[] data) {
        // check header length
        if (data.length < HEADER_LENGTH) {
            return false;
        }
        isOpen = (data[0] == 0x01);
        int value = ((data[1] & 0xff) << 8) | (data[2] & 0xff);

        privateValue = JWUtils.parserRound(1, privateValue / 10f);


        privateRtcTime = ((data[3] & 0xff)) | ((data[4] & 0xff) << 8) | ((data[5] & 0xff) << 16) | ((data[6] & 0xff) << 24);

        return true;
    }

    public byte[] getPacket() {
        byte[] data = new byte[HEADER_LENGTH];
        data[0] = (byte) (isOpen ? 0x01 : 0x00);

        int value = (int) (privateValue * 10);
        data[1] = (byte) ((value >> 8) & 0xff);
        data[2] = (byte) (value & 0xff);
        data[3] = (byte) ((privateRtcTime) & 0xff);
        data[4] = (byte) ((privateRtcTime >> 8) & 0xff);
        data[5] = (byte) ((privateRtcTime >> 16) & 0xff);
        data[6] = (byte) ((privateRtcTime >> 24) & 0xff);

        return data;
    }


    public boolean isOpen() {
        return isOpen;
    }

    public void setOpen(boolean open) {
        isOpen = open;
    }

    public float getPrivateValue() {
        return privateValue;
    }

    public void setPrivateValue(float privateValue) {
        this.privateValue = privateValue;
    }

    public int getPrivateRtcTime() {
        return privateRtcTime;
    }

    public void setPrivateRtcTime(int privateRtcTime) {
        this.privateRtcTime = privateRtcTime;
    }


    @Override
    public String toString() {
        return "ApplicationLayerMulBloodFatPacket{" +
                "isOpen=" + isOpen +
                ", privateValue=" + isOpen +
                ", privateRtcTime=" + isOpen +
                '}';
    }
}
