package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerPrivateBpPacket {

    private boolean isOpen;

    private int highValue;

    private int lowValue;

    public ApplicationLayerPrivateBpPacket() {
    }

    public ApplicationLayerPrivateBpPacket(boolean isOpen, int highValue, int lowValue) {
        this.isOpen = isOpen;
        this.highValue = highValue;
        this.lowValue = lowValue;
    }

    public boolean isOpen() {
        return isOpen;
    }

    public void setOpen(boolean open) {
        isOpen = open;
    }

    public int getHighValue() {
        return highValue;
    }

    public void setHighValue(int highValue) {
        this.highValue = highValue;
    }

    public int getLowValue() {
        return lowValue;
    }

    public void setLowValue(int lowValue) {
        this.lowValue = lowValue;
    }

    @Override
    public String toString() {
        return "ApplicationLayerPrivateBpPacket{" +
                "isOpen=" + isOpen +
                ", highValue=" + highValue +
                ", lowValue=" + lowValue +
                '}';
    }
}
