package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.model.enums.DeviceFunctionStatus;

public class ApplicationLayerDeviceStatusPacket {
    //低功耗模式
    private DeviceFunctionStatus lowPower;

    public ApplicationLayerDeviceStatusPacket() {
    }

    public DeviceFunctionStatus getLowPower() {
        return lowPower;
    }

    public void setLowPower(DeviceFunctionStatus lowPower) {
        this.lowPower = lowPower;
    }

    public boolean parseData(byte[] data) {
        if (data.length >= 4) {
            int LowPower = data[3] & 0x01;
            if (LowPower == 1) {
                lowPower = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                lowPower = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerDeviceStatusPacket{" +
                "lowPower=" + lowPower +
                '}';
    }

}
