package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerTemperatureControlPacket {

    /**
     * temperature show on remote device
     */
    private boolean show;

    /**
     * temperature adjust;
     */
    private boolean adjust;

    /**
     * celsius unit
     */
    private boolean celsiusUnit;

    /**
     * package length
     */
    private final int ITEM_LENGTH = 4;

    public void setShow(boolean show) {
        this.show = show;
    }

    public void setAdjust(boolean adjust) {
        this.adjust = adjust;
    }

    public boolean isShow() {
        return show;
    }

    public boolean isAdjust() {
        return adjust;
    }

    public boolean isCelsiusUnit() {
        return celsiusUnit;
    }

    public void setCelsiusUnit(boolean celsiusUnit) {
        this.celsiusUnit = celsiusUnit;
    }

    public byte[] getPacket() {
        byte[] data = new byte[ITEM_LENGTH];
        data[3] = (byte) ((show ? 0x01 : 0x00) | (adjust ? 0x02 : 0x00) | (celsiusUnit ? 0x00 : 0x04));
        return data;
    }


    public boolean parseData(byte[] data) {
        if (data.length >= ITEM_LENGTH) {
            int Show = data[3] & 0x01;
            int Adjust = (data[3] >> 1) & 0x01;
            int CelsiusUnit = (data[3] >> 2) & 0x01;
            show = (Show == 1);
            adjust = (Adjust == 1);
            celsiusUnit = (CelsiusUnit == 0);
        }
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerTemperatureControlPacket{" +
                "show=" + show +
                ", adjust=" + adjust +
                ", celsiusUnit=" + celsiusUnit +
                '}';
    }
}
