package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerMulTemperatureReminderPacket {

    private int value;

    // Packet Length
    private final static int HEADER_LENGTH = 2;

    public ApplicationLayerMulTemperatureReminderPacket() {

    }

    public boolean parseData(byte[] data) {
        // check header length
        if (data.length < HEADER_LENGTH) {
            return false;
        }
        value = ((data[0] & 0xff) << 8) | (data[1] & 0xff);
        return true;
    }

    public byte[] getPacket(){
        byte[] data = new byte[2];
        data[0] = (byte) ((value >> 8) & 0xff);
        data[1] = (byte) (value & 0xff);
        return data;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "ApplicationLayerMulTemperatureReminderPacket{" +
                "value=" + value +
                '}';
    }

}
