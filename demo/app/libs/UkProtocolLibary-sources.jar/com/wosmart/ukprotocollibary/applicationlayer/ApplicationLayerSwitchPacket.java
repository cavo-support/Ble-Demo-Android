package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.model.enums.DeviceFunctionStatus;

public class ApplicationLayerSwitchPacket {

    /**
     * stop watch function
     */
    private DeviceFunctionStatus stopWatch;

    /**
     * find phone function
     */
    private DeviceFunctionStatus findPhone;

    /**
     * auto lock screen
     */
    private DeviceFunctionStatus autoLock;

    /**
     * dual slide
     */
    private DeviceFunctionStatus dualSlide;

    /**
     * voiceAssistant
     */
    private DeviceFunctionStatus voiceAssistant;

    /**
     * package length
     */
    private final int REMINDER_HEAD_LENGTH = 4;

    public ApplicationLayerSwitchPacket() {
    }

    public DeviceFunctionStatus getStopWatch() {
        return stopWatch;
    }

    public void setStopWatch(DeviceFunctionStatus stopWatch) {
        this.stopWatch = stopWatch;
    }

    public DeviceFunctionStatus getFindPhone() {
        return findPhone;
    }

    public void setFindPhone(DeviceFunctionStatus findPhone) {
        this.findPhone = findPhone;
    }

    public DeviceFunctionStatus getAutoLock() {
        return autoLock;
    }

    public void setAutoLock(DeviceFunctionStatus autoLock) {
        this.autoLock = autoLock;
    }

    public DeviceFunctionStatus getDualSlide() {
        return dualSlide;
    }

    public void setDualSlide(DeviceFunctionStatus dualSlide) {
        this.dualSlide = dualSlide;
    }

    public DeviceFunctionStatus getVoiceAssistant() {
        return voiceAssistant;
    }

    public void setVoiceAssistant(DeviceFunctionStatus voiceAssistant) {
        this.voiceAssistant = voiceAssistant;
    }

    public byte[] getPacket() {
        byte[] data = new byte[REMINDER_HEAD_LENGTH];

        byte VoiceAssistant = (byte) 0x00;
        if (voiceAssistant == DeviceFunctionStatus.SUPPORT_OPEN) {
            VoiceAssistant = (byte) 0x03;
        } else if (voiceAssistant == DeviceFunctionStatus.SUPPORT_CLOSE) {
            VoiceAssistant = (byte) 0x02;
        }

        byte StopWatch = (byte) 0x00;
        if (stopWatch == DeviceFunctionStatus.SUPPORT_OPEN) {
            StopWatch = (byte) 0x03;
        } else if (stopWatch == DeviceFunctionStatus.SUPPORT_CLOSE) {
            StopWatch = (byte) 0x02;
        }

        byte FindPhone = (byte) 0x00;
        if (findPhone == DeviceFunctionStatus.SUPPORT_OPEN) {
            FindPhone = (byte) 0x0c;
        } else if (findPhone == DeviceFunctionStatus.SUPPORT_CLOSE) {
            FindPhone = (byte) 0x08;
        }

        byte AutoClock = (byte) 0x00;
        if (autoLock == DeviceFunctionStatus.SUPPORT_OPEN) {
            AutoClock = (byte) 0x30;
        } else if (autoLock == DeviceFunctionStatus.SUPPORT_CLOSE) {
            AutoClock = (byte) 0x20;
        }

        byte DualSlide = (byte) 0x00;
        if (dualSlide == DeviceFunctionStatus.SUPPORT_OPEN) {
            DualSlide = (byte) 0xc0;
        } else if (dualSlide == DeviceFunctionStatus.SUPPORT_CLOSE) {
            DualSlide = (byte) 0x80;
        }

        data[2] = VoiceAssistant;
        data[3] = (byte) (DualSlide | AutoClock | FindPhone | StopWatch);
        return data;
    }

    public boolean parseData(byte[] data) {
        if (data.length >= REMINDER_HEAD_LENGTH) {
            int StopWatch = data[3] & 0x01;
            int StopWatch2 = (data[3] >> 1) & 0x01;
            int FindPhone = (data[3] >> 2) & 0x01;
            int FindPhone2 = (data[3] >> 3) & 0x01;
            int AutoLock = (data[3] >> 4) & 0x01;
            int AutoLock2 = (data[3] >> 5) & 0x01;
            int DualSlide = (data[3] >> 6) & 0x01;
            int DualSlide2 = (data[3] >> 7) & 0x01;

            int VoiceAssistant = data[2] & 0x01;
            int VoiceAssistant2 = (data[2] >> 1) & 0x01;

            if (StopWatch2 == 1) {
                if (StopWatch == 1) {
                    stopWatch = DeviceFunctionStatus.SUPPORT_OPEN;
                } else {
                    stopWatch = DeviceFunctionStatus.SUPPORT_CLOSE;
                }
            } else {
                stopWatch = DeviceFunctionStatus.UN_SUPPORT;
            }

            if (FindPhone2 == 1) {
                if (FindPhone == 1) {
                    findPhone = DeviceFunctionStatus.SUPPORT_OPEN;
                } else {
                    findPhone = DeviceFunctionStatus.SUPPORT_CLOSE;
                }
            } else {
                findPhone = DeviceFunctionStatus.UN_SUPPORT;
            }

            if (AutoLock2 == 1) {
                if (AutoLock == 1) {
                    autoLock = DeviceFunctionStatus.SUPPORT_OPEN;
                } else {
                    autoLock = DeviceFunctionStatus.SUPPORT_CLOSE;
                }
            } else {
                autoLock = DeviceFunctionStatus.UN_SUPPORT;
            }

            if (DualSlide2 == 1) {
                if (DualSlide == 1) {
                    dualSlide = DeviceFunctionStatus.SUPPORT_OPEN;
                } else {
                    dualSlide = DeviceFunctionStatus.SUPPORT_CLOSE;
                }
            } else {
                dualSlide = DeviceFunctionStatus.UN_SUPPORT;
            }

            if (VoiceAssistant2 == 1) {
                if (VoiceAssistant == 1) {
                    voiceAssistant = DeviceFunctionStatus.SUPPORT_OPEN;
                } else {
                    voiceAssistant = DeviceFunctionStatus.SUPPORT_CLOSE;
                }
            } else {
                voiceAssistant = DeviceFunctionStatus.UN_SUPPORT;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerSwitchPacket{" +
                "stopWatch=" + stopWatch +
                ", findPhone=" + findPhone +
                ", autoLock=" + autoLock +
                ", dualSlide=" + dualSlide +
                ", voiceAssistant=" + voiceAssistant +
                '}';
    }
}
