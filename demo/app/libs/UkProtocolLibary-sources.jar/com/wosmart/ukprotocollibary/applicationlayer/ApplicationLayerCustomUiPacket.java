package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerCustomUiPacket {


    /**
     * 字体颜色
     * 0 黑色
     * #ffff 白色
     */
    private int timeColor;

    /**
     * 布局方式
     * 0 左对齐
     * 1 中对齐
     * 2 右对齐
     */
    private int gravity;

    /**
     * y坐标
     */
    private int yCoordinate;

    /**
     * x 坐标
     */
    private int xCoordinate;

    /**
     * 长度
     */
    private int width;

    /**
     * 高度
     */
    private int height;

    private int package_length = 8;

    public int getTimeColor() {
        return timeColor;
    }

    public void setTimeColor(int timeColor) {
        this.timeColor = timeColor;
    }

    public int getGravity() {
        return gravity;
    }

    public void setGravity(int gravity) {
        this.gravity = gravity;
    }

    public int getyCoordinate() {
        return yCoordinate;
    }

    public void setyCoordinate(int yCoordinate) {
        this.yCoordinate = yCoordinate;
    }

    public int getxCoordinate() {
        return xCoordinate;
    }

    public void setxCoordinate(int xCoordinate) {
        this.xCoordinate = xCoordinate;
    }

    public byte[] getPacket() {
        byte[] data = new byte[package_length];
        data[1] = (byte) ((timeColor >> 14) & 0xff);
        data[2] = (byte) ((timeColor >> 6) & 0xff);
        data[3] = (byte) (((timeColor & 0xff) << 2) | ((gravity & 0x0c) >> 2));
        data[4] = (byte) (((gravity & 0x03) << 6) | ((yCoordinate >> 5) & 0x3f));
        data[5] = (byte) (((yCoordinate & 0x1f) << 3) | ((xCoordinate >> 8) & 0x07));
        data[6] = (byte) (xCoordinate & 0xff);
        return data;
    }

    public boolean parseData(byte[] data) {
        timeColor = ((data[1] & 0xff) << 14) | ((data[2] & 0xff) << 6) | ((data[3] & 0xff) >> 2);
        gravity = ((data[3] & 0x03) << 2) | ((data[4] >> 6) & 0x03);
        yCoordinate = ((data[4] & 0x3f) << 5) | ((data[5] & 0xf8) >> 3);
        xCoordinate = ((data[5] & 0x07) << 3) | (data[6] & 0xff);
        width = ((data[8] & 0xff) << 8) | (data[9] & 0xff);
        height = ((data[10] & 0xff) << 8) | (data[11] & 0xff);
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerCustomUiPacket{" +
                "timeColor=" + timeColor +
                ", gravity=" + gravity +
                ", yCoordinate=" + yCoordinate +
                ", xCoordinate=" + xCoordinate +
                ", package_length=" + package_length +
                '}';
    }
}
