package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerSleepAdjustPacket {

    /**
     * long sit reminder threshold
     */
    private int lightMinutes;            // 11bytes

    /**
     * reminder timer
     */
    private int deepMinutes;        // 11byte

    /**
     * start reminder timer
     */
    private int quality;    // 3byte

    /**
     * Packet Length
     */
    private final static int SIT_HEADER_LENGTH = 4;

    public ApplicationLayerSleepAdjustPacket() {

    }

    public ApplicationLayerSleepAdjustPacket(int lightMinutes, int deepMinutes, int quality) {
        this.lightMinutes = lightMinutes;
        this.deepMinutes = deepMinutes;
        this.quality = quality;
    }

    public int getLightMinutes() {
        return lightMinutes;
    }

    public void setLightMinutes(int lightMinutes) {
        this.lightMinutes = lightMinutes;
    }

    public int getDeepMinutes() {
        return deepMinutes;
    }

    public void setDeepMinutes(int deepMinutes) {
        this.deepMinutes = deepMinutes;
    }

    public int getQuality() {
        return quality;
    }

    public void setQuality(int quality) {
        this.quality = quality;
    }

    public byte[] getPacket() {
        byte[] data = new byte[SIT_HEADER_LENGTH];

        data[0] = (byte) ((quality & 0x07) >> 1);
        data[1] = (byte) (((quality & 0x01) << 7) | ((deepMinutes & 0x7ff) >> 4));
        data[2] = (byte) (((deepMinutes & 0x0f) << 4) | ((lightMinutes & 0x7ff) >> 7));
        data[3] = (byte) (((lightMinutes & 0x7f) << 1) | ((deepMinutes == 0 && lightMinutes == 0 && quality == 0) ? 0x00 : 0x01));
        return data;
    }

//    public boolean parseData(byte[] data) {
//        if (data.length >= SIT_HEADER_LENGTH) {
//            mDayFlags = data[0];
//            mStopNotifyTime = data[1] & 0xff;
//            mStartNotifyTime = data[2] & 0xff;
//            mNotifyTime = data[3] & 0xff;
//            mThreshold = ((data[5] << 8) & 0xff) | (data[4] & 0xff);
//            mEnable = data[6] == LONG_SIT_CONTROL_ENABLE ? true : false;
//        }
//        return true;
//    }


    @Override
    public String toString() {
        return "ApplicationLayerSleepAdjustPacket{" +
                "lightMinutes=" + lightMinutes +
                ", deepMinutes=" + deepMinutes +
                ", quality=" + quality +
                '}';
    }
}
