package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

public class ApplicationLayerRateItemPacket {

    /**
     * year
     */
    private int mYear;            // 6bits

    /**
     * month
     */
    private int mMonth;            // 4bits

    /**
     * day
     */
    private int mDay;            // 5bits

    /**
     * item count
     */
    private int mItemCount;        // 8bits

    /**
     * minute
     */
    private int mMinutes;             // 16bits

    /**
     * id
     */
    private int mSequenceNum;        //8 bits

    /**
     * rate value
     */
    private int mValue;             // 8bits

    /**
     * temperature value
     * 温度值
     */
    private float temperature;

    /**
     * temperature wear status
     * 佩戴状态 只与温度相关
     */
    private boolean wearStatus;

    /**
     * temperature adjust status
     * 补偿状态 与温度相关
     */
    private boolean adjustStatus;

    /**
     * 动画状态
     */
    private boolean animationStatus;

    /**
     * 原始值
     */
    private float tempOriginValue;

    /**
     * Packet Length
     */
    public final static int ITEM_LENGTH = 8;

    public final static int TEMP_LENGTH = 12;

    public boolean parseData(byte[] data) {
        if (data.length >= TEMP_LENGTH) {
            mYear = (data[0] & 0x7e) >> 1;// here must be care shift operation of negative
            mMonth = ((data[0] & 0x01) << 3) | (data[1] >> 5) & 0x07;//here must be care shift operation of negative
            mDay = data[1] & 0x1f;//here must be care shift operation of negative
            mItemCount = data[3] & 0xff;

            animationStatus = ((data[5] >> 2) & 0x01) == 1 ? true : false;
            adjustStatus = ((data[5] >> 1) & 0x01) == 1 ? true : false;
            wearStatus = (data[5] & 0x01) == 1 ? true : false;

            int temp = ((data[6] << 8) | (data[7] & 0xff)) & 0xffff;// here must be care shift operation of negative
            if (temp > 0) {
                if (animationStatus) {
                    temperature = JWUtils.parserRound(1, temp / 10f);
                } else {
                    if (temp >= 368) {
                        temperature = JWUtils.parserRound(1, temp / 10f);
                    } else {
                        //自动检测的 不只保留一位小数
                        if (wearStatus && adjustStatus) {
                            float temp2 = 368 - (368 - temp) / 20f;
                            temperature = JWUtils.parserRound(1, temp2 / 10f);
                        } else {
                            temperature = JWUtils.parserRound(1, temp / 10f);
                        }
                    }
                }
            } else {
                temperature = 0f;
            }

            tempOriginValue = JWUtils.parserRound(1, temp / 10f);

            mMinutes = ((data[8] << 8) | (data[9] & 0xff)) & 0xffff;// here must be care shift operation of negative
            mSequenceNum = (data[10] & 0xff);
            //mValue = ((data[2] << 8) | (data[3] & 0xff)) & 0xffff;// here must be care shift operation of negative
            mValue = (data[11] & 0xff);

            return true;
        } else if (data.length >= ITEM_LENGTH) {
            mYear = (data[0] & 0x7e) >> 1;// here must be care shift operation of negative
            mMonth = ((data[0] & 0x01) << 3) | (data[1] >> 5) & 0x07;//here must be care shift operation of negative
            mDay = data[1] & 0x1f;//here must be care shift operation of negative
            mItemCount = data[3] & 0xff;

            mMinutes = ((data[4] << 8) | (data[5] & 0xff)) & 0xffff;// here must be care shift operation of negative
            mSequenceNum = (data[6] & 0xff);
            //mValue = ((data[2] << 8) | (data[3] & 0xff)) & 0xffff;// here must be care shift operation of negative
            mValue = (data[7] & 0xff);

            return true;
        }
        return false;
    }

    public int getYear() {
        return mYear;
    }

    public int getMonth() {
        return mMonth;
    }

    public int getDay() {
        return mDay;
    }

    public int getItemCount() {
        return mItemCount;
    }

    public int getMinutes() {
        return mMinutes;
    }

    public int getSequenceNum() {
        return mSequenceNum;
    }

    public int getValue() {
        return mValue;
    }

    public float getTemperature() {
        return temperature;
    }

    public boolean isWearStatus() {
        return wearStatus;
    }

    public boolean isAdjustStatus() {
        return adjustStatus;
    }

    public boolean isAnimationStatus() {
        return animationStatus;
    }

    public float getTempOriginValue() {
        return tempOriginValue;
    }

    @Override
    public String toString() {
        return "ApplicationLayerRateItemPacket{" +
                "mYear=" + mYear +
                ", mMonth=" + mMonth +
                ", mDay=" + mDay +
                ", mItemCount=" + mItemCount +
                ", mMinutes=" + mMinutes +
                ", mSequenceNum=" + mSequenceNum +
                ", mValue=" + mValue +
                ", temperature=" + temperature +
                ", wearStatus=" + wearStatus +
                ", adjustStatus=" + adjustStatus +
                ", tempOriginValue=" + tempOriginValue +
                '}';
    }
}
