package com.wosmart.ukprotocollibary.applicationlayer;

import java.util.ArrayList;
import java.util.List;

public class ApplicationLayerBeginPacket {

    private int totalCount;

    private List<ApplicationLayerDataCountItem> dataCountItemList;

    public ApplicationLayerBeginPacket() {
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<ApplicationLayerDataCountItem> getDataCountItemList() {
        return dataCountItemList;
    }

    public void setDataCountItemList(List<ApplicationLayerDataCountItem> dataCountItemList) {
        this.dataCountItemList = dataCountItemList;
    }

    public boolean parseData(byte[] data) {
        // check header length
        int size = data.length;
        if (size > 0) {
            int count = size / 3;
            if (count > 0) {
                dataCountItemList = new ArrayList<>();
                byte[] subData = new byte[ApplicationLayerDataCountItem.ITEM_HEADER_LENGTH];
                for (int i = 0; i < count; i++) {
                    ApplicationLayerDataCountItem countItem = new ApplicationLayerDataCountItem();
                    System.arraycopy(data, i * ApplicationLayerDataCountItem.ITEM_HEADER_LENGTH,
                            subData, 0, ApplicationLayerDataCountItem.ITEM_HEADER_LENGTH);

                    countItem.parseData(subData);
                    totalCount += countItem.getDataCount();
                    dataCountItemList.add(countItem);
                }
            } else {
                totalCount = 0;
                dataCountItemList = new ArrayList<>();
            }
        } else {
            totalCount = 0;
            dataCountItemList = new ArrayList<>();
        }
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerBeginPacket{" +
                "\ntotalCount = " + totalCount +
                ", dataList =  " + dataCountItemList +
                '}';
    }
}
