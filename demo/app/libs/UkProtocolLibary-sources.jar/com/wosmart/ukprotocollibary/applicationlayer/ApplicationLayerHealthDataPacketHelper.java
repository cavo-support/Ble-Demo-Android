package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.common.JWLog;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodFatInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.UricAcidInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUltravioletInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWearingTimeInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWDefaultFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWHealthRiskAssessmentInfo;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ApplicationLayerHealthDataPacketHelper {

    public static List<ApplicationLayerStepPacket> parseStepData(byte[] data) {
        List<ApplicationLayerStepPacket> packetList = new ArrayList<>();
        int packetLength = 12;
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);
            ApplicationLayerStepPacket packet = new ApplicationLayerStepPacket();
            boolean result = packet.parseData(subData);
            if (result) {
                packetList.add(packet);
            }
        }
        return packetList;
    }

    public static List<ApplicationLayerSleepPacket> parseSleepData(byte[] data) {
        List<ApplicationLayerSleepPacket> packetList = new ArrayList<>();
        int packetLength = 8;
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);
            ApplicationLayerSleepPacket packet = new ApplicationLayerSleepPacket();
            boolean result = packet.parseData(subData);
            if (result) {
                packetList.add(packet);
            }
        }
        return packetList;
    }

    public static List<ApplicationLayerBpPacket> parseBloodPressureData(byte[] data) {
        List<ApplicationLayerBpPacket> packetList = new ArrayList<>();
        int packetLength = 12;
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);
            ApplicationLayerBpPacket packet = new ApplicationLayerBpPacket();
            boolean result = packet.parseData(subData);
            if (result) {
                packetList.add(packet);
            }
        }
        return packetList;
    }

    public static List<ApplicationLayerSpo2Packet> parseSpO2Data(byte[] data) {
        List<ApplicationLayerSpo2Packet> packetList = new ArrayList<>();
        int packetLength = 8;
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);
            ApplicationLayerSpo2Packet packet = new ApplicationLayerSpo2Packet();
            boolean result = packet.parseData(subData);
            if (result) {
                packetList.add(packet);
            }
        }
        return packetList;
    }

    public static List<ApplicationLayerRtkHrvPacket> parseHrvData(byte[] data) {
        List<ApplicationLayerRtkHrvPacket> packetList = new ArrayList<>();
        int packetLength = 8;
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);
            ApplicationLayerRtkHrvPacket packet = new ApplicationLayerRtkHrvPacket();
            boolean result = packet.parseData(subData);
            if (result) {
                packetList.add(packet);
            }
        }
        return packetList;
    }

    public static List<ApplicationLayerGLUPacket> parseBloodSugarData(byte[] data) {
        List<ApplicationLayerGLUPacket> packetList = new ArrayList<>();
        int packetLength = 8;
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);
            ApplicationLayerGLUPacket packet = new ApplicationLayerGLUPacket();
            boolean result = packet.parseData(subData);
            if (result) {
                packetList.add(packet);
            }
        }
        return packetList;
    }

    public static List<JWWearingTimeInfo> parseWearingTimeData(byte[] data) {
        List<JWWearingTimeInfo> dataList = new ArrayList<>();
        int packetLength = 8;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return dataList;
        }
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            long timestamp = (((subData[0] & 0xff)) | ((subData[1] & 0xff) << 8) | ((subData[2] & 0xff) << 16) | ((subData[3] & 0xff) << 24));
            int wearStatus = subData[4] & 0xff;

            JWWearingTimeInfo info = new JWWearingTimeInfo();

            long time = DateUtil.getDate(2000, 1, 1);

            time += (timestamp * 1000);

            info.setTime(time);
            info.wearStatus = wearStatus;

            dataList.add(info);
        }
        return dataList;
    }

    public static List<JWUricAcidInfo> parseUricAcidData(byte[] data) {
        List<JWUricAcidInfo> dataList = new ArrayList<>();
        int packetLength = 16;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return dataList;
        }
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            long cycleStartTime = (((subData[0] & 0xff)) | ((subData[1] & 0xff) << 8) | ((subData[2] & 0xff) << 16) | ((subData[3] & 0xff) << 24));
            int dayStatusList = (((subData[4] & 0xff)) | ((subData[5] & 0xff) << 8) | ((subData[6] & 0xff) << 16) | ((subData[7] & 0xff) << 24));
            long valueTime = (((subData[8] & 0xff)) | ((subData[9] & 0xff) << 8) | ((subData[10] & 0xff) << 16) | ((subData[11] & 0xff) << 24));
            int evaluationResult = subData[12] & 0xff;

            JWUricAcidInfo info = new JWUricAcidInfo();

            long time = DateUtil.getDate(2000, 1, 1);

            cycleStartTime = cycleStartTime * 1000 + time;
            valueTime = valueTime == 0 ? 0 : (valueTime * 1000 + time);
            long cycleEndTime = cycleStartTime + 24 * 3600000 * 13;

            // 结束时间为当天最后 1 秒
            cycleEndTime = DateUtil.getLastSecondOfTheDay(cycleEndTime);

            info.cycleStartTime = cycleStartTime;
            info.cycleEndTime = cycleEndTime;
            info.evaluationResult = evaluationResult;
            info.valueTime = valueTime;
            info.dayStatusList = UricAcidInfo.convertDayStatusList(cycleStartTime, dayStatusList);

            dataList.add(info);
        }
        return dataList;
    }

    public static List<JWBloodFatInfo> parseBloodFatData(byte[] data) {
        List<JWBloodFatInfo> dataList = new ArrayList<>();
        int packetLength = 16;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return dataList;
        }
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            long cycleStartTime = (((subData[0] & 0xff)) | ((subData[1] & 0xff) << 8) | ((subData[2] & 0xff) << 16) | ((subData[3] & 0xff) << 24));
            int dayStatusList = (((subData[4] & 0xff)) | ((subData[5] & 0xff) << 8) | ((subData[6] & 0xff) << 16) | ((subData[7] & 0xff) << 24));
            long valueTime = (((subData[8] & 0xff)) | ((subData[9] & 0xff) << 8) | ((subData[10] & 0xff) << 16) | ((subData[11] & 0xff) << 24));
            int evaluationResult = subData[12] & 0xff;

            JWBloodFatInfo info = new JWBloodFatInfo();

            long time = DateUtil.getDate(2000, 1, 1);

            cycleStartTime = cycleStartTime * 1000 + time;
            valueTime = valueTime == 0 ? 0 : (valueTime * 1000 + time);
            long cycleEndTime = cycleStartTime + 24 * 3600000 * 13;

            // 结束时间为当天最后 1 秒
            cycleEndTime = DateUtil.getLastSecondOfTheDay(cycleEndTime);

            info.cycleStartTime = cycleStartTime;
            info.cycleEndTime = cycleEndTime;
            info.evaluationResult = evaluationResult;
            info.valueTime = valueTime;
            info.dayStatusList = BloodFatInfo.convertDayStatusList(cycleStartTime, dayStatusList);

            dataList.add(info);
        }
        return dataList;
    }

    public static List<JWBloodSugarCycleInfo> parseBloodSugarCycleData(byte[] data) {
        List<JWBloodSugarCycleInfo> dataList = new ArrayList<>();
        int packetLength = 16;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return dataList;
        }
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            long cycleStartTime = (((subData[0] & 0xff)) | ((subData[1] & 0xff) << 8) | ((subData[2] & 0xff) << 16) | ((subData[3] & 0xff) << 24));
            int dayStatusList = (((subData[4] & 0xff)) | ((subData[5] & 0xff) << 8) | ((subData[6] & 0xff) << 16) | ((subData[7] & 0xff) << 24));
            long valueTime = (((subData[8] & 0xff)) | ((subData[9] & 0xff) << 8) | ((subData[10] & 0xff) << 16) | ((subData[11] & 0xff) << 24));
            int evaluationResult = subData[12] & 0xff;

            JWBloodSugarCycleInfo info = new JWBloodSugarCycleInfo();

            long time = DateUtil.getDate(2000, 1, 1);

            cycleStartTime = cycleStartTime * 1000 + time;
            valueTime = valueTime == 0 ? 0 : (valueTime * 1000 + time);
            long cycleEndTime = cycleStartTime + 24 * 3600000 * 13;

            // 结束时间为当天最后 1 秒
            cycleEndTime = DateUtil.getLastSecondOfTheDay(cycleEndTime);

            info.cycleStartTime = cycleStartTime;
            info.cycleEndTime = cycleEndTime;
            info.evaluationResult = evaluationResult;
            info.valueTime = valueTime;
            info.dayStatusList = BloodSugarCycleInfo.convertDayStatusList(cycleStartTime, dayStatusList);

            dataList.add(info);
        }
        return dataList;
    }

    public static List<JWUricAcidContinuousMonitoringInfo> parseUricAcidContinuousMonitoringData(byte[] data) {
        List<JWUricAcidContinuousMonitoringInfo> dataList = new ArrayList<>();
        int packetLength = 8;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return dataList;
        }
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            long timestamp = (((subData[0] & 0xff)) | ((subData[1] & 0xff) << 8) | ((subData[2] & 0xff) << 16) | ((subData[3] & 0xff) << 24));
            int value = ((subData[4] & 0xff) << 8) | (subData[5] & 0xff);

            JWUricAcidContinuousMonitoringInfo info = new JWUricAcidContinuousMonitoringInfo();

            long time = DateUtil.getDate(2000, 1, 1);

            time += (timestamp * 1000);

            info.setTime(time);
            info.value = value;

            dataList.add(info);
        }
        return dataList;
    }

    public static List<JWBloodFatContinuousMonitoringInfo> parseBloodFatContinuousMonitoringData(byte[] data) {
        List<JWBloodFatContinuousMonitoringInfo> dataList = new ArrayList<>();
        int packetLength = 8;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return dataList;
        }
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            long timestamp = (((subData[0] & 0xff)) | ((subData[1] & 0xff) << 8) | ((subData[2] & 0xff) << 16) | ((subData[3] & 0xff) << 24));
            int value = ((subData[4] & 0xff) << 8) | (subData[5] & 0xff);

            JWBloodFatContinuousMonitoringInfo info = new JWBloodFatContinuousMonitoringInfo();

            long time = DateUtil.getDate(2000, 1, 1);

            time += (timestamp * 1000);

            info.setTime(time);
            info.value = JWUtils.parserRound(2, value / 100f);

            dataList.add(info);
        }
        return dataList;
    }

    public static JWBodyFatInfo parseBodyFatData(byte[] data) {
        JWBodyFatInfo info = new JWBodyFatInfo();

        int packetLength = 4;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return info;
        }

        // 时间在前 4 个字节
        long startTime = (((data[0] & 0xff)) | ((data[1] & 0xff) << 8) | ((data[2] & 0xff) << 16) | ((data[3] & 0xff) << 24));
        long time = DateUtil.getDate(2000, 1, 1);

        startTime = startTime * 1000 + time;

        info.time = startTime;

        byte[] subData = new byte[packetLength];
        // 从第 2 个 4 字节组开始组数据
        for (int i = 1; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            int type = subData[0] & 0xff;
            int realValue = ((subData[1] & 0xff) << 8) | (subData[2] & 0xff);
            float value = JWUtils.parserRound(1, realValue / 10f);
            int maxLevel= (subData[3] >> 4) & 0x0f;
            int level = subData[3] & 0x0f;

            switch (type) {
                case 0:
                    info.weight = value;
                    info.weightLevel = level;
                    info.weightMaxLevel = maxLevel;
                    break;
                case 1:
                    info.bmi = value;
                    info.bmiLevel = level;
                    info.bmiMaxLevel = maxLevel;
                    break;
                case 2:
                    info.bodyFat = value;
                    info.bodyFatLevel = level;
                    info.bodyFatMaxLevel = maxLevel;
                    break;
                case 3:
                    info.bodyWater = value;
                    info.bodyWaterLevel = level;
                    info.bodyWaterMaxLevel = maxLevel;
                    break;
                case 4:
                    info.protein = value;
                    info.proteinLevel = level;
                    info.proteinMaxLevel = maxLevel;
                    break;
                case 5:
                    info.boneMass = value;
                    info.boneMassLevel = level;
                    info.boneMassMaxLevel = maxLevel;
                    break;
                case 6:
                    info.muscle = value;
                    info.muscleLevel = level;
                    info.muscleMaxLevel = maxLevel;
                    break;
                case 7:
                    info.bmr = value;
                    info.bmrLevel = level;
                    info.bmrMaxLevel = maxLevel;
                    break;
                default:
                    break;
            }
        }
        return info;
    }

    public static JWPhysicalExamInfo parsePhysicalExamData(byte[] data) {
        JWPhysicalExamInfo info = new JWPhysicalExamInfo();

        int packetLength = 4;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return info;
        }

        // 时间在前 4 个字节
        long startTime = (((data[0] & 0xff)) | ((data[1] & 0xff) << 8) | ((data[2] & 0xff) << 16) | ((data[3] & 0xff) << 24));
        long time = DateUtil.getDate(2000, 1, 1);

        startTime = startTime * 1000 + time;

        info.time = startTime;

        byte[] subData = new byte[packetLength];
        // 从第 2 个 4 字节组开始组数据
        for (int i = 1; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            int type = subData[0] & 0xff;
            int value = ((subData[1] & 0xff) << 8) | (subData[2] & 0xff);

            switch (type) {
                case 0:
                    info.heartRate = value;
                    break;
                case 1:
                    info.spo2 = value;
                    break;
                case 2:
                    info.pressure = value;
                    break;
                case 3:
                    info.temperature = JWUtils.parserRound(1, value / 10f);
                    break;
                case 4:
                    info.skinTemperature = JWUtils.parserRound(1, value / 10f);
                    break;
                case 5:
                    info.bloodVesselElasticity = value;
                    break;
                case 6:
                    info.cardiovascularRisk = value;
                    break;
                default:
                    break;
            }
        }
        return info;
    }

    public static List<JWHRVRmssdInfo> parseHRVRmssdData(byte[] data) {
        List<JWHRVRmssdInfo> infoList = new ArrayList<>();
        if ((data.length < 8) || (data.length % 8) != 0) {
            return infoList;
        }
        Calendar calendar = Calendar.getInstance();
        byte[] subData = new byte[8];
        for (int i = 0; i < data.length / 8; i++) {

            System.arraycopy(data, i * 8, subData, 0, 8);

            // 该时间戳为 2000.1.1 以后的秒
            long timestamp = (((subData[0] & 0xff) << 24) | ((subData[1] & 0xff) << 16) | ((subData[2] & 0xff) << 8) | ((subData[3] & 0xff)));
            int value = (((subData[4] & 0xff) << 8) | (subData[5] & 0xff)) & 0xffff;

            calendar.clear();
            calendar.set(2000, 0, 1);

            long time = calendar.getTimeInMillis();

            time += timestamp * 1000;

            JWHRVRmssdInfo info = new JWHRVRmssdInfo();

            info.time = time;
            info.userID = BaseManager.getInstance().getUserID();
            info.deviceMac = BaseManager.getInstance().getMacAddress();
            info.value = value;

            infoList.add(info);
        }

        return infoList;
    }


    public static JWDefaultFunctionInfo parseDefaultFunctionData(byte[] data) {
        JWDefaultFunctionInfo functionInfo = new JWDefaultFunctionInfo();
        if (data == null || data.length != 1) {
            return functionInfo;
        }
        byte key = data[0];
        functionInfo.bloodPressureEnable = (key & 1) == 1;
        functionInfo.temperatureEnable = (key >> 1 & 1) == 1;
        functionInfo.pressureEnable = (key >> 2 & 1) == 1;
        functionInfo.sceneEnable = (key >> 3 & 1) == 1;
        functionInfo.alexaEnable = (key >> 4 & 1) == 1;
        functionInfo.lightSenseEnable = (key >> 5 & 1) == 1;
        functionInfo.agingModeEnable = (key >> 6 & 1) != 1;

        return functionInfo;
    }

    public static List<JWUltravioletInfo> parseUltravioletData(byte[] data) {
        List<JWUltravioletInfo> infoList = new ArrayList<>();
        if ((data.length < 8) || (data.length % 8) != 0) {
            return infoList;
        }
        byte[] subData = new byte[8];
        for (int i = 0; i < data.length / 8; i++) {
            System.arraycopy(data, i * 8, subData, 0, 8);

            long startTime = (((subData[0] & 0xff)) | ((subData[1] & 0xff) << 8) | ((subData[2] & 0xff) << 16) | ((subData[3] & 0xff) << 24));
            long time = DateUtil.getDate(2000, 1, 1);
            startTime = startTime * 1000 + time;

            int value = subData[4] & 0xff;
            int vd = subData[5] & 0xff;
            int skin = subData[6] & 0xff;
            int skinCancer = subData[7] & 0xff;


            JWUltravioletInfo info = new JWUltravioletInfo();

            info.time = startTime;
            info.userID = BaseManager.getInstance().getUserID();
            info.deviceMac = BaseManager.getInstance().getMacAddress();
            info.value = value;
            info.vd = vd;
            info.skin = skin;
            info.skinCancer = skinCancer;

            infoList.add(info);
        }

        return infoList;
    }

    public static List<JWPressureInfo> parsePressureData(byte[] data) {
        List<JWPressureInfo> infoList = new ArrayList<>();
        if ((data.length < 8) || (data.length % 8) != 0) {
            return infoList;
        }
        byte[] subData = new byte[8];
        for (int i = 0; i < data.length / 8; i++) {

            System.arraycopy(data, i * 8, subData, 0, 8);

            // 该时间戳为 2000.1.1 以后的秒
            long timestamp = (((subData[0] & 0xff)) | ((subData[1] & 0xff) << 8) | ((subData[2] & 0xff) << 16) | ((subData[3] & 0xff) << 24));
            int value = subData[4] & 0xff;
            if (value == 0) {
                continue;
            }

            timestamp = timestamp * 1000 + 946656000000L;

            JWPressureInfo info = new JWPressureInfo();

            info.time = timestamp;
            info.userID = BaseManager.getInstance().getUserID();
            info.deviceMac = BaseManager.getInstance().getMacAddress();
            info.value = value;

            infoList.add(info);
        }

        return infoList;
    }

    public static JWHealthRiskAssessmentInfo parseHealthRiskAssessmentData(byte[] data) {
        JWHealthRiskAssessmentInfo info = new JWHealthRiskAssessmentInfo();
        if ((data.length < 2) || (data.length % 2) != 0) {
            return info;
        }

        byte[] subData = new byte[2];
        for (int i = 0; i < data.length / 2; i++) {

            System.arraycopy(data, i * 2, subData, 0, 2);

            int type = subData[0] & 0x0f;
            int value = subData[1] & 0x0f;

            if (type == 0) {
                info.bloodSugarEnable = value != 0;
            } else if (type == 1) {
                info.uricAcidEnable = value != 0;
            } else if (type == 2) {
                info.bloodFatEnable = value != 0;
            }
        }
        return info;
    }

}
