package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.util.DataConverter;
import com.wosmart.ukprotocollibary.util.SDKLogger;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

public class ApplicationLayerHrpItemPacket {

    /**
     * minute
     */
    private int mMinutes;             // 16bits

    /**
     * id
     */
    private int mSequenceNum;     //8 bits

    /**
     * heart rate value
     */
    private int mValue;             // 8bits

    /**
     * temperature value
     * 温度值
     */
    private float temperature;

    /**
     * temperature wear status
     * 佩戴状态 只与温度相关
     */
    private boolean wearStatus;

    /**
     * temperature adjust status
     * 补偿状态 与温度相关
     */
    private boolean adjustStatus;

    /**
     * 动画状态
     */
    private boolean animationStatus;

    /**
     * 原始值
     */
    private float tempOriginValue;

    /**
     * Packet Length
     */
    public final static int ITEM_LENGTH = 4;


    public final static int TEMP_LENGTH = 8;

    public boolean parseData(byte[] data) {
        // check header length
        SDKLogger.d(DataConverter.bytes2Hex(data));
        if (data.length >= TEMP_LENGTH) {
            animationStatus = ((data[1] >> 2) & 0x01) == 1 ? true : false;
            adjustStatus = ((data[1] >> 1) & 0x01) == 1 ? true : false;
            wearStatus = (data[1] & 0x01) == 1 ? true : false;

            int temp = ((data[2] << 8) | (data[3] & 0xff)) & 0xffff;// here must be care shift operation of negative
            if (temp > 0) {
                if (animationStatus) {
                    temperature = JWUtils.parserRound(1, temp / 10f);
                } else {
                    if (temp >= 368) {
                        temperature = JWUtils.parserRound(1, temp / 10f);
                    } else {
                        //手动检测的 只保留一位小数
                        if (wearStatus && adjustStatus) {
                            int temp2 = 368 - (368 - temp) / 20;
                            temperature = JWUtils.parserRound(1, temp2 / 10f);
                        } else {
                            temperature = JWUtils.parserRound(1, temp / 10f);
                        }
                    }
                }
            } else {
                temperature = 0f;
            }
            tempOriginValue = JWUtils.parserRound(1, temp / 10f);

            mMinutes = ((data[4] << 8) | (data[5] & 0xff)) & 0xffff;// here must be care shift operation of negative
            mSequenceNum = (data[6] & 0xff);
            //mValue = ((data[2] << 8) | (data[3] & 0xff)) & 0xffff;// here must be care shift operation of negative
            mValue = (data[7] & 0xff);
            return true;
        } else if (data.length >= ITEM_LENGTH) {
            mMinutes = ((data[0] << 8) | (data[1] & 0xff)) & 0xffff;// here must be care shift operation of negative
            mSequenceNum = (data[2] & 0xff);
            //mValue = ((data[2] << 8) | (data[3] & 0xff)) & 0xffff;// here must be care shift operation of negative
            mValue = (data[3] & 0xff);
            return true;
        } else {
            return false;
        }
    }

    public int getMinutes() {
        return mMinutes;
    }

    public int getSequenceNum() {
        return mSequenceNum;
    }

    public int getValue() {
        return mValue;
    }

    public float getTemperature() {
        return temperature;
    }

    public boolean isWearStatus() {
        return wearStatus;
    }

    public boolean isAdjustStatus() {
        return adjustStatus;
    }

    public boolean isAnimationStatus() {
        return animationStatus;
    }

    public float getTempOriginValue() {
        return tempOriginValue;
    }

    @Override
    public String toString() {
        return "ApplicationLayerHrpItemPacket{" +
                "mMinutes=" + mMinutes +
                ", mSequenceNum=" + mSequenceNum +
                ", mValue=" + mValue +
                ", temperature=" + temperature +
                ", wearStatus=" + wearStatus +
                ", adjustStatus=" + adjustStatus +
                ", tempOriginValue=" + tempOriginValue +
                '}';
    }
}
