package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.util.SDKLogger;

import java.util.Arrays;

public class ApplicationLayerScreenStylePacket {

    /**
     * cur screen index
     */
    private int curIndex;

    /**
     * screen theme count
     * 总风格数
     */
    private int total;

    public int getCurIndex() {
        return curIndex;
    }

    public void setCurIndex(int curIndex) {
        this.curIndex = curIndex;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public boolean parseData(byte[] data) {
        SDKLogger.d(true,"ApplicationLayerScreenStylePacket="+ Arrays.toString(data));
        if (data.length >= 1) {
            curIndex = data[0] & 0xFF;
            if (data.length >= 2) {
                total = data[1] & 0xff;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerScreenStylePacket{" +
                "curIndex=" + curIndex +
                ", total=" + total +
                '}';
    }
}
