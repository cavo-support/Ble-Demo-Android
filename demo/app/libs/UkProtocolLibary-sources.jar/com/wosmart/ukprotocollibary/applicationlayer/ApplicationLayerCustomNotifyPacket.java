package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.model.enums.DeviceFunctionStatus;

public class ApplicationLayerCustomNotifyPacket {

    /**
     *
     */
    private DeviceFunctionStatus Bus;

    /**
     *
     */
    private final int REMINDER_HEAD_LENGTH = 1;

    public DeviceFunctionStatus getBus() {
        return Bus;
    }

    public void setBus(DeviceFunctionStatus bus) {
        Bus = bus;
    }

    public ApplicationLayerCustomNotifyPacket() {

    }

    public byte[] getPacket() {
        byte[] data = new byte[REMINDER_HEAD_LENGTH];

        data[0] = (Bus == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x01 : (byte) 0x00);

        return data;
    }

    public boolean parseData(byte[] data) {
        if (data.length >= REMINDER_HEAD_LENGTH) {
            int bus = data[0] & 0x01;
            if (bus == 1) {
                Bus = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                Bus = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
        }
        return true;
    }
}
