package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerTempFunctionPacket {

    private ApplicationLayerMulPrivateBpPacket mulPrivateBpPacket;// 多命令--私人血压

    private ApplicationLayerMulTemperatureReminderPacket mulTemperatureReminder;// 多命令--体温提醒

    private ApplicationLayerMulDrinkWaterReminderPacket mulDrinkWaterReminder;// 多命令--喝水提醒

    private boolean isSupportSOS = false;// 多命令--SOS

    private boolean isSupportMedicationReminder = false;// 多命令--吃药提醒

    private boolean isSupportPulse = false;// 支持脉冲

    private boolean isSupportSleepHelp = false;// 支持睡眠辅助

    private boolean isSupportSauna = false;// 支持桑拿

    private boolean isSupportFemaleHealth = false;// 支持女性健康

    private boolean isSupportWeather = false;// 支持天气

    private boolean isSupportWearingTime = false;// 支持穿戴时间

    private boolean isSupportBodyFat = false;// 支持体脂
    private boolean isSupportPhysicalExam = false;// 支持体检
    private boolean isSupportUltraviolet = false;// 支持紫外线

    private ApplicationLayerMulUricAcidPacket uricAcidPacket;// 支持尿酸

    private ApplicationLayerMulBloodFatPacket bloodFatPacket;// 支持血脂

    private ApplicationLayerMulBloodSugarCyclePacket bloodSugarCyclePacket;// 支持血糖周期

    private ApplicationLayerMulPrivateUricAcidPacket privateUricAcidPacket;// 支持私人尿酸

    private ApplicationLayerMulPrivateBloodFatPacket privateBloodFatPacket;// 支持私人血脂

    public void init() {
        mulPrivateBpPacket = null;
        isSupportSOS = false;
        mulTemperatureReminder = null;
        mulDrinkWaterReminder = null;
        isSupportMedicationReminder = false;
        isSupportPulse = false;
        isSupportSleepHelp = false;
        isSupportSauna = false;
        isSupportFemaleHealth = false;
        isSupportWeather = false;
        isSupportWearingTime = false;
        isSupportBodyFat = false;
        isSupportPhysicalExam = false;
        isSupportUltraviolet = false;
        uricAcidPacket = null;
        bloodFatPacket = null;
        bloodSugarCyclePacket = null;
        privateUricAcidPacket = null;
        privateBloodFatPacket = null;
    }

    public ApplicationLayerMulPrivateBpPacket getMulPrivateBpPacket() {
        return mulPrivateBpPacket;
    }

    public void setMulPrivateBpPacket(ApplicationLayerMulPrivateBpPacket mulPrivateBpPacket) {
        this.mulPrivateBpPacket = mulPrivateBpPacket;
    }

    public boolean isSupportSOS() {
        return isSupportSOS;
    }

    public void setSupportSOS(boolean supportSOS) {
        isSupportSOS = supportSOS;
    }

    public ApplicationLayerMulTemperatureReminderPacket getMulTemperatureReminder() {
        return mulTemperatureReminder;
    }

    public void setMulTemperatureReminder(ApplicationLayerMulTemperatureReminderPacket mulTemperatureReminder) {
        this.mulTemperatureReminder = mulTemperatureReminder;
    }

    public ApplicationLayerMulDrinkWaterReminderPacket getMulDrinkWaterReminder() {
        return mulDrinkWaterReminder;
    }

    public void setMulDrinkWaterReminder(ApplicationLayerMulDrinkWaterReminderPacket mulDrinkWaterReminder) {
        this.mulDrinkWaterReminder = mulDrinkWaterReminder;
    }

    public boolean isSupportMedicationReminder() {
        return isSupportMedicationReminder;
    }

    public void setSupportMedicationReminder(boolean supportMedicationReminder) {
        isSupportMedicationReminder = supportMedicationReminder;
    }

    public boolean isSupportPulse() {
        return isSupportPulse;
    }

    public void setSupportPulse(boolean supportPulse) {
        isSupportPulse = supportPulse;
    }

    public boolean isSupportSleepHelp() {
        return isSupportSleepHelp;
    }

    public void setSupportSleepHelp(boolean supportSleepHelp) {
        isSupportSleepHelp = supportSleepHelp;
    }

    public boolean isSupportSauna() {
        return isSupportSauna;
    }

    public void setSupportSauna(boolean supportSauna) {
        isSupportSauna = supportSauna;
    }

    public boolean isSupportFemaleHealth() {
        return isSupportFemaleHealth;
    }

    public void setSupportFemaleHealth(boolean supportFemaleHealth) {
        isSupportFemaleHealth = supportFemaleHealth;
    }

    public boolean isSupportWeather() {
        return isSupportWeather;
    }

    public void setSupportWeather(boolean supportWeather) {
        isSupportWeather = supportWeather;
    }

    public boolean isSupportWearingTime() {
        return isSupportWearingTime;
    }

    public void setSupportWearingTime(boolean supportWearingTime) {
        isSupportWearingTime = supportWearingTime;
    }

    public boolean isSupportBodyFat() {
        return isSupportBodyFat;
    }

    public void setSupportBodyFat(boolean supportBodyFat) {
        isSupportBodyFat = supportBodyFat;
    }

    public boolean isSupportPhysicalExam() {
        return isSupportPhysicalExam;
    }

    public void setSupportPhysicalExam(boolean supportPhysicalExam) {
        isSupportPhysicalExam = supportPhysicalExam;
    }

    public boolean isSupportUltraviolet() {
        return isSupportUltraviolet;
    }

    public void setSupportUltraviolet(boolean supportUltraviolet) {
        isSupportUltraviolet = supportUltraviolet;
    }

    public ApplicationLayerMulUricAcidPacket getUricAcidPacket() {
        return uricAcidPacket;
    }

    public void setUricAcidPacket(ApplicationLayerMulUricAcidPacket uricAcidPacket) {
        this.uricAcidPacket = uricAcidPacket;
    }

    public ApplicationLayerMulBloodFatPacket getBloodFatPacket() {
        return bloodFatPacket;
    }

    public void setBloodFatPacket(ApplicationLayerMulBloodFatPacket bloodFatPacket) {
        this.bloodFatPacket = bloodFatPacket;
    }

    public ApplicationLayerMulBloodSugarCyclePacket getBloodSugarCyclePacket() {
        return bloodSugarCyclePacket;
    }

    public void setBloodSugarCyclePacket(ApplicationLayerMulBloodSugarCyclePacket bloodSugarCyclePacket) {
        this.bloodSugarCyclePacket = bloodSugarCyclePacket;
    }

    public ApplicationLayerMulPrivateUricAcidPacket getPrivateUricAcidPacket() {
        return privateUricAcidPacket;
    }

    public void setPrivateUricAcidPacket(ApplicationLayerMulPrivateUricAcidPacket privateUricAcidPacket) {
        this.privateUricAcidPacket = privateUricAcidPacket;
    }

    public ApplicationLayerMulPrivateBloodFatPacket getPrivateBloodFatPacket() {
        return privateBloodFatPacket;
    }

    public void setPrivateBloodFatPacket(ApplicationLayerMulPrivateBloodFatPacket privateBloodFatPacket) {
        this.privateBloodFatPacket = privateBloodFatPacket;
    }
}



