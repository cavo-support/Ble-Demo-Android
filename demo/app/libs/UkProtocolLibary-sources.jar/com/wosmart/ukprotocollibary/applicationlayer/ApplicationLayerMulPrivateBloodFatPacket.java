package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

public class ApplicationLayerMulPrivateBloodFatPacket {

    private boolean isOpen;
    private float value;

    // Packet Length
    private final static int HEADER_LENGTH = 5;

    public ApplicationLayerMulPrivateBloodFatPacket() {

    }

    public boolean parseData(byte[] data) {
        // check header length
        if (data.length < HEADER_LENGTH) {
            return false;
        }
        isOpen = (data[0] == 0x01);
        int tempValue = ((data[1] & 0xff) << 8) | (data[2] & 0xff);

        value = JWUtils.parserRound(2, tempValue / 100f);
        return true;
    }


    public boolean isOpen() {
        return isOpen;
    }

    public void setOpen(boolean open) {
        isOpen = open;
    }

    public float getValue() {
        return value;
    }

    public void setValue(float value) {
        this.value = value;
    }


    @Override
    public String toString() {
        return "ApplicationLayerMulPrivateBloodFatPacket{" +
                "isOpen=" + isOpen +
                ", value=" + value +
                '}';
    }
}
