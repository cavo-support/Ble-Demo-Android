package com.wosmart.ukprotocollibary.applicationlayer;

import java.util.ArrayList;
import java.util.List;

public class ApplicationLayerRateListPacket {

    /**
     * rate data list
     */
    List<ApplicationLayerRateItemPacket> rateList = new ArrayList<>();

    public List<ApplicationLayerRateItemPacket> getRateList() {
        return rateList;
    }

    public void setRateList(List<ApplicationLayerRateItemPacket> rateList) {
        this.rateList = rateList;
    }

    private final static int HRP_ITEM_LENGTH = 8;

    private final static int HRP_ITEM_LENGTH2 = 12;

    public boolean parseData(byte[] data) {
        int size = data.length;
        if (size < 12) {
            // 只有一个数据包，按 8 字节解析
            byte[] temp = new byte[8];
            System.arraycopy(data, 0, temp, 0, 8);
            ApplicationLayerRateItemPacket packet = new ApplicationLayerRateItemPacket();
            packet.parseData(temp);
            rateList.add(packet);
        } else {
            int itemLength;
            int dataType;
            // 先取第 11，12 字节判断数据类型
            byte n11 = data[10];
            byte n12 = data[11];
            if (n11 == 0 && n12 == 0) {
                itemLength = 12;
                dataType = 8;
            } else if (n11 == 0 && n12 == 1) {
                itemLength = 8;
                dataType = 8;
            } else {
                itemLength = 12;
                dataType = 12;
            }

            //   1. 取接收数据包前12个字节的最后2字节做为判断条件
            //    1. 等于0x0000: item长度12字节，8B解析
            //    2. 等于0x0001: item长度8字节，8B解析
            //    3. 其他: item长度12字节，12B解析
            int count = size / itemLength;
            for (int i = 0; i < count; i++) {
                byte[] temp = new byte[dataType];
                System.arraycopy(data, i * itemLength, temp, 0, dataType);
                ApplicationLayerRateItemPacket packet = new ApplicationLayerRateItemPacket();
                packet.parseData(temp);
                rateList.add(packet);
            }
        }
        return true;
    }

    public boolean parseData2(byte[] data) {
        // 只按 12 个字节解析
        int itemLength = 12;
        int dataType = 12;

        int count = data.length / 12;
        for (int i = 0; i < count; i++) {
            byte[] temp = new byte[12];
            System.arraycopy(data, i * itemLength, temp, 0, dataType);
            ApplicationLayerRateItemPacket packet = new ApplicationLayerRateItemPacket();
            packet.parseData(temp);
            rateList.add(packet);
        }
        return true;
    }

//    public boolean parseData(byte[] data) {
//        int size = data.length;
//        if (size >= HRP_ITEM_LENGTH) {
//            int count = size / HRP_ITEM_LENGTH;
//            for (int i = 0; i < count; i++) {
//                ApplicationLayerRateItemPacket packet = new ApplicationLayerRateItemPacket();
//                byte[] temp = new byte[HRP_ITEM_LENGTH];
//                System.arraycopy(data, i * HRP_ITEM_LENGTH, temp, 0, HRP_ITEM_LENGTH);
//                packet.parseData(temp);
//                rateList.add(packet);
//            }
//        }
//        return true;
//    }

//    public boolean parseData2(byte[] data) {
//        int size = data.length;
//        if (size >= HRP_ITEM_LENGTH2) {
//            int count = size / HRP_ITEM_LENGTH2;
//            for (int i = 0; i < count; i++) {
//                ApplicationLayerRateItemPacket packet = new ApplicationLayerRateItemPacket();
//                byte[] temp = new byte[HRP_ITEM_LENGTH2];
//                System.arraycopy(data, i * HRP_ITEM_LENGTH2, temp, 0, HRP_ITEM_LENGTH2);
//                packet.parseData(temp);
//                rateList.add(packet);
//            }
//        }
//        return true;
//    }

    @Override
    public String toString() {
        return "ApplicationLayerRateListPacket{" +
                "rateList=" + rateList +
                '}';
    }
}
