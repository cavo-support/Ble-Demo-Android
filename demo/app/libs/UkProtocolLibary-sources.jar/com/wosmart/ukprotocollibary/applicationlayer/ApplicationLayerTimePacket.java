package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerTimePacket {

    /**
     * year
     */
    private int mYear;        // 6bits

    /**
     * month
     */
    private int mMonth;        // 4bits

    /**
     * day
     */
    private int mDay;        // 5bits

    /**
     * hour
     */
    private int mHour;        // 5bits

    /**
     * minute
     */
    private int mMinute;    // 6bits

    /**
     * seconds
     */
    private int mSecond;    // 6bits

    /**
     * Packet Length
     */
    private final static int TIMER_HEADER_LENGTH = 4;

    public ApplicationLayerTimePacket(int year, int mon, int day, int hour, int min, int sec) {
        mYear = year - 2000;// year start from 2000
        mMonth = mon;
        mDay = day;
        mHour = hour;
        mMinute = min;
        mSecond = sec;
    }

    public byte[] getPacket() {
        byte[] time_data = new byte[TIMER_HEADER_LENGTH];
        time_data[0] = (byte) ((mYear << 2) | (mMonth >> 2));
        time_data[1] = (byte) ((mMonth << 6) | (mDay << 1) | (mHour >> 4));
        time_data[2] = (byte) ((mHour << 4) | (mMinute >> 2));
        time_data[3] = (byte) ((mMinute << 6) | (mSecond));
        return time_data;
    }

    @Override
    public String toString() {
        return "ApplicationLayerTimePacket{" +
                "mYear=" + mYear +
                ", mMonth=" + mMonth +
                ", mDay=" + mDay +
                ", mHour=" + mHour +
                ", mMinute=" + mMinute +
                ", mSecond=" + mSecond +
                '}';
    }
}
