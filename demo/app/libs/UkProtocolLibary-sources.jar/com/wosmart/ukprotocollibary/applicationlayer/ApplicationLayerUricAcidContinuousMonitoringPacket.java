package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerUricAcidContinuousMonitoringPacket {

    private int value;
    private int rtcTime;

    // Packet Length
    private final static int HEADER_LENGTH = 8;

    public ApplicationLayerUricAcidContinuousMonitoringPacket() {

    }

    public boolean parseData(byte[] data) {
        // check header length
        if (data.length < HEADER_LENGTH) {
            return false;
        }
        rtcTime = ((data[0] & 0xff)) | ((data[1] & 0xff) << 8) | ((data[2] & 0xff) << 16) | ((data[3] & 0xff) << 24);
        value = ((data[4] & 0xff) << 8) | (data[5] & 0xff);

        return true;
    }


    @Override
    public String toString() {
        return "ApplicationLayerUricAcidContinuousMonitoringPacket{" +
                "value=" + value +
                ", rtcTime=" + rtcTime +
                '}';
    }
}
