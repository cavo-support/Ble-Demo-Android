package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerCalcTargetPacket {

    /**
     * calc goal  minutes
     */
    private int mCalcTarget;            // 2byte

    /**
     * Packet Length
     */
    private final static int CALC_HEADER_LENGTH = 2;

    public ApplicationLayerCalcTargetPacket() {
    }

    public ApplicationLayerCalcTargetPacket(int mCalcTarget) {
        this.mCalcTarget = mCalcTarget;
    }


    public int getmCalcTarget() {
        return mCalcTarget;
    }

    public void setmCalcTarget(int mCalcTarget) {
        this.mCalcTarget = mCalcTarget;
    }

    public byte[] getPacket() {
        byte[] data = new byte[CALC_HEADER_LENGTH];
        data[0] = (byte) ((mCalcTarget >> 8) & 0xff);
        data[1] = (byte) (mCalcTarget & 0xff);
        return data;
    }

    @Override
    public String toString() {
        return "ApplicationLayerSleepTargetPacket{" +
                "mCalcTarget=" + mCalcTarget +
                '}';
    }
}
