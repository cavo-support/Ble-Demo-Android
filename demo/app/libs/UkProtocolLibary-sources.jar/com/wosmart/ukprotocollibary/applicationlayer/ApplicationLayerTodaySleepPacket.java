package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerTodaySleepPacket {
    private int fallSleep;

    private int wakeNum;

    private int lightSleep;

    private int lightSleep2;

    private int lightSleep3;

    private int deepSleep;

    private int deepSleep2;

    private int deepSleep3;

    /**
     * Packet Length
     */
    public final static int SLEEP_PACKAGE_LENGTH = 14;

    public ApplicationLayerTodaySleepPacket() {
    }

    public int getFallSleep() {
        return fallSleep;
    }

    public int getWakeNum() {
        return wakeNum;
    }

    public int getLightSleep() {
        return lightSleep;
    }

    public int getLightSleep2() {
        return lightSleep2;
    }

    public int getLightSleep3() {
        return lightSleep3;
    }

    public int getDeepSleep() {
        return deepSleep;
    }

    public int getDeepSleep2() {
        return deepSleep2;
    }

    public int getDeepSleep3() {
        return deepSleep3;
    }

    public boolean parseData(byte[] data) {
        if (data.length >= SLEEP_PACKAGE_LENGTH) {
            fallSleep = data[0] & 0xff;
            wakeNum = ((data[1] << 8) & 0xff00) | (data[2] & 0xff);

            lightSleep = ((data[2] << 8) & 0xff00) | (data[3] & 0xff);
            lightSleep2 = ((data[4] << 8) & 0xff00) | (data[5] & 0xff);
            lightSleep3 = ((data[6] << 8) & 0xff00) | (data[7] & 0xff);

            deepSleep = ((data[8] << 8) & 0xff00) | (data[9] & 0xff);
            deepSleep2 = ((data[10] << 8) & 0xff00) | (data[11] & 0xff);
            deepSleep3 = ((data[12] << 8) & 0xff00) | (data[13] & 0xff);

        }
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerTodaySleepPacket{" +
                "fallSleep=" + fallSleep +
                ", wakeNum=" + wakeNum +
                ", lightSleep=" + lightSleep +
                ", lightSleep2=" + lightSleep2 +
                ", lightSleep3=" + lightSleep3 +
                ", deepSleep=" + deepSleep +
                ", deepSleep2=" + deepSleep2 +
                ", deepSleep3=" + deepSleep3 +
                '}';
    }
}
