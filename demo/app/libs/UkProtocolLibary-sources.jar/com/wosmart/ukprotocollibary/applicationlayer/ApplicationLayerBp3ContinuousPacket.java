package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerBp3ContinuousPacket {

    /**
     * 1--连续血压采集
     * 0--禁止连续血压采集
     */
    private int switchIsOpen;
    /**
     * 时间（单位：分钟）
     */
    private int time;

    public boolean parseData(byte[] data){
        if(data.length >= 2){
            switchIsOpen = data[0] & 0xff;
            time = data[1] & 0xff;
        }else if(data.length >= 1){
            switchIsOpen = data[0] & 0xff;
        }else{
            return false;
        }
        return true;
    }

    public int getSwitchIsOpen() {
        return switchIsOpen;
    }

    public void setSwitchIsOpen(int switchIsOpen) {
        this.switchIsOpen = switchIsOpen;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "ApplicationLayerBp3ContinuousPacket{" +
                "switchIsOpen=" + switchIsOpen +
                ", time=" + time +
                '}';
    }
}
