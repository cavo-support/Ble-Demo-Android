package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.model.enums.DeviceFunctionStatus;

/**
 * device support function
 */
public class ApplicationLayerMultiSportPacket {
    /**
     *
     */
    private DeviceFunctionStatus Run;

    /**
     *
     */
    private DeviceFunctionStatus Climb;

    /**
     *
     */
    private DeviceFunctionStatus Football;

    /**
     *
     */
    private DeviceFunctionStatus Cycle;

    /**
     *
     */
    private DeviceFunctionStatus Rope;

    /**
     *
     */
    private DeviceFunctionStatus RunOutDoor;

    /**
     *
     */
    private DeviceFunctionStatus RideOutDoor;

    /**
     *
     */
    private DeviceFunctionStatus WalkOutDoor;

    /**
     *
     */
    private DeviceFunctionStatus RunInDoor;

    /**
     *
     */
    private DeviceFunctionStatus FreeTrain;

    /**
     *
     */
    private DeviceFunctionStatus Plank;

    /**
     * package length
     */
    private int SPORT_HEAD_LENGTH = 4;

    public ApplicationLayerMultiSportPacket() {
    }

    public DeviceFunctionStatus getRun() {
        return Run;
    }

    public void setRun(DeviceFunctionStatus run) {
        Run = run;
    }

    public DeviceFunctionStatus getClimb() {
        return Climb;
    }

    public void setClimb(DeviceFunctionStatus climb) {
        Climb = climb;
    }

    public DeviceFunctionStatus getFootball() {
        return Football;
    }

    public void setFootball(DeviceFunctionStatus football) {
        Football = football;
    }

    public DeviceFunctionStatus getCycle() {
        return Cycle;
    }

    public void setCycle(DeviceFunctionStatus cycle) {
        Cycle = cycle;
    }

    public DeviceFunctionStatus getRope() {
        return Rope;
    }

    public void setRope(DeviceFunctionStatus rope) {
        Rope = rope;
    }

    public DeviceFunctionStatus getRunOutDoor() {
        return RunOutDoor;
    }

    public void setRunOutDoor(DeviceFunctionStatus runOutDoor) {
        RunOutDoor = runOutDoor;
    }

    public DeviceFunctionStatus getRideOutDoor() {
        return RideOutDoor;
    }

    public void setRideOutDoor(DeviceFunctionStatus rideOutDoor) {
        RideOutDoor = rideOutDoor;
    }

    public DeviceFunctionStatus getWalkOutDoor() {
        return WalkOutDoor;
    }

    public void setWalkOutDoor(DeviceFunctionStatus walkOutDoor) {
        WalkOutDoor = walkOutDoor;
    }

    public DeviceFunctionStatus getRunInDoor() {
        return RunInDoor;
    }

    public void setRunInDoor(DeviceFunctionStatus runInDoor) {
        RunInDoor = runInDoor;
    }

    public DeviceFunctionStatus getFreeTrain() {
        return FreeTrain;
    }

    public void setFreeTrain(DeviceFunctionStatus freeTrain) {
        FreeTrain = freeTrain;
    }

    public DeviceFunctionStatus getPlank() {
        return Plank;
    }

    public void setPlank(DeviceFunctionStatus plank) {
        Plank = plank;
    }

    public boolean parseData(byte[] data) {
        if (data.length >= SPORT_HEAD_LENGTH) {
            int run = data[0] & 0x01;
            int climb = (data[0] >> 1) & 0x01;
            int footBall = (data[0] >> 2) & 0x01;
            int cycle = (data[0] >> 3) & 0x01;
            int rope = (data[0] >> 4) & 0x01;
            int runOutDoor = (data[0] >> 5) & 0x01;
            int rideOutDoor = (data[0] >> 6) & 0x01;
            int walkOutDoor = (data[0] >> 7) & 0x01;

            int runInDoor = data[1] & 0x01;
            int freeTrain = (data[1] >> 1) & 0x01;
            int plank = (data[1] >> 2) & 0x01;

            if (run == 1) {
                this.Run = DeviceFunctionStatus.SUPPORT;
            } else {
                this.Run = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (climb == 1) {
                this.Climb = DeviceFunctionStatus.SUPPORT;
            } else {
                this.Climb = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (footBall == 1) {
                this.Football = DeviceFunctionStatus.SUPPORT;
            } else {
                this.Football = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (cycle == 1) {
                this.Cycle = DeviceFunctionStatus.SUPPORT;
            } else {
                this.Cycle = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (rope == 1) {
                this.Rope = DeviceFunctionStatus.SUPPORT;
            } else {
                this.Rope = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (runOutDoor == 1) {
                this.RunOutDoor = DeviceFunctionStatus.SUPPORT;
            } else {
                this.RunOutDoor = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (rideOutDoor == 1) {
                this.RideOutDoor = DeviceFunctionStatus.SUPPORT;
            } else {
                this.RideOutDoor = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (walkOutDoor == 1) {
                this.WalkOutDoor = DeviceFunctionStatus.SUPPORT;
            } else {
                this.WalkOutDoor = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (runInDoor == 1) {
                this.RunInDoor = DeviceFunctionStatus.SUPPORT;
            } else {
                this.RunInDoor = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (freeTrain == 1) {
                this.FreeTrain = DeviceFunctionStatus.SUPPORT;
            } else {
                this.FreeTrain = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (plank == 1) {
                this.Plank = DeviceFunctionStatus.SUPPORT;
            } else {
                this.Plank = DeviceFunctionStatus.UN_SUPPORT;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerMultiSportPacket{" +
                "Run=" + Run +
                ", Climb=" + Climb +
                ", Football=" + Football +
                ", Cycle=" + Cycle +
                ", Rope=" + Rope +
                ", RunOutDoor=" + RunOutDoor +
                ", RideOutDoor=" + RideOutDoor +
                ", WalkOutDoor=" + WalkOutDoor +
                ", RunInDoor=" + RunInDoor +
                ", FreeTrain=" + FreeTrain +
                ", Plank=" + Plank +
                '}';
    }
}
