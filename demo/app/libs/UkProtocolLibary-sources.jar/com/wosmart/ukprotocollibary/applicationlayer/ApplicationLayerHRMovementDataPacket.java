package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.entity.JWHRMovementInfo;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

import java.util.ArrayList;
import java.util.List;


public class ApplicationLayerHRMovementDataPacket {

    public List<JWHRMovementInfo> hrMovementInfoList = new ArrayList<>();

    public boolean parseData(byte[] data) {
        if ((data.length < 8) || (data.length % 8) != 0) {
            return false;
        }
        byte[] subData = new byte[8];
        for (int i = 0; i < data.length / 8; i++) {
            System.arraycopy(data, i * 8, subData, 0, 8);

            // 该时间戳为 2000.1.1 以后的秒
            long timestamp = (((subData[0] & 0xff) << 24) | ((subData[1] & 0xff) << 16) | ((subData[2] & 0xff) << 8) | ((subData[3] & 0xff)));
            int heartRateValue = subData[4] & 0xff;
            int temperature = (((subData[5] & 0xff) << 8) | (subData[6] & 0xff)) & 0xffff;
            int label = (subData[7] >> 4) & 0x0f;
            int movement = subData[7] & 0x0f;

            long time = DateUtil.getDate(2000, 1, 1);

            time += (timestamp * 1000);

            JWHRMovementInfo info = new JWHRMovementInfo();

            info.time = time;
            info.heartRateValue = heartRateValue;
            info.temperature = JWUtils.parserRound(1, temperature / 10f);
            info.label = label;
            info.movement = movement;

            hrMovementInfoList.add(info);
        }
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerHRMovementDataPacket{" +
                "hrMovementInfoList=" + hrMovementInfoList +
                '}';
    }
}
