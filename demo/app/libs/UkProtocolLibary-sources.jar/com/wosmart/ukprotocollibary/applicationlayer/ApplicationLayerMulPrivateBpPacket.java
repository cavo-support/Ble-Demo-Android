package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerMulPrivateBpPacket {

    private boolean isOpen;
    private int highBp;
    private int lowBp;

    // Packet Length
    private final static int HEADER_LENGTH = 3;

    public ApplicationLayerMulPrivateBpPacket() {

    }

    public ApplicationLayerMulPrivateBpPacket(boolean isOpen, int highBp, int lowBp) {
        this.isOpen = isOpen;
        this.highBp = highBp;
        this.lowBp = lowBp;
    }

    public boolean parseData(byte[] data) {
        // check header length
        if (data.length < HEADER_LENGTH) {
            return false;
        }
        isOpen = ((data[0]) == 0x01);
        highBp = (data[1] & 0xFF);
        lowBp = (data[2] & 0xFF);
        return true;
    }

    public byte[] getPacket() {
        byte[] data = new byte[3];
        data[0] = (byte) (isOpen ? 0x01 : 0x00);
        data[1] = (byte) (highBp & 0xff);
        data[2] = (byte) (lowBp & 0xff);

        return data;
    }

    public boolean isOpen() {
        return isOpen;
    }

    public int getLowBp() {
        return lowBp;
    }

    public int getHighBp() {
        return highBp;
    }

    @Override
    public String toString() {
        return "ApplicationLayerMulPrivateBpPacket{" +
                "isOpen=" + isOpen +
                ", highBp=" + highBp +
                ", lowBp=" + lowBp +
                '}';
    }
}
