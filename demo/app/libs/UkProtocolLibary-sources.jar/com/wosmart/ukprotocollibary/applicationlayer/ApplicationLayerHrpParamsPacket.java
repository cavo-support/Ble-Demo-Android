package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.model.enums.DeviceFunctionStatus;

/**
 * 支持的心率检测间隔
 */
public class ApplicationLayerHrpParamsPacket {

    /**
     * rate detect every second
     * 连续检测
     */
    private DeviceFunctionStatus consequentDetect;

    /**
     * rate detect five minute
     */
    private DeviceFunctionStatus fiveMinuteDetect;

    /**
     * rate detect ten minute
     */
    private DeviceFunctionStatus tenMinuteDetect;

    /**
     * rate detect 30 minute
     */
    private DeviceFunctionStatus halfHourDetect;

    /**
     * rate detect one hour
     */
    private DeviceFunctionStatus oneHourDetect;

    /**
     * rate detect two hour
     */
    private DeviceFunctionStatus twoHourDetect;

    /**
     * package length
     */
    private final int HEAD_LENGTH = 1;

    public ApplicationLayerHrpParamsPacket() {
    }

    public DeviceFunctionStatus getConsequentDetect() {
        return consequentDetect;
    }

    public void setConsequentDetect(DeviceFunctionStatus consequentDetect) {
        this.consequentDetect = consequentDetect;
    }

    public DeviceFunctionStatus getFiveMinuteDetect() {
        return fiveMinuteDetect;
    }

    public void setFiveMinuteDetect(DeviceFunctionStatus fiveMinuteDetect) {
        this.fiveMinuteDetect = fiveMinuteDetect;
    }

    public DeviceFunctionStatus getTenMinuteDetect() {
        return tenMinuteDetect;
    }

    public void setTenMinuteDetect(DeviceFunctionStatus tenMinuteDetect) {
        this.tenMinuteDetect = tenMinuteDetect;
    }

    public DeviceFunctionStatus getHalfHourDetect() {
        return halfHourDetect;
    }

    public void setHalfHourDetect(DeviceFunctionStatus halfHourDetect) {
        this.halfHourDetect = halfHourDetect;
    }

    public DeviceFunctionStatus getOneHourDetect() {
        return oneHourDetect;
    }

    public void setOneHourDetect(DeviceFunctionStatus oneHourDetect) {
        this.oneHourDetect = oneHourDetect;
    }

    public DeviceFunctionStatus getTwoHourDetect() {
        return twoHourDetect;
    }

    public void setTwoHourDetect(DeviceFunctionStatus twoHourDetect) {
        this.twoHourDetect = twoHourDetect;
    }

    public boolean parseData(byte[] data) {
        if (data.length >= HEAD_LENGTH) {
            int consequent = data[0] & 0x01;
            int fiveMinute = (data[0] >> 1) & 0x01;
            int tenMinute = (data[0] >> 2) & 0x01;
            int halfHour = (data[0] >> 3) & 0x01;
            int oneHour = (data[0] >> 4) & 0x01;
            int twoHour = (data[0] >> 5) & 0x01;

            if (consequent == 1) {
                consequentDetect = DeviceFunctionStatus.SUPPORT;
            } else {
                consequentDetect = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (fiveMinute == 1) {
                fiveMinuteDetect = DeviceFunctionStatus.SUPPORT;
            } else {
                fiveMinuteDetect = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (tenMinute == 1) {
                tenMinuteDetect = DeviceFunctionStatus.SUPPORT;
            } else {
                tenMinuteDetect = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (halfHour == 1) {
                halfHourDetect = DeviceFunctionStatus.SUPPORT;
            } else {
                halfHourDetect = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (oneHour == 1) {
                oneHourDetect = DeviceFunctionStatus.SUPPORT;
            } else {
                oneHourDetect = DeviceFunctionStatus.UN_SUPPORT;
            }
            if (twoHour == 1) {
                twoHourDetect = DeviceFunctionStatus.SUPPORT;
            } else {
                twoHourDetect = DeviceFunctionStatus.UN_SUPPORT;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerHrpParamsPacket{" +
                "consequentDetect=" + consequentDetect +
                ", fiveMinuteDetect=" + fiveMinuteDetect +
                ", tenMinuteDetect=" + tenMinuteDetect +
                ", halfHourDetect=" + halfHourDetect +
                ", oneHourDetect=" + oneHourDetect +
                ", twoHourDetect=" + twoHourDetect +
                '}';
    }
}
