package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerMulPrivateUricAcidPacket {

    private boolean isOpen;
    private int value;

    // Packet Length
    private final static int HEADER_LENGTH = 5;

    public ApplicationLayerMulPrivateUricAcidPacket() {

    }

    public boolean parseData(byte[] data) {
        // check header length
        if (data.length < HEADER_LENGTH) {
            return false;
        }
        isOpen = (data[0] == 0x01);
        value = ((data[1] & 0xff) << 8) | (data[2] & 0xff);

        return true;
    }


    public boolean isOpen() {
        return isOpen;
    }

    public void setOpen(boolean open) {
        isOpen = open;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }


    @Override
    public String toString() {
        return "ApplicationLayerMulPrivateUricAcidPacket{" +
                "isOpen=" + isOpen +
                ", value=" + value +
                '}';
    }
}
