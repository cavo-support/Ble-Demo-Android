package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerSleepItemPacket {

    /**
     * minute
     * 从当天的0点开始的分钟数
     * 如1440，即为当天的24点
     */
    private int mMinutes;            // 16bits

    /**
     * sleep model
     * 1 light sleep
     * 2 deep sleep
     * 3 awake
     */
    private int mMode;                // 4bits

    /**
     * Packet Length
     */
    public final static int SLEEP_ITEM_LENGTH = 4;

    public boolean parseData(byte[] data) {
        // check header length
        if (data.length < SLEEP_ITEM_LENGTH) {
            return false;
        }
        mMinutes = ((data[0] << 8) | (data[1] & 0xff)) & 0xffff;// here must be care shift operation of negative
        mMode = data[3] & 0x0f;// here must be care shift operation of negative
        return true;
    }

    public int getMinutes() {
        return mMinutes;
    }

    public int getMode() {
        return mMode;
    }

    @Override
    public String toString() {
        return "ApplicationLayerSleepItemPacket{" +
                "mMinutes=" + mMinutes +
                ", mMode=" + mMode +
                '}';
    }
}
