package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerSleepTimeAdjustPacket {

    /**
     * fall sleep minute
     */
    private int fallSleepMinute;

    /**
     * wake up minute
     */
    private int wakeUpMinute;

    /**
     * Packet Length
     */
    private final static int SIT_HEADER_LENGTH = 4;

    public ApplicationLayerSleepTimeAdjustPacket() {

    }

    public ApplicationLayerSleepTimeAdjustPacket(int fallSleepMinute, int wakeUpMinute) {
        this.fallSleepMinute = fallSleepMinute;
        this.wakeUpMinute = wakeUpMinute;
    }

    public int getFallSleepMinute() {
        return fallSleepMinute;
    }

    public void setFallSleepMinute(int fallSleepMinute) {
        this.fallSleepMinute = fallSleepMinute;
    }

    public int getWakeUpMinute() {
        return wakeUpMinute;
    }

    public void setWakeUpMinute(int wakeUpMinute) {
        this.wakeUpMinute = wakeUpMinute;
    }

    public byte[] getPacket() {
        byte[] data = new byte[SIT_HEADER_LENGTH];


        data[0] = (byte) ((wakeUpMinute >> 8) & 0xff);
        data[1] = (byte) (wakeUpMinute & 0xff);

        data[2] = (byte) ((fallSleepMinute >> 8) & 0xff);
        data[3] = (byte) (fallSleepMinute & 0xff);
        return data;
    }

//    public boolean parseData(byte[] data) {
//        if (data.length >= SIT_HEADER_LENGTH) {
//            mDayFlags = data[0];
//            mStopNotifyTime = data[1] & 0xff;
//            mStartNotifyTime = data[2] & 0xff;
//            mNotifyTime = data[3] & 0xff;
//            mThreshold = ((data[5] << 8) & 0xff00) | (data[4] & 0xff);
//            mEnable = data[6] == LONG_SIT_CONTROL_ENABLE ? true : false;
//        }
//        return true;
//    }


    @Override
    public String toString() {
        return "ApplicationLayerSleepTimeAdjustPacket{" +
                "fallSleepMinute=" + fallSleepMinute +
                ", wakeUpMinute=" + wakeUpMinute +
                '}';
    }
}
