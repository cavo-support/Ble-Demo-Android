package com.wosmart.ukprotocollibary.applicationlayer;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class ApplicationLayerEcgBeltToDevicePacket {

    /**
     * 返回数据类型
     * 0--测试结束
     * 1--测试开始
     * 2--QT、HTV等参数返回
     * 3--图表数据
     * 4--测试状态
     */
    private int dataType = -1;
    /**
     * 年--22
     */
    private int year;
    /**
     * 月--7
     */
    private int month;
    /**
     * 日--5
     */
    private int day;
    private int hour;
    private int minute;
    private int second;
    private int bpmNumber;
    private int qtNumber;
    private int hrvNumber;
    private int rriNumber;
    private int progress;
    /**
     * 图表数据
     */
    private List<Integer> filterSigns;

    /**
     * 1 正在测试
     * 2/4 停止
     * 3 中断(导联脱落)
     */
    private int testState;

    public boolean parseData(byte[] data) {
        // check header length
//        SDKLogger.d(true,"\ndata.length="+data.length+"\ndata="+ Arrays.toString(data)+"\ndataHex="+ DataConverter.bytes2Hex(data));
        dataType = data[0] & 0xff;
        if(dataType == 0 || dataType == 1){
            year = data[1] & 0xff;
            month = data[2] & 0xff;
            day = data[3] & 0xff;
            hour = data[4] & 0xff;
            minute = data[5] & 0xff;
            second = data[6] & 0xff;
        }else if(dataType == 2){
            bpmNumber = data[1] & 0xff;
            qtNumber = ((data[2] & 0xff) << 8) | (data[3] & 0xff);
            hrvNumber = ((data[4] & 0xff) << 8) | (data[5] & 0xff);
            rriNumber = ((data[6] & 0xff) << 8) | (data[7] & 0xff);
            progress = data[8] & 0xff;
        }else if(dataType == 3){
            if (data.length >= 50) {
                for (int i = 0; i < 25; i++) {
//                    int filter = data[i] & 0xff;
//                    filterSigns.add(filter);
                    int filter = ((data[i*2+1] & 0xff) << 8) | (data[i*2+2] & 0xff);
                    if(filter > 32767){
                        filter = filter - 65536;
                    }
                    filterSigns.add(filter);
                }
            }
        }else if(dataType == 4){
            testState = data[1] & 0xff;
        }
        Log.d("UkOptManager",toString());
        return true;
    }

    public ApplicationLayerEcgBeltToDevicePacket() {
        filterSigns = new ArrayList<>();
    }

    public int getDataType() {
        return dataType;
    }

    public void setDataType(int dataType) {
        this.dataType = dataType;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public int getSecond() {
        return second;
    }

    public void setSecond(int second) {
        this.second = second;
    }

    public int getBpmNumber() {
        return bpmNumber;
    }

    public void setBpmNumber(int bpmNumber) {
        this.bpmNumber = bpmNumber;
    }

    public int getQtNumber() {
        return qtNumber;
    }

    public void setQtNumber(int qtNumber) {
        this.qtNumber = qtNumber;
    }

    public int getHrvNumber() {
        return hrvNumber;
    }

    public void setHrvNumber(int hrvNumber) {
        this.hrvNumber = hrvNumber;
    }

    public int getRriNumber() {
        return rriNumber;
    }

    public void setRriNumber(int rriNumber) {
        this.rriNumber = rriNumber;
    }

    public List<Integer> getFilterSigns() {
        return filterSigns;
    }

    public void setFilterSigns(List<Integer> filterSigns) {
        this.filterSigns = filterSigns;
    }

    public int getTestState() {
        return testState;
    }

    public void setTestState(int testState) {
        this.testState = testState;
    }

    public int getProgress() {
        return progress;
    }

    public void setProgress(int progress) {
        this.progress = progress;
    }

    @Override
    public String toString() {
        return "ApplicationLayerBeltToDevicePacket{" +
                "dataType=" + dataType +
                ", bpmNumber=" + bpmNumber +
                ", qtNumber=" + qtNumber +
                ", hrvNumber=" + hrvNumber +
                ", rriNumber=" + rriNumber +
                ", progress=" + progress +
                ", testState=" + testState +
                '}';
    }
}
