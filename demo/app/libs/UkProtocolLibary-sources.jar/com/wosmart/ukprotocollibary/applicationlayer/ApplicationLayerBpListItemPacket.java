package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerBpListItemPacket {

    /**
     * year
     */
    private int mYear;            // 6bits

    /**
     * month
     */
    private int mMonth;            // 4bits

    /**
     * day
     */
    private int mDay;            // 5bits

    /**
     * item count
     */
    private int mItemCount;        // 8bits

    /**
     * minute
     */
    private int mMinutes;             // 16bits

    /**
     * id
     */
    private int mSequenceNum;        //8 bits


    /**
     * bp high value 8bits
     */
    private int mLowValue;

    /**
     * bo low value 8bits
     */
    private int mHighValue;


    public int getmYear() {
        return mYear;
    }

    public void setmYear(int mYear) {
        this.mYear = mYear;
    }

    public int getmMonth() {
        return mMonth;
    }

    public void setmMonth(int mMonth) {
        this.mMonth = mMonth;
    }

    public int getmDay() {
        return mDay;
    }

    public void setmDay(int mDay) {
        this.mDay = mDay;
    }

    public int getmItemCount() {
        return mItemCount;
    }

    public void setmItemCount(int mItemCount) {
        this.mItemCount = mItemCount;
    }

    public int getmMinutes() {
        return mMinutes;
    }

    public void setmMinutes(int mMinutes) {
        this.mMinutes = mMinutes;
    }

    public int getmSequenceNum() {
        return mSequenceNum;
    }

    public void setmSequenceNum(int mSequenceNum) {
        this.mSequenceNum = mSequenceNum;
    }

    public int getmLowValue() {
        return mLowValue;
    }

    public void setmLowValue(int mLowValue) {
        this.mLowValue = mLowValue;
    }

    public int getmHighValue() {
        return mHighValue;
    }

    public void setmHighValue(int mHighValue) {
        this.mHighValue = mHighValue;
    }

    @Override
    public String toString() {
        return "ApplicationLayerBpListItemPacket{" +
                "mYear=" + mYear +
                ", mMonth=" + mMonth +
                ", mDay=" + mDay +
                ", mItemCount=" + mItemCount +
                ", mMinutes=" + mMinutes +
                ", mSequenceNum=" + mSequenceNum +
                ", mLowValue=" + mLowValue +
                ", mHighValue=" + mHighValue +
                '}';
    }
}
