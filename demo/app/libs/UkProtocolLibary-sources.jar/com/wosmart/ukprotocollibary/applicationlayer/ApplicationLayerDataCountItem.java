package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.model.enums.DeviceDataType;

public class ApplicationLayerDataCountItem {

    private DeviceDataType dataType;

    private int dataCount;

    public final static int ITEM_HEADER_LENGTH = 3;

    public DeviceDataType getDataType() {
        return dataType;
    }

    public void setDataType(DeviceDataType dataType) {
        this.dataType = dataType;
    }

    public ApplicationLayerDataCountItem() {

    }

    public int getDataCount() {
        return dataCount;
    }

    public void setDataCount(int dataCount) {
        this.dataCount = dataCount;
    }

    public boolean parseData(byte[] data) {
        if (data.length >= ITEM_HEADER_LENGTH) {
            int type = data[0] & 0xff;
            switch (type) {
                case 0:
                    dataType = DeviceDataType.STEP;
                    break;
                case 1:
                    dataType = DeviceDataType.SLEEP;
                    break;
                case 2:
                    dataType = DeviceDataType.HEART_RATE;
                    break;
                case 3:
                    dataType = DeviceDataType.BLOOD_PRESSURE;
                    break;
                case 4:
                    dataType = DeviceDataType.EXERCISE;
                    break;
                case 5:
                    dataType = DeviceDataType.BO;
                    break;
                case 6:
                    dataType = DeviceDataType.HRV;
                    break;
                case 7:
                    dataType = DeviceDataType.GLU;
                    break;
                case 8:
                    dataType = DeviceDataType.WEARING_TIME;
                    break;
                case 9:
                    dataType = DeviceDataType.URIC_ACID;
                    break;
                case 10:
                    dataType = DeviceDataType.BLOOD_FAT;
                    break;
                case 11:
                    dataType = DeviceDataType.BLOOD_SUGAR_CYCLE;
                    break;
                case 12:
                    dataType = DeviceDataType.URIC_ACID_CONTINUOUS_MONITORING;
                    break;
                case 13:
                    dataType = DeviceDataType.BLOOD_FAT_CONTINUOUS_MONITORING;
                    break;
                default:
                    dataType = DeviceDataType.UN_KNOW;
                    break;
            }
            dataCount = ((data[1] & 0xff) << 8) | (data[2] & 0xff);
        }
        return true;
    }


    @Override
    public String toString() {
        return "\nItem{" +
                "dataType = " + dataType +
                ", dataCount = " + dataCount +
                '}';
    }
}
