package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerMusicPlayerPacket {

    /**
     * 是否有播放器
     */
    private boolean playerToggle;

    /**
     * 播放状态
     */
    private boolean playStatus;

    /**
     * 音量百分比
     */
    private int volumePercent;


    public ApplicationLayerMusicPlayerPacket() {

    }

    public boolean isPlayerToggle() {
        return playerToggle;
    }

    public void setPlayerToggle(boolean playerToggle) {
        this.playerToggle = playerToggle;
    }

    public boolean isPlayStatus() {
        return playStatus;
    }

    public void setPlayStatus(boolean playStatus) {
        this.playStatus = playStatus;
    }

    public int getVolumePercent() {
        return volumePercent;
    }

    public void setVolumePercent(int volumePercent) {
        this.volumePercent = volumePercent;
    }

    public byte[] getPacket() {
        byte[] data = new byte[1];
        byte player = playerToggle ? (byte) 0x80 : (byte) 0x00;
        byte playPause = playStatus ? (byte) 0x00 : (byte) 0x40;
        byte volume = (byte) (volumePercent & 0xff);
        data[0] = (byte) (player | playPause | volume);

        return data;
    }

    public boolean parseData(byte[] data) {
        playerToggle = (data[0] & 0xff) >> 7 == 0x00;
        playStatus = (data[0] & 0xff) >> 6 == 0x00;
        volumePercent = data[0] & 0x3f;
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerMusicPlayerPacket{" +
                "playerToggle=" + playerToggle +
                ", playStatus=" + playStatus +
                ", volumePercent=" + volumePercent +
                '}';
    }
}
