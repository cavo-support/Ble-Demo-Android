package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerPathPacket {

    /**
     *
     */
    private int reserve;

    /**
     * version
     */
    private int version;

    /**
     * minor version
     */
    private int minor;

    /**
     * major version
     */
    private int major;

    /**
     * package length
     */
    public final static int PATH_HEADER_LENGTH = 4;

    public byte[] getPacket() {
        byte[] data = new byte[PATH_HEADER_LENGTH];
        data[0] = (byte) (((reserve & 0x1f) << 3) | ((version >> 12) & 0x07));
        data[1] = (byte) ((version >> 4) & 0xff);
        data[2] = (byte) (((version & 0x0f) << 4) | ((minor >> 4) & 0x0f));
        data[3] = (byte) (((minor & 0x0f) << 4) | (major & 0x0f));
        return data;
    }

    public boolean parseData(byte[] data) {
        if (data.length < PATH_HEADER_LENGTH) {
            return false;
        }
        this.reserve = (data[0] & 0xf8) >> 3;
        this.version = (data[0] & 0x07) << 12 | ((data[1] & 0xff) << 4) | (data[2] & 0xf0) >> 4;
        this.minor = (data[2] << 4) & 0xf0 | (data[3] >> 4) & 0x0f;
        this.major = data[3] & 0x0f;
        return true;
    }


}
