package com.wosmart.ukprotocollibary.applicationlayer;


import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.wosmart.ukprotocollibary.model.enums.DeviceFunctionStatus;
import com.wosmart.ukprotocollibary.model.enums.DeviceLanguage;
import com.wosmart.ukprotocollibary.transportlayer.TransportLayer;
import com.wosmart.ukprotocollibary.transportlayer.TransportLayerCallback;
import com.wosmart.ukprotocollibary.util.DataConverter;
import com.wosmart.ukprotocollibary.util.SDKLogger;
import com.wosmart.ukprotocollibary.util.StringByteTrans;
import com.wosmart.ukprotocollibary.v2.entity.JWFemaleHealthInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWeatherInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWDefaultFunctionInfo;

import java.util.Arrays;
import java.util.List;


public class ApplicationLayer {
    // Log
    private final static String TAG = "ApplicationLayer";
    private final static boolean D = true;

    // Support Command Id
    private final static byte CMD_IMAGE_UPDATE = 0x01;
    private final static byte CMD_SETTING = 0x02;
    private final static byte CMD_BOND_REG = 0x03;
    private final static byte CMD_NOTIFY = 0x04;
    private final static byte CMD_SPORTS_DATA = 0x05;
    public final static byte CMD_FACTORY_TEST = 0x06;
    private final static byte CMD_CTRL = 0x07;
    private final static byte CMD_MULTIPLE_CMD = 0x08;// 多命令
    private final static byte CMD_TEST_FLASH = 0x09;
    private final static byte CMD_LOG = 0x0a;
    private final static byte CMD_CUSTOM_MADE = 0x58;

    /*CMD_UPDATE : key */
    private final static byte KEY_UPDATE_REQUEST = 0x01;
    private final static byte KEY_UPDATE_RESPONSE = 0x02;
    private final static byte KEY_UPDATE_RESPONSE_OK = 0x00;
    private final static byte KEY_UPDATE_RESPONSE_ERR = 0x01;
    private final static byte UPDATE_RESPONSE_ERRCODE = 0x01;       //low power

    /*CMD_SETTING : key */
    private final static byte KEY_SETTING_TIMER = 0x01;
    private final static byte KEY_SETTING_ALARM = 0x02;
    private final static byte KEY_SETTING_GET_ALARM_LIST_REQ = 0x03;
    private final static byte KEY_SETTING_GET_ALARM_LIST_RSP = 0x04;
    private final static byte KEY_SETTING_STEP_TARGET = 0x05;
    private final static byte KEY_SETTING_SLEEP_TARGET = 0x06;
    private final static byte KEY_SETTING_CALC_TARGET = 0x07;
    private final static byte KEY_SETTING_USER_PROFILE = 0x10;
    private final static byte KEY_SETTING_UNIT = 0x11;
    private final static byte KEY_SETTING_UNIT_REQ = 0x12;
    private final static byte KEY_SETTING_UNIT_RSP = 0x13;
    private final static byte KEY_SETTING_LOST_MODE = 0x20;
    private final static byte KEY_SETTING_SIT_TOO_LONG_NOTIFY = 0x21;
    private final static byte KEY_SETTING_LEFT_RIGHT_HAND_NOTIFY = 0x22;
    private final static byte KEY_SETTING_PHONE_OS = 0x23;
    private final static byte KEY_SETTING_INCOMING_CALL_LIST = 0x24;
    private final static byte KEY_SETTING_INCOMING_ON_OFF = 0x25;
    private final static byte KEY_SETTING_SIT_TOO_LONG_SWITCH_REQ = 0x26;
    private final static byte KEY_SETTING_SIT_TOO_LONG_SWITCH_RSP = 0x27;
    private final static byte KEY_SETTING_NOTIFY_SWITCH_REQ = 0x28;
    private final static byte KEY_SETTING_NOTIFY_SWITCH_RSP = 0x29;


    private final static byte KEY_SETTING_TURN_OVER_WRIST_SET = 0x2A;
    private final static byte KEY_SETTING_TURN_OVER_WRIST_REQ = 0x2B;
    private final static byte KEY_SETTING_TURN_OVER_WRIST_RSP = 0x2C;

    private final static byte KEY_SETTING_NOTIFY_ALL = 0x2D;

    private final static byte KEY_DEVICE_FUNCTION_REQ = 0x36;
    private final static byte KEY_DEVICE_FUNCTION_RSP = 0x37;

    private final static byte KEY_SETTING_DEVICE_HOME_PAGER_SET = 0x38;
    private final static byte KEY_SETTING_DEVICE_HOME_PAGER_REQ = 0x39;
    private final static byte KEY_SETTING_DEVICE_HOME_PAGER_RSP = 0x3A;

    private final static byte KEY_SETTING_DEVICE_MULTI_SPORT_REQ = 0x3B;

    private final static byte KEY_SETTING_DEVICE_HRP_PARAMS_REQ = 0x3F;

    private final static byte KEY_HOUR_SYSTEM_SETTING = 0x41;
    private final static byte KEY_HOUR_SYSTEM_REQ = 0x42;
    private final static byte KEY_HOUR_SYSTEM_RSP = 0x43;

    private final static byte KEY_UNIT_SYSTEM_SETTING = 0x44;
    private final static byte KEY_UNIT_SYSTEM_REQ = 0x45;
    private final static byte KEY_UNIT_SYSTEM_RSP = 0x46;

    private final static byte KEY_DISTURB_SETTING = 0x47;
    private final static byte KEY_DISTURB_REQ = 0x48;
    private final static byte KEY_DISTURB_RSP = 0x49;

    private final static byte KEY_SCREEN_LIGHT_DURATION_SETTING = 0x4A;
    private final static byte KEY_SCREEN_LIGHT_DURATION_REQ = 0x4B;
    private final static byte KEY_SCREEN_LIGHT_DURATION_RSP = 0x4C;

    private final static byte KEY_LANGUAGE_SETTING = 0x4E;
    private final static byte KEY_LANGUAGE_REQ = 0x4F;
    private final static byte KEY_LANGUAGE_RSP = 0x50;

    private final static byte KEY_DEVICE_INFO_REQ = 0x51;
    private final static byte KEY_DEVICE_INFO_RSP = 0x52;

    private final static byte KEY_DEVICE_SCREEN_LIGHT_SETTING = 0x53;
    private final static byte KEY_DEVICE_SCREEN_LIGHT_REQ = 0x54;
    private final static byte KEY_DEVICE_SCREEN_LIGHT_RSP = 0x55;

    private final static byte KEY_DEVICE_SWITCH_SETTING = 0x59;
    private final static byte KEY_DEVICE_SWITCH_REQ = 0x5A;
    private final static byte KEY_DEVICE_SWITCH_RSP = 0x5B;

    private final static byte KEY_SETTING_CLASSIC_ADDRESS_REQ = 0x60;

    private final static byte KEY_SETTING_CLASSIC_STATUS_REQ = 0x61;

    private final static byte KEY_SETTING_ALARM2_SETTING = 0x65;
    private final static byte KEY_SETTING_ALARM2_REQ = 0x66;
    private final static byte KEY_SETTING_ALARM2_RSP = 0x67;

    private final static byte KEY_SETTING_AUDIO_SET = 0x68;
    private final static byte KEY_AUDIO_GET_REQ = 0x69;
    private final static byte KEY_AUDIO_GET_RSP = 0x6A;

    private final static byte KEY_SETTING_FULL_SYNC = (byte) 0xFA;

    private final static byte KEY_SETTING_ADDRESS_BOOK_REQ = 0x6D;
    private final static byte KEY_SETTING_ADDRESS_BOOK_RSP = 0x6E;

    private final static byte KEY_SETTING_SLEEP_ALL_SWITCH = 0x6F;
    private final static byte KEY_SETTING_SLEEP_ALL_SWITCH_REQ = 0x70;
    private final static byte KEY_SETTING_SLEEP_ALL_SWITCH_RSP = 0x71;

    private final static byte KEY_SETTING_HYPOXIA_SWITCH = 0x72;
    private final static byte KEY_SETTING_HYPOXIA_SWITCH_REQ = 0x73;
    private final static byte KEY_SETTING_HYPOXIA_SWITCH_RSP = 0x74;

    private final static byte KEY_SETTING_HIGH_HEART_RATE_SWITCH = 0x75;
    private final static byte KEY_SETTING_HIGH_HEART_RATE_SWITCH_REQ = 0x76;
    private final static byte KEY_SETTING_HIGH_HEART_RATE_SWITCH_RSP = 0x77;

    private final static byte KEY_SETTING_DEVICE_DATE_FORMAT = 0x78;
    private final static byte KEY_SETTING_DEVICE_DATE_FORMAT_REQ = 0x79;
    private final static byte KEY_SETTING_DEVICE_DATE_FORMAT_RSP = 0x7A;

    private final static byte KEY_SETTING_SOS_NUMBER_REQ = 0x7B;
    private final static byte KEY_SETTING_SOS_NUMBER_RSP = 0x7C;

    private final static byte KEY_SETTING_MEDICATION_REMINDER_SET = 0x7D;
    private final static byte KEY_SETTING_MEDICATION_REMINDER_REQ = 0x7E;
    private final static byte KEY_SETTING_MEDICATION_REMINDER_RSP = 0x7F;

    /*CMD_BOND_REG : key */
    private final static byte KEY_BOND_REQ = 0x01;
    private final static byte KEY_BOND_RSP = 0x02;
    private final static byte KEY_LOGIN_REQ = 0x03;
    private final static byte KEY_LOGIN_RSP = 0x04;
    private final static byte KEY_UNBOND = 0x05;
    private final static byte KEY_SUP_BOND_KEY = 0x06;
    private final static byte KEY_CONFIRM_BOND_REQ = 0x07;
    private final static byte KEY_CONFIRM_BOND_RSP = 0x08;

    /* CMD_NOTIFY: key:*/
    private final static byte KEY_NOTIFY_IMCOMING_CALL = 0x01;
    private final static byte KEY_NOTIFY_IMCOMING_CALL_ACC = 0x02;
    private final static byte KEY_NOTIFY_IMCOMING_CALL_REJ = 0x03;
    private final static byte KEY_NOTIFY_INCOMING_OTHER_NOTIFY = 0x04;
    private final static byte KEY_NOTIFY_END_CALL = 0x05;
    private final static byte KEY_NOTIFY_CHARGING_STATUS = 0x06;
    private final static byte KEY_NOTIFY_ACCEPT_CALL = 0x07;
    private final static byte KEY_NOTIFY_CLASSIC_ADDRESS = 0x10;
    private final static byte KEY_NOTIFY_CLASSIC_STATUS = 0x11;
    private final static byte KEY_NOTIFY_CLASSIC_STATUS2 = 0x13;

    /* CMD_SPORTS: key:*/
    private final static byte KEY_SPORTS_REQ = 0x01;
    private final static byte KEY_SPORTS_RUNNIG_RSP = 0x02;
    private final static byte KEY_SPORTS_SLEEP_RSP = 0x03;
    private final static byte KEY_SPORTS_RUNNIG_RSP_MORE = 0x04;
    private final static byte KEY_SPORTS_SLEEP_SET_RSP = 0x05;
    private final static byte KEY_SPORTS_DATA_SYNC = 0x06;
    private final static byte KEY_SPORTS_HIS_SYNC_BEG = 0x07;
    private final static byte KEY_SPORTS_HIS_SYNC_END = 0x08;
    private final static byte KEY_SPORTS_DATA_TODAY_SYNC = 0x09;
    private final static byte KEY_SPORTS_DATA_LAST_SYNC = 0x0a;
    private final static byte KEY_SPORTS_DATA_TODAY_ADJUST_REQ = 0x0b;// 需要确认的功能
    private final static byte KEY_SPORTS_DATA_TODAY_ADJUST_RSP = 0x0c;// 需要确认的功能
    private final static byte KEY_SPORTS_HRP_SINGLE_REQ = 0x0d;// 单次读取心率请求
    private final static byte KEY_SPORTS_HRP_CONTINUE_SET = 0x0e;// 连续心率采集设定
    private final static byte KEY_SPORTS_HRP_DATA_RSP = 0x0f;// 心率数据返回
    private final static byte KEY_SPORTS_HRP_DEVICE_CANCEL_READ_HRP = 0x10;// 手环取消单次心率读取
    private final static byte KEY_SPORTS_HRP_CONTINUE_PARAMS_GET = 0x11;// 连续心率采集参数获取
    private final static byte KEY_SPORTS_HRP_CONTINUE_PARAMS_RSP = 0x12;// 连续心率采集参数返回
    private final static byte KEY_SPORTS_BP_DATA_RSP = 0x13;
    private final static byte KEY_SPORTS_BP_SINGLE_REQ = 0x14;
    private final static byte KEY_SPORTS_BP_CANCEL_READ = 0x15;
    private final static byte KEY_SPORTS_DATA_RSP = 0x16;
    private final static byte KEY_SPORTS_MODEL_RSP = 0x17;
    private final static byte KEY_SPORTS_HR_PARAMS_RSP = 0x18;
    private final static byte KEY_APP_SPORT_RATE_DETECT_START = 0x19;
    private final static byte KEY_APP_SPORT_RATE_DETECT_STOP = 0x1A;
    private final static byte KEY_SPORTS_HRP_DATA_LIST_RSP = 0x1B;
    private final static byte KEY_SPORTS_DATA_END = 0x1C;
    private final static byte KEY_SLEEP_TIME_ADJUST = 0x1E;
    private final static byte KEY_SLEEP_ADJUST = 0x1F;
    private final static byte KEY_TEMP_SET = 0x20;
    private final static byte KEY_TEMP_RSP = 0x21;
    private final static byte KEY_TEMP_CONTROL_SET = 0x22;
    private final static byte KEY_TEMP_CONTROL_REQ = 0x23;
    private final static byte KEY_TEMP_CONTROL_RSP = 0x24;
    private final static byte KEY_BP2_CONTROL_SET = 0x25;
    private final static byte KEY_BP2_CONTROL_REQ = 0x26;
    private final static byte KEY_BP2_CONTROL_RSP = 0x27;
    private final static byte KEY_HR_DATA_RSP = 0x28;
    private final static byte KEY_HR_DATA_LIST_RSP = 0x29;
    private final static byte KEY_DEVICE_STATUS_REQ = 0x2A;
    private final static byte KEY_DEVICE_STATUS_RSP = 0x2B;
    private final static byte KEY_SPO2_DATA_RSP = 0x2C;
    private final static byte KEY_SPO2_SETTING = 0x2D;
    private final static byte KEY_SPO2_RSP = 0x2E;
    private final static byte KEY_SPO2_CONTINUOUS_SETTING = 0x33;
    private final static byte KEY_SPO2_CONTINUOUS_GET = 0x34;
    private final static byte KEY_SPO2_CONTINUOUS_RSP = 0x35;
    private final static byte KEY_ECG_STATUS_REQ = 0x36;
    private final static byte KEY_ECG_BELT_SET = 0x37;
    private final static byte KEY_ECG_STATUS_RSP = 0x38;
    private final static byte KEY_ECG_DATA_RSP = 0x39;
    private final static byte KEY_READ_HEALTH_REQ = 0x3A;
    private final static byte KEY_READ_HEALTH_RSP = 0x3B;
    private final static byte KEY_RTK_HRV_RSP = 0x3C;
    private final static byte KEY_BP3_CONTINUOUS_SET = 0x3d;
    private final static byte KEY_BP3_CONTINUOUS_REQ = 0x3e;
    private final static byte KEY_BP3_CONTINUOUS_RSP = 0x3f;
    private final static byte KEY_GLU_HISTORY_RSP = 0x40;
    private final static byte KEY_GLU_TEST_START = 0x41;
    private final static byte KEY_GLU_TEST_STOP = 0x42;
    private final static byte KEY_GLU_CONTINUOUS_SET = 0x43;
    private final static byte KEY_GLU_CONTINUOUS_REQ = 0x44;
    private final static byte KEY_GLU_CONTINUOUS_RSP = 0x45;
    private final static byte KEY_GLU_PRIVATE_SET = 0x46;
    private final static byte KEY_GLU_PRIVATE_REQ = 0x47;
    private final static byte KEY_GLU_PRIVATE_RSP = 0x48;
    private final static byte KEY_WEARING_TIME_RSP = 0x49;
    private final static byte KEY_URIC_ACID_RSP = 0x4A;
    private final static byte KEY_BLOOD_FAT_RSP = 0x4B;
    private final static byte KEY_BLOOD_SUGAR_CYCLE_RSP = 0x4C;
    private final static byte KEY_URIC_ACID_CONTINUOUS_MONITORING_RSP = 0x4D;
    private final static byte KEY_BLOOD_FAT_CONTINUOUS_MONITORING_RSP = 0x4E;
    private final static byte KEY_CONTINUOUS_MONITORING_SET = 0x4F;
    private final static byte KEY_CONTINUOUS_MONITORING_REQ = 0x50;
    private final static byte KEY_CONTINUOUS_MONITORING_RSP = 0x51;
    private final static byte KEY_DEVICE_MEASURE_SET = 0x52;
    private final static byte KEY_DEVICE_MEASURE_STATUS_UPDATED = 0x53;
    private final static byte KEY_BODY_FAT_HISTORY_REQ = 0x54;
    private final static byte KEY_BODY_FAT_HISTORY_RSP = 0x55;
    private final static byte KEY_PHYSICAL_EXAM_HISTORY_REQ = 0x56;
    private final static byte KEY_PHYSICAL_EXAM_HISTORY_RSP = 0x57;
    private final static byte KEY_ULTRAVIOLET_REQ = 0x58;
    private final static byte KEY_ULTRAVIOLET_RSP = 0x59;
    private final static byte KEY_PRESSURE_REQ = 0x5A;
    private final static byte KEY_PRESSURE_RSP = 0x5B;


    /* CMD_FAC_TEST: key:*/
    public final static byte KEY_FAC_TEST_ECHO_REQ = 0x01;
    public final static byte KEY_FAC_TEST_ECHO_RSP = 0x02;
    public final static byte KEY_FAC_TEST_CHAR_REQ = 0x03;
    public final static byte KEY_FAC_TEST_CHAR_RSP = 0x04;
    public final static byte KEY_FAC_TEST_LED = 0x05;
    public final static byte KEY_FAC_TEST_MOTO = 0x06;
    public final static byte KEY_FAC_TEST_WRITE_SN = 0x07;
    public final static byte KEY_FAC_TEST_READ_SN = 0x08;
    public final static byte KEY_FAC_TEST_SN_RSP = 0x09;
    public final static byte KEY_FAC_TEST_WRITE_TEST_FLAG = 0x0a;
    public final static byte KEY_FAC_TEST_READ_TEST_FLAG = 0x0b;
    public final static byte KEY_FAC_TEST_FLAG_RSP = 0x0c;
    public final static byte KEY_FAC_TEST_SENSOR_DATA_REQ = 0x0d;
    public final static byte KEY_FAC_TEST_SENSOR_DATA_RSP = 0x0e;
    public final static byte KEY_FAC_TEST_ENTER_SPUER_KEY = 0x10;
    public final static byte KEY_FAC_TEST_LEAVE_SPUER_KEY = 0x11;
    public final static byte KEY_FAC_TEST_BUTTON_TEST = 0x21;
    public final static byte KEY_FAC_DEFAULT_FUNCTION_SET = 0x28;
    public final static byte KEY_FAC_TEST_MOTO_OLD = 0x31;
    public final static byte KEY_FAC_TEST_LED_OLD = 0x32;
    public final static byte KEY_FAC_TEST_TODAY_SLEEP_REQ = 0x33;
    public final static byte KEY_FAC_TEST_TODAY_SLEEP_RSP = 0x34;
    public final static byte KEY_FAC_DEFAULT_FUNCTION_REQ = 0x3D;
    public final static byte KEY_FAC_DEFAULT_FUNCTION_RSP = 0x3E;
    public final static byte KEY_FAC_TEST_SILENCE_UPGRADE = 0x3f;
    public final static byte KEY_FAC_TEST_SILENCE_UPGRADE_REQ = 0x40;
    public final static byte KEY_FAC_TEST_SILENCE_UPGRADE_RSP = 0x41;
    public final static byte KEY_FAC_TEST_HISTORY_REQ = (byte) 0xf7;
    public final static byte KEY_FAC_TEST_HISTORY_RSP = (byte) 0xf8;
    public final static byte KEY_FAC_TEST_RESET_REQ = (byte) 0xfc;
    /* CMD_MULTIPLE_CMD */
    public final static byte KEY_MUL_PRIVATE_BP = 0x01;// 私人血压
    public final static byte KEY_MUL_SOS_NUMBER = 0x02;// SOS
    public final static byte KEY_MUL_DRINK_WATER_REMINDER = 0x03;// 喝水提醒
    public final static byte KEY_MUL_TEMPERATURE_REMINDER = 0x04;// 体温提醒
    public final static byte KEY_MUL_MEDICATION_REMINDER = 0x05;// 吃药提醒
    public final static byte KEY_MUL_FEMALE_HEALTH = 0x06;// 女性健康
    public final static byte KEY_MUL_WEATHER = 0x07;// 天气
    public final static byte KEY_MUL_WEARING_TIME = 0x08;// 佩戴时间
    public final static byte KEY_MUL_URIC_ACID = 0x09;// 尿酸
    public final static byte KEY_MUL_BLOOD_FAT = 0x0A;// 血脂
    public final static byte KEY_MUL_BLOOD_SUGAR_CYCLE = 0x0B;// 血糖
    public final static byte KEY_MUL_PRIVATE_URIC_ACID = 0x0C;// 私人尿酸
    public final static byte KEY_MUL_PRIVATE_BLOOD_FAT = 0x0D;// 私人血脂
    public final static byte KEY_MUL_BODY_FAT = 0x0E;// 体脂
    public final static byte KEY_MUL_PHYSICAL_EXAM = 0x0F;// 体检
    public final static byte KEY_MUL_ULTRAVIOLET = 0x10;// 紫外线

    /* CMD_CUSTOM_MADE */
    public final static byte KEY_CUSTOM_TRANSLATE_RSP = 0x01;
    public final static byte KEY_CUSTOM_EXERCISE_SET = 0x02;
    public final static byte KEY_CUSTOM_NOTIFY_SET = 0x03;
    public final static byte KEY_CUSTOM_NOTIFY_REQ = 0x04;
    public final static byte KEY_CUSTOM_NOTIFY_RSP = 0x05;
    public final static byte KEY_CUSTOM_NOTIFY_SYNC = 0x06;
    public final static byte KEY_CUSTOM_STYLE_COLOR = 0x07;
    public final static byte KEY_CUSTOM_NOTIFY_CONTENT = 0x08;
    public final static byte KEY_CUSTOM_SUPPORT_PULSE = 0x09;
    public final static byte KEY_CUSTOM_PULSE_SET = 0x0A;
    public final static byte KEY_CUSTOM_PULSE_RSP = 0x0B;
    public final static byte KEY_CUSTOM_SUPPORT_SLEEP_HELP = 0x0C;
    public final static byte KEY_CUSTOM_SLEEP_HELP_SET = 0x0D;
    public final static byte KEY_CUSTOM_SLEEP_HELP_RSP = 0x0E;
    public final static byte KEY_CUSTOM_SYNC_PULSE_DATA_RSP = 0x0F;
    public final static byte KEY_CUSTOM_SYNC_PULSE_STATUS_RSP = 0x10;
    public final static byte KEY_CUSTOM_PULSE_FINISHED_RSP = 0x11;
    public final static byte KEY_CUSTOM_SUPPORT_SAUNA = 0x12;
    public final static byte KEY_CUSTOM_SYNC_SAUNA_DATA_RSP = 0x13;
    public final static byte KEY_CUSTOM_SYNC_SAUNA_STATUS_RSP = 0x14;
    public final static byte KEY_CUSTOM_HRV_RMSSD_SET = 0x1A;
    public final static byte KEY_CUSTOM_HRV_RMSSD_REQ = 0x1B;
    public final static byte KEY_CUSTOM_HRV_RMSSD_RSP = 0x1C;
    public final static byte KEY_CUSTOM_SYNC_HRV_RMSSD_RSP = 0x1D;
    public final static byte KEY_CUSTOM_SYNC_HR_MOVEMENT_RSP = 0x1E;

    /* CMD_CONTROL: key:*/
    private final static byte KEY_CTRL_PHOTO_RSP = 0x01;
    private final static byte KEY_CTRL_FIND_PHONE_RSP = 0x02;
    private final static byte KEY_CTRL_DOUBLE_CLICK_RSP = 0x03;
    private final static byte KEY_CTRL_APP_REQ = 0x11;
    private final static byte KEY_CTRL_TIMER_SETTING = 0x12;
    private final static byte KEY_CTRL_TIMER_REQ = 0x13;
    private final static byte KEY_CTRL_TIMER_RSP = 0x14;
    private final static byte KEY_CTRL_CUSTOM_UI_SETTING = 0x15;
    private final static byte KEY_CTRL_CUSTOM_UI_REQ = 0x16;
    private final static byte KEY_CTRL_CUSTOM_UI_RSP = 0x17;
    private final static byte key_CTRL_MUSIC_CONTROL = 0x18;
    private final static byte KEY_CTRL_MUSIC_STATUS = 0x19;
    private final static byte KEY_CTRL_OTA_STATUS_REQ = 0x1a;
    private final static byte KEY_CTRL_OTA_STATUS_RSP = 0x1b;
    private final static byte KEY_CTRL_FIND_PHONE_RSP2 = 0x1c;
    private final static byte KEY_CTRL_CUS_REQ = 0x1c;
    private final static byte KEY_CTRL_CUS_RSP = 0x1d;
    private final static byte KEY_CTRL_FEMALE_SET = 0x1E;
    private final static byte KEY_CTRL_FEMALE_RSP = 0x1F;
    private final static byte KEY_CTRL_WEATHER_SET = 0x20;
    private final static byte KEY_CTRL_WEATHER_RSP = 0x21;
    private final static byte KEY_CTRL_HIDE_HEALTH_FUNCTION_SET = 0x22;
    private final static byte KEY_CTRL_HIDE_HEALTH_FUNCTION_REQ = 0x23;
    private final static byte KEY_CTRL_HIDE_HEALTH_FUNCTION_RSP = 0x24;

    /* CMD_DUMP: key:*/
    public final static byte KEY_DUMP_ASSERT_LOCATE_REQ = 0x01;
    public final static byte KEY_DUMP_ASSERT_LOCATE_RSP = 0x02;
    public final static byte KEY_DUMP_ASSERT_STACK_REQ = 0x03;
    public final static byte KEY_DUMP_ASSERT_STACK_RSP = 0x14;

    /* LOG: key:*/
    private final static byte KEY_LOG_FUNC_OPEN = 0x01;
    private final static byte KEY_LOG_FUNC_CLOSE = 0x02;
    private final static byte KEY_LOG_RSP = 0x03;
    private final static byte KEY_LOG_REQ = 0x04;
    private final static byte KEY_LOG_START = 0x05;
    private final static byte KEY_LOG_END = 0x06;

    /* Login response*/
    public final static byte LOGIN_RSP_SUCCESS = 0x00;
    public final static byte LOGIN_RSP_ERROR = 0x01;
    public final static byte LOGIN_LOSS_LOGIN_INFO = 0x02;

    /* Bond response*/
    public final static byte BOND_RSP_SUCCESS = 0x00;
    public final static byte BOND_RSP_ERROR = 0x01;

    /* Sport Sync Mode */
    public final static byte SPORT_DATA_SYNC_MODE_DISABLE = 0x00;
    public final static byte SPORT_DATA_SYNC_MODE_ENABLE = 0x01;

    /* err code*/
    public final static byte SUCCESS = 0x00;
    public final static byte BOND_FAIL_TIMEOUT = 0x02;
    public final static byte SUPER_KEY_FAIL = 0x02;
    public final static byte LOW_POWER = 0x03;

    // Day Flags
    public final static byte REPETITION_NULL = 0x00;
    public final static byte REPETITION_ALL = 0x7f;
    public final static byte REPETITION_MON = 0x01;
    public final static byte REPETITION_TUES = 0x02;
    public final static byte REPETITION_WED = 0x04;
    public final static byte REPETITION_THU = 0x08;
    public final static byte REPETITION_FRI = 0x10;
    public final static byte REPETITION_SAT = 0x20;
    public final static byte REPETITION_SUN = 0x40;

    // Sex Flags
    public final static boolean SEX_MAN = true;
    public final static boolean SEX_WOMAN = false;

    // Call notify flags
    public final static byte PHONE_OS_IOS = 0x01;
    public final static byte PHONE_OS_ANDROID = 0x02;

    // Call notify flags
    public final static byte CALL_NOTIFY_MODE_ON = 0x01;
    public final static byte CALL_NOTIFY_MODE_OFF = 0x02;
    public final static byte CALL_NOTIFY_MODE_ENABLE_QQ = 0x03;
    public final static byte CALL_NOTIFY_MODE_DISABLE_QQ = 0x04;
    public final static byte CALL_NOTIFY_MODE_ENABLE_WECHAT = 0x05;
    public final static byte CALL_NOTIFY_MODE_DISABLE_WECHAT = 0x06;
    public final static byte CALL_NOTIFY_MODE_ENABLE_MESSAGE = 0x07;
    public final static byte CALL_NOTIFY_MODE_DISABLE_MESSAGE = 0x08;
    public final static byte CALL_NOTIFY_MODE_ENABLE_LINE = 0x09;
    public final static byte CALL_NOTIFY_MODE_DISABLE_LINE = 0x0a;
    public final static byte CALL_NOTIFY_MODE_ENABLE_TWITTER = 0x0b;
    public final static byte CALL_NOTIFY_MODE_DISABLE_TWITTER = 0x0c;
    public final static byte CALL_NOTIFY_MODE_ENABLE_FACEBOOK = 0x0e;
    public final static byte CALL_NOTIFY_MODE_DISABLE_FACEBOOK = 0x0f;
    public final static byte CALL_NOTIFY_MODE_ENABLE_MESSENGER = 0x10;
    public final static byte CALL_NOTIFY_MODE_DISABLE_MESSENGER = 0x11;
    public final static byte CALL_NOTIFY_MODE_ENABLE_WHATSAPP = 0x12;
    public final static byte CALL_NOTIFY_MODE_DISABLE_WHATSAPP = 0x13;
    public final static byte CALL_NOTIFY_MODE_ENABLE_LINKEDIN = 0x14;
    public final static byte CALL_NOTIFY_MODE_DISABLE_LINKEDIN = 0x15;
    public final static byte CALL_NOTIFY_MODE_ENABLE_INSTAGRAM = 0x16;
    public final static byte CALL_NOTIFY_MODE_DISABLE_INSTAGRAM = 0x17;
    public final static byte CALL_NOTIFY_MODE_ENABLE_SKYPE = 0x18;
    public final static byte CALL_NOTIFY_MODE_DISABLE_SKYPE = 0x19;
    public final static byte CALL_NOTIFY_MODE_ENABLE_VIBER = 0x1A;
    public final static byte CALL_NOTIFY_MODE_DISABLE_VIBER = 0x1B;
    public final static byte CALL_NOTIFY_MODE_ENABLE_KAKAOTALK = 0x1C;
    public final static byte CALL_NOTIFY_MODE_DISABLE_KAKAOTALK = 0x1D;
    public final static byte CALL_NOTIFY_MODE_ENABLE_VKONTAKTE = 0x1E;
    public final static byte CALL_NOTIFY_MODE_DISABLE_VKONTAKE = 0x1F;
    public final static byte CALL_NOTIFY_MODE_ENABLE_TIM = 0x26;
    public final static byte CALL_NOTIFY_MODE_DISABLE_TIM = 0x27;
    public final static byte CALL_NOTIFY_MODE_ENABLE_GMAIL = 0x28;
    public final static byte CALL_NOTIFY_MODE_DISABLE_GMAIL = 0x29;
    public final static byte CALL_NOTIFY_MODE_ENABLE_DINGTALK = 0x2A;
    public final static byte CALL_NOTIFY_MODE_DISABLE_DINGTALK = 0x2B;
    public final static byte CALL_NOTIFY_MODE_ENABLE_WORK_WECHAT = 0x2C;
    public final static byte CALL_NOTIFY_MODE_DISABLE_WORK_WECHAT = 0x2D;
    public final static byte CALL_NOTIFY_MODE_ENABLE_OTHER = 0x36;
    public final static byte CALL_NOTIFY_MODE_DISABLE_OTHER = 0x37;


    // notify flags
    public final static byte OTHER_NOTIFY_INFO_OTHER = 0x00;
    public final static byte OTHER_NOTIFY_INFO_QQ = 0x01;
    public final static byte OTHER_NOTIFY_INFO_WECHAT = 0x02;
    public final static byte OTHER_NOTIFY_INFO_TIM = 0x03;
    public final static byte OTHER_NOTIFY_INFO_SMS = 0x04;
    public final static byte OTHER_NOTIFY_INFO_GMAIL = 0x05;
    public final static byte OTHER_NOTIFY_INFO_DINGTALK = 0x06;
    public final static byte OTHER_NOTIFY_INFO_WORKWECHAT = 0x07;
    public final static byte OTHER_NOTIFY_INFO_LINE = 0x08;
    public final static byte OTHER_NOTIFY_INFO_TWITTER = 0x09;
    public final static byte OTHER_NOTIFY_INFO_FACEBOOK = 0x0A;
    public final static byte OTHER_NOTIFY_INFO_MESSENGER = 0x0B;
    public final static byte OTHER_NOTIFY_INFO_WHATSAPP = 0x0C;
    public final static byte OTHER_NOTIFY_INFO_LINKEDIN = 0x0D;
    public final static byte OTHER_NOTIFY_INFO_INSTAGRAM = 0x0E;
    public final static byte OTHER_NOTIFY_INFO_SKYPE = 0x0F;
    public final static byte OTHER_NOTIFY_INFO_VIBER = 0x10;
    public final static byte OTHER_NOTIFY_INFO_KAKAOTALK = 0x11;
    public final static byte OTHER_NOTIFY_INFO_VKONTAKTE = 0x12;

    public final static byte NOTIFY_SWITCH_SETTING_CALL = 0x01;
    public final static byte NOTIFY_SWITCH_SETTING_QQ = 0x02;
    public final static byte NOTIFY_SWITCH_SETTING_WECHAT = 0x04;
    public final static byte NOTIFY_SWITCH_SETTING_MESSAGE = 0x08;

    // Long sit Flags
    public final static byte LONG_SIT_CONTROL_ENABLE = 0x01;
    public final static byte LONG_SIT_CONTROL_DISABLE = 0x00;

    // FAC Led Flags
    public final static byte FAC_LED_CONTROL_ENABLE_ALL = (byte) 0xFF;
    public final static byte FAC_LED_CONTROL_ENABLE_0 = 0x00;
    public final static byte FAC_LED_CONTROL_ENABLE_1 = 0x01;
    public final static byte FAC_LED_CONTROL_ENABLE_2 = 0x02;

    // Sleep Mode
    public static final int SLEEP_MODE_START_SLEEP = 1;
    public static final int SLEEP_MODE_START_DEEP_SLEEP = 2;
    public static final int SLEEP_MODE_START_WAKE = 3;

    // Debug Log type
    public final static byte DEBUG_LOG_TYPE_MODULE_APP = (byte) 0x01;
    public final static byte DEBUG_LOG_TYPE_MODULE_LOWERSTACK = (byte) 0x02;
    public final static byte DEBUG_LOG_TYPE_MODULE_UPSTACK = (byte) 0x03;
    public final static byte DEBUG_LOG_TYPE_SLEEP_DATA = (byte) 0x11;
    public final static byte DEBUG_LOG_TYPE_SPORT_DATA = (byte) 0x21;
    public final static byte DEBUG_LOG_TYPE_CONFIG_DATA = (byte) 0x31;

    public final static int DEBUG_LOG_TYPE_MAX_CNT = 6;

    // Camera control
    public final static byte CAMERA_CONTROL_APP_IN_FORE = 0x00;
    public final static byte CAMERA_CONTROL_APP_IN_BACK = 0x01;


    // Turn over wrist control
    public final static byte TURN_OVER_WRIST_CONTROL_ENABLE = 0x01;
    public final static byte TURN_OVER_WRIST_CONTROL_DISABLE = 0x00;


    // Hrp single request
    public final static byte HRP_SINGLE_REQ_MODE_ENABLE = 0x01;
    public final static byte HRP_SINGLE_REQ_MODE_DISABLE = 0x00;

    // Hrp single request
    public final static byte BP_SINGLE_REQ_MODE_ENABLE = 0x01;
    public final static byte BP_SINGLE_REQ_MODE_DISABLE = 0x00;

    // Hrp continue request
    public final static byte HRP_CONTINUE_REQ_MODE_ENABLE = 0x01;
    public final static byte HRP_CONTINUE_REQ_MODE_DISABLE = 0x00;

    // hour model
    public final static byte HOUR_12_MODEL = 0x01;
    public final static byte HOUR_24_MODEL = 0x00;

    // unit model
    public final static byte UNIT_METRIC_SYSTEM = 0x00;
    public final static byte UNIT_ENGLISH_SYSTEM = 0x01;

    // disturb model
    public final static byte DISTURB_ENABLE = 0x01;
    public final static byte DISTURB_DISABLE = 0x00;

    // SLEEP_ALL
    public final static byte SLEEP_ALL_ENABLE = 0x01;
    public final static byte SLEEP_ALL_DISABLE = 0x00;

    // HYPOXIA_NOTIFY
    public final static byte HYPOXIA_NOTIFY_ENABLE = 0x01;
    public final static byte HYPOXIA_NOTIFY_DISABLE = 0x00;

    // DATA_FORMAT
    public final static byte DATA_FORMAT_OPTION_0 = 0x00;
    public final static byte DATA_FORMAT_OPTION_1 = 0x01;

    // Transport Layer Object
    TransportLayer mTransportLayer;

    // Application Layer Call
    private ApplicationLayerCallback mCallback;

    public ApplicationLayerFunctionPacket deviceFunction;

    public ApplicationLayer(Context context, ApplicationLayerCallback callback) {
        SDKLogger.d(D, "initial");
        // register callback
        mCallback = callback;

        // initial the transport layer
        mTransportLayer = new TransportLayer(context, mTransportCallback);
    }

    /**
     * Connect to the remote device.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onConnectionStateChange} callback is invoked, reporting the result of the operation.
     *
     * @return the operation result
     */
    public boolean connect(String addr) {
        SDKLogger.d(D, "connect with: " + addr);
        return mTransportLayer.connect(addr);
    }

    /**
     * Close, it will disconnect to the remote, and close gatt.
     */
    public void close() {
        SDKLogger.d(D, "close()");
        mTransportLayer.close();
    }

    /**
     * Disconnect, it will disconnect to the remote.
     */
    public void disconnect() {
        mTransportLayer.disconnect();
    }

    /**
     * Set the name
     *
     * @param name the name
     */
    public void setDeviceName(String name) {
        SDKLogger.d(D, "set name, name: " + name);
        mTransportLayer.setDeviceName(name);
    }

    /**
     * Get the name
     */
    public void getDeviceName() {
        SDKLogger.d(D, "getDeviceName");
        mTransportLayer.getDeviceName();
    }

    public boolean setEcgCharacteristic(boolean enable){
        return mTransportLayer.setEcgCharacteristic(enable);
    }

    /**
     * Request Remote enter OTA mode. Command: 0x01, Key: 0x01.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked, reporting the result of the operation.
     * then the remote will response some information, the {@link ApplicationLayerCallback#onUpdateCmdRequestEnterOtaMode}
     * callback will invoked, response some information to host
     *
     * @return the operation result
     */
    public boolean UpdateCmdRequestEnterOtaMode() {
        SDKLogger.d(D, "UpdateCmdRequestEnterOtaMode");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_UPDATE_REQUEST, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_IMAGE_UPDATE, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote time. Command: 0x02, Key: 0x01.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param year the current time of year.
     * @param mon  the current time of mon.
     * @param day  the current time of day.
     * @param hour the current time of hour.
     * @param min  the current time of min.
     * @param sec  the current time of sec.
     * @return the operation result
     */
    public boolean SettingCmdTimeSetting(int year, int mon, int day, int hour, int min, int sec) {
        SDKLogger.d(D, "year: " + year
                + ", mon: " + mon
                + ", day: " + day
                + ", hour: " + hour
                + ", min: " + min
                + ", sec: " + sec);
        // generate key value data
        ApplicationLayerTimePacket timePackt = new ApplicationLayerTimePacket(year, mon, day, hour, min, sec);
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_TIMER, timePackt.getPacket());
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote time. Command: 0x02, Key: 0x02.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param Alarms the alarm list.
     * @return the operation result
     */
    public boolean SettingCmdAlarmsSetting(ApplicationLayerAlarmsPacket Alarms) {
        SDKLogger.d(D, "SettingCmdAlarmSetting");
        // generate key value data
        byte[] keyValue = null;
        if (Alarms == null || (Alarms.size() == 0)) {
            //do nothing
        } else {
            if (Alarms.size() > 8) {
                return false;
            }
            keyValue = Alarms.getPacket();
        }
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_ALARM, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Setting alarm2
     *
     * @param packet
     * @return
     */
    public boolean SettingAlarm2(ApplicationLayerAlarm2Packet packet) {
        SDKLogger.d(D, "SettingAlarm2");
        // generate key value data
        byte[] keyValue = packet.getPacket();

        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_ALARM2_SETTING, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * set medication reminder
     */
    public boolean setMedicationReminder(ApplicationLayerMedicationReminderListPacket reminderListPacket) {
        SDKLogger.d(D, "setMedicationReminder");
        // generate key value data
        byte[] keyValue = reminderListPacket.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_MEDICATION_REMINDER_SET, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * setting addressBook
     * 设置设备通讯录
     * @param packet
     * @return
     */
    public boolean SendAddressBook(ApplicationLayerAddressBookPacket packet){
        SDKLogger.d(D, "SendAddressBook");
        // generate key value data
        byte[] keyValue = packet.getPacket();

        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_ADDRESS_BOOK_REQ, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * setting SOS number
     * 设置设备 SOS
     * @param packet
     * @return
     */
    public boolean SendSOSNumber(ApplicationLayerSOSNumberPacket packet){
        SDKLogger.d(D, "SendSOSNumber");
        // generate key value data
        byte[] keyValue = packet.getPacket();

        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_SOS_NUMBER_REQ, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Request Remote alarms list. Command: 0x01, Key: 0x03.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked, reporting the result of the operation.
     * then the remote will response some information, the {@link ApplicationLayerCallback#onSettingCmdRequestAlarmList}
     * callback will invoked, response some information to host
     *
     * @return the operation result
     */
    public boolean SettingCmdRequestAlarmList() {
        SDKLogger.d(D, "SettingCmdRequestAlarmList");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_GET_ALARM_LIST_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Request Remote medication reminder list
     */
    public boolean getMedicationReminder() {
        SDKLogger.d(D, "getMedicationReminder");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_MEDICATION_REMINDER_REQ, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Request Remote alarms2 list.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked, reporting the result of the operation.
     * then the remote will response some information
     * callback will invoked, response some information to host
     *
     * @return the operation result
     */
    public boolean RequestAlarm2() {
        SDKLogger.d(D, "RequestAlarm2");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_ALARM2_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set Audio switch
     * @param switchInt
     * @return
     */
    public boolean SettingAudioSwitch(int switchInt){
        SDKLogger.d(D, "SettingAudioSwitch");
        byte[] keyValue = new byte[]{(byte) (switchInt == 0 ? 0x00:0x01)};
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_AUDIO_SET,keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING,keyData);
        return mTransportLayer.sendData(appPacketData);
    }
    /**
     * Get Audio switch
     * @return
     */
    public boolean GetAudioSwitch(){
        SDKLogger.d(D, "GetAudioSwitch");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_AUDIO_GET_REQ,null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING,keyData);
        return mTransportLayer.sendData(appPacketData);
    }


    /**
     * Set the remote user profile. Command: 0x02, Key: 0x10.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param user the user profile packet.
     * @return the operation result
     */
    public boolean SettingCmdUserSetting(ApplicationLayerUserPacket user) {
        SDKLogger.d(D, "SettingCmdUserSetting");
        // generate key value data
        byte[] keyValue = user.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_USER_PROFILE, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote lost mode. Command: 0x02, Key: 0x20.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param mode the lost mode.
     * @return the operation result
     */
    public boolean SettingCmdLostModeSetting(byte mode) {
        SDKLogger.d(D, "mode: " + mode);
        // generate key value data
        byte[] keyValue = {mode};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_LOST_MODE, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote step target. Command: 0x02, Key: 0x05.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param step the step target.
     * @return the operation result
     */
    public boolean SettingCmdStepTargetSetting(long step) {
        SDKLogger.d(D, "step: " + step);
        // generate key value data
        ApplicationLayerStepTargetPacket p = new ApplicationLayerStepTargetPacket(step);
        byte[] keyValue = p.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_STEP_TARGET, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote step target. Command: 0x02, Key: 0x05.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param sleepMinute the sleep minute target.
     * @return the operation result
     */
    public boolean SettingCmdSleepTargetSetting(int sleepMinute) {
        SDKLogger.d(D, "sleepMinute: " + sleepMinute);
        // generate key value data
        ApplicationLayerSleepTargetPacket p = new ApplicationLayerSleepTargetPacket(sleepMinute);
        byte[] keyValue = p.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_SLEEP_TARGET, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote step target. Command: 0x02, Key: 0x05.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param kCalc the kCalc target.
     * @return the operation result
     */
    public boolean SettingCmdCalcTargetSetting(int kCalc) {
        SDKLogger.d(D, "kCalc: " + kCalc);
        // generate key value data
        ApplicationLayerCalcTargetPacket p = new ApplicationLayerCalcTargetPacket(kCalc);
        byte[] keyValue = p.getPacket();
        // generate key data
        SDKLogger.i(D, "appData--keyValue[]=: " + Arrays.toString(keyValue));
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_CALC_TARGET, keyValue);
        // generate application layer packet
        SDKLogger.i(D, "appData--keyData[]=: " + Arrays.toString(keyData));
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        SDKLogger.i(D, "appData--appPacketData[]=: " + Arrays.toString(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote long sit notification. Command: 0x02, Key: 0x21.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param packet the sit packet.
     * @return the operation result
     */
    public boolean SettingCmdLongSitSetting(ApplicationLayerSitPacket packet) {
        SDKLogger.d(D, "SettingCmdLongSitSetting");
        // generate key value data
        byte[] keyValue = packet.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_SIT_TOO_LONG_NOTIFY, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        SDKLogger.i(D, "appData--appPacketData[]=: " + Arrays.toString(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote left right hand. Command: 0x02, Key: 0x22.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param mode the left right hand mode.
     * @return the operation result
     */
    public boolean SettingCmdLeftRightSetting(byte mode) {
        SDKLogger.d(D, "mode: " + mode);
        // generate key value data
        byte[] keyValue = {mode};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_LEFT_RIGHT_HAND_NOTIFY, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the phone OS. Command: 0x02, Key: 0x23.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param mode the phone os.
     * @return the operation result
     */
    public boolean SettingCmdPhoneOSSetting(byte mode) {
        SDKLogger.d(D, "mode: " + mode);
        // generate key value data
        byte[] keyValue = {mode, 0x00};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_PHONE_OS, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote call notify mode. Command: 0x02, Key: 0x25.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param mode call notify mode.
     * @return the operation result
     */
    public boolean SettingCmdCallNotifySetting(byte mode) {
        SDKLogger.d(D, "mode: " + mode);
        // generate key value data
        byte[] keyValue = {mode};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_INCOMING_ON_OFF, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }


    public boolean SettingCmdNotifySetting(ApplicationLayerNotifyPacket packet) {
        SDKLogger.d(D, "packet: " + packet.toString());
        // generate key value data
        byte[] keyValue = packet.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_NOTIFY_ALL, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Request the remote current long sit setting. Command: 0x02, Key: 0x26.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked, reporting the result of the operation.
     * then the remote will response some information, the {@link ApplicationLayerCallback#onSettingCmdRequestLongSit}
     * callback will invoked, response some information to host
     *
     * @return the operation result
     */
    public boolean SettingCmdRequestLongSitSetting() {
        SDKLogger.d(D, "SettingCmdRequestLongSitSetting");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_SIT_TOO_LONG_SWITCH_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Request the remote support function. Command: 0x01, Key: 0x37.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked, reporting the result of the operation.
     * then the remote will response some information, the {@link ApplicationLayerCallback#onSportFunction(ApplicationLayerMultiSportPacket)} ,the {@link ApplicationLayerCallback#onDeviceFunction(ApplicationLayerFunctionPacket)}
     * callback will invoked, response some information to host
     *
     * @return the operation result
     */
    public boolean SettingCmdRequestDeviceFunctionSetting() {
        SDKLogger.d(D, "SettingCmdRequestDeviceFunctionSetting");
        // generate key data

        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_DEVICE_FUNCTION_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * setting the remote hour system command:0x01  key:0x41
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked, reporting the result of the operation.
     *
     * @param mode 0x01: 12 hour model  0x00: 24 hour model
     * @return the operation result
     */
    public boolean SettingCmdSettingHourSystem(byte mode) {
        SDKLogger.d(D, "SettingCmdSettingHourSystem");
        // generate key value
        byte[] keyValue = {mode};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_HOUR_SYSTEM_SETTING, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request the remote hour system setting command:0x01  key:0x42
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked, reporting the result of the operation.
     *
     * @return the operation result
     */
    public boolean SettingCmdRequestHourSystemSetting() {
        SDKLogger.d(D, "SettingCmdRequestHourSystemSetting");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_HOUR_SYSTEM_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }


    public boolean SettingCmdSettingUnit(byte mode) {
        SDKLogger.d(D, "SettingCmdSettingUnit");
        byte[] keyValue = {mode};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_UNIT_SYSTEM_SETTING, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SettingCmdSettingDisturbSetting(ApplicationLayerDisturbPacket packet) {
        SDKLogger.d(D, "SettingCmdSettingDisturbSetting");
        byte[] keyValue = packet.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_DISTURB_SETTING, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SettingCmdSettingScreenLightDuration(int duration) {
        SDKLogger.d(D, "SettingCmdSettingScreenLightDuration");
        byte[] keyValue = {(byte) (duration & 0xFF)};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SCREEN_LIGHT_DURATION_SETTING, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SettingCmdRequestScreenLightDurationSetting() {
        SDKLogger.d(D, "SettingCmdRequestScreenLightDurationSetting");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SCREEN_LIGHT_DURATION_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SettingCmdSettingLanguage(DeviceLanguage language) {
        SDKLogger.d(D, "SettingCmdSettingLanguage");
        byte[] keyValue = new byte[]{1};
        switch (language) {
            case LANGUAGE_SAMPLE_CHINESE:
                keyValue[0] = (byte) 0x01;
                break;
            case LANGUAGE_TRADITIONAL_CHINESE:
                keyValue[0] = (byte) 0x02;
                break;
            case LANGUAGE_ENGLISH:
                keyValue[0] = (byte) 0x00;
                break;
            case LANGUAGE_SPANISH:
                keyValue[0] = (byte) 0x57;
                break;
            case LANGUAGE_FRENCH:
                keyValue[0] = (byte) 0x14;
                break;
            case LANGUAGE_GERMAN:
                keyValue[0] = (byte) 0x12;
                break;
            case LANGUAGE_ITALIAN:
                keyValue[0] = (byte) 0x60;
                break;
            case LANGUAGE_JAPANESE:
                keyValue[0] = (byte) 0x41;
                break;
            case LANGUAGE_SWEDISH:
                keyValue[0] = (byte) 0x42;
                break;
            case LANGUAGE_KOREAN:
                keyValue[0] = (byte) 0x1d;
                break;
            case LANGUAGE_PORTUGUESE:
                keyValue[0] = (byte) 0x3e;
                break;
            case LANGUAGE_RUSSIAN:
                keyValue[0] = (byte) 0x13;
                break;
            case LANGUAGE_TURKISH:
                keyValue[0] = (byte) 0x52;
                break;
            case LANGUAGE_POLAND:
                keyValue[0] = (byte) 0x0d;
                break;
            case LANGUAGE_MONGOLIA:
                keyValue[0] = (byte) 0x35;
                break;
            case LANGUAGE_VIETNAM:
                keyValue[0] = (byte) 0x66;
                break;
            case LANGUAGE_THAI:
                keyValue[0] = (byte) 0x51;
                break;
            default:
                keyValue[0] = (byte) 0x00;
                break;
        }
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_LANGUAGE_SETTING, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SettingCmdRequestLanguage() {
        SDKLogger.d(D, "SettingCmdRequestLanguage");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_LANGUAGE_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SettingCmdRequestDeviceInfo() {
        SDKLogger.d(D, "SettingCmdRequestLanguage");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_DEVICE_INFO_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request device status
     *
     * @return
     */
    public boolean RequestDeviceStatus() {
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_DEVICE_STATUS_REQ, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SettingCmdSettingScreenLight(int lightPercent) {
        SDKLogger.d(D, "SettingCmdRequestLanguage");
        byte[] keyValue = {(byte) (lightPercent & 0xFF)};
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_DEVICE_SCREEN_LIGHT_SETTING, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SettingCmdRequestScreenLight() {
        SDKLogger.d(D, "SettingCmdRequestLanguage");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_DEVICE_SCREEN_LIGHT_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SettingCmdSettingSwitch(ApplicationLayerSwitchPacket packet) {
        SDKLogger.d(D, "SettingCmdRequestLanguage");
        byte[] keyValue = packet.getPacket();
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_DEVICE_SWITCH_SETTING, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SettingCmdRequestSwitch() {
        SDKLogger.d(D, "SettingCmdRequestLanguage");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_DEVICE_SWITCH_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SettingCmdRequestDisturbSetting() {
        SDKLogger.d(D, "SettingCmdRequestDisturbSetting");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_DISTURB_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SettingCmdRequestUnit() {
        SDKLogger.d(D, "SettingCmdRequestUnit");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_UNIT_SYSTEM_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }


    /**
     * Request the remote current notify setting. Command: 0x02, Key: 0x28.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked, reporting the result of the operation.
     * then the remote will response some information, the {@link ApplicationLayerCallback#onSettingCmdRequestNotifySwitch}
     * callback will invoked, response some information to host
     *
     * @return the operation result
     */
    public boolean SettingCmdRequestNotifySwitchSetting() {
        SDKLogger.d(D, "SettingCmdRequestNotifySwitchSetting");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_NOTIFY_SWITCH_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote Turn Over Wrist. Command: 0x02, Key: 0x2A.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param enable ENABLE/DISABLE.
     * @return the operation result
     */
    public boolean SettingCmdTurnOverWristSetting(boolean enable) {
        SDKLogger.d(D, "enable: " + enable);
        // generate key value data
        byte[] keyValue = {enable ? TURN_OVER_WRIST_CONTROL_ENABLE : TURN_OVER_WRIST_CONTROL_DISABLE};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_TURN_OVER_WRIST_SET, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Request the remote current Turn Over Wrist setting. Command: 0x02, Key: 0x2B.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked, reporting the result of the operation.
     * then the remote will response some information, the {@link ApplicationLayerCallback#onSettingCmdRequestLongSit}
     * callback will invoked, response some information to host
     *
     * @return the operation result
     */
    public boolean SettingCmdRequestTurnOverWristSetting() {
        SDKLogger.d(D, "SettingCmdRequestTurnOverWristSetting");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_TURN_OVER_WRIST_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request the remote current home pager index Command: 0x02, Key: 0x39.
     *
     * @return the operation result
     */
    public boolean SettingCmdRequestHomePager() {
        SDKLogger.d(D, "SettingCmdRequestHomePager");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_DEVICE_HOME_PAGER_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }


    /**
     * request the remote current support sport model Command: 0x02, Key: 0x39.
     *
     * @return the operation result
     */
    public boolean SettingCmdRequestMultiSport() {
        SDKLogger.d(D, "SettingCmdRequestMultiSport");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_DEVICE_MULTI_SPORT_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request the remote current support sport model Command: 0x02, Key: 0x39.
     *
     * @return the operation result
     */
    public boolean SettingCmdRequestHrpParams() {
        SDKLogger.d(D, "SettingCmdRequestHrpParams");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_DEVICE_HRP_PARAMS_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * set the remote home pager
     *
     * @param index index of home pager
     * @return
     */
    public boolean SettingCmdHomePagerSetting(int index) {
        SDKLogger.d(D, "SettingCmdRequestHomePager");
        // generate key data
        byte[] keyValue = {(byte) (index & 0xFF)};
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_DEVICE_HOME_PAGER_SET, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Request bond to remote. Command: 0x03, Key: 0x01.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked, reporting the result of the operation.
     * then the remote will response some information, the {@link ApplicationLayerCallback#onBondCmdRequestBond}
     * callback will invoked, response some information to host
     *
     * @param userId the user id string.
     * @return the operation result
     */
    public boolean BondCmdRequestBond(String userId) {
        SDKLogger.d(D, "userId=" + userId);
        // generate key value data
        // be careful java use the UTF-16 code, so we need change the ascii byte array
        byte[] asciiArray = StringByteTrans.Str2Bytes(userId);
        byte[] keyValue = new byte[32];
        if (asciiArray.length > 32) {
            System.arraycopy(asciiArray, 0, keyValue, 0, 32);
        } else {
            System.arraycopy(asciiArray, 0, keyValue, 0, asciiArray.length);
        }
        SDKLogger.i(D, "keyValue=" + DataConverter.bytes2Hex(keyValue));
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_BOND_REQ, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_BOND_REG, keyData);
        SDKLogger.i(D, "appData=" + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean BondConfirmRequestBond(String userId) {
        SDKLogger.d(D, "userId=" + userId);
        // generate key value data
        // be careful java use the UTF-16 code, so we need change the ascii byte array
        byte[] asciiArray = StringByteTrans.Str2Bytes(userId);
        byte[] keyValue = new byte[32];
        if (asciiArray.length > 32) {
            System.arraycopy(asciiArray, 0, keyValue, 0, 32);
        } else {
            System.arraycopy(asciiArray, 0, keyValue, 0, asciiArray.length);
        }
        SDKLogger.i(D, "keyValue=" + DataConverter.bytes2Hex(keyValue));
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CONFIRM_BOND_REQ, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_BOND_REG, keyData);
        SDKLogger.i(D, "appData=" + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Request login to remote. Command: 0x03, Key: 0x03.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked, reporting the result of the operation.
     * then the remote will response some information, the {@link ApplicationLayerCallback#onBondCmdRequestLogin}
     * callback will invoked, response some information to host
     *
     * @param userId the user id string.
     * @return the operation result
     */
    public boolean BondCmdRequestLogin(String userId) {
        SDKLogger.d(D, "userid: " + userId);
        // generate key value data
        // be careful java use the UTF-16 code, so we need change the ascii byte array
        byte[] asciiArray = StringByteTrans.Str2Bytes(userId);
        byte[] keyValue = new byte[32];
        if (asciiArray.length > 32) {
            System.arraycopy(asciiArray, 0, keyValue, 0, 32);
        } else {
            System.arraycopy(asciiArray, 0, keyValue, 0, asciiArray.length);
        }
        SDKLogger.i(D, "keyValue: " + DataConverter.bytes2Hex(keyValue));
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_LOGIN_REQ, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_BOND_REG, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Request clear bond to remote. Command: 0x03, Key: 0x05.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked, reporting the result of the operation.
     *
     * @return the operation result
     */
    public boolean BondCmdRequestRemoveBond() {
        // generate key value data, reserve one byte
        byte[] keyValue = new byte[1];
        SDKLogger.i(D, "keyValue: " + DataConverter.bytes2Hex(keyValue));
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_UNBOND, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_BOND_REG, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Send notify info to the remote. Command: 0x04, Key: 0x01.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @return the operation result
     */
    public boolean NotifyCmdCallNotifyInfoSetting() {
        SDKLogger.d(D, "NotifyCmdCallNotifyInfoSetting");
        return NotifyCmdCallNotifyInfoSetting("");
        /*
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_NOTIFY_IMCOMING_CALL, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_NOTIFY, keyData);
        ZLogger.i(D,"appData: " + DataConverter.bytes2Hex(appPacketData) + "\n, length: " + appPacketData.length);

        // sent the data
        return mTransportLayer.sendData(appPacketData);
        */
    }

    public boolean NotifyCmdCallNotifyInfoSetting(String showData) {
        SDKLogger.d(D, "showData: " + showData);
        // generate key data
        byte[] keyData;
        if (TextUtils.isEmpty(showData)) {
            keyData = ApplicationLayerKeyPacket.preparePacket(KEY_NOTIFY_IMCOMING_CALL, null);
        } else {
            keyData = ApplicationLayerKeyPacket.preparePacket(KEY_NOTIFY_IMCOMING_CALL, showData.getBytes());
        }
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_NOTIFY, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Send call accept notify info to the remote. Command: 0x04, Key: 0x02.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @return the operation result
     */
    public boolean NotifyCmdCallAcceptNotifyInfoSetting() {
        SDKLogger.d(D, "NotifyCmdCallAcceptNotifyInfoSetting");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_NOTIFY_IMCOMING_CALL_ACC, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_NOTIFY, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Send call reject notify info to the remote. Command: 0x04, Key: 0x03.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @return the operation result
     */
    public boolean NotifyCmdCallRejectNotifyInfoSetting() {
        SDKLogger.d(D, "NotifyCmdCallRejectNotifyInfoSetting");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_NOTIFY_IMCOMING_CALL_REJ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_NOTIFY, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Send notify info to the remote. Command: 0x04, Key: 0x04.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param info call notify info.
     * @return the operation result
     */
    public boolean NotifyCmdOtherNotifyInfoSetting(byte info) {
        SDKLogger.d(D, "NotifyCmdOtherNotifyInfoSetting, info: " + info);
        /*
        // generate key value data
        byte[] keyValue = {info};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_NOTIFY_INCOMING_OTHER_NOTIFY, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_NOTIFY, keyData);
        SDKLogger.i(D,"appData: " + DataConverter.bytes2Hex(appPacketData) + "\n, length: " + appPacketData.length);

        // sent the data
        return mTransportLayer.sendData(appPacketData);
        */
        return NotifyCmdOtherNotifyInfoSetting(info, "");
    }

    public boolean NotifyCmdOtherNotifyInfoSetting(byte info, String showData) {
        SDKLogger.d(D, "info: " + info + "showData: " + showData);
        // generate key value data
        //byte[] keyValue = {info};
        byte[] showDataByte = null;
        byte[] keyValue = null;
        if (TextUtils.isEmpty(showData)) {
            keyValue = new byte[1];
            keyValue[0] = info;
        } else {
            showDataByte = showData.getBytes();    //UTF-8
            int len = showDataByte.length;
            //设置 最多200个utf-8
            if (len > 200) {
                len = 200;
            }
            keyValue = new byte[1 + len];
            keyValue[0] = info;
            System.arraycopy(showDataByte, 0, keyValue, 1, len);
        }

        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_NOTIFY_INCOMING_OTHER_NOTIFY, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_NOTIFY, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }


    /**
     * Request remote send sport data. Command: 0x05, Key: 0x01.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked, reporting the result of the operation.
     * then the remote will response some information, the {@link ApplicationLayerCallback#onSportDataCmdStepData}
     * and {@link ApplicationLayerCallback#onSportDataCmdSleepData}
     * callback will invoked, response some information to host
     *
     * @return the operation result
     */
    public boolean SportDataCmdRequestData() {
        SDKLogger.d(D, "SportDataCmdRequestData");
        // generate key value data

        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SPORTS_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.d(D,"SportDataCmdRequestData appData="+DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote sync mode. Command: 0x05, Key: 0x06.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param mode the left right hand mode.
     * @return the operation result
     */
    public boolean SportDataCmdSyncSetting(byte mode) {
        SDKLogger.d(D, "mode: " + mode);
        // generate key value data
        byte[] keyValue = {mode};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SPORTS_DATA_SYNC, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote sync today. Command: 0x05, Key: 0x09.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param packet the today sport packet.
     * @return the operation result
     */
    public boolean SportDataCmdSyncToday(ApplicationLayerTodaySportPacket packet) {
        SDKLogger.d(D, "SportDataCmdSyncToday");
        // generate key value data
        byte[] keyValue = packet.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SPORTS_DATA_TODAY_SYNC, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote sync recently. Command: 0x05, Key: 0x0a.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param packet the recently sport packet.
     * @return the operation result
     */
    public boolean SportDataCmdSyncRecently(ApplicationLayerRecentlySportPacket packet) {
        SDKLogger.d(D, "SportDataCmdSyncRecently");
        // generate key value data
        byte[] keyValue = packet.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SPORTS_DATA_LAST_SYNC, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.d(D,"SportDataCmdSyncRecently appData="+DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * hrp single request. Command: 0x05, Key: 0x0b.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @return the operation result
     */
    public boolean SportDataRequestTodayAdjust() {
        SDKLogger.d(D, "SportDataRequestTodayAdjust: ");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SPORTS_DATA_TODAY_ADJUST_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * hrp single request. Command: 0x05, Key: 0x0d.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param enable enable/disable hrp single request .
     * @return the operation result
     */
    public boolean SportDataCmdHrpSingleRequest(boolean enable) {
        SDKLogger.d(D, "enable: " + enable);
        // generate key value data
        byte[] keyValue = new byte[]{enable ? HRP_SINGLE_REQ_MODE_ENABLE : HRP_SINGLE_REQ_MODE_DISABLE};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SPORTS_HRP_SINGLE_REQ, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * hrp single request. Command: 0x05, Key: 0x0d.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param enable enable/disable hrp single request .
     * @return the operation result
     */
    public boolean SportDataCmdBpSingleRequest(boolean enable) {
        SDKLogger.d(D, "enable: " + enable);
        // generate key value data
        byte[] keyValue = new byte[]{enable ? BP_SINGLE_REQ_MODE_ENABLE : BP_SINGLE_REQ_MODE_DISABLE};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SPORTS_BP_SINGLE_REQ, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * hrp continue set. Command: 0x05, Key: 0x0d.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param enable   enable/disable hrp continue request .
     * @param interval Unit minutes, only enable valid.
     * @return the operation result
     */
    public boolean SportDataCmdHrpContinueSet(boolean enable, int interval) {
        SDKLogger.d(D, "SportDataCmdHrpContinueRequest, enable: " + enable + ", interval: " + interval);
        // generate key value data
        byte[] keyValue = new byte[]{enable ? HRP_CONTINUE_REQ_MODE_ENABLE : HRP_CONTINUE_REQ_MODE_DISABLE
                , (byte) (interval & 0xFF)};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SPORTS_HRP_CONTINUE_SET, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * hrp continue set. Command: 0x05, Key: 0x11.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked, reporting the result of the operation.
     * then the remote will response some information, the {@link ApplicationLayerCallback#onSportDataCmdHrpContinueParamRsp}
     * callback will invoked, response some information to host
     * reporting the result of the operation.
     *
     * @return the operation result
     */
    public boolean SportDataCmdHrpContinueParamRequest() {
        SDKLogger.d(D, "SportDataCmdHrpContinueParamRequest");
        // generate key value data
        byte[] keyValue = null;
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SPORTS_HRP_CONTINUE_PARAMS_GET, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }


    /**
     * Fac Command use to enable led. Command: 0x06, Key: 0x05.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param led the led want to enable
     * @return the operation result
     */
    public boolean FACCmdEnableLed(byte led) {
        SDKLogger.d(D, "FACCmdEnableLed");
        byte[] keyData;
        if (led != FAC_LED_CONTROL_ENABLE_ALL) {
            // generate key value data
            byte[] keyValue = {led};
            // generate key data
            keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_TEST_LED, keyValue);
        } else {
            keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_TEST_LED, null);
        }
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_FACTORY_TEST, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Fac Command use to enable vibrate. Command: 0x06, Key: 0x06.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @return the operation result
     */
    public boolean FACCmdEnableVibrate() {
        // generate key value data
        //byte[] keyValue = packet.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_TEST_MOTO, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_FACTORY_TEST, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData) + "\n, length: " + appPacketData.length);

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Fac Command use to request sensor data. Command: 0x06, Key: 0x0d.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     * then the remote will response some information, the {@link ApplicationLayerCallback#onFACCmdSensorData}
     * and {@link ApplicationLayerCallback#onSportDataCmdSleepData}
     * callback will invoked, response some information to host
     *
     * @return the operation result
     */
    public boolean FACCmdRequestSensorData() {
        // generate key value data
        //byte[] keyValue = packet.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_TEST_SENSOR_DATA_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_FACTORY_TEST, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }


    public boolean FACCmdSetDefaultFunction(JWDefaultFunctionInfo functionInfo) {
        byte key = 0b00000000;
        if (functionInfo.bloodPressureEnable) {
            key |= 0b00000001;
        }
        if (functionInfo.temperatureEnable) {
            key |= 0b00000010;
        }
        if (functionInfo.pressureEnable) {
            key |= 0b00000100;
        }
        if (functionInfo.sceneEnable) {
            key |= 0b00001000;
        }
        if (functionInfo.alexaEnable) {
            key |= 0b00010000;
        }
        if (functionInfo.lightSenseEnable) {
            key |= 0b00100000;
        }
        if (!functionInfo.agingModeEnable) {
            key |= 0b01000000;
        }
        byte[] data = {key};
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_DEFAULT_FUNCTION_SET, data);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_FACTORY_TEST, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        return mTransportLayer.sendData(appPacketData);
    }

    public boolean FACCmdReadDefaultFunction() {
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_DEFAULT_FUNCTION_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_FACTORY_TEST, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }


    /**
     * Fac Command use to request sensor data. Command: 0x06, Key: 0x0d.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     * then the remote will response some information, the {@link ApplicationLayerCallback#onFACCmdSensorData}
     * and {@link ApplicationLayerCallback#onSportDataCmdSleepData}
     * callback will invoked, response some information to host
     *
     * @return the operation result
     */
    public boolean FACCmdRequestTodaySleep() {
        // generate key value data
        //byte[] keyValue = packet.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_TEST_TODAY_SLEEP_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_FACTORY_TEST, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Fac Command use to request Silence upgrade model
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     * then the remote will response some information, the {@link ApplicationLayerCallback#onFACCmdSensorData}
     * callback will invoked, response some information to host
     *
     * @return the operation result
     */
    public boolean FACCmdRequestSilenceUpgradeModel() {
        // generate key value data
        //byte[] keyValue = packet.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_TEST_SILENCE_UPGRADE_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_FACTORY_TEST, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * @param model 0  1  2  3  4
     * @return the operation result
     */
    public boolean FACCmdSetSilenceUpgradeModel(int model) {
        // generate key value data
        byte[] keyValue = {(byte) (model & 0xFF)};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_TEST_SILENCE_UPGRADE, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_FACTORY_TEST, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Fac Command use to request sensor data. Command: 0x06, Key: 0x0d.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     * then the remote will response some information, the {@link ApplicationLayerCallback#onFACCmdSensorData}
     * and {@link ApplicationLayerCallback#onSportDataCmdSleepData}
     * callback will invoked, response some information to host
     *
     * @return the operation result
     */
    public boolean FACCmdRequestHistoryIndex() {
        // generate key value data
        //byte[] keyValue = packet.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_TEST_HISTORY_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_FACTORY_TEST, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * reset device
     * 恢复出厂设置
     * @return
     */
    public boolean FACCmdRequestReset(){
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_TEST_RESET_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_FACTORY_TEST, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }


    /**
     * Fac Command use to enter test mode. Command: 0x06, Key: 0x0e.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param key the 32 byte token key
     * @return the operation result
     */
    public boolean FACCmdEnterTestMode(byte[] key) {
        byte[] keyData;
        if (key != null) {
            if (key.length != 32) {
                SDKLogger.d(D, "The length is not right.");
                return false;
            }
            byte[] keyValue = new byte[32];
            // generate key value data
            System.arraycopy(key, 0, keyValue, 0, 32);
            // generate key data
            keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_TEST_ENTER_SPUER_KEY, keyValue);
        } else {
            keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_TEST_ENTER_SPUER_KEY, null);
        }
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_FACTORY_TEST, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Fac Command use to exit test mode. Command: 0x06, Key: 0x0e.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param key the 32 byte token key
     * @return the operation result
     */
    public boolean FACCmdExitTestMode(byte[] key) {
        byte[] keyData;
        if (key != null) {
            if (key.length != 32) {
                SDKLogger.d(D, "The length is not right.");
                return false;
            }
            byte[] keyValue = new byte[32];
            // generate key value data
            System.arraycopy(key, 0, keyValue, 0, 32);
            // generate key data
            keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_TEST_LEAVE_SPUER_KEY, keyValue);
        } else {
            keyData = ApplicationLayerKeyPacket.preparePacket(KEY_FAC_TEST_LEAVE_SPUER_KEY, null);
        }
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_FACTORY_TEST, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Send control cmd to the remote. Command: 0x07, Key: 0x11.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param cmd cmd.
     * @return the operation result
     */
    public boolean ControlCmdCameraControl(byte cmd) {
        SDKLogger.d(D, "cmd: " + cmd);
        // generate key value data
        byte[] keyValue = {cmd};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CTRL_APP_REQ, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CTRL, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Log Command use to open log. Command: 0x0a, Key: 0x01.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param key the 32 byte token key
     * @return the operation result
     */
    public boolean LogCmdOpenLog(byte[] key) {
        SDKLogger.d(D, "LogCmdOpenLog");
        byte[] keyData;
        if (key != null) {
            byte[] keyValue = new byte[key.length];
            // generate key value data
            System.arraycopy(key, 0, keyValue, 0, key.length);
            // generate key data
            keyData = ApplicationLayerKeyPacket.preparePacket(KEY_LOG_FUNC_OPEN, keyValue);
        } else {
            keyData = ApplicationLayerKeyPacket.preparePacket(KEY_LOG_FUNC_OPEN, null);
        }
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_LOG, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Log Command use to close log. Command: 0x0a, Key: 0x02.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @return the operation result
     */
    public boolean LogCmdCloseLog() {
        SDKLogger.d(D, "LogCmdCloseLog");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_LOG_FUNC_CLOSE, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_LOG, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Log Command use to request log. Command: 0x0a, Key: 0x04.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param key the 32 byte token key
     * @return the operation result
     */
    public boolean LogCmdRequestLog(byte key) {
        SDKLogger.d(D, "LogCmdRequestLog");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_LOG_REQ, new byte[]{key});

        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_LOG, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request classic address
     *
     * @return
     */
    public boolean RequestClassicAddress() {
        SDKLogger.d(D, "LogCmdRequestLog");

        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_CLASSIC_ADDRESS_REQ, null);

        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }


    /**
     * request classic status
     *
     * @return
     */
    public boolean RequestClassicStatus() {
        SDKLogger.d(D, "LogCmdRequestLog");

        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_CLASSIC_STATUS_REQ, null);

        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * SettingFullSync
     *
     * @return
     */
    public boolean SettingFullSync() {
        SDKLogger.d(D, "SettingFullSync");

        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_FULL_SYNC, null);

        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * when app start sport set device rate detect
     *
     * @param flag isOpen
     * @return
     */
    public boolean SettingAppSportRateDetect(boolean flag) {
        byte[] keyValue = new byte[1];
        if (flag) {
            keyValue[0] = 0x01;
        } else {
            keyValue[0] = 0x00;
        }
        byte[] keyData;

        keyData = ApplicationLayerKeyPacket.preparePacket(KEY_APP_SPORT_RATE_DETECT_START, keyValue);
//        if (flag) {
//
//        } else {
//            keyData = ApplicationLayerKeyPacket.preparePacket(KEY_APP_SPORT_RATE_DETECT_START, null);
//        }
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * when app start sport set device rate detect
     *
     * @return
     */
    public boolean CheckAppSportRateDetect() {
        byte[] keyValue = new byte[1];

        keyValue[0] = 0x02;

        byte[] keyData;

        keyData = ApplicationLayerKeyPacket.preparePacket(KEY_APP_SPORT_RATE_DETECT_START, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * set sync data end
     *
     * @return
     */
    public boolean SettingSyncDataEnd() {
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SPORTS_DATA_END, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * set sleep adjust info
     *
     * @return
     */
    public boolean SettingSleepAdjust(ApplicationLayerSleepAdjustPacket packet) {
        byte[] keyValue = packet.getPacket();
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SLEEP_ADJUST, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * set sleep adjust info
     *
     * @return
     */
    public boolean SettingSleepTimeAdjust(ApplicationLayerSleepTimeAdjustPacket packet) {
        byte[] keyValue = packet.getPacket();
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SLEEP_TIME_ADJUST, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * check temperature measure
     *
     * @return
     */
    public boolean CheckTemperatureMeasure() {
        byte[] keyValue = new byte[1];
        keyValue[0] = 0x02;
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_TEMP_SET, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * check temperature measure
     *
     * @return
     */
    public boolean SetTemperatureMeasure(boolean openFlag) {
        byte[] keyValue = new byte[1];
        if (openFlag) {
            keyValue[0] = 0x01;
        } else {
            keyValue[0] = 0x00;
        }
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_TEMP_SET, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SetSpo2Measure(boolean openFlag) {
        byte[] keyValue = new byte[1];
        if (openFlag) {
            keyValue[0] = 0x01;
        } else {
            keyValue[0] = 0x00;
        }
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SPO2_SETTING, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean CheckSpo2MeasureStatus() {
        byte[] keyValue = new byte[1];
        keyValue[0] = 0x02;
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SPO2_SETTING, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request temperature control
     *
     * @return
     */
    public boolean RequestTemperatureSetting() {
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_TEMP_CONTROL_REQ, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request bp2 control
     *
     * @return
     */
    public boolean RequestBp2Setting() {
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_BP2_CONTROL_REQ, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request sleep all switch
     * @return
     */
    public boolean RequestSleepAllSwitch() {
        SDKLogger.d(D, "RequestSleepAllSwitch");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_SLEEP_ALL_SWITCH_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request HypoxiaSwitch
     * @return
     */
    public boolean RequestHypoxiaSwitch() {
        SDKLogger.d(D, "RequestHypoxiaSwitch");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_HYPOXIA_SWITCH_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request HighHrvSwitch
     * @return
     */
    public boolean RequestHighHrvSwitch() {
        SDKLogger.d(D, "RequestHighHrvSwitch");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_HIGH_HEART_RATE_SWITCH_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request DeviceDataFormat
     * @return
     */
    public boolean RequestDeviceDateFormat() {
        SDKLogger.d(D, "RequestDeviceDateFormat");
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_DEVICE_DATE_FORMAT_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * set temperature control
     *
     * @return control info
     */
    public boolean SetTemperatureControl(ApplicationLayerTemperatureControlPacket packet) {
        byte[] keyValue = packet.getPacket();
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_TEMP_CONTROL_SET, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * set temperature control
     *
     * @return control info
     */
    public boolean SetBp2Control(ApplicationLayerBp2ControlPacket packet) {
        byte[] keyValue = packet.getPacket();
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_BP2_CONTROL_SET, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote SleepAllSwitch. Command: 0x02, Key: 0x6F.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param enable ENABLE/DISABLE.
     * @return the operation result
     */
    public boolean SetSleepAllSwitch(boolean enable) {
        SDKLogger.d(D, "enable: " + enable);
        // generate key value data
        byte[] keyValue = {enable ? SLEEP_ALL_ENABLE : SLEEP_ALL_DISABLE};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_SLEEP_ALL_SWITCH, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote HypoxiaSwitch. Command: 0x02, Key: 0x72.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param enable ENABLE/DISABLE.
     * @return the operation result
     */
    public boolean SetHypoxiaSwitch(boolean enable) {
        SDKLogger.d(D, "enable: " + enable);
        // generate key value data
        byte[] keyValue = {enable ? HYPOXIA_NOTIFY_ENABLE : HYPOXIA_NOTIFY_DISABLE};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_HYPOXIA_SWITCH, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SetHighHeartRateSwitch(ApplicationLayerHighHeartRatePacket packet) {
        SDKLogger.d(D, "SetHighHeartRateSwitch");
        byte[] keyValue = packet.getPacket();
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_HIGH_HEART_RATE_SWITCH, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * Set the remote DateFormat. Command: 0x02, Key: 0x78.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param format ENABLE/DISABLE.
     * @return the operation result
     */
    public boolean SetDeviceDateFormat(int format) {
        SDKLogger.d(D, "format: " + format);
        // generate key value data
        byte[] keyValue = {format == 0 ? DATA_FORMAT_OPTION_0 : DATA_FORMAT_OPTION_1};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_DEVICE_DATE_FORMAT, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setPrivateBp(boolean isOpen, int high, int low) {
        ApplicationLayerMulPrivateBpPacket packet = new ApplicationLayerMulPrivateBpPacket(isOpen, high, low);
        byte[] keyValue = packet.getPacket();
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_MUL_PRIVATE_BP, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_MULTIPLE_CMD, keyData);
        SDKLogger.i(D, "setPrivateBp: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * setting timer info
     *
     * @param packet
     * @return
     */
    public boolean SettingTimerInfo(ApplicationLayerTimerPacket packet) {
        byte[] keyValue = packet.getPacket();
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CTRL_TIMER_SETTING, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CTRL, keyData);
        SDKLogger.i(D, "timerData: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request timer info
     *
     * @return
     */
    public boolean RequestTimerInfo() {
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CTRL_TIMER_REQ, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CTRL, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * setting custom ui
     *
     * @param packet
     * @return
     */
    public boolean SettingCustomUi(ApplicationLayerCustomUiPacket packet) {
        byte[] keyValue = packet.getPacket();
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CTRL_CUSTOM_UI_SETTING, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CTRL, keyData);
        SDKLogger.i(D, "Custom ui: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request custom ui
     *
     * @return
     */
    public boolean RequestCustomUi() {
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CTRL_CUSTOM_UI_REQ, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CTRL, keyData);
        SDKLogger.i(D, "App data: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }


    /**
     * setting music ui
     *
     * @param packet
     * @return
     */
    public boolean SettingMusicStatus(ApplicationLayerMusicPlayerPacket packet) {
        byte[] keyValue = packet.getPacket();
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CTRL_MUSIC_STATUS, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CTRL, keyData);
        SDKLogger.i(D, "Music status: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request ota status
     *
     * @return
     */
    public boolean ReqSilenceOtaStatus() {
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CTRL_OTA_STATUS_REQ, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CTRL, keyData);
        SDKLogger.i(D, "Music status: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * set custom exercise lack
     *
     * @return
     */
    public boolean SetCustomExerciseLack() {
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CUSTOM_EXERCISE_SET, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CUSTOM_MADE, keyData);
        SDKLogger.i(D, "Music status: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * request custom notify
     *
     * @return
     */
    public boolean ReqCustomNotify() {
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CUSTOM_NOTIFY_REQ, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CUSTOM_MADE, keyData);
        SDKLogger.i(D, "Music status: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * sync custom notify
     *
     * @return
     */
    public boolean SyncCustomNotify() {
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CUSTOM_NOTIFY_SYNC, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CUSTOM_MADE, keyData);
        SDKLogger.i(D, "Music status: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * setting custom style color
     * 设置更换表盘颜色
     * @param color 0-7
     *              0-默认，1-M60Y100,2-M75Y100,3-M0Y100,
     *             4-C75Y100,5-C100M50,6-C100M100,7-C60M90
     * @return
     */
    public boolean SetCustomStyleColor(int color) {
        byte[] colorData = new byte[]{(byte) (color & 0xff)};
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CUSTOM_STYLE_COLOR, colorData);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CUSTOM_MADE, keyData);
        SDKLogger.i(D, "Music status: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean sendCustomNotify(String content) {
        SDKLogger.d(D, "showData content: " + content);
        if (TextUtils.isEmpty(content)) {
            return false;
        }
        byte[] showDataByte = content.getBytes();    //UTF-8
        int len = showDataByte.length;
        // 最多 200 个 utf-8
        if (len > 200) {
            len = 200;
        }
        byte[] keyValue = new byte[len];
        System.arraycopy(showDataByte, 0, keyValue, 0, len);

        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CUSTOM_NOTIFY_CONTENT, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CUSTOM_MADE, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setPulse(boolean isOpen, int duration, int level) {
        SDKLogger.d(D, "setPulse isOpen: " + isOpen + ", duration = " + duration + ", level = " + level);

        byte[] keyValue = new byte[3];
        keyValue[0] = (byte) (isOpen ? 0x01 : 0x00);
        keyValue[1] = (byte) (duration & 0xFF);
        keyValue[2] = (byte) (level & 0xFF);

        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CUSTOM_PULSE_SET, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CUSTOM_MADE, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setSleepHelp(boolean isOpen, int mode, int duration, int effectiveTime, int level) {
        SDKLogger.d(D, "setSleepHelp isOpen: " + isOpen + ", mode = " + mode +  ", duration = " + duration + ", effectiveTime = " + effectiveTime + ", level = " + level);

        byte[] keyValue = new byte[5];
        keyValue[0] = (byte) (isOpen ? 0x01 : 0x00);
        keyValue[1] = (byte) (mode & 0xFF);
        keyValue[2] = (byte) (duration & 0xFF);
        keyValue[3] = (byte) (effectiveTime & 0xFF);
        keyValue[4] = (byte) (level & 0xFF);

        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CUSTOM_SLEEP_HELP_SET, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CUSTOM_MADE, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setFemaleHealth(JWFemaleHealthInfo healthInfo) {
        ApplicationLayerFemaleHealthPacket packet = new ApplicationLayerFemaleHealthPacket(healthInfo);

        byte[] keyValue = packet.getPacket();

        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CTRL_FEMALE_SET, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CTRL, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setWeather(JWWeatherInfo weatherInfo) {
        ApplicationLayerWeatherPacket packet = new ApplicationLayerWeatherPacket(weatherInfo);

        byte[] keyValue = packet.getPacket();

        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CTRL_WEATHER_SET, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CTRL, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setHRVRmssd(boolean enable, int interval) {
        SDKLogger.d(D, "setHRVRmssd enable: " + enable + ", interval = " + interval);

        byte[] keyValue = new byte[1];
        keyValue[0] = (byte) (enable ? interval : 0x00);

        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CUSTOM_HRV_RMSSD_SET, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CUSTOM_MADE, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean readHRVRmssdConfig() {
        SDKLogger.d(D, "readHRVRmssdConfig");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CUSTOM_HRV_RMSSD_REQ, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CUSTOM_MADE, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * set blood sugar risk assessment
     * @param enable true open false close
     */
    public boolean setBloodSugarRiskAssessment(int type, boolean enable) {
        SDKLogger.d(D, "setRiskAssessment enable: " + enable + ", type = " + type);

        byte[] keyValue = new byte[2];
        keyValue[0] = (byte) (type);
        keyValue[1] = (byte) (enable ? 0x01 : 0x00);

        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CTRL_HIDE_HEALTH_FUNCTION_SET, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CTRL, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }


    /**
     * read health risk assessment info
     */
    public boolean readHealthRiskAssessment() {
        SDKLogger.d(D, "readHealthRiskAssessment");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CTRL_HIDE_HEALTH_FUNCTION_REQ, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CTRL, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * sync custom notify
     *
     * @return
     */
    public boolean RequestCusStatus() {
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CTRL_CUS_REQ, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CTRL, keyData);
        SDKLogger.i(D, "Music status: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }


    /**
     * set custom notify
     *
     * @return
     */
    public boolean SetCustomNotify(ApplicationLayerCustomNotifyPacket packet) {
        byte[] keyValue = packet.getPacket();
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CUSTOM_NOTIFY_SET, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_CUSTOM_MADE, keyData);
        SDKLogger.i(D, "Music status: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean RequestSpo2Continuous(){
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SPO2_CONTINUOUS_GET, null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "spo2Continuous status: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean SetSpo2Continuous(boolean enable, int interval) {
        SDKLogger.d(D, "SetSpo2Continuous, enable: " + enable + ", interval: " + interval);
        // generate key value data
        byte[] keyValue = new byte[]{enable ? HRP_CONTINUE_REQ_MODE_ENABLE : HRP_CONTINUE_REQ_MODE_DISABLE
                , (byte) (interval & 0xFF)};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SPO2_CONTINUOUS_SETTING, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * ecg single request. Command: 0x05, Key: 0x36.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * 开始/停止心电数据采集
     * @param enable enable/disable ecg single request .
     * @return the operation result
     */
    public boolean StartEcgTestRequest(boolean enable) {
        SDKLogger.d(D, "enable: " + enable);
        // generate key value data
        byte[] keyValue = new byte[]{enable ? BP_SINGLE_REQ_MODE_ENABLE : BP_SINGLE_REQ_MODE_DISABLE};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_ECG_STATUS_REQ, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * ecg belt single request. Command: 0x05, Key: 0x37.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * 开始/停止心电带数据采集
     * @param enable enable/disable ecg single request .
     * @return the operation result
     */
    public boolean StartEcgBeltTestRequest(boolean enable) {
        SDKLogger.d(D, "enable: " + enable);
        // generate key value data
        byte[] keyValue = new byte[]{enable ? BP_SINGLE_REQ_MODE_ENABLE : BP_SINGLE_REQ_MODE_DISABLE};
        // generate key data
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_ECG_BELT_SET, keyValue);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * hrp single request. Command: 0x05, Key: 0x3A.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * 读取设备正在运行功能列表
     * @return the operation result
     */
    public boolean ReadHealthRequest() {
        SDKLogger.d(D, "ReadHealthRequest");
        // generate key data

        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_READ_HEALTH_REQ, null);
        // generate application layer packet
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "appData: " + DataConverter.bytes2Hex(appPacketData));

        // sent the data
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * 连续血压3.0采集设置
     * @param enable
     * @return
     */
    public boolean SetBp3Continuous(boolean enable,int interval){
        SDKLogger.i(D,"SetBp3Continuous enable="+enable);
        byte[] keyValue = new byte[]{enable?BP_SINGLE_REQ_MODE_ENABLE:BP_SINGLE_REQ_MODE_DISABLE,(byte) (interval & 0xFF)};
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_BP3_CONTINUOUS_SET,keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA,keyData);
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * 获取连续血压3.0采集设置
     * @return
     */
    public boolean GetBp3Continuous(){
        SDKLogger.i(D,"GetBp3Continuous");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_BP3_CONTINUOUS_REQ,null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA,keyData);
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * 连接血糖采集
     * @param enable
     * @param interval
     * @return
     */
    public boolean SetGLUContinuous(boolean enable,int interval){
        SDKLogger.i(D,"SetGLUContinuous enable="+enable);
        byte[] keyValue = new byte[]{enable?BP_SINGLE_REQ_MODE_ENABLE:BP_SINGLE_REQ_MODE_DISABLE,(byte) (interval & 0xFF)};
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_GLU_CONTINUOUS_SET,keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA,keyData);
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * 获取连接血糖采集
     */
    public boolean GetGLUContinuous() {
        SDKLogger.i(D,"GetGLUContinuous");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_GLU_CONTINUOUS_REQ,null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA,keyData);
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * 测试血糖
     * @param enable true--开始测试，false--停止测试
     * @return
     */
    public boolean startTestGlu(boolean enable){
        SDKLogger.i(D,"startTestGlu enable="+enable);
        byte[] keyValue = new byte[]{enable?BP_SINGLE_REQ_MODE_ENABLE:BP_SINGLE_REQ_MODE_DISABLE};
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_GLU_TEST_START,keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA,keyData);
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * 设置私人血糖参数
     * @param height
     * @param low
     * @return
     */
    public boolean SetPrivateGlu(int height,int low){
        SDKLogger.i(D,"SetPrivateGlu height="+height+"\tlow="+low);
        byte[] keyValue = new byte[]{(byte) (height & 0xFF),(byte) (low & 0xFF)};
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_GLU_PRIVATE_SET,keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA,keyData);
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * 获取私人血糖参数
     * @return
     */
    public boolean GetPrivateGlu(){
        SDKLogger.i(D,"GetPrivateGlu");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_GLU_PRIVATE_REQ,null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA,keyData);
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * 设置体温提醒
     */
    public boolean setTemperatureReminder(boolean isOpen, int value){
        SDKLogger.i(D,"setTemperatureReminder isOpen = " + isOpen + ", value = " + value);
        ApplicationLayerMulTemperatureReminderPacket packet = new ApplicationLayerMulTemperatureReminderPacket();
        packet.setValue(isOpen ? value : 0);// 关闭情况下设置为 0 即可
        byte[] keyValue = packet.getPacket();
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_MUL_TEMPERATURE_REMINDER, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_MULTIPLE_CMD,keyData);
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setDrinkWaterReminder(boolean isOpen, int startHour, int startMin, int endHour, int endMin, int interval) {
        SDKLogger.i(D,"setDrinkWaterReminder isOpen = " + isOpen + ", startHour = " + startHour + ", startMin = " + startMin + ", endHour = " + endHour + ", endMin = " + endMin + ", interval = " + interval);
        ApplicationLayerMulDrinkWaterReminderPacket packet = new ApplicationLayerMulDrinkWaterReminderPacket();
        packet.setOpen(isOpen);
        packet.setStartHour(startHour);
        packet.setStartMin(startMin);
        packet.setEndHour(endHour);
        packet.setEndMin(endMin);
        packet.setInterval(interval);
        byte[] keyValue = packet.getPacket();
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_MUL_DRINK_WATER_REMINDER, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_MULTIPLE_CMD,keyData);
        return mTransportLayer.sendData(appPacketData);
    }



    /**
     * 单位请求（血糖）
     * @return
     */
    public boolean GetUnitSetting(){
        SDKLogger.i(D,"GetSwitches");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_UNIT_REQ,null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING,keyData);
        return mTransportLayer.sendData(appPacketData);
    }

    /**
     * 单位设置（血糖）
     * @param packet
     * @return
     */
    public boolean SetUnitSetting(ApplicationLayerUnitPacket packet) {
        byte[] keyValue = packet.getPacket();
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_SETTING_UNIT, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SETTING, keyData);
        SDKLogger.i(D, "unit setting: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setUricAcid(boolean isOpen, int privateValue, int privateRTCTime) {
        byte[] keyValue = new byte[7];
        keyValue[0] = (byte) (isOpen ? 0x01 : 0x00);
        keyValue[1] = (byte) ((privateValue >> 8) & 0xff);
        keyValue[2] = (byte) (privateValue & 0xff);
        keyValue[3] = (byte) ((privateRTCTime) & 0xff);
        keyValue[4] = (byte) ((privateRTCTime >> 8) & 0xff);
        keyValue[5] = (byte) ((privateRTCTime >> 16) & 0xff);
        keyValue[6] = (byte) ((privateRTCTime >> 24) & 0xff);
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_MUL_URIC_ACID, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_MULTIPLE_CMD, keyData);
        SDKLogger.i(D, "setUricAcid: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setBloodFat(boolean isOpen, int privateValue, int privateRTCTime) {
        byte[] keyValue = new byte[7];
        keyValue[0] = (byte) (isOpen ? 0x01 : 0x00);
        keyValue[1] = (byte) ((privateValue >> 8) & 0xff);
        keyValue[2] = (byte) (privateValue & 0xff);
        keyValue[3] = (byte) ((privateRTCTime) & 0xff);
        keyValue[4] = (byte) ((privateRTCTime >> 8) & 0xff);
        keyValue[5] = (byte) ((privateRTCTime >> 16) & 0xff);
        keyValue[6] = (byte) ((privateRTCTime >> 24) & 0xff);
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_MUL_BLOOD_FAT, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_MULTIPLE_CMD, keyData);
        SDKLogger.i(D, "setBloodFat: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setBloodSugarCycle(boolean isOpen, int privateValue, int privateRTCTime) {
        byte[] keyValue = new byte[7];
        keyValue[0] = (byte) (isOpen ? 0x01 : 0x00);
        keyValue[1] = (byte) ((privateValue >> 8) & 0xff);
        keyValue[2] = (byte) (privateValue & 0xff);
        keyValue[3] = (byte) ((privateRTCTime) & 0xff);
        keyValue[4] = (byte) ((privateRTCTime >> 8) & 0xff);
        keyValue[5] = (byte) ((privateRTCTime >> 16) & 0xff);
        keyValue[6] = (byte) ((privateRTCTime >> 24) & 0xff);
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_MUL_BLOOD_SUGAR_CYCLE, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_MULTIPLE_CMD, keyData);
        SDKLogger.i(D, "setBloodSugarCycle: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setPrivateUricAcid(boolean isOpen, int value) {
        byte[] keyValue = new byte[5];
        keyValue[0] = (byte) (isOpen ? 0x01 : 0x00);
        keyValue[1] = (byte) ((value >> 8) & 0xff);
        keyValue[2] = (byte) (value & 0xff);
        keyValue[3] = 0;
        keyValue[4] = 0;
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_MUL_PRIVATE_URIC_ACID, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_MULTIPLE_CMD, keyData);
        SDKLogger.i(D, "setPrivateUricAcid: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setPrivateBloodFat(boolean isOpen, int value) {
        byte[] keyValue = new byte[5];
        keyValue[0] = (byte) (isOpen ? 0x01 : 0x00);
        keyValue[1] = (byte) ((value >> 8) & 0xff);
        keyValue[2] = (byte) (value & 0xff);
        keyValue[3] = 0;
        keyValue[4] = 0;
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_MUL_PRIVATE_BLOOD_FAT, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_MULTIPLE_CMD, keyData);
        SDKLogger.i(D, "setPrivateBloodFat: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setUricAcidContinuousMonitoring(boolean isOpen) {
        byte[] keyValue = new byte[3];
        keyValue[0] = (byte) (0x05);
        keyValue[1] = (byte) (isOpen ? 0x01 : 0x00);
        keyValue[2] = 0;
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CONTINUOUS_MONITORING_SET, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "setUricAcidContinuousMonitoring: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setBloodFatContinuousMonitoring(boolean isOpen) {
        byte[] keyValue = new byte[3];
        keyValue[0] = (byte) (0x06);
        keyValue[1] = (byte) (isOpen ? 0x01 : 0x00);
        keyValue[2] = 0;
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CONTINUOUS_MONITORING_SET, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "setBloodFatContinuousMonitoring: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setPressureContinuousMonitoring(boolean isOpen) {
        byte[] keyValue = new byte[3];
        keyValue[0] = (byte) (0x07);
        keyValue[1] = (byte) (isOpen ? 0x01 : 0x00);
        keyValue[2] = 0;
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_CONTINUOUS_MONITORING_SET, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "setBloodFatContinuousMonitoring: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean setBodyFatMonitoring(boolean isOpen) {
        byte[] keyValue = new byte[3];
        keyValue[0] = (byte) (0x05);
        keyValue[1] = (byte) (isOpen ? 0x01 : 0x00);
        keyValue[2] = 0;
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_DEVICE_MEASURE_SET, keyValue);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA, keyData);
        SDKLogger.i(D, "setBodyFatMonitoring: " + DataConverter.bytes2Hex(appPacketData));
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean getRecentBodyFatInfo() {
        SDKLogger.i(D,"getRecentBodyFatInfo");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_BODY_FAT_HISTORY_REQ,null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA,keyData);
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean getPhysicalExamInfo() {
        SDKLogger.i(D,"getPhysicalExamInfo");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_PHYSICAL_EXAM_HISTORY_REQ,null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA,keyData);
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean syncUltraviolet() {
        SDKLogger.i(D,"syncUltraviolet");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_ULTRAVIOLET_REQ,null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA,keyData);
        return mTransportLayer.sendData(appPacketData);
    }

    public boolean syncPressure() {
        SDKLogger.i(D,"syncPressure");
        byte[] keyData = ApplicationLayerKeyPacket.preparePacket(KEY_PRESSURE_REQ,null);
        byte[] appPacketData = ApplicationLayerPacket.preparePacket(CMD_SPORTS_DATA,keyData);
        return mTransportLayer.sendData(appPacketData);
    }

    TransportLayerCallback mTransportCallback = new TransportLayerCallback() {

        @Override
        public void onConnectionStateChange(boolean isConnect, int code, String msg) {
            super.onConnectionStateChange(isConnect, code, msg);
            SDKLogger.d(D, "onConnectionStateChange, isConnect: " + isConnect + ", code: " + code + ", msg: " + msg);
            mCallback.onConnectionStateChange(isConnect, code, msg);
        }

        @Override
        public void onConnectionStateChange(final boolean status, final boolean newState) {
            SDKLogger.d(D, "onConnectionStateChange, status: " + status + ", newState: " + newState);
            mCallback.onConnectionStateChange(status, newState);
        }

        @Override
        public void onDataSend(final boolean status, byte[] data) {
            SDKLogger.d(D, "onDataSend, status: " + status);
            // decode the packet
            ApplicationLayerPacket appPacket = new ApplicationLayerPacket();
            appPacket.parseData(data);
            // dispatch the key value
            List<ApplicationLayerKeyPacket> keyPackets = appPacket.getKeyPacketArrays();
            for (ApplicationLayerKeyPacket keyPacket : keyPackets) {
                byte commandId = appPacket.getCommandId();
                byte keyId = keyPacket.getKey();
                SDKLogger.d(D, "onDataSend, commandId: " + DataConverter.bytes2Hex(new byte[]{commandId}) + ", keyId: " + DataConverter.bytes2Hex(new byte[]{keyId}));
                mCallback.onCommandSend(status, commandId, keyId);
            }
        }

        @Override
        public void onDataReceive(byte[] data) {
            SDKLogger.d(D, "onDataReceive, data length: " + data.length);
            // decode the packet
            ApplicationLayerPacket appPacket = new ApplicationLayerPacket();
            appPacket.parseData(data);

            // dispatch the key value
            List<ApplicationLayerKeyPacket> keyPackets = appPacket.getKeyPacketArrays();
            for (ApplicationLayerKeyPacket keyPacket : keyPackets) {
                byte commandId = appPacket.getCommandId();
                byte keyId = keyPacket.getKey();
                byte[] keyData = keyPacket.getKeyData();
                SDKLogger.d(D,"onDataReceive, commandId: " + DataConverter.bytes2Hex(new byte[]{commandId}) + ", keyId: " + DataConverter.bytes2Hex(new byte[]{keyId})+ "\ndata[] = " + DataConverter.bytes2Hex(data) +"\nkeyData[]="+ DataConverter.bytes2Hex(keyData));
                // check the command id
                switch (commandId) {
                    case CMD_IMAGE_UPDATE:
                        // check the key id
                        switch (keyId) {
                            case KEY_UPDATE_RESPONSE:
                                mCallback.onUpdateCmdRequestEnterOtaMode(keyData[0], keyData[1]);
                                break;
                            default:
                                SDKLogger.w(D, "onDataReceive, unknown key id: " + keyId);
                                break;
                        }
                        break;
                    case CMD_SETTING:
                        // check the key id
                        switch (keyId) {
                            case KEY_SETTING_GET_ALARM_LIST_RSP:
                                // parse the alarm list
                                ApplicationLayerAlarmsPacket alarms = new ApplicationLayerAlarmsPacket();
                                alarms.parseData(keyData);
                                mCallback.onSettingCmdRequestAlarmList(alarms);
                                break;
                            case KEY_SETTING_ALARM2_RSP:
                                if (keyData.length > 0) {
                                    ApplicationLayerAlarm2Packet alarm2Packet = new ApplicationLayerAlarm2Packet();
                                    alarm2Packet.parseData(keyData);
                                    mCallback.onAlarm2(alarm2Packet);
                                } else {
                                    ApplicationLayerAlarm2Packet alarm2Packet = new ApplicationLayerAlarm2Packet();
                                    alarm2Packet.setCount(0);
                                    mCallback.onAlarm2(alarm2Packet);
                                }
                                break;
                            case KEY_SETTING_MEDICATION_REMINDER_RSP:
                                ApplicationLayerMedicationReminderListPacket medicationReminderListPacket = new ApplicationLayerMedicationReminderListPacket();
                                medicationReminderListPacket.parseData(keyData);
                                mCallback.onMedicationReminderList(medicationReminderListPacket);
                                break;
                            case KEY_SETTING_NOTIFY_SWITCH_RSP:
                                ApplicationLayerNotifyPacket applicationLayerNotifyPacket = new ApplicationLayerNotifyPacket();
                                applicationLayerNotifyPacket.parseData2(keyData);
                                mCallback.onSettingCmdRequestNotifySwitch(applicationLayerNotifyPacket);
                                break;
                            case KEY_SETTING_SIT_TOO_LONG_SWITCH_RSP:
                                ApplicationLayerSitPacket sitPacket = new ApplicationLayerSitPacket();
                                sitPacket.parseData(keyData);
                                mCallback.onSettingCmdRequestLongSit(sitPacket);
                                break;
                            case KEY_SETTING_TURN_OVER_WRIST_RSP:
                                if (keyData.length > 0) {
                                    mCallback.onTurnOverWristSettingReceive(keyData[0] == TURN_OVER_WRIST_CONTROL_ENABLE);
                                }
                                break;
                            case KEY_DEVICE_FUNCTION_RSP:
                                //parse the function data
                                SDKLogger.d(D,"keyId=0x37");
                                ApplicationLayerFunctionPacket functionPacket = new ApplicationLayerFunctionPacket();
                                functionPacket.parseData(keyData);
                                deviceFunction = functionPacket;
                                mCallback.onDeviceFunction(functionPacket);
                                break;
                            case KEY_SETTING_DEVICE_HOME_PAGER_RSP:
                                ApplicationLayerScreenStylePacket packet = new ApplicationLayerScreenStylePacket();
                                packet.parseData(keyData);
                                mCallback.onHomePager(packet);
                                break;
                            case KEY_HOUR_SYSTEM_RSP:
                                if (keyData.length > 0) {
                                    mCallback.onHour(keyData[0] == HOUR_24_MODEL);
                                }
                                break;
                            case KEY_UNIT_SYSTEM_RSP:
                                if (keyData.length > 0) {
                                    mCallback.onUnit(keyData[0] == UNIT_METRIC_SYSTEM);
                                }
                                break;
                            case KEY_DISTURB_RSP:
                                ApplicationLayerDisturbPacket disturbPacket = new ApplicationLayerDisturbPacket();
                                disturbPacket.parseData(keyData);
                                mCallback.onDisturb(disturbPacket);
                                break;
                            case KEY_SCREEN_LIGHT_DURATION_RSP:
                                if (keyData.length > 0) {
                                    if (keyData.length > 1) {
                                        mCallback.onScreenLightDuration(keyData[0] & 0xFF, keyData[1] & 0xFF);
                                    } else {
                                        mCallback.onScreenLightDuration(keyData[0] & 0xFF, 0);
                                    }
                                }
                                break;
                            case KEY_LANGUAGE_RSP:
                                DeviceLanguage language;
                                int languageCode = keyData[0] & 0xFF;
                                switch (languageCode) {
                                    case 0:
                                        language = DeviceLanguage.LANGUAGE_ENGLISH;
                                        break;
                                    case 1:
                                        language = DeviceLanguage.LANGUAGE_SAMPLE_CHINESE;
                                        break;
                                    case 2:
                                        language = DeviceLanguage.LANGUAGE_TRADITIONAL_CHINESE;
                                        break;
                                    case 87:
                                        language = DeviceLanguage.LANGUAGE_SPANISH;
                                        break;
                                    case 20:
                                        language = DeviceLanguage.LANGUAGE_FRENCH;
                                        break;
                                    case 18:
                                        language = DeviceLanguage.LANGUAGE_GERMAN;
                                        break;
                                    case 96:
                                        language = DeviceLanguage.LANGUAGE_ITALIAN;
                                        break;
                                    case 65:
                                        language = DeviceLanguage.LANGUAGE_JAPANESE;
                                        break;
                                    case 66:
                                        language = DeviceLanguage.LANGUAGE_SWEDISH;
                                        break;
                                    case 29:
                                        language = DeviceLanguage.LANGUAGE_KOREAN;
                                        break;
                                    case 62:
                                        language = DeviceLanguage.LANGUAGE_PORTUGUESE;
                                        break;
                                    case 19:
                                        language = DeviceLanguage.LANGUAGE_RUSSIAN;
                                        break;
                                    case 82:
                                        language = DeviceLanguage.LANGUAGE_TURKISH;
                                        break;
                                    case 13:
                                        language = DeviceLanguage.LANGUAGE_POLAND;
                                        break;
                                    case 53:
                                        language = DeviceLanguage.LANGUAGE_MONGOLIA;
                                        break;
                                    case 102:
                                        language = DeviceLanguage.LANGUAGE_VIETNAM;
                                        break;
                                    case 81:
                                        language = DeviceLanguage.LANGUAGE_THAI;
                                        break;
                                    default:
                                        language = DeviceLanguage.LANGUAGE_ENGLISH;
                                        break;
                                }
                                mCallback.onLanguage(language);
                                break;
                            case KEY_DEVICE_INFO_RSP:
                                ApplicationLayerDeviceInfoPacket deviceInfoPacket = new ApplicationLayerDeviceInfoPacket();
                                deviceInfoPacket.parseData(keyData);
                                mCallback.onDeviceInfo(deviceInfoPacket);
                                break;
                            case KEY_DEVICE_SCREEN_LIGHT_RSP:
                                if (keyData.length > 0) {
                                    int lightPercent = keyData[0] & 0xFF;
                                    mCallback.onScreenLight(lightPercent);
                                }
                                break;
                            case KEY_DEVICE_SWITCH_RSP:
                                ApplicationLayerSwitchPacket switchPacket = new ApplicationLayerSwitchPacket();
                                switchPacket.parseData(keyData);
                                mCallback.onSwitch(switchPacket);
                                break;
                            case KEY_AUDIO_GET_RSP:
                                if (keyData.length > 0) {
                                    int switchState = keyData[0] & 0xff;
                                    mCallback.onAudioSwitch(switchState);
                                }
                                break;
                            case KEY_SETTING_ADDRESS_BOOK_RSP:
                                if (keyData.length > 0) {
                                    int state = keyData[0] & 0xff;
                                    SDKLogger.i("同步通讯录返回-->state="+state);
                                    mCallback.onAddressBookToDevice(state);
                                }
                                break;
                            case KEY_SETTING_SOS_NUMBER_RSP:
                                if (keyData.length > 0) {
                                    int sosState = keyData[0] & 0xff;
                                    SDKLogger.i("同步 SOS 通讯录返回-->state="+sosState);
                                    mCallback.onSOSNumberToDevice(sosState);
                                }
                                break;
                            case KEY_SETTING_UNIT_RSP:
                                ApplicationLayerUnitPacket unitPacket = new ApplicationLayerUnitPacket();
                                unitPacket.parseData(keyData);
                                mCallback.onUnitRes(unitPacket);
                                break;
                            case KEY_SETTING_SLEEP_ALL_SWITCH_RSP:
                                if (keyData.length > 0) {
                                    mCallback.onSleepAllSwitch(keyData[0] == SLEEP_ALL_ENABLE);
                                }
                                break;
                            case KEY_SETTING_HYPOXIA_SWITCH_RSP:
                                if (keyData.length > 0) {
                                    mCallback.onHypoxiaSwitch(keyData[0] == HYPOXIA_NOTIFY_ENABLE);
                                }
                                break;
                            case KEY_SETTING_HIGH_HEART_RATE_SWITCH_RSP:
                                if (keyData.length >= 2) {
                                    ApplicationLayerHighHeartRatePacket highHrvPacket = new ApplicationLayerHighHeartRatePacket();
                                    highHrvPacket.parseData(keyData);
                                    mCallback.onHighHeartRateSwitch(highHrvPacket);
                                }
                                break;
                            case KEY_SETTING_DEVICE_DATE_FORMAT_RSP:
                                if (keyData.length > 0) {
                                    mCallback.onDeviceDateFormat(keyData[0] == DATA_FORMAT_OPTION_0 ? DATA_FORMAT_OPTION_0 : DATA_FORMAT_OPTION_1);
                                }
                                break;
                            default:
                                SDKLogger.i(D, "onDataReceive, unknown key id: " + keyId);
                                break;
                        }
                        break;
                    case CMD_BOND_REG:
                        // check the key id
                        switch (keyId) {
                            case KEY_BOND_RSP:
                                if (keyData.length > 0) {
                                    mCallback.onBondCmdRequestBond(keyData[0]);
                                }
                                break;
                            case KEY_LOGIN_RSP:
                                if (keyData.length > 0) {
                                    mCallback.onBondCmdRequestLogin(keyData[0]);
                                }
                                break;
                            case KEY_SUP_BOND_KEY:
                                if (keyData.length > 0) {
                                    int type = keyData[0] & 0xFF;
                                    SDKLogger.d(D,"onChipType = "+type);
                                    mCallback.onBondReqChipType(type);
                                }
                                break;
                            case KEY_CONFIRM_BOND_RSP:
                                if (keyData.length > 0) {
                                    mCallback.onBondConfirmRequest(keyData[0]);
                                }
                                break;
                            default:
                                SDKLogger.i(D, "onDataReceive, unknown key id: " + keyId);
                                break;
                        }
                        break;
                    case CMD_NOTIFY:
                        switch (keyId) {
                            case KEY_NOTIFY_END_CALL:
                                mCallback.onEndCallReceived();
                                break;
                            case KEY_NOTIFY_ACCEPT_CALL:
                                mCallback.onAcceptCallReceived();
                                break;
                            case KEY_NOTIFY_CHARGING_STATUS:
                                if (keyData.length > 0) {
                                    int chargeStatus = keyData[0] & 0xFF;
                                    mCallback.onChargeStatus(chargeStatus);
                                }
                                break;
                            case KEY_NOTIFY_CLASSIC_ADDRESS:
                                ApplicationLayerEarMacPacket packet = new ApplicationLayerEarMacPacket();
                                packet.parseData(keyData);
                                mCallback.onEarMac(packet);
                                break;
                            case KEY_NOTIFY_CLASSIC_STATUS:
                                if (keyData.length > 0) {
                                    int status = keyData[0] & 0xFF;
                                    mCallback.onEarConnectStatus(status);
                                }
                                break;
                            case KEY_NOTIFY_CLASSIC_STATUS2:
                                ApplicationLayerEarStatusPacket earStatusPacket = new ApplicationLayerEarStatusPacket();
                                earStatusPacket.parseData(keyData);
                                mCallback.onEarStatus(earStatusPacket);
//                                int status = keyData[0] & 0xFF;
//                                mCallback.onClassicStatus(status);
                                break;
                            default:
                                SDKLogger.i(D, "onDataReceive, unknown key id: " + keyId);
                                break;
                        }
                        break;
                    case CMD_SPORTS_DATA:
                        // check the key id
                        switch (keyId) {
                            case KEY_SPORTS_RUNNIG_RSP:
                                mCallback.onSportDataCmdStepData(ApplicationLayerHealthDataPacketHelper.parseStepData(keyData));
                                break;
                            case KEY_SPORTS_SLEEP_RSP:
                                mCallback.onSportDataCmdSleepData(ApplicationLayerHealthDataPacketHelper.parseSleepData(keyData));
                                break;
                            case KEY_SPORTS_RUNNIG_RSP_MORE:
                                mCallback.onSportDataCmdMoreData();
                                break;
                            case KEY_SPORTS_SLEEP_SET_RSP:
                                // parse the alarm list
                                ApplicationLayerSleepPacket sleepSet = new ApplicationLayerSleepPacket();
                                sleepSet.parseData(keyData);
                                mCallback.onSportDataCmdSleepSetData(sleepSet);
                                break;
                            case KEY_SPORTS_HIS_SYNC_BEG:
                                ApplicationLayerBeginPacket beginPacket = new ApplicationLayerBeginPacket();
                                beginPacket.parseData(keyData);
                                if (beginPacket.getTotalCount() == 0) {
                                    mCallback.onSportDataCmdHistorySyncBegin(null);
                                } else {
                                    mCallback.onSportDataCmdHistorySyncBegin(beginPacket);
                                }
                                break;
                            case KEY_SPORTS_HIS_SYNC_END:
                                // Here need check have total data or not
                                SDKLogger.i(true, "onTodayAdjust", "KEY_SPORTS_HIS_SYNC_END onSyncData");
                                ApplicationLayerTodaySumSportPacket todaySumSportPacket = new ApplicationLayerTodaySumSportPacket();

                                if (keyData.length != 0) {
                                    if (!todaySumSportPacket.parseData(keyData)) {
                                        todaySumSportPacket = null;
                                    }
                                } else {
                                    todaySumSportPacket = null;
                                }
                                mCallback.onSportDataCmdHistorySyncEnd(todaySumSportPacket);
                                break;
                            case KEY_SPORTS_DATA_TODAY_ADJUST_RSP:
                                ApplicationLayerTodayAdjustPacket todayAdjustPacket = new ApplicationLayerTodayAdjustPacket();
                                todayAdjustPacket.parseData(keyData);
                                mCallback.onTodayAdjust(todayAdjustPacket);
                                break;
                            case KEY_SPORTS_HRP_DATA_RSP:
                                ApplicationLayerHrpPacket hrp = new ApplicationLayerHrpPacket();
                                if (null != deviceFunction) {
                                    DeviceFunctionStatus temp = deviceFunction.getTemperature();
                                    if (temp == DeviceFunctionStatus.SUPPORT) {
                                        hrp.parseData2(keyData);
                                    } else {
                                        hrp.parseData(keyData);
                                    }
                                } else {
                                    hrp.parseData(keyData);
                                }
                                mCallback.onSportDataCmdHrpData(hrp);
                                break;
                            case KEY_HR_DATA_RSP:
                                ApplicationLayerHrpPacket hrp2 = new ApplicationLayerHrpPacket();
                                hrp2.parseData2(keyData);
                                mCallback.onSportDataCmdHrpData(hrp2);
                                break;
                            case KEY_SPORTS_HRP_DATA_LIST_RSP:
                                ApplicationLayerRateListPacket packet = new ApplicationLayerRateListPacket();
                                packet.parseData(keyData);
                                mCallback.onRateList(packet);
                                break;
                            case KEY_HR_DATA_LIST_RSP:
                                ApplicationLayerRateListPacket packet2 = new ApplicationLayerRateListPacket();
                                packet2.parseData2(keyData);
                                mCallback.onRateList(packet2);
                                break;
                            case KEY_SPORTS_BP_DATA_RSP:
                                mCallback.onSportDataCmdBpData(ApplicationLayerHealthDataPacketHelper.parseBloodPressureData(keyData));
                                break;
                            case KEY_SPORTS_HRP_DEVICE_CANCEL_READ_HRP:
                                mCallback.onSportDataCmdDeviceCancelSingleHrpRead();
                                break;
                            case KEY_SPORTS_BP_CANCEL_READ:
                                mCallback.onSportDataCmdDeviceCancelSingleBpRead();
                                break;
                            case KEY_SPORTS_HRP_CONTINUE_PARAMS_RSP:
                                if (keyData.length > 1) {
                                    boolean hrpEnable = (keyData[0] == HRP_CONTINUE_REQ_MODE_ENABLE);
                                    int hrpInterval = (keyData[1] & 0xFF);
                                    mCallback.onSportDataCmdHrpContinueParamRsp(hrpEnable, hrpInterval);
                                }
                                break;
                            case KEY_SPORTS_DATA_RSP:
                                ApplicationLayerSportPacket sportPacket = new ApplicationLayerSportPacket();
                                sportPacket.parseData(keyData);
                                mCallback.onSportDataCmdSportData(sportPacket);
                                break;
                            case KEY_SPORTS_MODEL_RSP:
                                ApplicationLayerMultiSportPacket mulSportPacket = new ApplicationLayerMultiSportPacket();
                                mulSportPacket.parseData(keyData);
                                mCallback.onSportFunction(mulSportPacket);
                                break;
                            case KEY_SPORTS_HR_PARAMS_RSP:
                                ApplicationLayerHrpParamsPacket hrpParamsPacket = new ApplicationLayerHrpParamsPacket();
                                hrpParamsPacket.parseData(keyData);
                                mCallback.onHrpParams(hrpParamsPacket);
                                break;
                            case KEY_APP_SPORT_RATE_DETECT_STOP:
                                if (keyData.length >= 1) {
                                    int status = keyData[0] & 0xFF;
                                    mCallback.onSportRateStatus(status);
                                } else {
                                    mCallback.onSportRateStatus(0);
                                }
                                break;
                            case KEY_TEMP_RSP:
                                if (keyData.length > 0) {
                                    int status = keyData[0] & 0xFF;
                                    mCallback.onTemperatureMeasureStatus(status);
                                }
                                break;
                            case KEY_TEMP_CONTROL_RSP:
                                ApplicationLayerTemperatureControlPacket controlPacket = new ApplicationLayerTemperatureControlPacket();
                                controlPacket.parseData(keyData);
                                mCallback.onTemperatureControl(controlPacket);
                                break;
                            case KEY_BP2_CONTROL_RSP:
                                ApplicationLayerBp2ControlPacket bpControlPacket = new ApplicationLayerBp2ControlPacket();
                                bpControlPacket.parseData(keyData);
                                mCallback.onBp2Control(bpControlPacket);
                                break;
                            case KEY_DEVICE_STATUS_RSP:
                                ApplicationLayerDeviceStatusPacket packet1 = new ApplicationLayerDeviceStatusPacket();
                                packet1.parseData(keyData);
                                mCallback.onDeviceStatus(packet1);
                                break;
                            case KEY_SPO2_DATA_RSP:
                                mCallback.onSpo2DataReceive(ApplicationLayerHealthDataPacketHelper.parseSpO2Data(keyData));
                                break;
                            case KEY_SPO2_RSP:
                                if (keyData.length > 0) {
                                    int spo2Status = keyData[0] & 0xFF;
                                    mCallback.onSpo2MeasureStatus(spo2Status);
                                }
                                break;
                            case KEY_SPO2_CONTINUOUS_RSP:
                                if (keyData.length > 1) {
                                    boolean spo2Continuous = ((keyData[0]) == HRP_CONTINUE_REQ_MODE_ENABLE);
                                    int spo2ContinuousInterval = (keyData[1] & 0xFF);
                                    SDKLogger.d(D,"UkOptManager35 spo2Continuous="+spo2Continuous+"\tspo2ContinuousInterval="+spo2ContinuousInterval);
                                    mCallback.onSpo2Continuous(spo2Continuous, spo2ContinuousInterval);
                                }
                                break;
                            case KEY_ECG_STATUS_RSP:
                                if (keyData.length > 0) {
                                    int ecgStatus = keyData[0] & 0xFF;
                                    SDKLogger.d(D,"EcgStatus="+ecgStatus);
                                    mCallback.onEcgTestStatus(ecgStatus);
                                }
                                break;
                            case KEY_ECG_DATA_RSP:
                                ApplicationLayerECGPacket ecgPacket = new ApplicationLayerECGPacket();
                                if (!ecgPacket.parseData(keyData)) {
                                    ecgPacket.setBpmNumber(0);
                                    ecgPacket.setHrvNumber(0);
                                    ecgPacket.setQtNumber(0);
                                    ecgPacket.setRriNumber(0);
                                }
                                mCallback.onEcgTestData(ecgPacket);
                                break;
                            case KEY_READ_HEALTH_RSP:
                                ApplicationLayerReadHealthPacket readHealthPacket = new ApplicationLayerReadHealthPacket();
                                readHealthPacket.parseData(keyData);
                                mCallback.onReadHealth(readHealthPacket);
                                break;
                            case KEY_RTK_HRV_RSP:
                                mCallback.onRtkHrvData(ApplicationLayerHealthDataPacketHelper.parseHrvData(keyData));
                                break;
                            case KEY_BP3_CONTINUOUS_RSP:
                                ApplicationLayerBp3ContinuousPacket bp3ContinuousPacket = new ApplicationLayerBp3ContinuousPacket();
                                bp3ContinuousPacket.parseData(keyData);
                                mCallback.onBp3Continuous(bp3ContinuousPacket);
                                break;
                            case KEY_GLU_CONTINUOUS_RSP:
                                boolean gluEnable = false;
                                int gluInterval = 0;
                                if (keyData.length >= 2) {
                                    gluEnable = (keyData[0] & 0xff) == 1;
                                    gluInterval = keyData[1] & 0xff;
                                } else if (keyData.length >= 1) {
                                    gluEnable = (keyData[0] & 0xff) == 1;
                                }
                                mCallback.onGluContinuous(gluEnable, gluInterval);
                                break;
                            case KEY_GLU_HISTORY_RSP:
                                mCallback.onGluDataRsp(ApplicationLayerHealthDataPacketHelper.parseBloodSugarData(keyData));
                                break;
                            case KEY_GLU_TEST_STOP:
                                mCallback.onTestGluDis();
                                break;
                            case KEY_GLU_PRIVATE_RSP:
                                if(keyData.length >= 2) {
                                    int height = (keyData[0] & 0xFF);
                                    int low = (keyData[1] & 0xFF);
                                    mCallback.onPrivateGlu(height,low);
                                }
                                break;
                            case KEY_WEARING_TIME_RSP:
                                mCallback.onWearingTimeDataRsp(ApplicationLayerHealthDataPacketHelper.parseWearingTimeData(keyData));
                                break;
                            case KEY_URIC_ACID_RSP:
                                mCallback.onUricAcidDataRsp(ApplicationLayerHealthDataPacketHelper.parseUricAcidData(keyData));
                                break;
                            case KEY_BLOOD_FAT_RSP:
                                mCallback.onBloodFatDataRsp(ApplicationLayerHealthDataPacketHelper.parseBloodFatData(keyData));
                                break;
                            case KEY_BLOOD_SUGAR_CYCLE_RSP:
                                mCallback.onBloodSugarCycleDataRsp(ApplicationLayerHealthDataPacketHelper.parseBloodSugarCycleData(keyData));
                                break;
                            case KEY_URIC_ACID_CONTINUOUS_MONITORING_RSP:
                                mCallback.onUricAcidContinuousMonitoringDataRsp(ApplicationLayerHealthDataPacketHelper.parseUricAcidContinuousMonitoringData(keyData));
                                break;
                            case KEY_BLOOD_FAT_CONTINUOUS_MONITORING_RSP:
                                mCallback.onBloodFatContinuousMonitoringDataRsp(ApplicationLayerHealthDataPacketHelper.parseBloodFatContinuousMonitoringData(keyData));
                                break;
                            case KEY_DEVICE_MEASURE_STATUS_UPDATED:
                                int measureStatus = keyData[0] & 0xff;
                                mCallback.onDeviceMeasureStatusUpdated(measureStatus);
                                break;
                            case KEY_BODY_FAT_HISTORY_RSP:
                                mCallback.onBodyFatDataRsp(ApplicationLayerHealthDataPacketHelper.parseBodyFatData(keyData));
                                break;
                            case KEY_PHYSICAL_EXAM_HISTORY_RSP:
                                mCallback.onPhysicalExamDataRsp(ApplicationLayerHealthDataPacketHelper.parsePhysicalExamData(keyData));
                                break;
                            case KEY_ULTRAVIOLET_RSP:
                                mCallback.onUltravioletDataRsp(ApplicationLayerHealthDataPacketHelper.parseUltravioletData(keyData));
                                break;
                            case KEY_PRESSURE_RSP:
                                mCallback.onPressureDataRsp(ApplicationLayerHealthDataPacketHelper.parsePressureData(keyData));
                                break;
                            default:
                                SDKLogger.w(D, "onDataReceive, unknown key id: " + keyId);
                                break;
                        }
                        break;
                    case CMD_CTRL:
                        // check the key id
                        switch (keyId) {
                            case KEY_CTRL_PHOTO_RSP:
                                mCallback.onTakePhotoRsp();
                                break;
                            case KEY_CTRL_FIND_PHONE_RSP:
                                mCallback.onFindPhone();
                                break;
                            case KEY_CTRL_TIMER_RSP:
                                ApplicationLayerTimerPacket timerPacket = new ApplicationLayerTimerPacket();
                                timerPacket.parseData(keyData);
                                mCallback.onTimerInfo(timerPacket);
                                break;
                            case KEY_CTRL_CUSTOM_UI_RSP:
                                ApplicationLayerCustomUiPacket packet = new ApplicationLayerCustomUiPacket();
                                packet.parseData(keyData);
                                mCallback.onCustomUiSetting(packet);
                                break;
                            case key_CTRL_MUSIC_CONTROL:
                                if (keyData.length > 0) {
                                    int value = keyData[0] & 0xFF;
                                    switch (value) {
                                        case 0:
                                            mCallback.onMusicPlay();
                                            break;
                                        case 1:
                                            mCallback.onMusicPause();
                                            break;
                                        case 2:
                                            mCallback.onMusicToggle();
                                            break;
                                        case 3:
                                            mCallback.onMusicNext();
                                            break;
                                        case 4:
                                            mCallback.onMusicPre();
                                            break;
                                        case 5:
                                            mCallback.onMusicVolumeUp();
                                            break;
                                        case 6:
                                            mCallback.onMusicVolumeDown();
                                            break;
                                    }
                                }
                                break;
                            case KEY_CTRL_OTA_STATUS_RSP:
                                if (keyData.length > 0) {
                                    int status = keyData[0] & 0xFF;
                                    mCallback.onSilenceOtaStatus(status);
                                }
                                break;
                            case KEY_CTRL_CUS_RSP:
//                                int status = keyData[0] & 0xFF;
//                                if (keyData.length >= 4) {
//                                    int status2 = ((keyData[0] << 24) & 0xff) | ((keyData[0] << 16) & 0xff) | ((keyData[0] << 8) & 0xff) | (keyData[0] & 0xff);
//                                    mCallback.onCusStatus(status2);
//                                }
//                                SDKLogger.d(D,"onSnycSwitch dataLength="+keyData.length);
                                ApplicationLayerSyncSwitchPacket switchPacket = new ApplicationLayerSyncSwitchPacket();
                                switchPacket.parseData(keyData);
                                mCallback.onSyncSwitch(switchPacket);
                                SDKLogger.e(true, "AAAA", "onSyncSwitch packet : " + switchPacket.toString());
                                break;
                            case KEY_CTRL_FIND_PHONE_RSP2:
                                if (keyData.length > 0) {
                                    int phoneStatus = keyData[0] & 0xFF;
                                    mCallback.onFindPhone(phoneStatus);
                                }
                                break;
                            case KEY_CTRL_FEMALE_RSP:
                                mCallback.onSetFemaleHealthSuccess();
                                SDKLogger.e(true, "AAAA", "onSetFemaleHealthSuccess");
                                break;
                            case KEY_CTRL_WEATHER_RSP:
                                mCallback.onSetWeatherSuccess();
                                SDKLogger.e(true, "AAAA", "onSetWeatherSuccess");
                                break;
                            case KEY_CTRL_HIDE_HEALTH_FUNCTION_RSP:
                                mCallback.onReadHealthRiskAssessmentRsp(ApplicationLayerHealthDataPacketHelper.parseHealthRiskAssessmentData(keyData));
                                break;
                            default:
                                SDKLogger.w(D, "onDataReceive, unknown key id: " + keyId);
                                break;
                        }
                        break;
                    case CMD_FACTORY_TEST:
                        // check the key id
                        switch (keyId) {
                            case KEY_FAC_TEST_SENSOR_DATA_RSP:
                                // parse the alarm list
                                ApplicationLayerFacSensorPacket sensor = new ApplicationLayerFacSensorPacket();
                                sensor.parseData(keyData);
                                mCallback.onFACCmdSensorData(sensor);
                                break;
                            case KEY_FAC_DEFAULT_FUNCTION_RSP:
                                JWDefaultFunctionInfo defaultFunctionInfo = ApplicationLayerHealthDataPacketHelper.parseDefaultFunctionData(keyData);
                                mCallback.onFacCmdDefaultFunction(defaultFunctionInfo);
                                break;
                            case KEY_FAC_TEST_TODAY_SLEEP_RSP:
                                ApplicationLayerTodaySleepPacket packet = new ApplicationLayerTodaySleepPacket();
                                packet.parseData(keyData);
                                mCallback.onFacCmdTodaySleep(packet);
                                break;
                            case KEY_FAC_TEST_HISTORY_RSP:
                                mCallback.onFacCmdHistoryIndex(keyData);
                                break;
                            case KEY_FAC_TEST_SILENCE_UPGRADE_RSP:
                                if (keyData.length > 0) {
                                    mCallback.onSilenceUpgradeModel(keyData[0] & 0xFF);
                                }
                                break;
                            default:
                                SDKLogger.w(D, "onDataReceive, unknown key id: " + keyId);
                                break;
                        }
                        break;
                    case CMD_MULTIPLE_CMD:
                        switch (keyId) {
                            case KEY_MUL_PRIVATE_BP:
                                ApplicationLayerMulPrivateBpPacket packet = new ApplicationLayerMulPrivateBpPacket();
                                packet.parseData(keyData);
                                mCallback.onMulPrivateBp(packet);
                                Log.e("EEEE", packet.toString());
                                break;
                            case KEY_MUL_SOS_NUMBER:
                                // 有这个 key 即代表支持 SOS，无效解析后续的数据
                                mCallback.onMulSupportSOSNumber();
                                break;
                            case KEY_MUL_DRINK_WATER_REMINDER:
                                ApplicationLayerMulDrinkWaterReminderPacket drinkWaterReminderPacket = new ApplicationLayerMulDrinkWaterReminderPacket();
                                drinkWaterReminderPacket.parseData(keyData);
                                mCallback.onMulDrinkWaterReminder(drinkWaterReminderPacket);
                                break;
                            case KEY_MUL_TEMPERATURE_REMINDER:
                                ApplicationLayerMulTemperatureReminderPacket temperaturePacket = new ApplicationLayerMulTemperatureReminderPacket();
                                temperaturePacket.parseData(keyData);
                                mCallback.onMulTemperatureReminder(temperaturePacket);
                                break;
                            case KEY_MUL_MEDICATION_REMINDER:
                                // 有这个 key 即代表支持 吃药提醒，无需解析后续的数据
                                mCallback.onMulSupportMedicationReminder();
                                break;
                            case KEY_MUL_FEMALE_HEALTH:
                                // 有这个 key 即代表支持 女性健康，无需解析后续的数据
                                mCallback.onSupportFemaleHealth();
                                break;
                            case KEY_MUL_WEATHER:
                                // 有这个 key 即代表支持 天气，无需解析后续的数据
                                mCallback.onSupportWeather();
                                break;
                            case KEY_MUL_WEARING_TIME:
                                mCallback.onSupportWearingTime();
                                break;
                            case KEY_MUL_BODY_FAT:
                                mCallback.onSupportBodyFat();
                                break;
                            case KEY_MUL_PHYSICAL_EXAM:
                                mCallback.onSupportPhysicalExam();
                                break;
                            case KEY_MUL_ULTRAVIOLET:
                                mCallback.onSupportUltraviolet();
                                break;
                            case KEY_MUL_URIC_ACID:
                                ApplicationLayerMulUricAcidPacket mulUricAcidPacket = new ApplicationLayerMulUricAcidPacket();
                                mulUricAcidPacket.parseData(keyData);
                                mCallback.onSupportUricAcid(mulUricAcidPacket);
                                break;
                            case KEY_MUL_BLOOD_FAT:
                                ApplicationLayerMulBloodFatPacket mulBloodFatPacket = new ApplicationLayerMulBloodFatPacket();
                                mulBloodFatPacket.parseData(keyData);
                                mCallback.onSupportBloodFat(mulBloodFatPacket);
                                break;
                            case KEY_MUL_BLOOD_SUGAR_CYCLE:
                                ApplicationLayerMulBloodSugarCyclePacket mulBloodSugarCyclePacket = new ApplicationLayerMulBloodSugarCyclePacket();
                                mulBloodSugarCyclePacket.parseData(keyData);
                                mCallback.onSupportBloodSugarCycle(mulBloodSugarCyclePacket);
                                break;
                            case KEY_MUL_PRIVATE_URIC_ACID:
                                ApplicationLayerMulPrivateUricAcidPacket mulPrivateUricAcidPacket = new ApplicationLayerMulPrivateUricAcidPacket();
                                mulPrivateUricAcidPacket.parseData(keyData);
                                mCallback.onSupportPrivateUricAcid(mulPrivateUricAcidPacket);
                                break;
                            case KEY_MUL_PRIVATE_BLOOD_FAT:
                                ApplicationLayerMulPrivateBloodFatPacket mulPrivateBloodFatPacket = new ApplicationLayerMulPrivateBloodFatPacket();
                                mulPrivateBloodFatPacket.parseData(keyData);
                                mCallback.onSupportPrivateBloodFat(mulPrivateBloodFatPacket);
                                break;
                        }
                        break;
                    case CMD_LOG:
                        // check the key id
                        switch (keyId) {
                            case KEY_LOG_START:
                                // parse the log length
                                long logLength = 0;
                                for (int i = 0; i < keyData.length; i++) {
                                    logLength = (keyData[i] & 0xFF) << (8 * (keyData.length - (i + 1)));
                                }
                                mCallback.onLogCmdStart(logLength);
                                break;
                            case KEY_LOG_END:
                                mCallback.onLogCmdEnd();
                                break;
                            case KEY_LOG_RSP:
                                // parse the alarm list
                                ApplicationLayerLogResponsePacket logResponsePacket = new ApplicationLayerLogResponsePacket();
                                logResponsePacket.parseData(keyData);
                                mCallback.onLogCmdRsp(logResponsePacket);
                                break;
                            default:
                                SDKLogger.w(D, "onDataReceive, unknown key id: " + keyId);
                                break;
                        }
                        break;
                    case CMD_CUSTOM_MADE:
                        switch (keyId) {
                            case KEY_CUSTOM_TRANSLATE_RSP:
                                if (keyData.length >= 1) {
                                    int model = keyData[0] & 0xFF;
                                    mCallback.onLangcoTranslate(model);
                                }
                                break;
                            case KEY_CUSTOM_NOTIFY_RSP:
                                ApplicationLayerCustomNotifyPacket packet = new ApplicationLayerCustomNotifyPacket();
                                packet.parseData(keyData);
                                mCallback.onCustomNotify(packet);
                                break;
                            case KEY_CUSTOM_SUPPORT_PULSE:
                                SDKLogger.w(D, "onSupportPulse ");
                                mCallback.onSupportPulse();
                                break;
                            case KEY_CUSTOM_PULSE_RSP:
                                if (keyData.length >= 3) {
                                    int status = keyData[0];
                                    int duration = (keyData[1] & 0xFF);
                                    int level = (keyData[2] & 0xFF);
                                    SDKLogger.w(D, "onSetPulseRes, isOpen = " + status + ", duration = " + duration + ", level = " + level);
                                    mCallback.onSetPulseRsp(status != 2);
                                }
                                break;
                            case KEY_CUSTOM_SUPPORT_SLEEP_HELP:
                                SDKLogger.w(D, "onSupportSleepHelp ");
                                mCallback.onSupportSleepHelp();
                                break;
                            case KEY_CUSTOM_SLEEP_HELP_RSP:
                                if (keyData.length >= 5) {
                                    int status = keyData[0];
                                    int mode = (keyData[1] & 0xFF);
                                    int duration = (keyData[2] & 0xFF);
                                    int effectiveTime = (keyData[3] & 0xFF);
                                    int level = (keyData[4] & 0xFF);
                                    SDKLogger.w(D, "onSetSleepHelpRes, isOpen = " + status + ", mode = " + mode + ", duration = " + duration + ", effectiveTime = " + effectiveTime + ", level = " + level);
                                    mCallback.onSetSleepHelpRsp(status);
                                }
                                break;
                            case KEY_CUSTOM_SYNC_PULSE_DATA_RSP:
                                ApplicationLayerPulseDataPacket pulseDataPacket = new ApplicationLayerPulseDataPacket();
                                pulseDataPacket.parseData(keyData);
                                mCallback.onSyncPulseDataRsp(pulseDataPacket);
                                break;
                            case KEY_CUSTOM_SYNC_PULSE_STATUS_RSP:
                                if (keyData.length >= 3) {
                                    int status = keyData[0] & 0xff;
                                    int count = ((keyData[1] & 0xff) << 8) | (keyData[2] & 0xff);
                                    SDKLogger.w(D, "onSyncPulseStatusRsp, status = " + status + ", count = " + count);
                                    mCallback.onSyncPulseStatusRsp(status, count);
                                }
                                break;
                            case KEY_CUSTOM_PULSE_FINISHED_RSP:
                                if (keyData.length >= 2) {
                                    int duration = ((keyData[0] & 0xff) << 8) | (keyData[1] & 0xff);
                                    SDKLogger.w(D, "onPulseFinishedRsp, duration = " + duration);
                                    mCallback.onPulseFinishedRsp(duration);
                                }
                                break;
                            case KEY_CUSTOM_SUPPORT_SAUNA:
                                SDKLogger.w(D, "onSupportSauna");
                                mCallback.onSupportSauna();
                                break;
                            case KEY_CUSTOM_SYNC_SAUNA_DATA_RSP:
                                ApplicationLayerSaunaDataPacket saunaDataPacket = new ApplicationLayerSaunaDataPacket();
                                saunaDataPacket.parseData(keyData);
                                mCallback.onSyncSaunaDataRsp(saunaDataPacket);
                                SDKLogger.w(D, "onSauna data");
                                break;
                            case KEY_CUSTOM_SYNC_SAUNA_STATUS_RSP:
                                if (keyData.length >= 3) {
                                    int status = keyData[0] & 0xff;
                                    int count = ((keyData[1] & 0xff) << 8) | (keyData[2] & 0xff);
                                    SDKLogger.w(D, "onSyncSaunaStatusRsp, status = " + status + ", count = " + count);
                                    mCallback.onSyncSaunaStatusRsp(status, count);
                                }
                                break;
                            case KEY_CUSTOM_SYNC_HR_MOVEMENT_RSP:
                                ApplicationLayerHRMovementDataPacket hrMovementDataPacket = new ApplicationLayerHRMovementDataPacket();
                                hrMovementDataPacket.parseData(keyData);
                                mCallback.onSyncHRMovementDataRsp(hrMovementDataPacket);
                                SDKLogger.w(D, "onHRMovementDataPacket data");
                                break;
                            case KEY_CUSTOM_HRV_RMSSD_RSP:
                                if (keyData.length >= 1) {
                                    int value = keyData[0] & 0xff;
                                    SDKLogger.w(D, "onReadHRVRmssdConfig, value = " + value);
                                    mCallback.onReadHRVRmssdConfigRsp(value != 0, value);
                                }
                                break;
                            case KEY_CUSTOM_SYNC_HRV_RMSSD_RSP:
                                mCallback.onHRVRmssdDataRsp(ApplicationLayerHealthDataPacketHelper.parseHRVRmssdData(keyData));
                                break;
                            default:
                                SDKLogger.w(D, "onDataReceive, unknown key id: " + keyId);
                                break;
                        }
                        break;
                    default:
                        SDKLogger.w(D, "onDataReceive, unknown command id: " + commandId);
                        break;
                }
            }
        }

        @Override
        public void onNameReceive(final String data) {
            mCallback.onNameReceive(data);
        }

        @SuppressWarnings("MismatchedReadAndWriteOfArray")
        @Override
        public void onDeviceEcgData(byte[] data) {
            if(data.length > 10) {
                int cmdType = ((data[8] & 0xff) << 8) | (data[9] & 0xff);
                byte[] tempData = new byte[data.length - 10];
                for (int i = 10; i < data.length; i++) {
                    tempData[i - 10] = data[i];
                }
                if (cmdType == 1) {
                    ApplicationLayerEcgToDevicePacket packet = new ApplicationLayerEcgToDevicePacket();
                    packet.parseData(tempData);
                    mCallback.onDeviceEcgData(packet);
                } else if (cmdType == 2) {
                    ApplicationLayerEcgBeltToDevicePacket packet = new ApplicationLayerEcgBeltToDevicePacket();
                    packet.parseData(tempData);
                    mCallback.onDeviceEcgBeltData(packet);
                }

            }else{
                SDKLogger.d(true,"EcgToDevice data fail");
            }

        }
    };
}
