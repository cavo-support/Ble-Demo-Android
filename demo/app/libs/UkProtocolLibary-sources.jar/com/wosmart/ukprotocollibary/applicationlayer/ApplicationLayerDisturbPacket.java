package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.util.SDKLogger;

public class ApplicationLayerDisturbPacket {

    /**
     * open status
     */
    private boolean isOpen; //1bit

    /**
     * disturb start hour
     */
    private int startHour; //5bit

    /**
     * disturb start minute
     */
    private int startMinute; //6bit

    /**
     * disturb end hour
     */
    private int endHour; //5bit

    /**
     * disturb end minute
     */
    private int endMinute; //6bit

    /**
     * Packet Length
     */
    public final static int DISTURB_HEADER_LENGTH = 3;

    public ApplicationLayerDisturbPacket() {
    }

    public ApplicationLayerDisturbPacket(boolean isOpen, int startHour, int startMinute, int endHour, int endMinute) {
        this.isOpen = isOpen;
        this.startHour = startHour;
        this.startMinute = startMinute;
        this.endHour = endHour;
        this.endMinute = endMinute;
    }

    public boolean isOpen() {
        return isOpen;
    }

    public void setOpen(boolean open) {
        isOpen = open;
    }

    public int getStartHour() {
        return startHour;
    }

    public void setStartHour(int startHour) {
        this.startHour = startHour;
    }

    public int getStartMinute() {
        return startMinute;
    }

    public void setStartMinute(int startMinute) {
        this.startMinute = startMinute;
    }

    public int getEndHour() {
        return endHour;
    }

    public void setEndHour(int endHour) {
        this.endHour = endHour;
    }

    public int getEndMinute() {
        return endMinute;
    }

    public void setEndMinute(int endMinute) {
        this.endMinute = endMinute;
    }

    public byte[] getPacket() {
        byte[] data = new byte[DISTURB_HEADER_LENGTH];
        data[0] = (byte) ((isOpen ? 0x40 : 0x00) | ((startHour & 0x1f) << 1) | ((startMinute & 0x3f) >> 5));
        data[1] = (byte) (((startMinute & 0x3f) << 3) | ((endHour & 0x1f) >> 2));
        data[2] = (byte) (((endHour & 0x1f) << 6) | (endMinute & 0x3f));
        SDKLogger.i("isOpen: " + isOpen +
                ", startHour: " + startHour +
                ", startMinute: " + startMinute +
                ", endHour: " + endHour +
                ", endMinute: " + endMinute);
        return data;
    }

    public boolean parseData(byte[] data) {
        isOpen = (((data[0] >> 6) & 0x01) == 0x01) ? true : false;
        startHour = (data[0] >> 1) & 0x1f;
        startMinute = (data[0] & 0x01) << 5 | ((data[1] >> 3) & 0x1f);
        endHour = (data[1] & 0x07) << 2 | (data[2] >> 6) & 0x03;
        endMinute = data[2] & 0x3f;
        SDKLogger.i("isOpen: " + isOpen +
                ", startHour: " + startHour +
                ", startMinute: " + startMinute +
                ", endHour: " + endHour +
                ", endMinute: " + endMinute);
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerDisturbPacket{" +
                "isOpen=" + isOpen +
                ", startHour=" + startHour +
                ", startMinute=" + startMinute +
                ", endHour=" + endHour +
                ", endMinute=" + endMinute +
                '}';
    }
}
