package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.model.enums.DeviceFunctionStatus;
import com.wosmart.ukprotocollibary.v2.entity.JWAllNotifyConfigInfo;

/**
 * device support reminder function
 */
public class ApplicationLayerNotifyPacket {
    /**
     *
     */
    private DeviceFunctionStatus Call;

    /**
     *
     */
    private DeviceFunctionStatus Sms;

    /**
     *
     */
    private DeviceFunctionStatus QQ;

    /**
     *
     */
    private DeviceFunctionStatus WeChat;

    /**
     *
     */
    private DeviceFunctionStatus Line;

    /**
     *
     */
    private DeviceFunctionStatus Twitter;

    /**
     *
     */
    private DeviceFunctionStatus Facebook;

    /**
     *
     */
    private DeviceFunctionStatus Messenger;

    /**
     *
     */
    private DeviceFunctionStatus WhatsApp;

    /**
     *
     */
    private DeviceFunctionStatus LinkedIn;

    /**
     *
     */
    private DeviceFunctionStatus Instagram;

    /**
     *
     */
    private DeviceFunctionStatus Skype;

    /**
     *
     */
    private DeviceFunctionStatus Viber;

    /**
     *
     */
    private DeviceFunctionStatus KakaoTalk;

    /**
     *
     */
    private DeviceFunctionStatus VkonTakte;

    /**
     *
     */
    private DeviceFunctionStatus Tim;

    /**
     *
     */
    private DeviceFunctionStatus Gmail;

    /**
     *
     */
    private DeviceFunctionStatus DingTalk;

    /**
     *
     */
    private DeviceFunctionStatus WorkWechat;

    /**
     *
     */
    private DeviceFunctionStatus Other;

    /**
     *
     */
    private final int REMINDER_HEAD_LENGTH = 4;

    public ApplicationLayerNotifyPacket() {
    }

    public DeviceFunctionStatus getCall() {
        return Call;
    }

    public void setCall(DeviceFunctionStatus call) {
        Call = call;
    }

    public DeviceFunctionStatus getSms() {
        return Sms;
    }

    public void setSms(DeviceFunctionStatus sms) {
        Sms = sms;
    }

    public DeviceFunctionStatus getQQ() {
        return QQ;
    }

    public void setQQ(DeviceFunctionStatus QQ) {
        this.QQ = QQ;
    }

    public DeviceFunctionStatus getWeChat() {
        return WeChat;
    }

    public void setWeChat(DeviceFunctionStatus weChat) {
        WeChat = weChat;
    }

    public DeviceFunctionStatus getLine() {
        return Line;
    }

    public void setLine(DeviceFunctionStatus line) {
        this.Line = line;
    }

    public DeviceFunctionStatus getTwitter() {
        return Twitter;
    }

    public void setTwitter(DeviceFunctionStatus twitter) {
        Twitter = twitter;
    }

    public DeviceFunctionStatus getFacebook() {
        return Facebook;
    }

    public void setFacebook(DeviceFunctionStatus facebook) {
        Facebook = facebook;
    }

    public DeviceFunctionStatus getMessenger() {
        return Messenger;
    }

    public void setMessenger(DeviceFunctionStatus messenger) {
        Messenger = messenger;
    }

    public DeviceFunctionStatus getWhatsApp() {
        return WhatsApp;
    }

    public void setWhatsApp(DeviceFunctionStatus whatsApp) {
        WhatsApp = whatsApp;
    }

    public DeviceFunctionStatus getLinkedIn() {
        return LinkedIn;
    }

    public void setLinkedIn(DeviceFunctionStatus linkedIn) {
        LinkedIn = linkedIn;
    }

    public DeviceFunctionStatus getInstagram() {
        return Instagram;
    }

    public void setInstagram(DeviceFunctionStatus instagram) {
        Instagram = instagram;
    }

    public DeviceFunctionStatus getSkype() {
        return Skype;
    }

    public void setSkype(DeviceFunctionStatus skype) {
        Skype = skype;
    }

    public DeviceFunctionStatus getViber() {
        return Viber;
    }

    public void setViber(DeviceFunctionStatus viber) {
        Viber = viber;
    }

    public DeviceFunctionStatus getKakaoTalk() {
        return KakaoTalk;
    }

    public void setKakaoTalk(DeviceFunctionStatus kakaoTalk) {
        KakaoTalk = kakaoTalk;
    }

    public DeviceFunctionStatus getVkonTakte() {
        return VkonTakte;
    }

    public void setVkonTakte(DeviceFunctionStatus vkonTakte) {
        VkonTakte = vkonTakte;
    }

    public DeviceFunctionStatus getTim() {
        return Tim;
    }

    public void setTim(DeviceFunctionStatus tim) {
        Tim = tim;
    }

    public DeviceFunctionStatus getGmail() {
        return Gmail;
    }

    public void setGmail(DeviceFunctionStatus gmail) {
        Gmail = gmail;
    }

    public DeviceFunctionStatus getDingTalk() {
        return DingTalk;
    }

    public void setDingTalk(DeviceFunctionStatus dingTalk) {
        DingTalk = dingTalk;
    }

    public DeviceFunctionStatus getWorkWechat() {
        return WorkWechat;
    }

    public void setWorkWechat(DeviceFunctionStatus workWechat) {
        WorkWechat = workWechat;
    }

    public DeviceFunctionStatus getOther() {
        return Other;
    }

    public void setOther(DeviceFunctionStatus other) {
        Other = other;
    }

    public byte[] getPacket() {
        byte[] data = new byte[REMINDER_HEAD_LENGTH];

        data[0] = (Other == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x80 : (byte) 0x00);

        data[1] = (byte) (
                (WorkWechat == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x20 : (byte) 0x00)
                        | (DingTalk == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x10 : (byte) 0x00)
                        | (Gmail == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x08 : (byte) 0x00)
                        | (Tim == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x04 : (byte) 0x00)
        );

        data[2] = (byte) (
                (VkonTakte == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x40 : (byte) 0x00)
                        | (KakaoTalk == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x20 : (byte) 0x00)
                        | (Viber == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x10 : (byte) 0x00)
                        | (Skype == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x08 : (byte) 0x00)
                        | (Instagram == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x04 : (byte) 0x00)
                        | (LinkedIn == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x02 : (byte) 0x00)
                        | (WhatsApp == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x01 : (byte) 0x00)
        );

        data[3] = (byte) (
                (Messenger == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x80 : (byte) 0x00)
                        | (Facebook == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x40 : (byte) 0x00)
                        | (Twitter == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x20 : (byte) 0x00)
                        | (Line == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x10 : (byte) 0x00)
                        | (Sms == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x08 : (byte) 0x00)
                        | (WeChat == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x04 : (byte) 0x00)
                        | (QQ == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x02 : (byte) 0x00)
                        | (Call == DeviceFunctionStatus.SUPPORT_OPEN ? (byte) 0x01 : (byte) 0x00)
        );
        return data;
    }

    public boolean parseData2(byte[] data) {
        if (data.length >= REMINDER_HEAD_LENGTH) {
            int call = data[3] & 0x01;
            int qq = (data[3] >> 1) & 0x01;
            int wechat = (data[3] >> 2) & 0x01;
            int sms = (data[3] >> 3) & 0x01;
            int line = (data[3] >> 4) & 0x01;
            int twitter = (data[3] >> 5) & 0x01;
            int facebook = (data[3] >> 6) & 0x01;
            int messenger = (data[3] >> 7) & 0x01;

            int whatsapp = data[2] & 0x01;
            int linkedin = (data[2] >> 1) & 0x01;
            int instagram = (data[2] >> 2) & 0x01;
            int skype = (data[2] >> 3) & 0x01;
            int viber = (data[2] >> 4) & 0x01;
            int kakaotalk = (data[2] >> 5) & 0x01;
            int vkontakte = (data[2] >> 6) & 0x01;

            int tim = (data[1] >> 2) & 0x01;
            int gmail = (data[1] >> 3) & 0x01;
            int dingTalk = (data[1] >> 4) & 0x01;
            int workWechat = (data[1] >> 5) & 0x01;

            int other = (data[0] >> 7) & 0x01;

            if (call == 1) {
                Call = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                Call = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (qq == 1) {
                QQ = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                QQ = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (wechat == 1) {
                WeChat = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                WeChat = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (sms == 1) {
                Sms = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                Sms = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (line == 1) {
                Line = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                Line = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (twitter == 1) {
                Twitter = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                Twitter = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (facebook == 1) {
                Facebook = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                Facebook = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (messenger == 1) {
                Messenger = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                Messenger = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (whatsapp == 1) {
                WhatsApp = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                WhatsApp = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (linkedin == 1) {
                LinkedIn = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                LinkedIn = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (instagram == 1) {
                Instagram = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                Instagram = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (skype == 1) {
                Skype = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                Skype = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (viber == 1) {
                Viber = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                Viber = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (kakaotalk == 1) {
                KakaoTalk = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                KakaoTalk = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (vkontakte == 1) {
                VkonTakte = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                VkonTakte = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (tim == 1) {
                Tim = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                Tim = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (gmail == 1) {
                Gmail = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                Gmail = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (dingTalk == 1) {
                DingTalk = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                DingTalk = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (workWechat == 1) {
                WorkWechat = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                WorkWechat = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
            if (other == 1) {
                Other = DeviceFunctionStatus.SUPPORT_OPEN;
            } else {
                Other = DeviceFunctionStatus.SUPPORT_CLOSE;
            }
        }
        return true;
    }

    public ApplicationLayerNotifyPacket(JWAllNotifyConfigInfo configInfo) {
        Call = configInfo.call ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        Sms = configInfo.sms ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        QQ = configInfo.qq ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        WeChat = configInfo.wechat ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        Line = configInfo.line ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        Twitter = configInfo.twitter ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        Facebook = configInfo.facebook ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        Messenger = configInfo.messenger ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        WhatsApp = configInfo.whatsapp ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        LinkedIn = configInfo.linkedin ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        Instagram = configInfo.instagram ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        Skype = configInfo.skype ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        Viber = configInfo.viber ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        KakaoTalk = configInfo.kakaoTalk ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        VkonTakte = configInfo.vkontakte ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        Tim = configInfo.tim ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        Gmail = configInfo.gmail ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        DingTalk = configInfo.dingTalk ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        WorkWechat = configInfo.workWeChat ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
        Other = configInfo.other ? DeviceFunctionStatus.SUPPORT_OPEN : DeviceFunctionStatus.SUPPORT_CLOSE;
    }


    @Override
    public String toString() {
        return "ApplicationLayerNotifyPacket{" +
                "Call=" + Call +
                ", Sms=" + Sms +
                ", QQ=" + QQ +
                ", WeChat=" + WeChat +
                ", Line=" + Line +
                ", Twitter=" + Twitter +
                ", Facebook=" + Facebook +
                ", Messenger=" + Messenger +
                ", WhatsApp=" + WhatsApp +
                ", LinkedIn=" + LinkedIn +
                ", Instagram=" + Instagram +
                ", Skype=" + Skype +
                ", Viber=" + Viber +
                ", KakaoTalk=" + KakaoTalk +
                ", VkonTakte=" + VkonTakte +
                ", Tim=" + Tim +
                ", Gmail=" + Gmail +
                ", DingTalk=" + DingTalk +
                ", WorkWechat=" + WorkWechat +
                ", Other=" + Other +
                '}';
    }
}
