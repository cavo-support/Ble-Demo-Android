package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.util.SDKLogger;

public class ApplicationLayerTodaySportPacket {

    /**
     * step count
     */
    private long mStepTarget;            // 4byte

    /**
     * step distance count
     */
    private long mDistance;                // 4byte

    /**
     * step calories
     */
    private long mCalory;                // 4byte

    /**
     * Packet Length
     */
    private final static int TODAY_SPORT_HEADER_LENGTH = 12;

    public long getmStepTarget() {
        return mStepTarget;
    }

    public long getmDistance() {
        return mDistance;
    }

    public long getmCalory() {
        return mCalory;
    }

    public ApplicationLayerTodaySportPacket(long step, long distance, long calory) {
        mStepTarget = step;
        mDistance = distance;
        mCalory = calory;
    }

    public byte[] getPacket() {
        SDKLogger.d("mStepTarget: " + mStepTarget
                + ", mDistance: " + mDistance
                + ", mCalory: " + mCalory);
        byte[] data = new byte[TODAY_SPORT_HEADER_LENGTH];
        data[0] = (byte) ((mStepTarget >> 24) & 0xff);
        data[1] = (byte) ((mStepTarget >> 16) & 0xff);
        data[2] = (byte) ((mStepTarget >> 8) & 0xff);
        data[3] = (byte) (mStepTarget & 0xff);
        data[4] = (byte) ((mDistance >> 24) & 0xff);
        data[5] = (byte) ((mDistance >> 16) & 0xff);
        data[6] = (byte) ((mDistance >> 8) & 0xff);
        data[7] = (byte) (mDistance & 0xff);
        data[8] = (byte) ((mCalory >> 24) & 0xff);
        data[9] = (byte) ((mCalory >> 16) & 0xff);
        data[10] = (byte) ((mCalory >> 8) & 0xff);
        data[11] = (byte) (mCalory & 0xff);
        return data;
    }

    public boolean parseDate(byte[] data) {
        if (data.length < TODAY_SPORT_HEADER_LENGTH) {
            return false;
        }
        mStepTarget = (((data[0] & 0xff) << 24) | ((data[1] & 0xff) << 16) | ((data[2] & 0xff) << 8) | (data[3] & 0xff)) & 0x00ffffffffL;
        mDistance = (((data[4] & 0xff) << 24) | ((data[5] & 0xff) << 16) | ((data[6] & 0xff) << 8) | (data[7] & 0xff)) & 0x00ffffffffL;
        mCalory = (((data[8] & 0xff) << 24) | ((data[9] & 0xff) << 16) | ((data[10] & 0xff) << 8) | (data[11] & 0xff)) & 0x00ffffffffL;
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerTodaySportPacket{" +
                "mStepTarget=" + mStepTarget +
                ", mDistance=" + mDistance +
                ", mCalory=" + mCalory +
                '}';
    }
}
