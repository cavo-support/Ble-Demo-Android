package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerBpItemPacket {

    /**
     * minute 16bits
     */
    private int mMinutes;

    /**
     * id 8 bits
     */
    private int mSequenceNum;

    /**
     * rate value
     */
    private int mValue;

    /**
     * bp high value 8bits
     */
    private int mLowValue;

    /**
     * bo low value 8bits
     */
    private int mHighValue;


    // Packet Length
    public final static int ITEM_LENGTH = 8;

    public int year;
    public int month;
    public int day;

    public boolean parseData(byte[] data) {
        // check header length
        if (data.length < ITEM_LENGTH) {
            return false;
        }
        mMinutes = ((data[2] << 8) | (data[3] & 0xff)) & 0xffff;// here must be care shift operation of negative
        mSequenceNum = (data[4] & 0xff);
        //mValue = ((data[2] << 8) | (data[3] & 0xff)) & 0xffff;// here must be care shift operation of negative
        mValue = (data[5] & 0xff);
        mLowValue = (data[6] & 0xff);
        mHighValue = (data[7] & 0xff);
        return true;
    }

    public int getmMinutes() {
        return mMinutes;
    }

    public void setmMinutes(int mMinutes) {
        this.mMinutes = mMinutes;
    }

    public int getmSequenceNum() {
        return mSequenceNum;
    }

    public void setmSequenceNum(int mSequenceNum) {
        this.mSequenceNum = mSequenceNum;
    }

    public int getmValue() {
        return mValue;
    }

    public void setmValue(int mValue) {
        this.mValue = mValue;
    }

    public int getmLowValue() {
        return mLowValue;
    }

    public void setmLowValue(int mLowValue) {
        this.mLowValue = mLowValue;
    }

    public int getmHighValue() {
        return mHighValue;
    }

    public void setmHighValue(int mHighValue) {
        this.mHighValue = mHighValue;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    @Override
    public String toString() {
        return "ApplicationLayerBpItemPacket{" +
                "mMinutes=" + mMinutes +
                ", mSequenceNum=" + mSequenceNum +
                ", mValue=" + mValue +
                ", mLowValue=" + mLowValue +
                ", mHighValue=" + mHighValue +
                ", year=" + year +
                ", month=" + month +
                ", day=" + day +
                '}';
    }
}
