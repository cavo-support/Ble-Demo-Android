package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerMulDrinkWaterReminderPacket {

    private boolean isOpen;

    /**
     * 开始小时
     */
    private int startHour;

    /**
     * 开始分钟
     */
    private int startMin;

    /**
     * 结束小时
     */
    private int endHour;

    /**
     * 结束小时
     */
    private int endMin;

    /**
     * 提醒间隔，单位分钟，最大支持 8 小时
     * unit min
     */
    private int interval;

    // Packet Length
    private final static int HEADER_LENGTH = 7;

    public ApplicationLayerMulDrinkWaterReminderPacket() {

    }

    public boolean parseData(byte[] data) {
        // check header length
        if (data.length < HEADER_LENGTH) {
            return false;
        }
        isOpen = ((data[0]) == 0x01);
        startHour = (data[1] & 0xFF);
        startMin = (data[2] & 0xFF);
        endHour = (data[3] & 0xFF);
        endMin = (data[4] & 0xFF);

        interval = ((data[5] & 0xff) << 8) | (data[6] & 0xff);
        return true;
    }

    public byte[] getPacket(){
        byte[] data = new byte[7];
        data[0] = (byte) (isOpen ? 0x01 : 0x00);
        data[1] = (byte) (startHour & 0xFF);
        data[2] = (byte) (startMin & 0xFF);
        data[3] = (byte) (endHour & 0xFF);
        data[4] = (byte) (endMin & 0xFF);
        data[5] = (byte) ((interval >> 8) & 0xff);
        data[6] = (byte) (interval & 0xff);
        return data;
    }

    public boolean isOpen() {
        return isOpen;
    }

    public void setOpen(boolean open) {
        isOpen = open;
    }

    public int getStartHour() {
        return startHour;
    }

    public void setStartHour(int startHour) {
        this.startHour = startHour;
    }

    public int getStartMin() {
        return startMin;
    }

    public void setStartMin(int startMin) {
        this.startMin = startMin;
    }

    public int getEndHour() {
        return endHour;
    }

    public void setEndHour(int endHour) {
        this.endHour = endHour;
    }

    public int getEndMin() {
        return endMin;
    }

    public void setEndMin(int endMin) {
        this.endMin = endMin;
    }

    public int getInterval() {
        return interval;
    }

    public void setInterval(int interval) {
        this.interval = interval;
    }

    @Override
    public String toString() {
        return "ApplicationLayerMulDrinkWaterReminderPacket{" +
                "isOpen=" + isOpen +
                ", startHour=" + startHour +
                ", startMin=" + startMin +
                ", endHour=" + endHour +
                ", endMin=" + endMin +
                ", interval=" + interval +
                '}';
    }
}
