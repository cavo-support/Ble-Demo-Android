package com.wosmart.ukprotocollibary.applicationlayer;

import android.util.Log;

import com.wosmart.ukprotocollibary.util.DataConverter;

import java.util.Arrays;

public class ApplicationLayerRtkHrvPacket {

    private int dateType;

    private long time;

    private int hrvValue;

    public ApplicationLayerRtkHrvPacket() {
    }

    public int getDateType() {
        return dateType;
    }

    public void setDateType(int dateType) {
        this.dateType = dateType;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public int getHrvValue() {
        return hrvValue;
    }

    public void setHrvValue(int hrvValue) {
        this.hrvValue = hrvValue;
    }

    @SuppressWarnings("PointlessBitwiseExpression")
    public boolean parseData(byte[] data) {
        Log.d("UkOptManager5.3C","data.length="+data.length+"\tdata="+ Arrays.toString(data)+"\ndataHex="+ DataConverter.bytes2Hex(data));
        if (data.length >= 7) {
            dateType = data[0] & 0xff;
            time = (((data[1] & 0xff) << 24) | ((data[2] & 0xff) << 16) | ((data[3] & 0xff) << 8) | (data[4] & 0xff)) & 0x00ffffffffL;
//            time = ((data[1] & 0xff) | ((data[2] << 8) & 0xff) | ((data[3] << 16) & 0xff) | ((data[4] << 24) & 0xff)) & 0xffffffff;
            hrvValue = data[5] & 0xff;
//            Log.d("UkOptManager5.3C","time-->"+Long.parseLong("62859DC7",16));
        }
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerRtkHrvPacket{" +
                "dateType=" + dateType +
                ", time=" + time +
                ", hrvValue=" + hrvValue +
                '}';
    }
}
