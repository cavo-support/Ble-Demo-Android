package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerGLUPacket {

    private int mYear;

    private int mMonth;

    private int mDay;

    private int mMinutes;

    private int mSecond;

    private int mGluValue;

    private int mOthers;

    public final static int ITEM_LENGTH = 8;

    public int getmYear() {
        return mYear;
    }

    public void setmYear(int mYear) {
        this.mYear = mYear;
    }

    public int getmMonth() {
        return mMonth;
    }

    public void setmMonth(int mMonth) {
        this.mMonth = mMonth;
    }

    public int getmDay() {
        return mDay;
    }

    public void setmDay(int mDay) {
        this.mDay = mDay;
    }

    public int getmMinutes() {
        return mMinutes;
    }

    public void setmMinutes(int mMinutes) {
        this.mMinutes = mMinutes;
    }

    public int getmGluValue() {
        return mGluValue;
    }

    public void setmGluValue(int mGluValue) {
        this.mGluValue = mGluValue;
    }

    public int getmOthers() {
        return mOthers;
    }

    public void setmOthers(int mOthers) {
        this.mOthers = mOthers;
    }

    public int getmSecond() {
        return mSecond;
    }

    public void setmSecond(int mSecond) {
        this.mSecond = mSecond;
    }

    public boolean parseData(byte[] data){
        if(data.length >= ITEM_LENGTH){
            mYear = (data[0] & 0x7e) >> 1;// here must be care shift operation of negative
            mMonth = ((data[0] & 0x01) << 3) | (data[1] >> 5) & 0x07;//here must be care shift operation of negative
            mDay = data[1] & 0x1f;//here must be care shift operation of negative
            mMinutes = ((data[2] << 8) | (data[3] & 0xff)) & 0xffff;// here must be care shift operation of negative
            mSecond = (data[4] & 0xff);
            mGluValue = (data[5] & 0xff);
            mOthers = ((data[6] << 8) | (data[7] & 0xff)) & 0xffff;

            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "ApplicationLayerGLUPacket{" +
                "mYear=" + mYear +
                ", mMonth=" + mMonth +
                ", mDay=" + mDay +
                ", mMinutes=" + mMinutes +
                ", mSecond=" + mSecond +
                ", mGluValue=" + mGluValue +
                ", mOthers=" + mOthers +
                '}';
    }
}
