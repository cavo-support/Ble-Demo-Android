package com.wosmart.ukprotocollibary.applicationlayer;

import java.util.ArrayList;
import java.util.List;

public class ApplicationLayerUnitPacket {

    private int gluUnit;

    private List<ApplicationLayerSyncSwitchItemPacket> itemPackets = new ArrayList<>();

    public boolean parseData(byte[] data){
        if(data.length < 2){
            return false;
        }
        for (int i = 0; i < data.length/2; i++) {
            ApplicationLayerSyncSwitchItemPacket itemPacket = new ApplicationLayerSyncSwitchItemPacket();
            if(i == 0){
                itemPacket.setSwitchType((data[0] & 0xff));
                itemPacket.setSwitchValue((data[1] & 0xff));
            }else{
                itemPacket.setSwitchType((data[i*2] & 0xff));
                itemPacket.setSwitchValue((data[i*2+1] & 0xff));
            }
            itemPackets.add(itemPacket);
        }
        return true;
    }

    @SuppressWarnings("ConstantConditions")
    public byte[] getPacket(){
        byte[] data = new byte[2];
        data[0] = (byte) 0x00;
        data[1] = (byte) (gluUnit & 0xff);
        return data;
    }

    public List<ApplicationLayerSyncSwitchItemPacket> getItemPackets() {
        return itemPackets;
    }

    public int getGluUnit() {
        return gluUnit;
    }

    public void setGluUnit(int gluUnit) {
        this.gluUnit = gluUnit;
    }
}
