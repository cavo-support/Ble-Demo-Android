package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.util.StringByteTrans;
import com.wosmart.ukprotocollibary.v2.entity.JWWeatherInfo;

public class ApplicationLayerWeatherPacket {

    public boolean isOpen;

    public int year;

    public int month;

    public int day;

    public String city;

    public JWWeatherInfo.CurrentWeather currentWeather;

    public JWWeatherInfo.FutureWeather nextOneDayWeather;

    public JWWeatherInfo.FutureWeather nextTwoDayWeather;

    public JWWeatherInfo.FutureWeather nextThreeDayWeather;

    public JWWeatherInfo.FutureWeather nextFourDayWeather;

    public JWWeatherInfo.FutureWeather nextFiveDayWeather;

    public JWWeatherInfo.FutureWeather nextSixDayWeather;


    public ApplicationLayerWeatherPacket(JWWeatherInfo weatherInfo) {
        this.isOpen = weatherInfo.isOpen;
        this.year = weatherInfo.year;
        this.month = weatherInfo.month;
        this.day = weatherInfo.day;
        this.city = weatherInfo.city;
        this.currentWeather = weatherInfo.currentWeather;
        this.nextOneDayWeather = weatherInfo.nextOneDayWeather;
        this.nextTwoDayWeather = weatherInfo.nextTwoDayWeather;
        this.nextThreeDayWeather = weatherInfo.nextThreeDayWeather;
        this.nextFourDayWeather = weatherInfo.nextFourDayWeather;
        this.nextFiveDayWeather = weatherInfo.nextFiveDayWeather;
        this.nextSixDayWeather = weatherInfo.nextSixDayWeather;
    }



    public byte[] getPacket(){
        byte[] keyValue = new byte[64];
        keyValue[0] = (byte) (this.isOpen ? 0x01 : 0x00);
        keyValue[1] = (byte) ((this.year >> 8) & 0xFF);
        keyValue[2] = (byte) (this.year & 0xFF);
        keyValue[3] = (byte) (this.month & 0xFF);
        keyValue[4] = (byte) (this.day & 0xFF);

        byte[] cityData = StringByteTrans.stringToBytes(this.city, 34);
        cityData[33] = 0;

        System.arraycopy(cityData, 0, keyValue, 5, cityData.length);

        keyValue[39] = (byte) (this.currentWeather == null ? 0 : (this.currentWeather.weatherCode & 0xFF));
        keyValue[40] = (byte) (this.currentWeather == null ? 0 : (this.currentWeather.temperature & 0xFF));
        keyValue[41] = (byte) (this.currentWeather == null ? 0 : (this.currentWeather.maxTemperature & 0xFF));
        keyValue[42] = (byte) (this.currentWeather == null ? 0 : (this.currentWeather.minTemperature & 0xFF));
        keyValue[43] = (byte) (this.currentWeather == null ? 0 : (this.currentWeather.humidity & 0xFF));
        keyValue[44] = (byte) (this.currentWeather == null ? 0 : (this.currentWeather.ultravioletIntensity & 0xFF));
        keyValue[45] = (byte) (this.currentWeather == null ? 0 : (this.currentWeather.pollutionIndex & 0xFF));

        keyValue[46] = (byte) (this.nextOneDayWeather == null ? 0 : (this.nextOneDayWeather.weatherCode & 0xFF));
        keyValue[47] = (byte) (this.nextOneDayWeather == null ? 0 : (this.nextOneDayWeather.maxTemperature & 0xFF));
        keyValue[48] = (byte) (this.nextOneDayWeather == null ? 0 : (this.nextOneDayWeather.minTemperature & 0xFF));

        keyValue[49] = (byte) (this.nextTwoDayWeather == null ? 0 : (this.nextTwoDayWeather.weatherCode & 0xFF));
        keyValue[50] = (byte) (this.nextTwoDayWeather == null ? 0 : (this.nextTwoDayWeather.maxTemperature & 0xFF));
        keyValue[51] = (byte) (this.nextTwoDayWeather == null ? 0 : (this.nextTwoDayWeather.minTemperature & 0xFF));

        keyValue[52] = (byte) (this.nextThreeDayWeather == null ? 0 : (this.nextThreeDayWeather.weatherCode & 0xFF));
        keyValue[53] = (byte) (this.nextThreeDayWeather == null ? 0 : (this.nextThreeDayWeather.maxTemperature & 0xFF));
        keyValue[54] = (byte) (this.nextThreeDayWeather == null ? 0 : (this.nextThreeDayWeather.minTemperature & 0xFF));

        keyValue[55] = (byte) (this.nextFourDayWeather == null ? 0 : (this.nextFourDayWeather.weatherCode & 0xFF));
        keyValue[56] = (byte) (this.nextFourDayWeather == null ? 0 : (this.nextFourDayWeather.maxTemperature & 0xFF));
        keyValue[57] = (byte) (this.nextFourDayWeather == null ? 0 : (this.nextFourDayWeather.minTemperature & 0xFF));

        keyValue[58] = (byte) (this.nextFiveDayWeather == null ? 0 : (this.nextFiveDayWeather.weatherCode & 0xFF));
        keyValue[59] = (byte) (this.nextFiveDayWeather == null ? 0 : (this.nextFiveDayWeather.maxTemperature & 0xFF));
        keyValue[60] = (byte) (this.nextFiveDayWeather == null ? 0 : (this.nextFiveDayWeather.minTemperature & 0xFF));

        keyValue[61] = (byte) (this.nextSixDayWeather == null ? 0 : (this.nextSixDayWeather.weatherCode & 0xFF));
        keyValue[62] = (byte) (this.nextSixDayWeather == null ? 0 : (this.nextSixDayWeather.maxTemperature & 0xFF));
        keyValue[63] = (byte) (this.nextSixDayWeather == null ? 0 : (this.nextSixDayWeather.minTemperature & 0xFF));

        return keyValue;
    }

}
