package com.wosmart.ukprotocollibary.applicationlayer;

import java.util.List;

public class ApplicationLayerBpListPacket {

    /**
     * rate data list
     */
    List<ApplicationLayerBpListItemPacket> bpListItemPackets;

    public List<ApplicationLayerBpListItemPacket> getBpListItemPackets() {
        return bpListItemPackets;
    }

    public void setBpListItemPackets(List<ApplicationLayerBpListItemPacket> bpListItemPackets) {
        this.bpListItemPackets = bpListItemPackets;
    }
}
