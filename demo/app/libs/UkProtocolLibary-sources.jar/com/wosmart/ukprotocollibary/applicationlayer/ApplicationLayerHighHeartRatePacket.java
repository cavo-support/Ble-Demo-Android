package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerHighHeartRatePacket {

    /**
     * open status
     */
    private boolean isOpen; //1bit

    /**
     * 心率过高阀值 有效值 40~220
     */
    private int highHeartRate; //8bit


    /**
     * Packet Length
     */
    public final static int HIGH_HR_HEADER_LENGTH = 2;

    public ApplicationLayerHighHeartRatePacket() {
    }

    public ApplicationLayerHighHeartRatePacket(boolean isOpen, int highHeartRate) {
        this.isOpen = isOpen;
        this.highHeartRate = highHeartRate;
    }

    public boolean isOpen() {
        return isOpen;
    }

    public void setOpen(boolean open) {
        isOpen = open;
    }

    public int getHighHeartRate() {
        return highHeartRate;
    }

    public void setHighHeartRate(int highHeartRate) {
        this.highHeartRate = highHeartRate;
    }

    public byte[] getPacket() {
        byte[] data = new byte[HIGH_HR_HEADER_LENGTH];
        data[0] = (byte) (isOpen ? 0x01 : 0x00);
        data[1] = (byte) (highHeartRate & 0xFF);
        return data;
    }

    public boolean parseData(byte[] data) {
        isOpen = (data[0] & 0x01) == 0x01;
        highHeartRate = data[1] & 0xFF;
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerHighHeartRatePacket{" +
                "isOpen=" + isOpen +
                ", highHeartRate=" + highHeartRate +
                '}';
    }
}
