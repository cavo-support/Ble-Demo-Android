package com.wosmart.ukprotocollibary.applicationlayer;

import com.wosmart.ukprotocollibary.model.enums.TimerOpt;

public class ApplicationLayerTimerPacket {

    /**
     * is show on remote device
     */
    private boolean isShow;

    /**
     * operate
     */
    private TimerOpt opt;

    /**
     *
     */
    private int seconds;

    public final static int TIMER_HEADER_LENGTH = 3;

    public ApplicationLayerTimerPacket() {
    }

    public ApplicationLayerTimerPacket(boolean isShow, TimerOpt opt, int seconds) {
        this.isShow = isShow;
        this.opt = opt;
        this.seconds = seconds;
    }

    public boolean isShow() {
        return isShow;
    }

    public void setShow(boolean show) {
        isShow = show;
    }

    public TimerOpt getOpt() {
        return opt;
    }

    public void setOpt(TimerOpt opt) {
        this.opt = opt;
    }

    public int getSeconds() {
        return seconds;
    }

    public void setSeconds(int seconds) {
        this.seconds = seconds;
    }

    public byte[] getPacket() {
        byte[] data = new byte[TIMER_HEADER_LENGTH];
        int optValue = 0;
        if (opt == TimerOpt.BEGIN) {
            optValue = 1;
        } else if (opt == TimerOpt.END) {
            optValue = 2;
        }
        data[0] = (byte) (((isShow ? (byte) 0x01 : (byte) 0x00) << 7) | ((optValue & 0x03) << 5) | ((seconds >> 16) & 0x1f));
        data[1] = (byte) ((seconds >> 8) & 0xff);
        data[2] = (byte) (seconds & 0xff);
        return data;
    }

    public boolean parseData(byte[] data) {
        if (data.length < TIMER_HEADER_LENGTH) {
            return false;
        }
        isShow = (byte) ((data[0] >> 7) & 0x01) == (byte) 0x01 ? true : false;
        int optValue = (data[0] >> 5) & 0x03;
        if (optValue == 1) {
            opt = TimerOpt.BEGIN;
        } else if (optValue == 2) {
            opt = TimerOpt.END;
        } else {
            opt = TimerOpt.SETTING;
        }
        seconds = ((data[0] & 0x1f) << 16) | ((data[1] & 0xff) << 8) | (data[2] & 0xff);
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationLayerTimerPacket{" +
                "isShow=" + isShow +
                ", opt=" + opt +
                ", seconds=" + seconds +
                '}';
    }
}
