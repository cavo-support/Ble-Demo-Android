package com.wosmart.ukprotocollibary.applicationlayer;

public class ApplicationLayerSyncSwitchItemPacket {

    /**
     * 同步设备可以控制的开关类型
     * 0--时间制式（12/24小时制）
     * 1--语言选择
     * 2--心率监测开关
     * 3--血压监测开关
     * 4--血氧监测开关
     * 5--温度监测开关
     * 6--温度补偿开关
     * 7--温度功能独立（不依赖心率测量）
     * 8--血糖监测开关
     * 9--手势亮屏开关（也叫转腕亮屏，抬手亮屏）
     * 10--尿酸监测开关
     * 11--血脂监测开关
     */
    private int switchType;
    /**
     * 同步设备可以控制的开关类型所代表的值
     * 0--时间制式（12/24小时制） [0--24小时制，1--12小时制]
     * 1--语言选择 （祥见协议2-4E）
     * 2--心率监测开关（0--关，1--开）
     * 3--血压监测开关（0--关，1--开）
     * 4--血氧监测开关（0--关，1--开）
     * 5--温度监测开关（0--关，1--开）
     * 6--温度补偿开关（0--关，1--开）
     * 7--温度功能独立（0--关，1--开）
     * 8--血糖监测开关（0--关，1--开）
     * 9--手势亮屏开关（0--关，1--开）
     * 10--尿酸监测开关（0--关，1--开）
     * 11--血脂监测开关（0--关，1--开）
     */
    private int switchValue;

    public int getSwitchType() {
        return switchType;
    }

    public void setSwitchType(int switchType) {
        this.switchType = switchType;
    }

    public int getSwitchValue() {
        return switchValue;
    }

    public void setSwitchValue(int switchValue) {
        this.switchValue = switchValue;
    }

    @Override
    public String toString() {
        return "ApplicationLayerSyncSwitchItemPacket{" +
                "switchType=" + switchType +
                ", switchValue=" + switchValue +
                '}';
    }
}
