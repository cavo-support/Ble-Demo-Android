package com.wosmart.ukprotocollibary.gattlayer;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Message;

import androidx.annotation.NonNull;

import com.wosmart.ukprotocollibary.util.DataConverter;
import com.wosmart.ukprotocollibary.corespec.BatteryService2;
import com.wosmart.ukprotocollibary.corespec.DebugService;
import com.wosmart.ukprotocollibary.corespec.EcgTestService;
import com.wosmart.ukprotocollibary.corespec.HeartRateService;
import com.wosmart.ukprotocollibary.corespec.ImmediateAlertService2;
import com.wosmart.ukprotocollibary.corespec.LinkLossService2;
import com.wosmart.ukprotocollibary.util.SDKLogger;
import com.wosmart.ukprotocollibary.v2.BaseConstants;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Random;
import java.util.UUID;


public class GattLayer {
    // Log
    private final static String TAG = "GattLayer";
    private final static boolean D = true;

    public static GattLayer instance = null;

    // Gatt Layer Call
    private GattLayerCallback mCallback;

    // Bluetooth Manager
    private BluetoothGatt mBluetoothGatt;

    // MTU size 512 240
    private static final int MTU_SIZE_EXPECT = 247;

    private int setMtuFailedCount = -1;

    /**
     * 0 默认 1 成功 2 失败
     */
    private int descriptorWriteStatus = 0;

    // Device info
    private String mBluetoothDeviceAddress;

    // Context
    private Context mContext;

    // Global Gatt
    private GlobalGatt2 mGlobalGatt;

    private boolean isRef = false;

    private boolean isToServiceDiscover = false;

    // UUID
    private final static UUID WRISTBAND_SERVICE_UUID = UUID.fromString("000001ff-3c17-d293-8e48-14fe2e4da212");      //ff01
    private final static UUID FD50_SERVICE_UUID = UUID.fromString("0000fd50-0000-1000-8000-00805f9b34fb");
    private final static UUID WRISTBAND_WRITE_CHARACTERISTIC_UUID = UUID.fromString("0000ff02-0000-1000-8000-00805f9b34fb");
    private final static UUID WRISTBAND_NOTIFY_CHARACTERISTIC_UUID = UUID.fromString("0000ff03-0000-1000-8000-00805f9b34fb");
    private final static UUID WRISTBAND_NAME_CHARACTERISTIC_UUID = UUID.fromString("0000ff04-0000-1000-8000-00805f9b34fb");
    private final static UUID WRISTBAND_ECG_CHARACTERISTIC_UUID = UUID.fromString("0000FF0A-0000-1000-8000-00805f9b34fb");

    /**
     * Client configuration descriptor that will allow us to enable notifications and indications
     */
    private static final UUID CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    // Characteristic
    private BluetoothGattCharacteristic mWriteCharacteristic;
    private BluetoothGattCharacteristic mNameCharacteristic;
    private BluetoothGattCharacteristic mNotifyCharacteristic;
    private BluetoothGattCharacteristic mEcgCharacteristic;

    private int failedCount;

    public GattLayer(Context context, GattLayerCallback callback) {
        SDKLogger.d(D, "initial.");
        instance = this;
        mContext = context;
        // register callback
        mCallback = callback;
        // Global Gatt
        GlobalGatt2.initial(context);
        mGlobalGatt = GlobalGatt2.getInstance();
        descriptorWriteStatus = 0;
    }

    /**
     * Set the name
     *
     * @param name the name
     */
    public void setDeviceName(String name) {
        SDKLogger.d(D, "name: " + name);
        if (mNameCharacteristic == null) {
            return;
        }
        // Send the data
        mNameCharacteristic.setValue(name);
        mGlobalGatt.writeCharacteristicSync(mBluetoothDeviceAddress, mNameCharacteristic);
    }

    /**
     * Get the name
     */
    public void getDeviceName() {
        SDKLogger.d(D, "getDeviceName");
        if (mNameCharacteristic == null) {
            return;
        }
        // Send the data
        mGlobalGatt.readCharacteristic(mBluetoothDeviceAddress, mNameCharacteristic);
    }

    public boolean setEcgCharacteristic(boolean enable){
        SDKLogger.w(D, "AAAAA setEcgCharacteristic");
        if(mEcgCharacteristic == null){
            SDKLogger.w(D, "WRISTBAND_ECG_CHARACTERISTIC_UUID not supported 直接认为打开了通知");
            return true;
        }else{
            boolean isSet = mGlobalGatt.setCharacteristicNotification(mBluetoothDeviceAddress,mEcgCharacteristic,enable);
            SDKLogger.w(D, "WRISTBAND_ECG_CHARACTERISTIC_UUID yes "+isSet + "\tenable="+enable);
            return isSet;
        }
    }

    /**
     * Send data
     *
     * @param data the data need to send
     */
    public boolean sendData(byte[] data) {
        if (mWriteCharacteristic == null) {
            SDKLogger.w(D, "WRISTBAND_WRITE_CHARACTERISTIC_UUID not supported");
            return false;
        }
        if (!mGlobalGatt.isConnected(mBluetoothDeviceAddress)) {
            SDKLogger.w(D, "disconnected, addr=" + mBluetoothDeviceAddress);
            return false;
        }
        SDKLogger.d(D, "-->> " + DataConverter.bytes2Hex(data));

        // Send the data
        mWriteCharacteristic.setValue(data);
        return mGlobalGatt.writeCharacteristic(mBluetoothDeviceAddress, mWriteCharacteristic);
//		return true;
    }

    /**
     * Connects to the GATT server hosted on the Bluetooth LE device.
     *
     * @param address The device address of the destination device.
     * @return Return true if the connection is initiated successfully. The connection result
     * is reported asynchronously through the
     * {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     * callback.
     */
    public boolean connect(final String address) {
        mBluetoothDeviceAddress = address;
        if(null == mGlobalGatt){
            mGlobalGatt = GlobalGatt2.getInstance();
        }
        SDKLogger.d(D, "GattLayer connect address: " + address);
        setMtuFailedCount = 0;
        descriptorWriteStatus = 0;
        failedCount = 0;
        return mGlobalGatt.connect(address, mGattCallback);
    }

    public void reConnect(final String address) {
        // 内部发起连接，失败 3 次直接回调失败，不再重连
        failedCount++;
        SDKLogger.d(D, "GattLayer reConnect address: " + address + ", failedCount = " + failedCount);
        mBluetoothDeviceAddress = address;
        setMtuFailedCount = 0;
        descriptorWriteStatus = 0;
        if (failedCount == 3) {
            failedCount = 0;
            mCallback.onConnectionStateChange(false, false);
            mCallback.onConnectionStateChange(false, BaseConstants.ERR_CONNECT_DEVICE_FAILED, "connect device failed");
            return;
        }
        mGlobalGatt.connect(address, mGattCallback);
    }



    /**
     * When the le services manager close, it must disconnect and close the gatt.
     */
    public void close() {
        SDKLogger.d(D, "close()");
        descriptorWriteStatus = 0;
        try {
            mGlobalGatt.close(mBluetoothDeviceAddress);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Clears the internal cache and forces a refresh of the services from the * remote device.
     */

    @SuppressWarnings("ConstantConditions")
    public boolean refreshDeviceCache(BluetoothGatt mBluetoothGatt) {
        SDKLogger.d(D,"断开连接后开始清除ble缓存");
        if (mBluetoothGatt != null) {
            try {
                BluetoothGatt localBluetoothGatt = mBluetoothGatt;
//                Method localMethod = localBluetoothGatt.getClass().getMethod("refresh", new Class[0]);
                Method localMethod = localBluetoothGatt.getClass().getMethod("refresh");
                if (localMethod != null) {
//                    boolean bool = ((Boolean) localMethod.invoke(localBluetoothGatt, new Object[0])).booleanValue();
                    boolean bool = (boolean) localMethod.invoke(localBluetoothGatt);
                    SDKLogger.d(D,"调用清除缓存方法：bool=" + bool);
                    return bool;
                }else{
                    SDKLogger.d(D,"调用清除缓存方法：localMethod=null");
                }
            } catch (Exception localException) {
                localException.printStackTrace();
                SDKLogger.d(D, "An exception occured while refreshing device");
            }
        }else{
            SDKLogger.d(D,"mBluetoothGatt = null");
        }
        return false;
    }

    /**
     * Disconnects an existing connection or cancel a pending connection. The disconnection result
     * is reported asynchronously through the
     * {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     * callback.
     */
    public void disconnectGatt() {
        SDKLogger.d(D, "disconnect()");
        descriptorWriteStatus = 0;
//        mGlobalGatt.disconnectGatt(mBluetoothDeviceAddress);
        mGlobalGatt.close(mBluetoothDeviceAddress);
    }

    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case 1:
                    while (!isToServiceDiscover) {
                        mBluetoothGatt.discoverServices();
                        try {
                            Thread.sleep(5000);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                case 98:
                    // 检查 onDescriptorWrite 是否写入成功
                    if (descriptorWriteStatus == 0) {
                        // 写入 descriptor 无回应，直接断开连接
                        disconnectGatt();
                        mCallback.onConnectionStateChange(false, false);
                        mCallback.onConnectionStateChange(false, BaseConstants.ERR_DESCRIPTOR_WRITE_FAILED, "descriptor write timeout");
                    }
                    break;
                case 99:
                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
                        if (setMtuFailedCount != -1 && mBluetoothGatt != null) {
                            setMtuFailedCount++;
                            int mtu = MTU_SIZE_EXPECT - 40 * setMtuFailedCount;
                            if (mtu < 20) {
                                mtu = 20;
                            }
                            SDKLogger.i(D, "Attempting to request mtu size check check , expect mtu size is: " + String.valueOf(mtu));
                            mBluetoothGatt.requestMtu(mtu);
                            if (mtu != 20) {
                                mHandler.sendEmptyMessageDelayed(99, 2000);
                            }
                        }
                    }
                    break;
            }
        }
    };

    public static void startFetch(BluetoothDevice device) { // Need to use reflection prior to API 15
        Class cl = null;
        try {
            cl = Class.forName("android.bluetooth.BluetoothDevice");
        } catch (ClassNotFoundException exc) {
            SDKLogger.d(true, "android.bluetooth.BluetoothDevice not found.");
        }
        if (null != cl) {
            Class[] param = {};
            Method method = null;
            try {
                method = cl.getMethod("fetchUuidsWithSdp", param);
            } catch (NoSuchMethodException exc) {
                SDKLogger.d(true, "fetchUuidsWithSdp not found.");
            }
            if (null != method) {
                Object[] args = {};
                try {
                    method.invoke(device, args);
                } catch (Exception exc) {
                    SDKLogger.d(true, "Failed to invoke fetchUuidsWithSdp method.");
                }
            }
        }
    }


    // Implements callback methods for GATT events that the app cares about.  For example,
    // connection change and services discovered.
    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            SDKLogger.d(D, "mtu=" + mtu + ", status=" + status);
            // change the mtu real payloaf size
            if (status == BluetoothGatt.GATT_SUCCESS) {
                mCallback.onDataLengthChanged(mtu - 3);
//                handler.sendEmptyMessage(1);
            }
            // 有回应后清空失败次数
            setMtuFailedCount = -1;

            // Attempts to discover services after successful connection.
            boolean sta = mBluetoothGatt.discoverServices();
            SDKLogger.i(D, "Attempting to start service discovery: " + sta);
            if(!sta){
                sta = mBluetoothGatt.discoverServices();
                if(sta){
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        SDKLogger.d(D,"设置requestConnectionPriority()");
                        mBluetoothGatt.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH);
                    }
                }
            }else{
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    SDKLogger.d(D,"设置requestConnectionPriority()");
                    mBluetoothGatt.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH);
                }
            }

        }

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            // 此处回调触发仅接收连接正常或异常，不会触发断开重连，自动重连已在 GlobalGatt2 里面处理并移除这里的回调了
            mBluetoothGatt = gatt;
            SDKLogger.d(true, "GattLayer1 onConnectionStateChange.status="+status+"\nnewState="+newState+"\tmBluetoothGatt="+(mBluetoothGatt == null));
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    SDKLogger.i(D, "GattLayer1 Connected to GATT server.");

                    // only android 5.0 add the requestMTU feature
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
                        failedCount = 0;
                        // Attempts to discover services after successful connection.
                        if (mBluetoothGatt != null) {
                            boolean sta = mBluetoothGatt.discoverServices();
                            SDKLogger.i(D, "Attempting to start service discovery: " +
                                    sta);
                        }
                    } else {
                        SDKLogger.i(D, "Attempting to request mtu size, expect mtu size is: " + String.valueOf(MTU_SIZE_EXPECT));

                        boolean isMtu = false;
                        if(null != mBluetoothGatt) {
                            isMtu = mBluetoothGatt.requestMtu(MTU_SIZE_EXPECT);
                            if(!isMtu){
                                SDKLogger.i(D,"setting mtu?" + isMtu);
                            }else{
                                SDKLogger.i(D,"setting mtu success1");
                            }
//                            // 2 秒后检查设置是否成功
//                            mHandler.sendEmptyMessageDelayed(99, 2000);
                        }
                    }
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    // try to close gatt
//                    disconnectGatt();
                    if(null != mBluetoothGatt){
                        refreshDeviceCache(mBluetoothGatt);
                        SDKLogger.i(D, "GattLayer1 Disconnected from GATT server.refresh gatt");
                    }else{
                        SDKLogger.i(D, "GattLayer1 Disconnected from GATT server.");
                    }
                    close();
                    // tell up stack the current connect state
                    mCallback.onConnectionStateChange(true, false);
                    mCallback.onConnectionStateChange(false, BaseConstants.ERR_CONNECT_DEVICE_FAILED, "connect device failed");
                }
            } else {
                SDKLogger.e(D, "GattLayer1 error: status " + status + " newState: " + newState);
                if(status == 133 || status == 257 || status == 129 || status == 22){
                    // 这里正常情况不会触发，已在 GlobalGatt2 里面处理并移除这里的回调了
//                    if(null != mBluetoothGatt){
//                        refreshDeviceCache(mBluetoothGatt);
//                    }
//                    BluetoothDevice device = gatt.getDevice();
//                    if(null != device){
//                        startFetch(device);
//                        SDKLogger.d(true,"refresh device");
//                    }else{
//                        SDKLogger.d(true,"device == null");
//                    }
//                    mGlobalGatt.closeAll();
//                    mGlobalGatt = null;
//                    connect(mBluetoothDeviceAddress);
                }else {
                    // try to close gatt
                    try{
                        if(null != mBluetoothGatt){
                            refreshDeviceCache(mBluetoothGatt);
                            SDKLogger.i(D, "Disconnected from GATT server.refresh gatt-->1");
                        }else{
                            SDKLogger.i(D, "Disconnected from GATT server-->1.");
                        }
                        mGlobalGatt.closeAll();
                        mCallback.onConnectionStateChange(false, false);
                        mCallback.onConnectionStateChange(false, BaseConstants.ERR_CONNECT_DEVICE_FAILED, "connect device failed");
                        mBluetoothGatt = null;
                    }catch (Exception ex){
                        ex.printStackTrace();
                    }
//                    close();
                    // tell up stack the current connect state
                }
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            SDKLogger.d(D,"AAAAA onServicesDiscovered");
            SDKLogger.d(D, "GattLayer onServicesDiscovered status=" + status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                // set the characteristic
                // initial the service and characteristic
                isToServiceDiscover = true;
                BluetoothGattService service = gatt.getService(WRISTBAND_SERVICE_UUID);

                if (service == null) {
                    SDKLogger.w(D, "WRISTBAND_SERVICE_UUID not supported");
                    SDKLogger.d(D,"AAAAA WRISTBAND_SERVICE_UUID not supported");

                    // try to disconnect gatt
                    disconnectGatt();
                    mCallback.onConnectionStateChange(false, false);
                    mCallback.onConnectionStateChange(false, BaseConstants.ERR_UN_FIND_SERVICE, "un find service");
                    return;
                }else{
                    SDKLogger.d(D,"BluetoothGattService is not null");
                    List<BluetoothGattCharacteristic> characteristics = service.getCharacteristics();
                    for (int i = 0; i < characteristics.size(); i++) {
                        SDKLogger.d(D,"characteristics-->"+characteristics.get(i).getUuid());
                    }
                }
                mNotifyCharacteristic = service.getCharacteristic(WRISTBAND_NOTIFY_CHARACTERISTIC_UUID);
                if (mNotifyCharacteristic == null) {
                    SDKLogger.w(D, "WRISTBAND_NOTIFY_CHARACTERISTIC_UUID not supported");
                    SDKLogger.d(D,"AAAAA WRISTBAND_NOTIFY_CHARACTERISTIC_UUID not supported");

                    // try to disconnect gatt
                    disconnectGatt();
                    mCallback.onConnectionStateChange(false, false);
                    mCallback.onConnectionStateChange(false, BaseConstants.ERR_UN_FIND_CHARACTERISTIC, "un find characteristic");
                    return;
                }

//                try {
//                    Thread.sleep(500);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
                // enable notification
                mGlobalGatt.setCharacteristicNotification(mBluetoothDeviceAddress, mNotifyCharacteristic, true);
                // 5 秒后检查设置是否成功
                mHandler.sendEmptyMessageDelayed(98, 5000);
//                BluetoothGattService fd50_service = gatt.getService(FD50_SERVICE_UUID);
//                if (fd50_service == null) {
//                    SDKLogger.w(D, "FD50_SERVICE_UUID not supported");
//
//                    // try to disconnect gatt
//                    disconnectGatt();
//                    return;
//                }
                mWriteCharacteristic = service.getCharacteristic(WRISTBAND_WRITE_CHARACTERISTIC_UUID);
                if (mWriteCharacteristic == null) {
                    SDKLogger.w(D, "WRISTBAND_WRITE_CHARACTERISTIC_UUID not supported");

                    // try to disconnect gatt
                    disconnectGatt();
                    mCallback.onConnectionStateChange(false, false);
                    mCallback.onConnectionStateChange(false, BaseConstants.ERR_UN_FIND_CHARACTERISTIC, "un find characteristic");
                    return;
                }
                mNameCharacteristic = service.getCharacteristic(WRISTBAND_NAME_CHARACTERISTIC_UUID);
                if (mNameCharacteristic == null) {
                    SDKLogger.w(D, "WRISTBAND_NAME_CHARACTERISTIC_UUID not supported");

                    // try to disconnect gatt
                    disconnectGatt();
                    mCallback.onConnectionStateChange(false, false);
                    mCallback.onConnectionStateChange(false, BaseConstants.ERR_UN_FIND_CHARACTERISTIC, "un find characteristic");
                    return;
                }
                mEcgCharacteristic = service.getCharacteristic(WRISTBAND_ECG_CHARACTERISTIC_UUID);

                DebugService debugService = DebugService.getInstance();
                if(null != debugService){
                    debugService.initial();
                    debugService.mGattCallback.onServicesDiscovered(gatt,status);
                }

                LinkLossService2 linkLossService2 = LinkLossService2.getInstance();
                if(null != linkLossService2){
                    linkLossService2.initial();
                    linkLossService2.mGattCallback.onServicesDiscovered(gatt,status);
                }

                HeartRateService heartRateService = HeartRateService.getInstance();
                if(null != heartRateService){
                    heartRateService.initial();
                    heartRateService.mGattCallback.onServicesDiscovered(gatt,status);
                }

                ImmediateAlertService2 immediateAlertService2 = ImmediateAlertService2.getInstance();
                if(null != immediateAlertService2){
                    immediateAlertService2.initial();
                    immediateAlertService2.mGattCallback.onServicesDiscovered(gatt,status);
                }

                BatteryService2 batteryService2 = BatteryService2.getInstance();
                if(null != batteryService2) {
                    batteryService2.initial();
                    batteryService2.mGattCallback.onServicesDiscovered(gatt, status);
//                    batteryService2.readBatteryLevel(); // 不明白这里为什么要读取电量，暂时注销，等待后续上层读取
                }
                EcgTestService ecgTestService = EcgTestService.getInstance();
                if(null != ecgTestService){
                    ecgTestService.initial();
                    ecgTestService.mGattCallback.onServicesDiscovered(gatt,status);
                }

            } else {
                // try to disconnect gatt
                disconnectGatt();
                mCallback.onConnectionStateChange(false, false);
                mCallback.onConnectionStateChange(false, BaseConstants.ERR_UN_FIND_SERVICE, "un find service");
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
//            SDKLogger.d(D,"uuid-->"+characteristic.getUuid());
            byte[] data = characteristic.getValue();
//            SDKLogger.d(D, "<<-- olength: " + characteristic.getValue().length
//                    + ", data: " + DataConverter.bytes2Hex(data));
//            Log.d("UkOptManager","GattLayer data[]="+ Arrays.toString(data));
            if (WRISTBAND_NOTIFY_CHARACTERISTIC_UUID.equals(characteristic.getUuid())) {
                // tell up stack a data receive
                mCallback.onDataReceive(data);
            }else if(WRISTBAND_ECG_CHARACTERISTIC_UUID.equals(characteristic.getUuid())){
//                SDKLogger.d(D,"ff0a-->value:"+DataConverter.bytes2Hex(characteristic.getValue()));
                mCallback.onDeviceEcgData(data);
            }

        }

        @Override
        public void onCharacteristicWrite(final BluetoothGatt gatt, final BluetoothGattCharacteristic characteristic, final int status) {
            SDKLogger.d(D,"uuid-->"+characteristic.getUuid());
            if (WRISTBAND_WRITE_CHARACTERISTIC_UUID.equals(characteristic.getUuid())) {
                mCallback.onDataSend(status == BluetoothGatt.GATT_SUCCESS);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            SDKLogger.d(D, "<<<--- status: " + status + " value: " + DataConverter.bytes2Hex(characteristic.getValue()));
            if (WRISTBAND_NAME_CHARACTERISTIC_UUID.equals(characteristic.getUuid())) {
                String name = characteristic.getStringValue(0);
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    // tell up stack data send right
                    mCallback.onNameReceive(name);
                }
            }
        }

        @Override
        public void onDescriptorWrite(final BluetoothGatt gatt, final BluetoothGattDescriptor descriptor, final int status) {
            SDKLogger.d(D,"GattLayer onDescriptorWrite status="+ status+"\tuuid="+descriptor.getUuid());
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR_UUID.equals(descriptor.getUuid())) {
                    if (descriptor.getCharacteristic().getUuid().equals(mNotifyCharacteristic.getUuid())) {
                        boolean enabled = descriptor.getValue()[0] == 1;
                        if (enabled) {
                            SDKLogger.d(D, "Notification enabled");
                            // tell up stack the current connect state
                            descriptorWriteStatus = 1;
                            mCallback.onConnectionStateChange(true, true);
                            mCallback.onConnectionStateChange(true, 0, "");
                        } else {
                            SDKLogger.e(D, "Notification  not enabled!!!");
                            descriptorWriteStatus = 2;
                            mCallback.onConnectionStateChange(false, false);
                            mCallback.onConnectionStateChange(false, BaseConstants.ERR_DESCRIPTOR_WRITE_FAILED, "descriptor write failed");
                            disconnectGatt();
                        }
                    }
                }
            } else {
                SDKLogger.e(D, "Descriptor write error: " + status);
                descriptorWriteStatus = 2;
                mCallback.onConnectionStateChange(false, false);
                mCallback.onConnectionStateChange(false, BaseConstants.ERR_DESCRIPTOR_WRITE_FAILED, "descriptor write failed");
                disconnectGatt();
            }
        }
    };
}
