package com.wosmart.ukprotocollibary.gattlayer;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.text.TextUtils;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.wosmart.ukprotocollibary.util.SDKLogger;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;


public class GlobalGatt2 {

    private static final boolean D = true;
    private static GlobalGatt2 mInstance;
    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private CopyOnWriteArrayList<String> mBluetoothDeviceAddress;
    public ConcurrentHashMap<String, BluetoothGatt> mBluetoothGatts;
    private HashMap<String, ArrayList<BluetoothGattCallback>> mCallbacks;
    private ConcurrentHashMap<String, Integer> mConnectionState;
    private volatile boolean mGattCallbackCalled;
    private final Object mGattCallbackLock = new Object();
    private BluetoothGatt gatt;

    private boolean isToServiceDiscover = false;

    //    private static final long MAX_CALLBACK_LOCK_WAIT_TIME = 1700;
    private static final long MAX_CALLBACK_LOCK_WAIT_TIME = 1500;
    public static final int STATE_DISCONNECTED = 0;
    public static final int STATE_CONNECTING = 1;
    public static final int STATE_CONNECTED = 2;
    private static Context mContext;
    public static String CLIENT_CHARACTERISTIC_CONFIG = "00002902-0000-1000-8000-00805f9b34fb";
    public static String CLIENT_ECGTEST_CHARACTERISTIC_CONFIG = "0000E0FF-0000-1000-8000-00805f9b34fb";
    private final static UUID DEBUG_SERVICE_UUID = UUID.fromString("0000a00a-0000-1000-8000-00805f9b34fb");

    private String mAddress = "";

    private GlobalGatt2() {
    }

    public BluetoothGatt getGatt() {
        return gatt;
    }

    public static void initial(Context context) {
        mContext = context;
        mInstance = new GlobalGatt2();
        mInstance.mBluetoothGatts = new ConcurrentHashMap<>();
        mInstance.mConnectionState = new ConcurrentHashMap<>();
        mInstance.mCallbacks = new HashMap<>();
        mInstance.mBluetoothDeviceAddress = new CopyOnWriteArrayList<>();
        mInstance.initialize();
    }

    public static GlobalGatt2 getInstance() {
        return mInstance;
    }

    public boolean initialize() {
        SDKLogger.d(true, "initialize()");
        if (this.mBluetoothManager == null) {
            this.mBluetoothManager = (BluetoothManager) mContext.getSystemService(Context.BLUETOOTH_SERVICE);
            if (this.mBluetoothManager == null) {
                SDKLogger.d(true, "BLUETOOTH_SERVICE not supported.");
                return false;
            }
        }

        if (this.mBluetoothAdapter == null) {
            this.mBluetoothAdapter = this.mBluetoothManager.getAdapter();
            if (this.mBluetoothAdapter == null) {
                SDKLogger.d(true, "Unable to obtain a BluetoothAdapter.");
                return false;
            }
        }

        return true;
    }

    public boolean isBluetoothSupported() {
        return this.mBluetoothAdapter != null || this.initialize();
    }

    public boolean isConnected(String address) {
        if (TextUtils.isEmpty(address)) {
            return false;
        }
        Integer isConnectStatus = this.mConnectionState.get(address);
        if (isConnectStatus == null) {
            SDKLogger.d(true, "no connection state found, addr: " + address);
            return false;
        } else {
            SDKLogger.d(true, "addr=" + address + ", isConnectStatus = " + isConnectStatus);
            return isConnectStatus == 2;
        }
    }

    public boolean isHostConnected(String address) {
        if (this.mBluetoothManager == null) {
            SDKLogger.d(true, "addr: " + address + ", mBluetoothManager == null");
            return false;
        } else {
            @SuppressLint("MissingPermission") List<BluetoothDevice> lists = this.mBluetoothManager.getConnectedDevices(7);
            if (lists != null) {
                Iterator var3 = lists.iterator();

                while (var3.hasNext()) {
                    BluetoothDevice device = (BluetoothDevice) var3.next();
                    if (device.getAddress().equals(address)) {
                        SDKLogger.d(true, "addr: " + address + ", Connected.");
                        return true;
                    }
                }
            }

            SDKLogger.d(true, "addr: " + address + ", Disconnected.");
            return false;
        }
    }

    @SuppressLint("MissingPermission")
    public synchronized boolean connect(String address, BluetoothGattCallback callback) {
//        disconnectGatt(address);
        SDKLogger.d(true, "GlobalGatt2 connect address=" + address + "\tbluetoothAdapter=" + (null != this.mBluetoothAdapter));
        if (this.mBluetoothAdapter != null && !TextUtils.isEmpty(address)) {
            mAddress = address;
            boolean isContainsAddress = this.mBluetoothDeviceAddress.contains(address);
            boolean isConnected = this.isConnected(address);
            BluetoothGatt bluetoothGatt = mBluetoothGatts.get(address);
            SDKLogger.d(true, "GlobalGatt2 connect isContainsAddress = " + isContainsAddress + ", isConnected = " + isConnected + ", bluetoothGatt = " + bluetoothGatt);
            if (isContainsAddress && isConnected) {
                SDKLogger.d(true, "device already connected, addr=" + address);
                this.registerCallback(address, callback);
                callback.onConnectionStateChange(bluetoothGatt, 0, 2);
                return true;
            } else if (isContainsAddress) {
                SDKLogger.d(true, "Trying to use an existing mBluetoothGatt for connection.");
                if (null != bluetoothGatt && bluetoothGatt.connect()) {
                    this.mConnectionState.put(address, 1);
                    return true;
                } else {
                    return false;
                }
            } else {
                this.registerCallback(address, callback);
                if(BluetoothAdapter.checkBluetoothAddress(address)) {
                    BluetoothDevice device = this.mBluetoothAdapter.getRemoteDevice(address);
                    if (device == null) {
                        SDKLogger.d(true, "Device not found.  Unable to connect.");
                        return false;
                    } else {
                        this.mConnectionState.put(address, 1);
                        BluetoothGatt gatt = null;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            gatt = device.connectGatt(mContext, false, callback1, BluetoothDevice.TRANSPORT_LE);
                        } else {
                            gatt = device.connectGatt(mContext, false, callback1);//new GlobalGatt2.GattCallback()
                        }
                        if (TextUtils.isEmpty(address) || gatt == null) {
                            SDKLogger.d(true, "Failed to create GATT connection, gatt is null");
                            // 清理连接状态
                            this.mConnectionState.remove(address);
                            // 通知连接失败
                            if (callback != null) {
                                callback.onConnectionStateChange(null, BluetoothGatt.GATT_SUCCESS, BluetoothProfile.STATE_DISCONNECTED);
                            }
                            return false;
                        }
                        this.mBluetoothGatts.put(address, gatt);
                        this.mBluetoothDeviceAddress.add(address);
                        SDKLogger.d(true, "Trying to create a new connection.gatt=null?" + (gatt == null));
                        return true;
                    }
                }else{
                    SDKLogger.d(true, "Invalid MAC: Address---无效MAC地址");
                    return false;
                }
            }
        } else {
            SDKLogger.d(true, "BluetoothAdapter not initialized or unspecified address.");
            return false;
        }
    }

    @SuppressLint("MissingPermission")
    public synchronized void closeBluetoothGatt(String addr) {
        if (TextUtils.isEmpty(addr)) {
            return;
        }
        try {
            SDKLogger.d(true, "addr:=" + addr);
            BluetoothGatt bluetoothGatt = this.mBluetoothGatts.get(addr);
            if (bluetoothGatt != null) {
                bluetoothGatt.close();
                this.mBluetoothGatts.remove(addr);
            }

            this.mCallbacks.remove(addr);
            if (this.mBluetoothDeviceAddress.contains(addr)) {
                this.mBluetoothDeviceAddress.remove(addr);
            }
        } catch (Exception var3) {
            SDKLogger.d(true, "closeGattError:" + var3.getMessage());
        }

    }

    public synchronized void close(String addr) {
        SDKLogger.d(true, "close addr :" + addr);
        if(null != gatt){
            BluetoothDevice device = gatt.getDevice();
            refreshDeviceCache(gatt);
            if(null != device){
                startFetch(device);
                SDKLogger.d(true,"close refresh device");
            }else{
                SDKLogger.d(true,"close device == null");
            }
        }else{
            SDKLogger.d(true,"close gatt == null");
        }
        this.disconnectGatt(addr);
        this.closeBluetoothGatt(addr);
    }

    public synchronized void closeAll() {
        SDKLogger.d(true, "mBluetoothDeviceAddress.size(): " + this.mBluetoothDeviceAddress.size());
        try {
            Iterator var1 = this.mBluetoothDeviceAddress.iterator();

            if (null != var1) {
                while (var1.hasNext()) {
                    String addr = (String) var1.next();
                    if (!TextUtils.isEmpty(addr)) {
                        this.close(addr);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            SDKLogger.d(true, "closeAllGattError:" + e.getMessage());
        }

    }

    @SuppressLint("MissingPermission")
    public synchronized void disconnectGatt(String addr) {
        SDKLogger.d(true, "disconnectGatt addr=" + addr);
        if (TextUtils.isEmpty(addr)) {
            return;
        }
        BluetoothGatt bluetoothGatt = this.mBluetoothGatts.get(addr);
        try {
            if (bluetoothGatt != null && this.isConnected(addr)) {
                SDKLogger.d(true, "disconnectGatt.disconnect");
                bluetoothGatt.disconnect();
            }
        } catch (Exception e) {
            SDKLogger.d(true, "disconnectGatt.disconnect e = " + e.getMessage());
        }
    }

    @SuppressLint("MissingPermission")
    public boolean readCharacteristic(String addr, BluetoothGattCharacteristic characteristic) {
        SDKLogger.d(true, "readCharacteristic addr=" + addr);
        if (TextUtils.isEmpty(addr)) {
            return false;
        }
        BluetoothGatt bluetoothGatt = this.mBluetoothGatts.get(addr);
        if (this.mBluetoothAdapter != null && bluetoothGatt != null) {
            SDKLogger.d(true, "raddr: " + addr);
            bluetoothGatt.readCharacteristic(characteristic);
            return true;
        } else {
            SDKLogger.d(true, "BluetoothAdapter not initialized or gatt is null");
            return false;
        }
    }

    @SuppressLint("MissingPermission")
    public boolean writeCharacteristic(String addr, BluetoothGattCharacteristic characteristic) {
        SDKLogger.d(true, "writeCharacteristic addr=" + addr);
        if (TextUtils.isEmpty(addr)) {
            return false;
        }
        if (this.mBluetoothAdapter != null && characteristic != null) {
            BluetoothGatt gatt = this.mBluetoothGatts.get(addr);
            if (gatt != null) {
                gatt.writeCharacteristic(characteristic);
            }
            return true;
        } else {
            SDKLogger.d(true, "BluetoothAdapter not initialized");
            return false;
        }
    }

    public boolean setCharacteristicNotificationSync(String addr, BluetoothGattCharacteristic characteristic, UUID descriptorUuid, boolean enabled) {
        SDKLogger.d(true, "addr:=" + addr + ", enabled=" + enabled);
        this.mGattCallbackCalled = false;
        if (!this.setCharacteristicNotification(addr, characteristic, descriptorUuid, enabled)) {
            return false;
        } else {
            SDKLogger.d(D,"AAAAA setCharacteristicNotificationSync synchronized");
            synchronized (this.mGattCallbackLock) {
                try {
                    if (!this.mGattCallbackCalled) {
                        SDKLogger.d(true, "wait for 3000ms");
                        this.mGattCallbackLock.wait(MAX_CALLBACK_LOCK_WAIT_TIME);
                        SDKLogger.d(true, "setCharacteristicNotificationSync wait time reached");
                    }
                } catch (InterruptedException var8) {
                    SDKLogger.d(true, "exception = " + var8.getMessage());
                }

                return true;
            }
        }
    }

    public boolean setCharacteristicNotification(String addr, BluetoothGattCharacteristic characteristic, boolean enabled) {
        return this.setCharacteristicNotificationSync(addr, characteristic, UUID.fromString(CLIENT_CHARACTERISTIC_CONFIG), enabled);
    }

    public boolean setEcgTestCharacteristicNotification(String addr, BluetoothGattCharacteristic characteristic, boolean enabled) {
        SDKLogger.d(D,"AAAAA setEcgTestCharacteristicNotification");
        return this.setCharacteristicNotificationSync(addr, characteristic, UUID.fromString(CLIENT_CHARACTERISTIC_CONFIG), enabled);
    }

    public boolean setEcgCharacteristicNotification(String addr, BluetoothGattCharacteristic characteristic, boolean enabled) {
        SDKLogger.d(D,"AAAAA setEcgCharacteristicNotification");
        return this.setCharacteristicNotificationSync(addr, characteristic, UUID.fromString(CLIENT_CHARACTERISTIC_CONFIG), enabled);
    }

    @SuppressLint("MissingPermission")
    public boolean
    setCharacteristicNotification(String addr, BluetoothGattCharacteristic characteristic, UUID descriptorUuid, boolean enabled) {
        if (this.mBluetoothAdapter == null) {
            SDKLogger.d(true, "BluetoothAdapter not initialized");
            return false;
        }
        if (TextUtils.isEmpty(addr)) {
            return false;
        }
        gatt = (BluetoothGatt) this.mBluetoothGatts.get(addr);
        if (gatt == null) {
            SDKLogger.d(true, "not found gatt, addr=" + addr);
            return false;
        } else {
            SDKLogger.d(true, "characteristic:=" + characteristic.getUuid() + ", enabled=" + enabled);
//                boolean flag = gatt.setCharacteristicNotification(characteristic, enabled);

//                try {
//                    Thread.sleep(500);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
            if (gatt.setCharacteristicNotification(characteristic, enabled)) {
                SDKLogger.d(true, "setCharacteristicNotification success ");

                BluetoothGattDescriptor descriptor = characteristic.getDescriptor(descriptorUuid);
                if (descriptor == null) {
                    SDKLogger.d(true, "descriptor not found, uuid=" + descriptorUuid.toString());
                    return false;
                } else {
                    boolean isSetValue = false;
                    if (enabled) {
                        isSetValue = descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    } else {
                        isSetValue = descriptor.setValue(BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
                    }

//                        gatt.writeDescriptor(descriptor);
                    SDKLogger.d(true, "AAAAA setCharacteristicNotification");
                    SDKLogger.d(true, "setCharacteristicNotification success isSetValue="+isSetValue+"\tisWrite="+gatt.writeDescriptor(descriptor));
                    return true;
                }
            } else {
                SDKLogger.d(true, "setCharacteristicNotification failed ");
                return false;
            }
        }
    }

    @SuppressLint("MissingPermission")
    public boolean setCharacteristicNotification2(String addr, BluetoothGattCharacteristic characteristic, boolean enabled) {
        if (this.mBluetoothAdapter == null) {
            SDKLogger.d(true, "BluetoothAdapter not initialized");
            return false;
        }
        if (TextUtils.isEmpty(addr)) {
            return false;
        }
        BluetoothGatt gatt = (BluetoothGatt) this.mBluetoothGatts.get(addr);
        if (gatt == null) {
            SDKLogger.d(true, "not found gatt, addr=" + addr);
            return false;
        } else {
            SDKLogger.d(true, "addr:=" + addr + ", enabled=" + enabled);
            gatt.setCharacteristicNotification(characteristic, enabled);
            return true;
        }
    }

    public boolean readCharacteristicSync(String addr, BluetoothGattCharacteristic characteristic) {
        SDKLogger.d(true, "readCharacteristicSync");
        this.mGattCallbackCalled = false;
        if (!this.readCharacteristic(addr, characteristic)) {
            return false;
        } else {
            synchronized (this.mGattCallbackLock) {
                try {
                    if (!this.mGattCallbackCalled) {
                        SDKLogger.d(true, "wait for 3000ms");
                        this.mGattCallbackLock.wait(MAX_CALLBACK_LOCK_WAIT_TIME);
                        SDKLogger.d(true, "readCharacteristicSync wait time reached");
                    }
                } catch (InterruptedException var6) {
                    SDKLogger.d(true, var6.toString());
                }

                return true;
            }
        }
    }

    public boolean writeCharacteristicSync(String addr, BluetoothGattCharacteristic characteristic) {
        SDKLogger.d(true, "addr=" + addr);
        this.mGattCallbackCalled = false;
        if (!this.writeCharacteristic(addr, characteristic)) {
            return false;
        } else {
            synchronized (this.mGattCallbackLock) {
                try {
                    if (!this.mGattCallbackCalled) {
                        SDKLogger.d(true, "wait for 3000ms");
                        this.mGattCallbackLock.wait(MAX_CALLBACK_LOCK_WAIT_TIME);
                        SDKLogger.d(true, "writeCharacteristicSync wait time reached");
                    }
                } catch (InterruptedException var6) {
                    SDKLogger.d(true, var6.toString());
                }

                return true;
            }
        }
    }

    public CopyOnWriteArrayList<String> getBluetoothDeviceAddresss() {
        return this.mBluetoothDeviceAddress;
    }

    public List<BluetoothGattService> getSupportedGattServices(String addr) {
        if (TextUtils.isEmpty(addr)) {
            return null;
        }
        return this.mBluetoothGatts.get(addr) == null ? null : ((BluetoothGatt) this.mBluetoothGatts.get(addr)).getServices();
    }

    public BluetoothGatt getBluetoothGatt(String addr) {
        if (TextUtils.isEmpty(addr)) {
            return null;
        }
        return (BluetoothGatt) this.mBluetoothGatts.get(addr);
    }

    public ArrayList<BluetoothDevice> getConnectDevices() {
        ArrayList<BluetoothDevice> devices = new ArrayList();
        Iterator var2 = this.mBluetoothDeviceAddress.iterator();

        while (var2.hasNext()) {
            String addr = (String) var2.next();
            if (this.isConnected(addr)) {
                devices.add(this.getBluetoothGatt(addr).getDevice());
            }
        }

        return devices;
    }

    @SuppressLint("MissingPermission")
    public String getDeviceName(String addr) {
        if (TextUtils.isEmpty(addr)) {
            return null;
        }
        BluetoothGatt bluetoothGatt = (BluetoothGatt) this.mBluetoothGatts.get(addr);
        if (bluetoothGatt == null) {
            SDKLogger.d(true, "no bluetoothGatt exist, addr=" + addr);
            return null;
        } else {
            return bluetoothGatt.getDevice().getName();
        }
    }

    public BluetoothAdapter getBluetoothAdapter() {
        return this.mBluetoothAdapter;
    }

    public ArrayList<BluetoothGattCallback> getCallback(String addr) {
        return (ArrayList) this.mCallbacks.get(addr);
    }

    public void registerCallback(String addr, BluetoothGattCallback callback) {
        SDKLogger.d(true, "find no BluetoothGattCallback, addr: " + addr);
        ArrayList c;
        Iterator key;
        if (this.mCallbacks.get(addr) == null) {
            SDKLogger.d(true, "find no BluetoothGattCallback, addr: " + addr);
            c = new ArrayList();
            c.add(callback);
            this.mCallbacks.put(addr, c);
            SDKLogger.d(true, "mCallbacks.get(addr) = " + this.mCallbacks.get(addr) + ". mCallbacks.size(): " + this.mCallbacks.size() + ", addr: " + addr);
            key = this.mCallbacks.keySet().iterator();

//            while (key.hasNext()) {
//                SDKLogger.d(true, "mCallbacks list: " + key.next());
//            }

        } else {
            if (!((ArrayList) this.mCallbacks.get(addr)).contains(callback)) {
                c = (ArrayList) this.mCallbacks.get(addr);
                c.add(callback);
                this.mCallbacks.put(addr, c);
                SDKLogger.d(true, "mCallbacks.get(addr).contains(callback). mCallbacks.size(): " + this.mCallbacks.size() + ", addr: " + addr);
                key = this.mCallbacks.keySet().iterator();

//                while (key.hasNext()) {
//                    SDKLogger.d(true, "mCallbacks list: " + key.next());
//                }
            } else {
                SDKLogger.d(true, "GlobalGatt2 registerCallback fail addr:" + addr);
            }
        }
    }

    public void unRegisterCallback(String addr, BluetoothGattCallback callback) {
        SDKLogger.d(true, "unRegisterCallback addr: " + addr);
        if (this.mCallbacks.get(addr) == null) {
            SDKLogger.d(true, "mCallbacks.get(addr) == null");
        } else {
            if (!TextUtils.isEmpty(addr)) {
                if (((ArrayList) this.mCallbacks.get(addr)).contains(callback)) {
                    SDKLogger.d(true, "unregister a callback");
                    ArrayList<BluetoothGattCallback> c = (ArrayList) this.mCallbacks.get(addr);
                    if (null != c && c.size() > 0 && null != callback) {
                        c.remove(callback);
                        this.mCallbacks.put(addr, c);
                    }
                }
            }

        }
    }

    public void unRegisterAllCallback(String addr) {
        SDKLogger.d(true, "unRegisterAllCallback addr: " + addr);
        if (this.mCallbacks.get(addr) == null) {
            SDKLogger.d(true, "mCallbacks.get(addr) == null");
        } else {
            this.mCallbacks.remove(addr);
        }
    }

    public static void startFetch(BluetoothDevice device) { // Need to use reflection prior to API 15
        Class cl = null;
        try {
            cl = Class.forName("android.bluetooth.BluetoothDevice");
        } catch (ClassNotFoundException exc) {
            SDKLogger.d(true, "android.bluetooth.BluetoothDevice not found.");
        }
        if (null != cl) {
            Class[] param = {};
            Method method = null;
            try {
                method = cl.getMethod("fetchUuidsWithSdp", param);
            } catch (NoSuchMethodException exc) {
                SDKLogger.d(true, "fetchUuidsWithSdp not found.");
            }
            if (null != method) {
                Object[] args = {};
                try {
                    method.invoke(device, args);
                    SDKLogger.d(true,"startFetch invoke");
                } catch (Exception exc) {
                    SDKLogger.d(true, "Failed to invoke fetchUuidsWithSdp method.");
                }
            }
        }
    }

    public static void startFetch1( BluetoothDevice device ) {
        // Need to use reflection prior to API 15
        Class cl = null;
        try {
            cl = Class.forName("android.bluetooth.BluetoothDevice");
        } catch( ClassNotFoundException exc ) {
            SDKLogger.d(true, "android.bluetooth.BluetoothDevice not found." );
        }
        if (null != cl) {
            Class[] param = {}; Method method = null;
            try {
                method = cl.getMethod("fetchUuidsWithSdp", param);
            } catch( NoSuchMethodException exc ) {
                SDKLogger.d(true, "fetchUuidsWithSdp not found." );
            }
            if (null != method) {
                Object[] args = {};
                try {
                    method.invoke(device, args);
                } catch (Exception exc) {
                    SDKLogger.d(true, "Failed to invoke fetchUuidsWithSdp method." );
                }
            }
        }
    }

    @SuppressWarnings("ConstantConditions")
    public boolean refreshDeviceCache(BluetoothGatt mBluetoothGatt) {
        SDKLogger.d(D,"断开连接后开始清除ble缓存");
        if (mBluetoothGatt != null) {
            try {
                //                Method localMethod = localBluetoothGatt.getClass().getMethod("refresh", new Class[0]);
                Method localMethod = mBluetoothGatt.getClass().getMethod("refresh");
                if (localMethod != null) {
//                    boolean bool = ((Boolean) localMethod.invoke(localBluetoothGatt, new Object[0])).booleanValue();
                    boolean bool = (boolean) localMethod.invoke(mBluetoothGatt);
                    SDKLogger.d(D,"调用清除缓存方法：bool=" + bool);
                    return bool;
                }else{
                    SDKLogger.d(D,"调用清除缓存方法：localMethod=null");
                }
            } catch (Exception localException) {
                localException.printStackTrace();
                SDKLogger.d(D, "An exception occured while refreshing device");
            }
        }else{
            SDKLogger.d(D,"mBluetoothGatt = null");
        }
        return false;
    }

    public BluetoothGattCallback callback1 = new BluetoothGattCallback() {
        @Override
        public void onPhyUpdate(BluetoothGatt gatt, int txPhy, int rxPhy, int status) {
            super.onPhyUpdate(gatt, txPhy, rxPhy, status);
            SDKLogger.d(true, "onPhyUpdate.txPhy=" + txPhy + "\trxPhy=" + rxPhy + "\tstatus=" + status);
        }

        @Override
        public void onPhyRead(BluetoothGatt gatt, int txPhy, int rxPhy, int status) {
            super.onPhyRead(gatt, txPhy, rxPhy, status);
            SDKLogger.d(true, "onPhyRead.txPhy=" + txPhy + "\trxPhy=" + rxPhy + "\tstatus=" + status);
        }

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            SDKLogger.d(D,"AAAAA onConnectionStateChange status " + status + ", newState = " + newState);
            String addr = gatt.getDevice().getAddress();
            SDKLogger.d(true, "GlobalGatt2 onConnectionStateChange.addr=" + addr + "\tstatus=" + status + "\nnewState=" + newState);
            if (status == 0 && newState == 2) {
                SDKLogger.d(true, "Connected to GATT server.");
                GlobalGatt2.this.mConnectionState.put(addr, 2);
                GlobalGatt2.this.mBluetoothGatts.put(addr, gatt);
            } else if (status == 133 || status == 257 || status == 129 || status == 22) {

//                if(null != mBluetoothAdapter){
//                    mBluetoothAdapter.disable();
//                    try {
//                        Thread.sleep(2500);
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//                    mBluetoothAdapter.enable();
//                }
                if (null != GattLayer.instance) {
                    BluetoothDevice device = gatt.getDevice();
                    refreshDeviceCache(gatt);
                    if(null != device){
                        startFetch(device);
                        SDKLogger.d(true,"refresh device");
                    }else{
                        SDKLogger.d(true,"device == null");
                    }
                    closeAll();
                    try {
                        Thread.sleep(500);
                    } catch (Exception e){
                        e.printStackTrace();
                    }
                    // 自动重连
                    GattLayer.instance.reConnect(addr);
                    GlobalGatt2.this.mConnectionState.put(addr, 0);
                }
            } else {
                SDKLogger.d(true, "Disconnected from GATT server.");
                refreshDeviceCache(gatt);
                GlobalGatt2.this.mConnectionState.put(addr, 0);
            }

            // 133 等错误会提前移除回调
            if (null != mCallbacks && !mCallbacks.isEmpty()) {
                if(mCallbacks.containsKey(addr)) {
                    Iterator var5 = ((ArrayList) GlobalGatt2.this.mCallbacks.get(addr)).iterator();

                    if (null != var5) {
                        while (var5.hasNext()) {
                            BluetoothGattCallback callback = (BluetoothGattCallback) var5.next();
                            if (null != callback)
                                callback.onConnectionStateChange(gatt, status, newState);
                        }
                    }
                }
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);
            SDKLogger.d(true, "OnServicesDiscovered.status=" + status);
            String addr = gatt.getDevice().getAddress();
            Iterator var4 = ((ArrayList) GlobalGatt2.this.mCallbacks.get(addr)).iterator();

            while (var4.hasNext()) {
                BluetoothGattCallback callback = (BluetoothGattCallback) var4.next();
                if (null != callback) {
                    callback.onServicesDiscovered(gatt, status);
                } else {
                    SDKLogger.d(true, "OnServicesDiscovered callback=null address=" + addr);
                }
            }
//            if(null != mCallbacks && mCallbacks.size() > 0) {
//            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicRead(gatt, characteristic, status);
            SDKLogger.d(true, "onCharacteristicRead.status=" + status);
            String addr = gatt.getDevice().getAddress();
//            SDKLogger.d(String.format("onCharacteristicRead %d-%s << %s", status, GattError.parse(status), DataConverter.bytes2Hex(characteristic.getValue())));
            synchronized (GlobalGatt2.this.mGattCallbackLock) {
                GlobalGatt2.this.mGattCallbackCalled = true;
                GlobalGatt2.this.mGattCallbackLock.notifyAll();
            }

            Iterator var5 = ((ArrayList) GlobalGatt2.this.mCallbacks.get(addr)).iterator();

            while (var5.hasNext()) {
                BluetoothGattCallback callback = (BluetoothGattCallback) var5.next();
                callback.onCharacteristicRead(gatt, characteristic, status);
            }
//            if(null != mCallbacks && mCallbacks.size() > 0) {
//            }
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);
            SDKLogger.d(true, "onCharacteristicWrite.status=" + status);
            String addr = gatt.getDevice().getAddress();
//            SDKLogger.d(String.format("onCharacteristicWrite %d-%s << %s", status, GattError.parse(status), DataConverter.bytes2Hex(characteristic.getValue())));
            synchronized (GlobalGatt2.this.mGattCallbackLock) {
                GlobalGatt2.this.mGattCallbackCalled = true;
                GlobalGatt2.this.mGattCallbackLock.notifyAll();
            }

            Iterator var5 = ((ArrayList) GlobalGatt2.this.mCallbacks.get(addr)).iterator();

            while (var5.hasNext()) {
                BluetoothGattCallback callback = (BluetoothGattCallback) var5.next();
                callback.onCharacteristicWrite(gatt, characteristic, status);
            }
//            if(null != mCallbacks && mCallbacks.size() > 0) {
//            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);
//            SDKLogger.d(true, "onCharacteristicChanged.");
            String addr = gatt.getDevice().getAddress();
//            SDKLogger.d(String.format("onCharacteristicChanged << %s", DataConverter.bytes2Hex(characteristic.getValue())));
            Iterator var4 = ((ArrayList) GlobalGatt2.this.mCallbacks.get(addr)).iterator();

            while (var4.hasNext()) {
                BluetoothGattCallback callback = (BluetoothGattCallback) var4.next();
                callback.onCharacteristicChanged(gatt, characteristic);
            }
//            if(null != mCallbacks && mCallbacks.size() > 0) {
//            }
        }

        @Override
        public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorRead(gatt, descriptor, status);
            SDKLogger.d(true, "onDescriptorRead.status=" + status);
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorWrite(gatt, descriptor, status);
            SDKLogger.d(D,"AAAAA onDescriptorWrite status " + status);
            SDKLogger.d(true, "onDescriptorWrite.status=" + status);
            String addr = gatt.getDevice().getAddress();
            synchronized (GlobalGatt2.this.mGattCallbackLock) {
                GlobalGatt2.this.mGattCallbackCalled = true;
                GlobalGatt2.this.mGattCallbackLock.notifyAll();
            }

            Iterator var5 = ((ArrayList) GlobalGatt2.this.mCallbacks.get(addr)).iterator();

            while (var5.hasNext()) {
                BluetoothGattCallback callback = (BluetoothGattCallback) var5.next();
                callback.onDescriptorWrite(gatt, descriptor, status);
            }
//            if(null != mCallbacks && mCallbacks.size() > 0) {
//            }
        }

        @Override
        public void onReliableWriteCompleted(BluetoothGatt gatt, int status) {
            super.onReliableWriteCompleted(gatt, status);
            SDKLogger.d(true, "onReliableWriteCompleted.status=" + status);
        }

        @Override
        public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
            super.onReadRemoteRssi(gatt, rssi, status);
            SDKLogger.d(true, "onReadRemoteRssi.status=" + status + "\trssi=" + rssi);
        }

        @SuppressLint("NewApi")
        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            super.onMtuChanged(gatt, mtu, status);
            SDKLogger.d(true, "onMtuChanged.status=" + status + "\tmtu=" + mtu);
            String addr = gatt.getDevice().getAddress();
            Iterator var5 = ((ArrayList) GlobalGatt2.this.mCallbacks.get(addr)).iterator();

            while (var5.hasNext()) {
                BluetoothGattCallback callback = (BluetoothGattCallback) var5.next();
                callback.onMtuChanged(gatt, mtu, status);
            }
//            if(null != mCallbacks && mCallbacks.size() > 0) {
//            }
        }
    };
//    @TargetApi(29)
//    public class GattCallback extends BluetoothGattCallback {
//        private GattCallback() {
//
//        }
//
//        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
//            SDKLogger.d(true, "new mtu is " + mtu + ", status is " + status);
//            String addr = gatt.getDevice().getAddress();
//            Iterator var5 = ((ArrayList) GlobalGatt2.this.mCallbacks.get(addr)).iterator();
//
//            while (var5.hasNext()) {
//                BluetoothGattCallback callback = (BluetoothGattCallback) var5.next();
//                callback.onMtuChanged(gatt, mtu, status);
//            }
//
//        }
//
//        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
////            SDKLogger.d(true, String.format("%d-%s >> %s", status, GattError.parseConnectionError(status), newState));
//            String addr = gatt.getDevice().getAddress();
//            SDKLogger.d(true, "onConnectionStateChange addr="+addr+"\tstatus="+status+"\nnewState="+newState);
//            if (status == 0 && newState == 2) {
//                SDKLogger.d(true, "Connected to GATT server.");
//                GlobalGatt2.this.mConnectionState.put(addr, 2);
//                GlobalGatt2.this.mBluetoothGatts.put(addr, gatt);
//            } else {
//                SDKLogger.d(true, "Disconnected from GATT server.");
//                GlobalGatt2.this.mConnectionState.put(addr, 0);
//            }
//
//            Iterator var5 = ((ArrayList) GlobalGatt2.this.mCallbacks.get(addr)).iterator();
//
//            while (var5.hasNext()) {
//                BluetoothGattCallback callback = (BluetoothGattCallback) var5.next();
//                callback.onConnectionStateChange(gatt, status, newState);
//            }
//
//        }
//
//        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
//            SDKLogger.d(true, "onServicesDiscovered  status is " + status);
//
//            String addr = gatt.getDevice().getAddress();
//            Iterator var4 = ((ArrayList) GlobalGatt2.this.mCallbacks.get(addr)).iterator();
//
//            while (var4.hasNext()) {
//                BluetoothGattCallback callback = (BluetoothGattCallback) var4.next();
//                callback.onServicesDiscovered(gatt, status);
//            }
//
//        }
//
//        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
//            String addr = gatt.getDevice().getAddress();
//            SDKLogger.d(String.format("onCharacteristicRead %d-%s << %s", status, GattError.parse(status), DataConverter.bytes2Hex(characteristic.getValue())));
//            synchronized (GlobalGatt2.this.mGattCallbackLock) {
//                GlobalGatt2.this.mGattCallbackCalled = true;
//                GlobalGatt2.this.mGattCallbackLock.notifyAll();
//            }
//
//            Iterator var5 = ((ArrayList) GlobalGatt2.this.mCallbacks.get(addr)).iterator();
//
//            while (var5.hasNext()) {
//                BluetoothGattCallback callback = (BluetoothGattCallback) var5.next();
//                callback.onCharacteristicRead(gatt, characteristic, status);
//            }
//
//        }
//
//        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
//            String addr = gatt.getDevice().getAddress();
//            SDKLogger.d(String.format("onCharacteristicChanged << %s", DataConverter.bytes2Hex(characteristic.getValue())));
//            Iterator var4 = ((ArrayList) GlobalGatt2.this.mCallbacks.get(addr)).iterator();
//
//            while (var4.hasNext()) {
//                BluetoothGattCallback callback = (BluetoothGattCallback) var4.next();
//                callback.onCharacteristicChanged(gatt, characteristic);
//            }
//
//        }
//
//        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
//            SDKLogger.d(true, "onDescriptorWrite  status is " + status);
//
//            String addr = gatt.getDevice().getAddress();
//            synchronized (GlobalGatt2.this.mGattCallbackLock) {
//                GlobalGatt2.this.mGattCallbackCalled = true;
//                GlobalGatt2.this.mGattCallbackLock.notifyAll();
//            }
//
//            Iterator var5 = ((ArrayList) GlobalGatt2.this.mCallbacks.get(addr)).iterator();
//
//            while (var5.hasNext()) {
//                BluetoothGattCallback callback = (BluetoothGattCallback) var5.next();
//                callback.onDescriptorWrite(gatt, descriptor, status);
//            }
//
//        }
//
//        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
//            String addr = gatt.getDevice().getAddress();
//            SDKLogger.d(String.format("onCharacteristicWrite %d-%s << %s", status, GattError.parse(status), DataConverter.bytes2Hex(characteristic.getValue())));
//            synchronized (GlobalGatt2.this.mGattCallbackLock) {
//                GlobalGatt2.this.mGattCallbackCalled = true;
//                GlobalGatt2.this.mGattCallbackLock.notifyAll();
//            }
//
//            Iterator var5 = ((ArrayList) GlobalGatt2.this.mCallbacks.get(addr)).iterator();
//
//            while (var5.hasNext()) {
//                BluetoothGattCallback callback = (BluetoothGattCallback) var5.next();
//                callback.onCharacteristicWrite(gatt, characteristic, status);
//            }
//
//        }
//    }
}
