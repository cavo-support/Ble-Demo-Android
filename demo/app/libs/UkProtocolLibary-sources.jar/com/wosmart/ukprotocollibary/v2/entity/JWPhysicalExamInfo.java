package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWPhysicalExamInfo extends JWHealthData implements Serializable {

    /**
     * 心率
     */
    public int heartRate;

    /**
     * 血氧
     */
    public int spo2;

    /**
     * 压力
     */
    public int pressure;

    /**
     * 体温
     */
    public float temperature;

    /**
     * 皮肤温度
     */
    public float skinTemperature;

    /**
     * 血管弹性
     */
    public int bloodVesselElasticity;

    /**
     * 心血管风险
     * 0 low risk 低风险
     * 1 medium risk 中风险
     * 2 high risk 高风险
     */
    public int cardiovascularRisk;


    @Override
    public String toString() {
        return "JWBodyFatInfo{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", heartRate=" + heartRate +
                ", spo2=" + spo2 +
                ", pressure=" + pressure +
                ", temperature=" + temperature +
                ", skinTemperature=" + skinTemperature +
                ", bloodVesselElasticity=" + bloodVesselElasticity +
                ", cardiovascularRisk=" + cardiovascularRisk +
                '}';
    }
}
