package com.wosmart.ukprotocollibary.v2.layer.handler.multiple;

import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodSugarCycleFunctionInfo;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.TempFunctionInfoListener;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

public class SupportBloodSugarCycleHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length < 7) {
            return;
        }
        TempFunctionInfoListener tempFunctionInfoListener = BaseManager.getInstance().getTempFunctionInfoListener();
        if (tempFunctionInfoListener != null) {
            JWBloodSugarCycleFunctionInfo functionInfo = new JWBloodSugarCycleFunctionInfo();

            functionInfo.enable = (data[0] == 0x01);

            int privateValue = ((data[1] & 0xff) << 8) | (data[2] & 0xff);
            functionInfo.privateValue = JWUtils.parserRound(1, privateValue / 10f);

            functionInfo.privateRtcTime = ((data[3] & 0xff)) | ((data[4] & 0xff) << 8) | ((data[5] & 0xff) << 16) | ((data[6] & 0xff) << 24);

            tempFunctionInfoListener.onSupportBloodSugarCycle(functionInfo);
        }
    }



}
