package com.wosmart.ukprotocollibary.v2.moudle.connector;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.os.Build;
import android.os.ParcelUuid;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.v2.BaseConstants;
import com.wosmart.ukprotocollibary.v2.JWScanCallback;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ScanManager {

    private final static UUID WRISTBAND_SERVICE_UUID = UUID.fromString("000001ff-3c17-d293-8e48-14fe2e4da212");
    private final static UUID FD50_SERVICE_UUID = UUID.fromString("0000fd50-0000-1000-8000-00805f9b34fb");// 涂鸦服务

    private final static UUID ZH_SERVICE_UUID = UUID.fromString("00000001-0000-1000-8000-00805f9b34fb");

    private final static UUID VEP_SERVICE_UUID = UUID.fromString("0000fee7-0000-1000-8000-00805f9b34fb");

    private BluetoothLeScanner scanner;

    private boolean isScanning;

    private BluetoothAdapter.LeScanCallback leScanCallback;

    private ScanCallback scanCallback;

    private JWScanCallback jwScanCallback;


    private static class ScanManagerHolder {
        private static final ScanManager scanManager = new ScanManager();
    }

    public static ScanManager getInstance() {
        return ScanManager.ScanManagerHolder.scanManager;
    }



    public void init(Context context) {
        if (null == leScanCallback) {
            leScanCallback = new BluetoothAdapter.LeScanCallback() {
                @Override
                public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {
                    if (!isScanning) {
                        return;
                    }

                    if (null != jwScanCallback) {
                        jwScanCallback.onDeviceFound(device, rssi, scanRecord);
                    }
                }
            };
        }
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (null == scanCallback) {
                scanCallback = new ScanCallback() {
                    @Override
                    public void onScanResult(int callbackType, ScanResult result) {
                        super.onScanResult(callbackType, result);
                        if (!isScanning) {
                            return;
                        }
                        if (null != jwScanCallback) {
                            jwScanCallback.onDeviceFound(result.getDevice(), result.getRssi(), result.getScanRecord());
                        }
                    }

                    @Override
                    public void onScanFailed(int errorCode) {
                        super.onScanFailed(errorCode);

                        if (null != jwScanCallback) {
                            jwScanCallback.onScanStopped();
                        }
                    }
                };
            }
        }
    }

    public void scanDevice(final JWScanCallback jwScanCallback) {
        if (jwScanCallback == null) {
            return;
        }
        if (!BaseManager.getInstance().isInited()) {
            jwScanCallback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "SDK not initialized");
            return;
        }
        BluetoothAdapter bluetoothAdapter = BaseManager.getInstance().getBluetoothAdapter();
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            jwScanCallback.onError(BaseConstants.ERR_BLUETOOTH_UN_ENABLE, "please check bluetooth enable");
            return;
        }
        this.jwScanCallback = jwScanCallback;

        if (isScanning) {
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                if (null != scanner) {
                    scanner.stopScan(scanCallback);
                }
            } else {
                bluetoothAdapter.stopLeScan(leScanCallback);
            }
        }

        boolean isDeepFit = TextUtils.equals(BaseManager.getInstance().getContext().getPackageName(), "com.hl.deepfit");

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (null == scanner) {
                scanner = bluetoothAdapter.getBluetoothLeScanner();
            }
            ScanSettings scanSettings = new ScanSettings.Builder()
                    //前台设置扫描模式为低时延
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .build();
            //过滤扫描蓝牙设备的主服务
            List<ScanFilter> scanFilters = new ArrayList<>();
            //uk
            scanFilters.add(new ScanFilter.Builder()
                    .setServiceUuid(ParcelUuid.fromString(WRISTBAND_SERVICE_UUID.toString()))
                    .build());
            scanFilters.add(new ScanFilter.Builder()
                    .setServiceUuid(ParcelUuid.fromString(FD50_SERVICE_UUID.toString()))
                    .build());
            //zh
            scanFilters.add(new ScanFilter.Builder()
                    .setServiceUuid(ParcelUuid.fromString(ZH_SERVICE_UUID.toString()))
                    .build());

            if (!isDeepFit) {
                //vep
                scanFilters.add(new ScanFilter.Builder()
                        .setServiceUuid(ParcelUuid.fromString(VEP_SERVICE_UUID.toString()))
                        .build());
            }
            scanner.startScan(scanFilters, scanSettings, scanCallback);

            isScanning = true;

            jwScanCallback.onScanStarted();
        } else {
            //通过特定的service UUID搜索设备
            UUID[] serviceUUIDs;
            if (isDeepFit) {
                serviceUUIDs = new UUID[]{WRISTBAND_SERVICE_UUID, FD50_SERVICE_UUID, ZH_SERVICE_UUID};
            } else {
                serviceUUIDs = new UUID[]{WRISTBAND_SERVICE_UUID, FD50_SERVICE_UUID, ZH_SERVICE_UUID, VEP_SERVICE_UUID};
            }
            isScanning = bluetoothAdapter.startLeScan(serviceUUIDs, leScanCallback);

            if (isScanning) {
                jwScanCallback.onScanStarted();
            } else {
                jwScanCallback.onScanStopped();
            }

        }
    }

    public void stopScan() {
        if (!BaseManager.getInstance().isInited()) {
            return;
        }
        BluetoothAdapter bluetoothAdapter = BaseManager.getInstance().getBluetoothAdapter();
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            return;
        }
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (null != scanner) {
                scanner.stopScan(scanCallback);
            }
        } else {
            bluetoothAdapter.stopLeScan(leScanCallback);
        }

        isScanning = false;
    }

}
