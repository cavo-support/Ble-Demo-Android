package com.wosmart.ukprotocollibary.v2.common.logger;

import static com.wosmart.ukprotocollibary.v2.common.logger.Utils.checkNotNull;


/**
 * <pre>
 *  ┌────────────────────────────────────────────
 *  │ LOGGER
 *  ├┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄
 *  │ Standard logging mechanism
 *  ├┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄
 *  │ But more pretty, simple and powerful
 *  └────────────────────────────────────────────
 * </pre>
 *
 * <h3>How to use it</h3>
 * Initialize it first
 * <pre><code>
 *   Logger.addLogAdapter(new AndroidLogAdapter());
 * </code></pre>
 * <p>
 * And use the appropriate static Logger methods.
 *
 * <pre><code>
 *   Logger.d("debug");
 *   Logger.e("error");
 *   Logger.w("warning");
 *   Logger.v("verbose");
 *   Logger.i("information");
 *   Logger.wtf("What a Terrible Failure");
 * </code></pre>
 *
 * <h3>String format arguments are supported</h3>
 * <pre><code>
 *   Logger.d("hello %s", "world");
 * </code></pre>
 *
 * <h3>Collections are support ed(only available for debug logs)</h3>
 * <pre><code>
 *   Logger.d(MAP);
 *   Logger.d(SET);
 *   Logger.d(LIST);
 *   Logger.d(ARRAY);
 * </code></pre>
 *
 * <h3>Json and Xml support (output will be in debug level)</h3>
 * <pre><code>
 *   Logger.json(JSON_CONTENT);
 *   Logger.xml(XML_CONTENT);
 * </code></pre>
 *
 * <h3>Customize Logger</h3>
 * Based on your needs, you can change the following settings:
 * <ul>
 *   <li>Different {@link LogAdapter}</li>
 *   <li>Different {@link FormatStrategy}</li>
 *   <li>Different {@link LogStrategy}</li>
 * </ul>
 *
 * @see LogAdapter
 * @see FormatStrategy
 * @see LogStrategy
 */
public final class JWLogger {

    public static final int LOG_TYPE_SDK = 0;
    public static final int LOG_TYPE_APP = 1;

    public static final int VERBOSE = 1;
    public static final int DEBUG = 2;
    public static final int INFO = 3;
    public static final int WARN = 4;
    public static final int ERROR = 5;
    public static final int ASSERT = 6;

    private static Printer printer = new LoggerPrinter();

    private JWLogger() {
        //no instance
    }

    public static void printer(Printer printer) {
        JWLogger.printer = checkNotNull(printer);
    }

    public static void addLogAdapter(int logType, LogAdapter adapter) {
        printer.addAdapter(logType, checkNotNull(adapter));
    }


    public static void clearLogAdapters(int logType) {
        printer.clearLogAdapters(logType);
    }

    /**
     * General log function that accepts all configurations as parameter
     */
    public static void log(int logType, int priority, String tag, String message, Throwable throwable) {
        printer.log(logType, priority, tag, message, throwable);
    }

    public static void json(int logType, String json) {
        printer.json(logType, json);
    }

    public static void xml(int logType, String json) {
        printer.xml(logType, json);
    }
}
