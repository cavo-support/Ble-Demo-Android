package com.wosmart.ukprotocollibary.v2.entity.function;

import java.io.Serializable;

public class JWHealthRiskAssessmentInfo implements Serializable {

    /**
     * true open blood sugar risk assessment
     */
    public boolean bloodSugarEnable = false;

    /**
     * true open uric acid risk assessment
     */
    public boolean uricAcidEnable = false;

    /**
     * true open blood fat risk assessment
     */
    public boolean bloodFatEnable = false;

    @Override
    public String toString() {
        return "JWHealthRiskAssessmentInfo{" +
                ", bloodSugarEnable=" + bloodSugarEnable +
                ", uricAcidEnable=" + uricAcidEnable +
                ", bloodFatEnable=" + bloodFatEnable +
                '}';
    }
}
