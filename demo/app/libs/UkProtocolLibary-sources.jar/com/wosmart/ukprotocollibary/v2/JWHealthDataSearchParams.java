package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.JWHealthData;

public class JWHealthDataSearchParams {

    private JWHealthData.DateType dataType;
    private String userID;
    private String deviceMac;
    private int count;
    private long timeBegin;
    private long timePeriod;

    /**
     * data type
     *
     * @param dataType {@link JWHealthData.DateType}
     */
    public void setDataType(JWHealthData.DateType dataType) {
        this.dataType = dataType;
    }

    public JWHealthData.DateType getDataType() {
        return this.dataType;
    }

    public String getUserID() {
        return userID;
    }

    /**
     * if you have multiple devices, you can distinguish by user ID
     * 如果你有多个设备，可以通过 ID 来区分
     *
     * @param userID default is null, means get all
     */
    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getDeviceMac() {
        return deviceMac;
    }

    /**
     * if you have multiple devices, you can distinguish by mac address
     * 如果你有多个设备，可以通过 设备 mac address 来区分
     *
     * @param deviceMac default is null, means get all
     */
    public void setDeviceMac(String deviceMac) {
        this.deviceMac = deviceMac;
    }

    public int getCount() {
        return count;
    }

    /**
     * count of get data
     * 获取数据总数
     *
     * @param count default is 0, means get all
     *              默认为 0，即获取所有
     */
    public void setCount(int count) {
        this.count = count;
    }

    public long getTimeBegin() {
        return timeBegin;
    }

    /**
     * begin of time, unit: millisecond
     * 开始时间，单位毫秒
     *
     * @param timeBegin the starting point of the time range, default is 0, means get from now on
     *                  开始时间，默认为 0，即从现在开始查询
     */
    public void setTimeBegin(long timeBegin) {
        this.timeBegin = timeBegin;
    }

    public long getTimePeriod() {
        return timePeriod;
    }

    /**
     * period of time, unit: millisecond, 24x60x60x1000 means one day
     * 时间周期，单位毫秒
     *
     * @param timePeriod period of time, default is 0, means unlimited time range
     *                   时间周期，默认为 0，即不限制范围
     */
    public void setTimePeriod(long timePeriod) {
        this.timePeriod = timePeriod;
    }
}
