package com.wosmart.ukprotocollibary.v2;

/**
 * 配置各项数据是否存储
 * Configure whether each data is stored
 */
public class JWDBConfig {

    /**
     * 血脂
     */
    public boolean bloodFatStorage = true;

    /**
     * 血压
     */
    public boolean bloodPressureStorage = true;

    /**
     * 血糖
     */
    public boolean bloodSugarStorage = true;

    /**
     * 血糖周期
     */
    public boolean bloodSugarCycleStorage = true;

    /**
     * 心率 1.0
     * heart rate 1.0
     */
    public boolean hrpStorage = true;

    /**
     * 心率 2.0
     */
    public boolean heartRateStorage = true;

    /**
     * 心率变异性
     */
    public boolean heartRateVariabilityStorage = true;

    /**
     * 脉冲
     */
    public boolean pulseStorage = true;

    /**
     * 桑拿
     */
    public boolean saunaStorage = true;

    /**
     * 睡眠 1.0
     */
    public boolean sleep1Storage = true;

    /**
     * 睡眠 2.0
     */
    public boolean sleep2Storage = true;

    /**
     * 血氧
     */
    public boolean spo2Storage = true;

    /**
     * 运动
     */
    public boolean sportStorage = true;

    /**
     * 步数 1.0
     */
    public boolean step1Storage = true;

    /**
     * 步数 2.0
     */
    public boolean step2Storage = true;

    /**
     * 温度
     */
    public boolean temperatureStorage = true;

    /**
     * 尿酸
     */
    public boolean uricAcidStorage = true;

    /**
     * 穿戴时间
     */
    public boolean wearingTimeStorage = true;

}
