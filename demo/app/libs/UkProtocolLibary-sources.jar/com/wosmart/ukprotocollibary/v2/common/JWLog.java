package com.wosmart.ukprotocollibary.v2.common;

import android.text.TextUtils;
import android.util.Log;


public class JWLog {

    private static final String TAG = JWLog.class.getSimpleName();

    public static final int LOG_LEVEL_OFF = 0;
    public static final int LOG_LEVEL_VERBOSE = 2;
    public static final int LOG_LEVEL_DEBUG = 3;
    public static final int LOG_LEVEL_INFO = 4;
    public static final int LOG_LEVEL_WARN = 5;
    public static final int LOG_LEVEL_ERROR = 6;

    /**
     * 打印INFO级别日志
     *
     * @param strTag  TAG
     * @param strInfo 消息
     */
    public static void v(String strTag, String strInfo) {
        log(LOG_LEVEL_VERBOSE, strTag, strInfo);
    }

    /**
     * 打印DEBUG级别日志
     *
     * @param strTag  TAG
     * @param strInfo 消息
     */
    public static void d(String strTag, String strInfo) {
        log(LOG_LEVEL_DEBUG, strTag, strInfo);
    }

    /**
     * 打印INFO级别日志
     *
     * @param strTag  TAG
     * @param strInfo 消息
     */
    public static void i(String strTag, String strInfo) {
        log(LOG_LEVEL_INFO, strTag, strInfo);
    }

    /**
     * 打印WARN级别日志
     *
     * @param strTag  TAG
     * @param strInfo 消息
     */
    public static void w(String strTag, String strInfo) {
        log(LOG_LEVEL_WARN, strTag, strInfo);
    }

    /**
     * 打印ERROR级别日志
     *
     * @param strTag  TAG
     * @param strInfo 消息
     */
    public static void e(String strTag, String strInfo) {
        log(LOG_LEVEL_ERROR, strTag, strInfo);
    }

    private static void log(int logLevel, String strTag, String strInfo) {
        if (logLevel < LOG_LEVEL_OFF || logLevel > LOG_LEVEL_ERROR) {
            JWLog.e(TAG, "invalid logLevel： " + logLevel);
            return;
        }

        if (TextUtils.isEmpty(strTag)) {
            JWLog.e(TAG, "empty logTag" );
            return;
        }

        if (TextUtils.isEmpty(strInfo)) {
            JWLog.e(TAG, "empty logContent");
            return;
        }

        String[] contents = wrapper(strTag, strInfo);
        String tag = contents[0];
        String msg = contents[1];
        String headString = contents[2];
        print(logLevel, tag, headString + msg);

        nativeWriteLog(logLevel, strTag, "", 0, strInfo);
    }


    protected static void nativeWriteLog(int level, String strTag, String funcName, int line, String logContent) {
//        Log.e(strTag, logContent);
    }

    private static void print(int level, String tag, String msg) {
        switch (level) {
            case LOG_LEVEL_VERBOSE:
                Log.v(tag, msg);
                break;
            case LOG_LEVEL_DEBUG:
                Log.d(tag, msg);
                break;
            case LOG_LEVEL_INFO:
                Log.i(tag, msg);
                break;
            case LOG_LEVEL_WARN:
                Log.w(tag, msg);
                break;
            case LOG_LEVEL_ERROR:
                Log.e(tag, msg);
                break;
        }
    }

    private static String[] wrapper(String tagStr, Object... objects) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        int index = 5;
        String className = stackTrace[index].getClassName();
        String[] classNameInfo = className.split("\\.");
        if (classNameInfo.length > 0) {
            className = classNameInfo[classNameInfo.length - 1] + ".java";
        }

        if (className.contains("$")) {
            className = className.split("\\$")[0] + ".java";
        }

        String methodName = stackTrace[index].getMethodName();
        int lineNumber = stackTrace[index].getLineNumber();
        if (lineNumber < 0) {
            lineNumber = 0;
        }

        String methodNameShort = methodName.substring(0, 1).toUpperCase() + methodName.substring(1);
        String tag = tagStr == null ? className : tagStr;
        if (TextUtils.isEmpty(tag)) {
            tag = "Realtek";
        }

        String msg = objects == null ? "" : getObjectsString(objects);
        StringBuilder sb = new StringBuilder();
        sb.append("[(").append(className).append(":").append(lineNumber).append(") #").append(methodNameShort).append("] ");
        String headString = sb.toString();
        return new String[]{tag, msg, headString};
    }

    private static String getObjectsString(Object... objects) {
        if (objects.length > 1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("\n");

            for (int i = 0; i < objects.length; ++i) {
                Object object = objects[i];
                if (object == null) {
                    stringBuilder.append("Param").append("[").append(i).append("]").append(" = ").append("null").append("\n");
                } else {
                    stringBuilder.append("Param").append("[").append(i).append("]").append(" = ").append(object.toString()).append("\n");
                }
            }

            return stringBuilder.toString();
        } else {
            Object object = objects[0];
            return object == null ? "null" : object.toString();
        }
    }

}
