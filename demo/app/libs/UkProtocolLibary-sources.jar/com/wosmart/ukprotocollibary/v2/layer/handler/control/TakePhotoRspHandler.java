package com.wosmart.ukprotocollibary.v2.layer.handler.control;

import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;

public class TakePhotoRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        TransportManager.getInstance().getFunctionListener().onTakePhoto();
    }

}
