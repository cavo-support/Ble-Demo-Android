package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import com.wosmart.ukprotocollibary.v2.common.JWBridge;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

import java.util.Collections;


public class HeartRateDataHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (TransportManager.getInstance().getSyncDataListener() == null) {
            return;
        }
        if (data == null || (data.length != 8 && data.length != 12)) {
            return;
        }

        int year = (data[0] & 0x7e) >> 1;
        int month = ((data[0] & 0x01) << 3) | (data[1] >> 5) & 0x07;
        int day = data[1] & 0x1f;
        int count = data[3] & 0xff;// 现在 count 已废弃, 只会有一条数据
        int minutes = 0;
        int second = 0;
        int value = 0;
        if (data.length == 8) {
            // 只有心率
            minutes = ((data[4] << 8) | (data[5] & 0xff)) & 0xffff;
            second = (data[6] & 0xff);
            value = (data[7] & 0xff);

            if (value == 0) {
                return;
            }

            long time = JWBridge.getTime(year, month, day);
            time += minutes * 60000;
            time += second * 1000;

            JWHeartRateInfo heartRateInfo = new JWHeartRateInfo();
            heartRateInfo.time = time;
            heartRateInfo.userID = BaseManager.getInstance().getUserID();
            heartRateInfo.deviceMac = BaseManager.getInstance().getMacAddress();
            heartRateInfo.value = value;

            TransportManager.getInstance().getSyncDataListener().onHeartRateDataReceived(Collections.singletonList(heartRateInfo));
            return;
        }
        // 心率和温度
        boolean animationStatus = ((data[5] >> 2) & 0x01) == 1;
        boolean adjustStatus = ((data[5] >> 1) & 0x01) == 1;
        boolean wearStatus = (data[5] & 0x01) == 1;

        float temperature = 0;
        int temp = ((data[6] << 8) | (data[7] & 0xff)) & 0xffff;
        if (temp > 0) {
            if (animationStatus) {
                temperature = JWUtils.parserRound(1, temp / 10f);
            } else {
                if (temp >= 368) {
                    temperature = JWUtils.parserRound(1, temp / 10f);
                } else {
                    //手动检测的 只保留一位小数
                    if (wearStatus && adjustStatus) {
                        int temp2 = 368 - (368 - temp) / 20;
                        temperature = JWUtils.parserRound(1, temp2 / 10f);
                    } else {
                        temperature = JWUtils.parserRound(1, temp / 10f);
                    }
                }
            }
        } else {
            temperature = 0f;
        }

        minutes = ((data[8] << 8) | (data[9] & 0xff)) & 0xffff;
        second = (data[10] & 0xff);
        value = (data[11] & 0xff);

        if (value == 0) {
            return;
        }
        long time = JWBridge.getTime(year, month, day);
        time += minutes * 60000L;
        time += second * 1000;

        JWHeartRateInfo heartRateInfo = new JWHeartRateInfo();
        heartRateInfo.time = time;
        heartRateInfo.userID = BaseManager.getInstance().getUserID();
        heartRateInfo.deviceMac = BaseManager.getInstance().getMacAddress();
        heartRateInfo.value = value;

        TransportManager.getInstance().getSyncDataListener().onHeartRateDataReceived(Collections.singletonList(heartRateInfo));

        if (temp == 0) {
            return;
        }
        JWTemperatureInfo temperatureInfo = new JWTemperatureInfo();
        temperatureInfo.time = time;
        temperatureInfo.userID = BaseManager.getInstance().getUserID();
        temperatureInfo.deviceMac = BaseManager.getInstance().getMacAddress();
        temperatureInfo.compensationStatus = adjustStatus;
        temperatureInfo.wearStatus = wearStatus;
        temperatureInfo.temperatureValue = JWUtils.parserRound(1, temperature / 10f);
        temperatureInfo.temperatureOriginValue = JWUtils.parserRound(1, temp / 10f);

        TransportManager.getInstance().getSyncDataListener().onTemperatureDataReceived(Collections.singletonList(temperatureInfo));
    }




}
