package com.wosmart.ukprotocollibary.v2.layer.handler.settings;

import android.util.SparseArray;

import com.wosmart.ukprotocollibary.v2.JWSettingsManager;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

public class DateFormatRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length > 0) {
            SparseArray<SendPacketCallback> callbackMap = TransportManager.getInstance().getCallbackMap();
            SendPacketCallback callback = callbackMap.get(CallbackKeyConstants.KEY_GET_DATE_FORMAT);
            if (callback != null) {
                callback.onResponse(data[0] == 0 ? JWSettingsManager.DATE_FORMAT_MM_DD : JWSettingsManager.DATE_FORMAT_DD_MM);
            }
        }
    }

}
