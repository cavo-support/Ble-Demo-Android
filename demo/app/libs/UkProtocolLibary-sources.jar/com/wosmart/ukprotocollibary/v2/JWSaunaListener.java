package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.JWHRMovementInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSaunaInfo;

import java.util.List;

public interface JWSaunaListener {

    /**
     * sync sauna data started
     */
    void onSyncDataStart(int totalCount);

    /**
     * sync sauna info received
     */
    void onSaunaDataReceived(List<JWSaunaInfo> saunaInfoList);

    /**
     * sync sauna data finished
     */
    void onSyncDataFinished();

    /**
     * sync hr movement info received
     */
    void onHRMovementDataReceived(List<JWHRMovementInfo> hrMovementInfoList);

}
