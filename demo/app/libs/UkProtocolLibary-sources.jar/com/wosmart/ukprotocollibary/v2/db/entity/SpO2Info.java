package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWSpO2Info;

public class SpO2Info extends BaseHealthDataInfo {

    public int curValue;

    public int lowValue;

    public int highValue;

    public SpO2Info(long time, String userID, String mac, int curValue, int lowValue, int highValue) {
        this.time = time;
        this.userID = userID;
        this.deviceMac = mac;
        this.curValue = curValue;
        this.lowValue = lowValue;
        this.highValue = highValue;
    }

    public SpO2Info(JWSpO2Info info) {
        this.time = info.getTime();
        this.userID = info.getUserID();
        this.deviceMac = info.deviceMac;
        this.curValue = info.curValue;
        this.lowValue = info.lowValue;
        this.highValue = info.highValue;
    }

    public JWSpO2Info convertToJWSpO2Info() {
        JWSpO2Info info = new JWSpO2Info();
        info.setUserID(userID);
        info.deviceMac = deviceMac;
        info.setTime(time);
        info.curValue = (curValue);
        info.lowValue = (lowValue);
        info.highValue = (highValue);

        return info;
    }
}
