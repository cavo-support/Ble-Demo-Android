package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.JWUltravioletInfo;

import java.util.List;

public interface JWUltravioletListener {


    /**
     * ultraviolet data received
     */
    void onUltravioletDataReceived(List<JWUltravioletInfo> dataList);

    /**
     * sync ultraviolet data end
     */
    void onSyncUltravioletDataEnd();

}
