package com.wosmart.ukprotocollibary.v2.layer.handler.custom;

import com.wosmart.ukprotocollibary.v2.JWPulseListener;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;

public class PulseFinishedRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length < 2) {
            return;
        }
        JWPulseListener pulseListener = TransportManager.getInstance().getPulseListener();
        if (pulseListener == null) {
            return;
        }

        int duration = (data[0] << 8) | (data[1] & 0xff);
        pulseListener.onPulseFinished(duration);
    }

}
