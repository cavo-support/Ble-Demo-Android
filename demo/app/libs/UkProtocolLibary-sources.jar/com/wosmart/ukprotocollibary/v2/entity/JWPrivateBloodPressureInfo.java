package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWPrivateBloodPressureInfo implements Serializable {

    /**
     * true is open
     */
    public boolean enable;

    /**
     * blood pressure high value
     */
    public int highValue;

    /**
     * blood pressure low value
     */
    public int lowValue;


}
