package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import android.util.SparseArray;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

public class BodyFatDataHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        int packetLength = 4;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return;
        }

        JWBodyFatInfo info = new JWBodyFatInfo();

        // 时间在前 4 个字节
        long startTime = (((data[0] & 0xff)) | ((data[1] & 0xff) << 8) | ((data[2] & 0xff) << 16) | ((data[3] & 0xff) << 24));
        long time = DateUtil.getDate(2000, 1, 1);

        startTime = startTime * 1000 + time;

        info.time = startTime;
        info.userID = BaseManager.getInstance().getUserID();
        info.deviceMac = BaseManager.getInstance().getMacAddress();

        byte[] subData = new byte[packetLength];
        // 从第 2 个 4 字节组开始组数据
        for (int i = 1; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            int type = subData[0] & 0xff;
            int realValue = ((subData[1] & 0xff) << 8) | (subData[2] & 0xff);
            float value = JWUtils.parserRound(1, realValue / 10f);
            int level = (subData[3] >> 4) & 0x0f;
            int maxLevel = subData[3] & 0x0f;

            switch (type) {
                case 0:
                    info.weight = value;
                    info.weightLevel = level;
                    info.weightMaxLevel = maxLevel;
                    break;
                case 1:
                    info.bmi = value;
                    info.bmiLevel = level;
                    info.bmiMaxLevel = maxLevel;
                    break;
                case 2:
                    info.bodyFat = value;
                    info.bodyFatLevel = level;
                    info.bodyFatMaxLevel = maxLevel;
                    break;
                case 3:
                    info.bodyWater = value;
                    info.bodyWaterLevel = level;
                    info.bodyWaterMaxLevel = maxLevel;
                    break;
                case 4:
                    info.protein = value;
                    info.proteinLevel = level;
                    info.proteinMaxLevel = maxLevel;
                    break;
                case 5:
                    info.boneMass = value;
                    info.boneMassLevel = level;
                    info.boneMassMaxLevel = maxLevel;
                    break;
                case 6:
                    info.muscle = value;
                    info.muscleLevel = level;
                    info.muscleMaxLevel = maxLevel;
                    break;
                case 7:
                    info.bmr = value;
                    info.bmrLevel = level;
                    info.bmrMaxLevel = maxLevel;
                    break;
                default:
                    break;
            }
        }

        // 全局回调一次
        TransportManager.getInstance().getFunctionListener().onBodyFatDataReceived(info);

        // 发起者回调一次
        SparseArray<SendPacketCallback> callbackMap = TransportManager.getInstance().getCallbackMap();
        SendPacketCallback callback = callbackMap.get(CallbackKeyConstants.KEY_GET_BODY_FAT_HISTORY);
        if (callback != null) {
            callback.onResponse(info);
            callbackMap.remove(CallbackKeyConstants.KEY_GET_BODY_FAT_HISTORY);
        }
    }
}
