package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.JWHealthData;

import java.util.List;

public class JWHealthDataSearchResult<T extends JWHealthData> {

    private int totalCount;

    private List<T> dataList;

}
