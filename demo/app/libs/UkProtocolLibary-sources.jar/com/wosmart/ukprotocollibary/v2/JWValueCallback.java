package com.wosmart.ukprotocollibary.v2;

public abstract class JWValueCallback<T> implements JWErrorCallback {

    public abstract void onSuccess(T data);

}
