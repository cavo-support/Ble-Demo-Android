package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.JWAllNotifyConfigInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWNotifyType;

public abstract class JWSettingsManager {

    public static final int GENDER_MALE = 0;
    public static final int GENDER_FEMALE = 1;

    public final static int DATE_FORMAT_MM_DD = 0;
    public final static int DATE_FORMAT_DD_MM = 1;

    static JWSettingsManager getInstance() {
        return JWSettingsManagerImpl.getInstance();
    }

    /**
     * set user profile to device
     *
     * @param gender   {@link JWSettingsManager#GENDER_MALE & {@link JWSettingsManager#GENDER_FEMALE
     * @param age      0 - 127
     * @param height   0 - 256, unit cm, for example, 180.5cm
     * @param weight   0 - 512, unit kg, for example, 65.5kg
     * @param callback
     */
    public abstract void setUserProfile(int gender, int age, float height, float weight, JWCallback callback);

    /**
     * set device hour system
     *
     * @param is24Model true 24 false 12
     */
    public abstract void setHourSystem(boolean is24Model, JWCallback callback);

    /**
     * set device audio switch
     *
     * @param enable true open false close
     */
    public abstract void setAudioSwitch(boolean enable, JWCallback callback);

    /**
     * get device audio switch
     *
     * @param callback true open false close
     */
    public abstract void getAudioSwitch(JWValueCallback<Boolean> callback);

    /**
     * set the notify switch
     *
     * @param notifyType {@link JWNotifyType}
     * @param enable     true open false close
     */
    public abstract void setNotifySwitch(JWNotifyType notifyType, boolean enable, JWCallback callback);

    /**
     * set all the notify switch
     *
     * @param notifyConfigInfo config info
     */
    public abstract void setAllNotifySwitch(JWAllNotifyConfigInfo notifyConfigInfo, JWCallback callback);

    /**
     * set device date format
     *
     * @param dateFormat date format, month first or day first
     * @see JWSettingsManager#DATE_FORMAT_MM_DD
     * @see JWSettingsManager#DATE_FORMAT_DD_MM
     */
    public abstract void setDateFormat(int dateFormat, JWCallback callback);

    /**
     * get date format
     *
     * @see JWSettingsManager#DATE_FORMAT_MM_DD
     * @see JWSettingsManager#DATE_FORMAT_DD_MM
     */
    public abstract void getDateFormat(JWValueCallback<Integer> callback);

    /**
     * set temperature unit
     *
     * @param isCelsiusUnit true celsius false fahrenheit
     */
    public abstract void setTemperatureUnit(boolean isCelsiusUnit, JWCallback callback);

}
