package com.wosmart.ukprotocollibary.v2.layer.handler.multiple;

import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureReminderInfo;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.TempFunctionInfoListener;

public class SupportTemperatureReminderHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length < 2) {
            return;
        }
        TempFunctionInfoListener tempFunctionInfoListener = BaseManager.getInstance().getTempFunctionInfoListener();
        if (tempFunctionInfoListener != null) {
            int value = ((data[0] & 0xff) << 8) | (data[1] & 0xff);
            JWTemperatureReminderInfo reminderInfo = new JWTemperatureReminderInfo();
            reminderInfo.value = value;
            reminderInfo.enable = value > 0;
            tempFunctionInfoListener.onSupportTemperatureReminder(reminderInfo);
        }
    }

}
