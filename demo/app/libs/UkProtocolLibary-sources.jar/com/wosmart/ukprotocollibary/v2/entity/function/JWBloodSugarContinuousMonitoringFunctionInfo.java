package com.wosmart.ukprotocollibary.v2.entity.function;


import java.io.Serializable;

public class JWBloodSugarContinuousMonitoringFunctionInfo extends JWCommonFunctionInfo implements Serializable {


    /**
     * 间隔，单位分钟，unit min
     */
    public int interval;



    @Override
    public String toString() {
        return "JWBloodSugarContinuousMonitoringFunctionInfo{" +
                "interval=" + interval +
                ", enable=" + enable +
                '}';
    }
}
