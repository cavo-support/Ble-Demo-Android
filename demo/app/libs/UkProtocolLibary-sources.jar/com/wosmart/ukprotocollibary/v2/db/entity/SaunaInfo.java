package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWSaunaInfo;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

public class SaunaInfo extends BaseHealthDataInfo {

    public int heartRateValue;

    public int temperature;

    public int label;

    public int movement;

    public SaunaInfo(String userID, String mac, long time, int heartRateValue, int temperature, int label, int movement) {
        this.userID = userID;
        this.time = time;
        this.heartRateValue = heartRateValue;
        this.temperature = temperature;
        this.label = label;
        this.movement = movement;
    }

    public SaunaInfo(JWSaunaInfo info) {
        this.userID = info.userID;
        this.deviceMac = info.deviceMac;
        this.time = info.time;
        this.heartRateValue = info.heartRateValue;
        this.temperature = (int) (info.temperature * 10);
        this.label = info.label;
        this.movement = info.movement;
    }

    public JWSaunaInfo convertToJWSaunaInfo() {
        JWSaunaInfo info = new JWSaunaInfo();

        info.userID = this.userID;
        info.deviceMac = deviceMac;
        info.time = this.time;
        info.heartRateValue = this.heartRateValue;
        info.temperature = JWUtils.parserRound(1, this.temperature / 10f);
        info.label = this.label;
        info.movement = this.movement;
        return info;
    }
}
