package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWHighHeartRateReminderInfo implements Serializable {

    /**
     * true is open
     */
    public boolean isOpen;

    /**
     * high heart rate reminder, range is 40 ~ 220
     */
    public int value;

}
