package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdInfo;

public class HRVRmssdInfo extends BaseHealthDataInfo {

    public int value;

    public HRVRmssdInfo(String userID, String mac, long time, int value) {
        this.userID = userID;
        this.time = time;
        this.value = value;
    }

    public HRVRmssdInfo(JWHRVRmssdInfo info) {
        this.userID = info.userID;
        this.deviceMac = info.deviceMac;
        this.time = info.time;
        this.value = info.value;
    }

    public JWHRVRmssdInfo convertToJWHRVRmssdInfo() {
        JWHRVRmssdInfo info = new JWHRVRmssdInfo();

        info.userID = this.userID;
        info.deviceMac = deviceMac;
        info.time = this.time;
        info.value = this.value;
        return info;
    }
}
