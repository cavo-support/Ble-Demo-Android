package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWHRVRmssdInfo extends JWHealthData implements Serializable {

    public int value;

    @Override
    public String toString() {
        return "JWHRVRmssdInfo{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", value=" + value +
                '}';
    }

}
