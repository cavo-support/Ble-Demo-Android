package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureInfo;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

public class TemperatureInfo extends BaseHealthDataInfo {

    public int temperatureValue;

    public int temperatureOriginValue;

    public int wearStatus;

    public int compensationStatus;

    public TemperatureInfo(long time, String userID, String mac, int temperatureValue, int temperatureOriginValue, int wearStatus, int compensationStatus) {
        this.time = time;
        this.userID = userID;
        this.temperatureValue = temperatureValue;
        this.temperatureOriginValue = temperatureOriginValue;
        this.wearStatus = wearStatus;
        this.compensationStatus = compensationStatus;
    }

    public TemperatureInfo(JWTemperatureInfo info) {
        this.time = info.time;
        this.userID = info.userID;
        this.deviceMac = info.deviceMac;
        this.temperatureValue = (int) (info.temperatureValue * 10);
        this.temperatureOriginValue = (int) (info.temperatureOriginValue * 10);
        this.wearStatus = info.wearStatus ? 1 : 0;
        this.compensationStatus = info.compensationStatus ? 1 : 0;
    }

    public JWTemperatureInfo convertToJWTempInfo() {
        JWTemperatureInfo info = new JWTemperatureInfo();
        info.userID = (userID);
        info.deviceMac = deviceMac;
        info.time = (time);
        info.temperatureValue = JWUtils.parserRound(1, temperatureValue / 10f);
        info.temperatureOriginValue = JWUtils.parserRound(1, temperatureOriginValue / 10f);
        info.wearStatus = (wearStatus == 1);
        info.compensationStatus = (compensationStatus == 1);

        return info;
    }

}
