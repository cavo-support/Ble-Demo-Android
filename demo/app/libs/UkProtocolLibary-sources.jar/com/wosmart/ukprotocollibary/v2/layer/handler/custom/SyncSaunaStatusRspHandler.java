package com.wosmart.ukprotocollibary.v2.layer.handler.custom;

import com.wosmart.ukprotocollibary.v2.JWSaunaListener;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;

public class SyncSaunaStatusRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length < 3) {
            return;
        }
        JWSaunaListener saunaListener = TransportManager.getInstance().getSaunaListener();
        if (saunaListener == null) {
            return;
        }

        int status = data[0] & 0xff;
        int count = ((data[1] & 0xff) << 8) | (data[2] & 0xff);
        if (status == 1) {
            saunaListener.onSyncDataStart(count);
        } else {
            saunaListener.onSyncDataFinished();
        }
    }

}
