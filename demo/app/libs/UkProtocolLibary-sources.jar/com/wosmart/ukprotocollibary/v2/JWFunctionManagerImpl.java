package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.common.BleCallback;
import com.wosmart.ukprotocollibary.v2.common.executor.JWArchTaskExecutor;
import com.wosmart.ukprotocollibary.v2.entity.JWAddressBook;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWDrinkWaterReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWFemaleHealthInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdConfigInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWMedicationReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPrivateBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWeatherInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodSugarContinuousMonitoringFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWDefaultFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWHealthRiskAssessmentInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWUricAcidFunctionInfo;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.function.FunctionManager;

import java.util.ArrayList;
import java.util.List;

public class JWFunctionManagerImpl extends JWFunctionManager {

    private JWFunctionListener mFunctionListener;
    private JWFunctionChangeListener mFunctionChangeListener;

    private final List<JWFunctionListener> mFunctionListenerList;

    private final List<JWFunctionChangeListener> mFunctionChangeListenerList;

    private JWFunctionManagerImpl() {
        this.mFunctionListenerList = new ArrayList<>();
        this.mFunctionChangeListenerList = new ArrayList<>();
        this.initListener();
    }

    private void initListener() {
        if (mFunctionListener == null) {
            mFunctionListener = new JWFunctionListener() {
                @Override
                public void onTakePhoto() {
                    for (JWFunctionListener listener : JWFunctionManagerImpl.this.mFunctionListenerList) {
                        listener.onTakePhoto();
                    }
                }

                @Override
                public void onFindPhone(boolean enable) {
                    for (JWFunctionListener listener : JWFunctionManagerImpl.this.mFunctionListenerList) {
                        listener.onFindPhone(enable);
                    }
                }

                @Override
                public void onDeviceMeasureStatusUpdated(int status) {
                    for (JWFunctionListener listener : JWFunctionManagerImpl.this.mFunctionListenerList) {
                        listener.onDeviceMeasureStatusUpdated(status);
                    }
                }

                @Override
                public void onBodyFatDataReceived(JWBodyFatInfo bodyFat) {
                    for (JWFunctionListener listener : JWFunctionManagerImpl.this.mFunctionListenerList) {
                        listener.onBodyFatDataReceived(bodyFat);
                    }
                }

                @Override
                public void onPhysicalExamDataReceived(JWPhysicalExamInfo physicalExam) {
                    for (JWFunctionListener listener : JWFunctionManagerImpl.this.mFunctionListenerList) {
                        listener.onPhysicalExamDataReceived(physicalExam);
                    }
                }
            };
        }
        if (mFunctionChangeListener == null) {
            mFunctionChangeListener = new JWFunctionChangeListener() {

                @Override
                public void onUricAcidFunctionChanged(JWUricAcidFunctionInfo functionInfo) {
                    super.onUricAcidFunctionChanged(functionInfo);
                    for (JWFunctionChangeListener listener : JWFunctionManagerImpl.this.mFunctionChangeListenerList) {
                        listener.onUricAcidFunctionChanged(functionInfo);
                    }
                }
            };
        }
        FunctionManager.getInstance().setFunctionListener(mFunctionListener);
        BaseManager.getInstance().setFunctionChangeListener(mFunctionChangeListener);
    }

    @Override
    public void addFunctionListener(JWFunctionListener listener) {
        if (listener == null) {
            return;
        }
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                if (!JWFunctionManagerImpl.this.mFunctionListenerList.contains(listener)) {
                    JWFunctionManagerImpl.this.mFunctionListenerList.add(listener);
                }
            }
        });
    }

    @Override
    public void removeFunctionListener(JWFunctionListener listener) {
        if (listener == null) {
            return;
        }
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                JWFunctionManagerImpl.this.mFunctionListenerList.remove(listener);
            }
        });
    }

    @Override
    public void addFunctionChangeListener(JWFunctionChangeListener listener) {
        if (listener == null) {
            return;
        }
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                if (!JWFunctionManagerImpl.this.mFunctionChangeListenerList.contains(listener)) {
                    JWFunctionManagerImpl.this.mFunctionChangeListenerList.add(listener);
                }
            }
        });
    }

    @Override
    public void removeFunctionChangeListener(JWFunctionChangeListener listener) {
        if (listener == null) {
            return;
        }
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                JWFunctionManagerImpl.this.mFunctionChangeListenerList.remove(listener);
            }
        });
    }

    @Override
    public void setTakePhotoControl(boolean enable, JWCallback callback) {
        FunctionManager.getInstance().setTakePhotoControl(enable, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setPrivateBloodPressureInfo(JWPrivateBloodPressureInfo privateBloodPressureInfo, JWCallback callback) {
        if (privateBloodPressureInfo == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "private blood pressure info cannot be null");
            }
            return;
        }
        FunctionManager.getInstance().setPrivateBloodPressure(privateBloodPressureInfo, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void getPrivateBloodPressureInfo(JWValueCallback<JWPrivateBloodPressureInfo> callback) {
        FunctionManager.getInstance().getPrivateBloodPressure(new BleCallback<JWPrivateBloodPressureInfo>(callback) {
            @Override
            public void success(JWPrivateBloodPressureInfo data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }


    @Override
    public void setTemperatureReminder(JWTemperatureReminderInfo reminderInfo, JWCallback callback) {
        if (BaseManager.getInstance().getDeviceFunctionInfo().temperatureReminder == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        if (reminderInfo == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "reminder info cannot be null");
            }
            return;
        }
        if (reminderInfo.value < 37 || reminderInfo.value > 41.9) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "value should be between 37°C - 41.9°C");
            }
            return;
        }
        FunctionManager.getInstance().setTemperatureReminder(reminderInfo, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void getTemperatureReminder(JWValueCallback<JWTemperatureReminderInfo> callback) {
        if (BaseManager.getInstance().getDeviceFunctionInfo().temperatureReminder == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().getTemperatureReminder(new BleCallback<JWTemperatureReminderInfo>(callback) {
            @Override
            public void success(JWTemperatureReminderInfo data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }


    @Override
    public void setDrinkWaterReminder(JWDrinkWaterReminderInfo reminderInfo, JWCallback callback) {
        if (BaseManager.getInstance().getDeviceFunctionInfo().drinkWaterReminder == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        if (reminderInfo == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "reminder info cannot be null");
            }
            return;
        }
        if (reminderInfo.startHour < 0 || reminderInfo.startHour > 23 || reminderInfo.endHour < 0 || reminderInfo.endHour > 23 ||
                reminderInfo.startMin < 0 || reminderInfo.startMin > 59 || reminderInfo.endMin < 0 || reminderInfo.endMin > 59) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            }
            return;
        }
        if (reminderInfo.interval < 30 || reminderInfo.interval > 240) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "interval should be between 30 - 240");
            }
            return;
        }
        if ((reminderInfo.startHour * 60 + reminderInfo.startMin) > (reminderInfo.endHour * 60 + reminderInfo.endMin)) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "the start time must be less than the end time");
            }
            return;
        }
        FunctionManager.getInstance().setDrinkWaterReminder(reminderInfo, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void getDrinkWaterReminder(JWValueCallback<JWDrinkWaterReminderInfo> callback) {
        if (BaseManager.getInstance().getDeviceFunctionInfo().drinkWaterReminder == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().getDrinkWaterReminder(new BleCallback<JWDrinkWaterReminderInfo>(callback) {
            @Override
            public void success(JWDrinkWaterReminderInfo data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setMedicationReminder(List<JWMedicationReminderInfo> reminderInfoList, JWCallback callback) {
        if (!BaseManager.getInstance().getDeviceFunctionInfo().medicationReminder) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().setMedicationReminder(reminderInfoList, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void getMedicationReminder(JWValueCallback<List<JWMedicationReminderInfo>> callback) {
        if (!BaseManager.getInstance().getDeviceFunctionInfo().medicationReminder) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().getMedicationReminder(new BleCallback<List<JWMedicationReminderInfo>>(callback) {
            @Override
            public void success(List<JWMedicationReminderInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setPulse(boolean enable, int duration, int level, JWCallback callback) {
        if (!BaseManager.getInstance().getDeviceFunctionInfo().pulse) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().setPulse(enable, duration, level, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setSleepHelp(boolean enable, int mode, int duration, int effectiveTime, int level, JWValueCallback<Integer> callback) {
        if (!BaseManager.getInstance().getDeviceFunctionInfo().sleepHelp) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().setSleepHelp(enable, mode, duration, effectiveTime, level, new BleCallback<Integer>(callback) {
            @Override
            public void success(Integer data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setFemaleHealth(JWFemaleHealthInfo healthInfo, JWCallback callback) {
        if (!BaseManager.getInstance().getDeviceFunctionInfo().femaleHealth) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        if (healthInfo == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "healthInfo cannot be null");
            }
            return;
        }
        if (healthInfo.mode != JWFemaleHealthInfo.MODE_MENSTRUAL_PERIOD && healthInfo.mode != JWFemaleHealthInfo.MODE_PREGNANCY_PREPARATION_PERIOD
                && healthInfo.mode != JWFemaleHealthInfo.MODE_EXPECTED_DATE_OF_CHILDBIRTH && healthInfo.mode != JWFemaleHealthInfo.MODE_SUCKLING_PERIOD) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "mode error");
            }
            return;
        }
        if (healthInfo.mode == JWFemaleHealthInfo.MODE_EXPECTED_DATE_OF_CHILDBIRTH) {
            long date = DateUtil.getDate(healthInfo.year, healthInfo.month, healthInfo.day);
            if (date < System.currentTimeMillis()) {
                if (callback != null) {
                    callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "the expected date needs to be greater than the current time");
                }
                return;
            }
        }
        FunctionManager.getInstance().setFemaleHealth(healthInfo, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setWeather(JWWeatherInfo weatherInfo, JWCallback callback) {
        if (!BaseManager.getInstance().getDeviceFunctionInfo().weather) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        if (weatherInfo.currentWeather != null) {
            if (weatherInfo.currentWeather.weatherCode < JWWeatherInfo.WEATHER_CODE_OTHER || weatherInfo.currentWeather.weatherCode > JWWeatherInfo.WEATHER_CODE_CLOUDY_TO_CLEAR) {
                weatherInfo.currentWeather.weatherCode = JWWeatherInfo.WEATHER_CODE_OTHER;
            }
        }
        FunctionManager.getInstance().setWeather(weatherInfo, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setTemperatureControl(boolean enable, boolean isAdjust, boolean isCelsiusUnit, JWCallback callback) {
        FunctionManager.getInstance().setTemperatureControl(enable, isAdjust, isCelsiusUnit, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setUricAcid(boolean enable, int privateValue, int privateRTCTime, JWCallback callback) {
        if (BaseManager.getInstance().getDeviceFunctionInfo().uricAcid == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().setUricAcid(enable, privateValue, privateRTCTime, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setBloodFat(boolean enable, int privateValue, int privateRTCTime, JWCallback callback) {
        if (BaseManager.getInstance().getDeviceFunctionInfo().bloodFat == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().setBloodFat(enable, privateValue, privateRTCTime, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setBloodSugarCycle(boolean enable, float privateValue, int privateRTCTime, JWCallback callback) {
        if (BaseManager.getInstance().getDeviceFunctionInfo().bloodSugarCycle == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().setBloodSugarCycle(enable, privateValue, privateRTCTime, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setPrivateUricAcid(boolean enable, int value, JWCallback callback) {
        if (BaseManager.getInstance().getDeviceFunctionInfo().privateUricAcid == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().setPrivateUricAcid(enable, value, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setPrivateBloodFat(boolean enable, float value, JWCallback callback) {
        if (BaseManager.getInstance().getDeviceFunctionInfo().privateBloodFat == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().setPrivateBloodFat(enable, value, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void getBloodSugarContinuousMonitoring(JWValueCallback<JWBloodSugarContinuousMonitoringFunctionInfo> callback) {
        if (!BaseManager.getInstance().getDeviceFunctionInfo().bloodSugar) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().getBloodSugarContinuousMonitoring(new BleCallback<JWBloodSugarContinuousMonitoringFunctionInfo>(callback) {
            @Override
            public void success(JWBloodSugarContinuousMonitoringFunctionInfo data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setBloodSugarContinuousMonitoring(boolean enable, int interval, JWCallback callback) {
        if (!BaseManager.getInstance().getDeviceFunctionInfo().bloodSugar) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().setBloodSugarContinuousMonitoring(enable, interval, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setUricAcidContinuousMonitoring(boolean enable, JWCallback callback) {
        if (BaseManager.getInstance().getDeviceFunctionInfo().privateUricAcid == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().setUricAcidContinuousMonitoring(enable, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setBloodFatContinuousMonitoring(boolean enable, JWCallback callback) {
        if (BaseManager.getInstance().getDeviceFunctionInfo().privateBloodFat == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().setBloodFatContinuousMonitoring(enable, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setPressureContinuousMonitoring(boolean enable, JWCallback callback) {
        if (!BaseManager.getInstance().getDeviceFunctionInfo().pressure) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        FunctionManager.getInstance().setPressureContinuousMonitoring(enable, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setBodyFatMeasure(boolean enable, JWCallback callback) {
        FunctionManager.getInstance().setBodyFatMeasure(enable, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void getRecentBodyFat(JWValueCallback<JWBodyFatInfo> callback) {
        FunctionManager.getInstance().getRecentBodyFat(new BleCallback<JWBodyFatInfo>(callback) {
            @Override
            public void success(JWBodyFatInfo data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void getPhysicalExam(JWValueCallback<JWPhysicalExamInfo> callback) {
        FunctionManager.getInstance().getPhysicalExam(new BleCallback<JWPhysicalExamInfo>(callback) {
            @Override
            public void success(JWPhysicalExamInfo data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void syncUltraviolet(JWCallback callback) {
        FunctionManager.getInstance().syncUltraviolet(new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void syncPressure(JWCallback callback) {
        FunctionManager.getInstance().syncPressure(new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setEcgBeltMeasure(boolean enable, JWCallback callback) {
        FunctionManager.getInstance().setEcgBeltMeasure(enable, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setHRVRmssd(boolean enable, int interval, JWCallback callback) {
        FunctionManager.getInstance().setHRVRmssd(enable, interval, new BleCallback<Void>(callback) {});
    }

    @Override
    public void readHRVRmssdConfig(JWValueCallback<JWHRVRmssdConfigInfo> callback) {
        FunctionManager.getInstance().readHRVRmssdConfig(new BleCallback<JWHRVRmssdConfigInfo>(callback) {});
    }

    @Override
    public void setBloodSugarRiskAssessment(boolean enable, JWCallback callback) {
        FunctionManager.getInstance().setBloodSugarRiskAssessment(enable, new BleCallback<Void>(callback) {});
    }

    @Override
    public void setUricAcidRiskAssessment(boolean enable, JWCallback callback) {
        FunctionManager.getInstance().setUricAcidRiskAssessment(enable, new BleCallback<Void>(callback) {});
    }

    @Override
    public void setBloodFatRiskAssessment(boolean enable, JWCallback callback) {
        FunctionManager.getInstance().setBloodFatRiskAssessment(enable, new BleCallback<Void>(callback) {});
    }

    @Override
    public void readHealthRiskAssessment(JWValueCallback<JWHealthRiskAssessmentInfo> callback) {
        FunctionManager.getInstance().readHealthRiskAssessment(new BleCallback<JWHealthRiskAssessmentInfo>(callback) {});
    }

    @Override
    public void setDefaultFunction(JWDefaultFunctionInfo defaultFunctionInfo, JWCallback callback) {
        if (defaultFunctionInfo == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "defaultFunctionInfo is null");
            }
            return;
        }
        FunctionManager.getInstance().setDefaultFunction(defaultFunctionInfo, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void readDefaultFunction(JWValueCallback<JWDefaultFunctionInfo> callback) {
        FunctionManager.getInstance().readDefaultFunction(new BleCallback<JWDefaultFunctionInfo>(callback) {
            @Override
            public void success(JWDefaultFunctionInfo data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }


    @Override
    public void setAddressBook(List<JWAddressBook> addressBookList, JWCallback callback) {
        if (!BaseManager.getInstance().getDeviceFunctionInfo().addressBook) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        if (addressBookList != null && addressBookList.size() > 10) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "the maximum address book size is 10");
            }
            return;
        }
        FunctionManager.getInstance().setAddressBook(addressBookList, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setSOSNumber(List<JWAddressBook> numberList, JWCallback callback) {
        if (!BaseManager.getInstance().getDeviceFunctionInfo().sosNumber) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        if (numberList != null && numberList.size() > 5) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "the maximum sos number size is 5");
            }
            return;
        }
        FunctionManager.getInstance().setSOSNumber(numberList, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    static JWFunctionManagerImpl getInstance() {
        return JWFunctionManagerImplHolder.functionManagerImpl;
    }

    private static class JWFunctionManagerImplHolder {
        private static final JWFunctionManagerImpl functionManagerImpl = new JWFunctionManagerImpl();
    }

}
