package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateInfo;

public class HeartRateInfo extends BaseHealthDataInfo {

    public int value;

    public HeartRateInfo(long time, String userID, String mac, int value) {
        this.time = time;
        this.userID = userID;
        this.deviceMac = mac;
        this.value = value;
    }

    public HeartRateInfo(JWHeartRateInfo info) {
        this.time = info.time;
        this.userID = info.userID;
        this.deviceMac = info.deviceMac;
        this.value = info.value;
    }

    public JWHeartRateInfo convertToJWHrInfo() {
        JWHeartRateInfo info = new JWHeartRateInfo();
        info.userID = userID;
        info.deviceMac = deviceMac;
        info.time = time;
        info.value = value;

        return info;
    }

}
