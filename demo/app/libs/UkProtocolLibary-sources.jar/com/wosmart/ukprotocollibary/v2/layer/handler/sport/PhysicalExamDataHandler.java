package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import android.util.SparseArray;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

public class PhysicalExamDataHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        int packetLength = 4;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return;
        }

        JWPhysicalExamInfo info = new JWPhysicalExamInfo();

        // 时间在前 4 个字节
        long startTime = (((data[0] & 0xff)) | ((data[1] & 0xff) << 8) | ((data[2] & 0xff) << 16) | ((data[3] & 0xff) << 24));
        long time = DateUtil.getDate(2000, 1, 1);

        startTime = startTime * 1000 + time;

        info.time = startTime;
        info.userID = BaseManager.getInstance().getUserID();
        info.deviceMac = BaseManager.getInstance().getMacAddress();

        byte[] subData = new byte[packetLength];
        // 从第 2 个 4 字节组开始组数据
        for (int i = 1; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            int type = subData[0] & 0xff;
            int value = ((subData[1] & 0xff) << 8) | (subData[2] & 0xff);

            switch (type) {
                case 0:
                    info.heartRate = value;
                    break;
                case 1:
                    info.spo2 = value;
                    break;
                case 2:
                    info.pressure = value;
                    break;
                case 3:
                    info.temperature = JWUtils.parserRound(1, value / 10f);
                    break;
                case 4:
                    info.skinTemperature = JWUtils.parserRound(1, value / 10f);
                    break;
                case 5:
                    info.bloodVesselElasticity = value;
                    break;
                case 6:
                    info.cardiovascularRisk = value;
                    break;
                default:
                    break;
            }
        }

        // 全局回调一次
        TransportManager.getInstance().getFunctionListener().onPhysicalExamDataReceived(info);

        // 发起者回调一次
        SparseArray<SendPacketCallback> callbackMap = TransportManager.getInstance().getCallbackMap();
        SendPacketCallback callback = callbackMap.get(CallbackKeyConstants.KEY_GET_PHYSICAL_EXAM_HISTORY);
        if (callback != null) {
            callback.onResponse(info);
            callbackMap.remove(CallbackKeyConstants.KEY_GET_PHYSICAL_EXAM_HISTORY);
        }
    }
}
