package com.wosmart.ukprotocollibary.v2.db;

import com.wosmart.ukprotocollibary.v2.db.dao.BloodFatContinuousMonitoringInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodFatInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodPressureInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodSugarCycleInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodSugarInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BodyFatInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HRMovementInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HRVRmssdInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HeartRateInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HeartRateVariabilityInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.PhysicalExamInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.PressureInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.PulseInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SaunaInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SleepInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SpO2InfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SportInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.StepInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.TemperatureInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.UltravioletInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.UricAcidContinuousMonitoringInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.UricAcidInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.WearingTimeInfoDao;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodFatContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodFatInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodSugarInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.BodyFatInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.HRMovementInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.HRVRmssdInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.HeartRateInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.HeartRateVariabilityInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.PhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.PressureInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.PulseInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.SaunaInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.SleepInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.SpO2Info;
import com.wosmart.ukprotocollibary.v2.db.entity.SportInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.StepInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.TemperatureInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.UltravioletInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.UricAcidContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.UricAcidInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.WearingTimeInfo;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.AbstractDaoSession;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.identityscope.IdentityScopeType;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.Map;
import java.util.Objects;


public class DatabaseSession extends AbstractDaoSession {

    private DaoConfig bloodPressureInfoDaoConfig;
    private DaoConfig bloodSugarInfoDaoConfig;
    private DaoConfig heartRateInfoDaoConfig;
    private DaoConfig heartRateVariabilityInfoDaoConfig;
    private DaoConfig sleepInfoDaoConfig;
    private DaoConfig spo2InfoDaoConfig;
    private DaoConfig sportInfoDaoConfig;
    private DaoConfig stepInfoDaoConfig;
    private DaoConfig temperatureInfoDaoConfig;
    private DaoConfig pulseInfoDaoConfig;
    private DaoConfig saunaInfoDaoConfig;
    private DaoConfig hrMovementInfoDaoConfig;
    private DaoConfig wearingTimeInfoDaoConfig;
    private DaoConfig uricAcidInfoDaoConfig;
    private DaoConfig bloodFatInfoDaoConfig;
    private DaoConfig bloodSugarCycleInfoDaoConfig;
    private DaoConfig uricAcidContinuousMonitoringInfoDaoConfig;
    private DaoConfig bloodFatContinuousMonitoringInfoDaoConfig;
    private DaoConfig bodyFatInfoDaoConfig;
    private DaoConfig physicalExamInfoDaoConfig;
    private DaoConfig hrvRmssdInfoDaoConfig;
    private DaoConfig ultravioletInfoDaoConfig;
    private DaoConfig pressureInfoDaoConfig;

    private BloodPressureInfoDao bloodPressureInfoDao;
    private BloodSugarInfoDao bloodSugarInfoDao;
    private HeartRateInfoDao heartRateInfoDao;
    private HeartRateVariabilityInfoDao heartRateVariabilityInfoDao;
    private SleepInfoDao sleepInfoDao;
    private SpO2InfoDao spo2InfoDao;
    private SportInfoDao sportInfoDao;
    private StepInfoDao stepInfoDao;
    private TemperatureInfoDao temperatureInfoDao;
    private PulseInfoDao pulseInfoDao;
    private SaunaInfoDao saunaInfoDao;
    private HRMovementInfoDao hrMovementInfoDao;
    private WearingTimeInfoDao wearingTimeInfoDao;
    private UricAcidInfoDao uricAcidInfoDao;
    private BloodFatInfoDao bloodFatInfoDao;
    private BloodSugarCycleInfoDao bloodSugarCycleInfoDao;
    private UricAcidContinuousMonitoringInfoDao uricAcidContinuousMonitoringInfoDao;
    private BloodFatContinuousMonitoringInfoDao bloodFatContinuousMonitoringInfoDao;
    private BodyFatInfoDao bodyFatInfoDao;
    private PhysicalExamInfoDao physicalExamInfoDao;
    private HRVRmssdInfoDao hrvRmssdInfoDao;
    private UltravioletInfoDao ultravioletInfoDao;
    private PressureInfoDao pressureInfoDao;

    public DatabaseSession(Database db, IdentityScopeType type, Map<Class<? extends AbstractDao<?, ?>>, DaoConfig> daoConfigMap) {
        super(db);

        initConfig(type, daoConfigMap);

        initDao();
    }

    private void initConfig(IdentityScopeType type, Map<Class<? extends AbstractDao<?, ?>>, DaoConfig> daoConfigMap) {
        bloodPressureInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(BloodPressureInfoDao.class)).clone();
        bloodPressureInfoDaoConfig.initIdentityScope(type);

        bloodSugarInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(BloodSugarInfoDao.class)).clone();
        bloodSugarInfoDaoConfig.initIdentityScope(type);

        heartRateInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(HeartRateInfoDao.class)).clone();
        heartRateInfoDaoConfig.initIdentityScope(type);

        heartRateVariabilityInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(HeartRateVariabilityInfoDao.class)).clone();
        heartRateVariabilityInfoDaoConfig.initIdentityScope(type);

        sleepInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(SleepInfoDao.class)).clone();
        sleepInfoDaoConfig.initIdentityScope(type);

        spo2InfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(SpO2InfoDao.class)).clone();
        spo2InfoDaoConfig.initIdentityScope(type);

        sportInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(SportInfoDao.class)).clone();
        sportInfoDaoConfig.initIdentityScope(type);

        stepInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(StepInfoDao.class)).clone();
        stepInfoDaoConfig.initIdentityScope(type);

        temperatureInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(TemperatureInfoDao.class)).clone();
        temperatureInfoDaoConfig.initIdentityScope(type);

        pulseInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(PulseInfoDao.class)).clone();
        pulseInfoDaoConfig.initIdentityScope(type);

        saunaInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(SaunaInfoDao.class)).clone();
        saunaInfoDaoConfig.initIdentityScope(type);

        hrMovementInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(HRMovementInfoDao.class)).clone();
        hrMovementInfoDaoConfig.initIdentityScope(type);

        wearingTimeInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(WearingTimeInfoDao.class)).clone();
        wearingTimeInfoDaoConfig.initIdentityScope(type);

        uricAcidInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(UricAcidInfoDao.class)).clone();
        uricAcidInfoDaoConfig.initIdentityScope(type);

        bloodFatInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(BloodFatInfoDao.class)).clone();
        bloodFatInfoDaoConfig.initIdentityScope(type);

        bloodSugarCycleInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(BloodSugarCycleInfoDao.class)).clone();
        bloodSugarCycleInfoDaoConfig.initIdentityScope(type);

        uricAcidContinuousMonitoringInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(UricAcidContinuousMonitoringInfoDao.class)).clone();
        uricAcidContinuousMonitoringInfoDaoConfig.initIdentityScope(type);

        bloodFatContinuousMonitoringInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(BloodFatContinuousMonitoringInfoDao.class)).clone();
        bloodFatContinuousMonitoringInfoDaoConfig.initIdentityScope(type);

        bodyFatInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(BodyFatInfoDao.class)).clone();
        bodyFatInfoDaoConfig.initIdentityScope(type);

        physicalExamInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(PhysicalExamInfoDao.class)).clone();
        physicalExamInfoDaoConfig.initIdentityScope(type);

        hrvRmssdInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(HRVRmssdInfoDao.class)).clone();
        hrvRmssdInfoDaoConfig.initIdentityScope(type);

        ultravioletInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(UltravioletInfoDao.class)).clone();
        ultravioletInfoDaoConfig.initIdentityScope(type);

        pressureInfoDaoConfig = Objects.requireNonNull(daoConfigMap.get(PressureInfoDao.class)).clone();
        pressureInfoDaoConfig.initIdentityScope(type);
    }

    private void initDao() {
        bloodPressureInfoDao = new BloodPressureInfoDao(bloodPressureInfoDaoConfig, this);
        bloodSugarInfoDao = new BloodSugarInfoDao(bloodSugarInfoDaoConfig, this);
        heartRateInfoDao = new HeartRateInfoDao(heartRateInfoDaoConfig, this);
        heartRateVariabilityInfoDao = new HeartRateVariabilityInfoDao(heartRateVariabilityInfoDaoConfig, this);
        sleepInfoDao = new SleepInfoDao(sleepInfoDaoConfig, this);
        spo2InfoDao = new SpO2InfoDao(spo2InfoDaoConfig, this);
        sportInfoDao = new SportInfoDao(sportInfoDaoConfig, this);
        stepInfoDao = new StepInfoDao(stepInfoDaoConfig, this);
        temperatureInfoDao = new TemperatureInfoDao(temperatureInfoDaoConfig, this);
        pulseInfoDao = new PulseInfoDao(pulseInfoDaoConfig, this);
        saunaInfoDao = new SaunaInfoDao(saunaInfoDaoConfig, this);
        hrMovementInfoDao = new HRMovementInfoDao(hrMovementInfoDaoConfig, this);
        wearingTimeInfoDao = new WearingTimeInfoDao(wearingTimeInfoDaoConfig, this);
        uricAcidInfoDao = new UricAcidInfoDao(uricAcidInfoDaoConfig, this);
        bloodFatInfoDao = new BloodFatInfoDao(bloodFatInfoDaoConfig, this);
        bloodSugarCycleInfoDao = new BloodSugarCycleInfoDao(bloodSugarCycleInfoDaoConfig, this);
        uricAcidContinuousMonitoringInfoDao = new UricAcidContinuousMonitoringInfoDao(uricAcidContinuousMonitoringInfoDaoConfig, this);
        bloodFatContinuousMonitoringInfoDao = new BloodFatContinuousMonitoringInfoDao(bloodFatContinuousMonitoringInfoDaoConfig, this);
        bodyFatInfoDao = new BodyFatInfoDao(bodyFatInfoDaoConfig, this);
        physicalExamInfoDao = new PhysicalExamInfoDao(physicalExamInfoDaoConfig, this);
        hrvRmssdInfoDao = new HRVRmssdInfoDao(hrvRmssdInfoDaoConfig, this);
        ultravioletInfoDao = new UltravioletInfoDao(ultravioletInfoDaoConfig, this);
        pressureInfoDao = new PressureInfoDao(pressureInfoDaoConfig, this);

        registerDao(BloodPressureInfo.class, bloodPressureInfoDao);
        registerDao(BloodSugarInfo.class, bloodSugarInfoDao);
        registerDao(HeartRateInfo.class, heartRateInfoDao);
        registerDao(HeartRateVariabilityInfo.class, heartRateVariabilityInfoDao);
        registerDao(SleepInfo.class, sleepInfoDao);
        registerDao(SpO2Info.class, spo2InfoDao);
        registerDao(SportInfo.class, sportInfoDao);
        registerDao(StepInfo.class, stepInfoDao);
        registerDao(TemperatureInfo.class, temperatureInfoDao);
        registerDao(PulseInfo.class, pulseInfoDao);
        registerDao(SaunaInfo.class, saunaInfoDao);
        registerDao(HRMovementInfo.class, hrMovementInfoDao);
        registerDao(WearingTimeInfo.class, wearingTimeInfoDao);
        registerDao(UricAcidInfo.class, uricAcidInfoDao);
        registerDao(BloodFatInfo.class, bloodFatInfoDao);
        registerDao(BloodSugarCycleInfo.class, bloodSugarCycleInfoDao);
        registerDao(UricAcidContinuousMonitoringInfo.class, uricAcidContinuousMonitoringInfoDao);
        registerDao(BloodFatContinuousMonitoringInfo.class, bloodFatContinuousMonitoringInfoDao);
        registerDao(BodyFatInfo.class, bodyFatInfoDao);
        registerDao(PhysicalExamInfo.class, physicalExamInfoDao);
        registerDao(HRVRmssdInfo.class, hrvRmssdInfoDao);
        registerDao(UltravioletInfo.class, ultravioletInfoDao);
        registerDao(PressureInfo.class, pressureInfoDao);
    }
    
    public void clear() {
        bloodPressureInfoDaoConfig.getIdentityScope().clear();
        bloodSugarInfoDaoConfig.getIdentityScope().clear();
        heartRateInfoDaoConfig.getIdentityScope().clear();
        heartRateVariabilityInfoDaoConfig.getIdentityScope().clear();
        sleepInfoDaoConfig.getIdentityScope().clear();
        spo2InfoDaoConfig.getIdentityScope().clear();
        sportInfoDaoConfig.getIdentityScope().clear();
        stepInfoDaoConfig.getIdentityScope().clear();
        temperatureInfoDaoConfig.getIdentityScope().clear();
        pulseInfoDaoConfig.getIdentityScope().clear();
        saunaInfoDaoConfig.getIdentityScope().clear();
        hrMovementInfoDaoConfig.getIdentityScope().clear();
        wearingTimeInfoDaoConfig.getIdentityScope().clear();
        uricAcidInfoDaoConfig.getIdentityScope().clear();
        bloodFatInfoDaoConfig.getIdentityScope().clear();
        bloodSugarCycleInfoDaoConfig.getIdentityScope().clear();
        uricAcidContinuousMonitoringInfoDaoConfig.getIdentityScope().clear();
        bloodFatContinuousMonitoringInfoDaoConfig.getIdentityScope().clear();
        bodyFatInfoDaoConfig.getIdentityScope().clear();
        physicalExamInfoDaoConfig.getIdentityScope().clear();
        hrvRmssdInfoDaoConfig.getIdentityScope().clear();
        ultravioletInfoDaoConfig.getIdentityScope().clear();
        pressureInfoDaoConfig.getIdentityScope().clear();
    }

    public BloodPressureInfoDao getBloodPressureDao() {
        return bloodPressureInfoDao;
    }

    public BloodSugarInfoDao getBloodSugarDao() {
        return bloodSugarInfoDao;
    }

    public HeartRateInfoDao getHeartRateDao() {
        return heartRateInfoDao;
    }

    public HeartRateVariabilityInfoDao getHrvDao() {
        return heartRateVariabilityInfoDao;
    }

    public SleepInfoDao getSleepDao() {
        return sleepInfoDao;
    }

    public SpO2InfoDao getSpO2Dao() {
        return spo2InfoDao;
    }

    public SportInfoDao getSportDao() {
        return sportInfoDao;
    }

    public StepInfoDao getStepDao() {
        return stepInfoDao;
    }

    public TemperatureInfoDao getTemperatureDao() {
        return temperatureInfoDao;
    }

    public PulseInfoDao getPulseDao() {
        return pulseInfoDao;
    }

    public SaunaInfoDao getSaunaDao() {
        return saunaInfoDao;
    }

    public HRMovementInfoDao getHRMovementDao() {
        return hrMovementInfoDao;
    }

    public WearingTimeInfoDao getWearingTimeDao() {
        return wearingTimeInfoDao;
    }

    public UricAcidInfoDao getUricAcidInfoDao() {
        return uricAcidInfoDao;
    }

    public BloodFatInfoDao getBloodFatInfoDao() {
        return bloodFatInfoDao;
    }

    public BloodSugarCycleInfoDao getBloodSugarCycleInfoDao() {
        return bloodSugarCycleInfoDao;
    }

    public UricAcidContinuousMonitoringInfoDao getUricAcidContinuousMonitoringInfoDao() {
        return uricAcidContinuousMonitoringInfoDao;
    }

    public BloodFatContinuousMonitoringInfoDao getBloodFatContinuousMonitoringInfoDao() {
        return bloodFatContinuousMonitoringInfoDao;
    }

    public BodyFatInfoDao getBodyFatInfoDao() {
        return bodyFatInfoDao;
    }

    public PhysicalExamInfoDao getPhysicalExamInfoDao() {
        return physicalExamInfoDao;
    }

    public HRVRmssdInfoDao getHRVRmssdDao() {
        return hrvRmssdInfoDao;
    }

    public UltravioletInfoDao getUltravioletDao() {
        return ultravioletInfoDao;
    }

    public PressureInfoDao getPressureDao() {
        return pressureInfoDao;
    }

}
