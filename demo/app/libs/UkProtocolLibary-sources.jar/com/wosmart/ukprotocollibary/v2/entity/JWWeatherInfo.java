package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWWeatherInfo implements Serializable {

    public static final int WEATHER_CODE_OTHER = 0x00;
    public static final int WEATHER_CODE_SUNNY = 0x01;//晴
    public static final int WEATHER_CODE_CLOUDY = 0x02;//多云
    public static final int WEATHER_CODE_OVERCAST = 0x03;//阴天
    public static final int WEATHER_CODE_RAIN = 0x04;//雨
    public static final int WEATHER_CODE_LIGHT_RAIN = 0x05;//小雨
    public static final int WEATHER_CODE_MODERATE_RAIN = 0x06;//中雨
    public static final int WEATHER_CODE_HEAVY_RAIN = 0x07;//大雨
    public static final int WEATHER_CODE_STORM = 0x08;//暴雨
    public static final int WEATHER_CODE_SHOWER_RAIN = 0x09;//阵雨
    public static final int WEATHER_CODE_HEAVY_SHOWER_RAIN = 0x0A;//雷阵雨
    public static final int WEATHER_CODE_FREEZING_RAIN = 0x0B;//冰雹
    public static final int WEATHER_CODE_SNOW = 0x0C;//雪
    public static final int WEATHER_CODE_LIGHT_SNOW = 0x0D;//小雪
    public static final int WEATHER_CODE_MODERATE_SNOW = 0x0E;//中雪
    public static final int WEATHER_CODE_HEAVY_SNOW = 0x0F;//大雪
    public static final int WEATHER_CODE_SLEET = 0x10;//雨夹雪
    public static final int WEATHER_CODE_TYPHOON = 0x11;//台风
    public static final int WEATHER_CODE_SANDSTORM  = 0x12;//沙尘暴
    public static final int WEATHER_CODE_SUNNY_AT_NIGHT = 0x13;//夜间晴
    public static final int WEATHER_CODE_CLOUDY_AT_NIGHT = 0x14;//夜间多云
    public static final int WEATHER_CODE_HOT = 0x15;//热
    public static final int WEATHER_CODE_COLD = 0x16;//冷
    public static final int WEATHER_CODE_BREEZE = 0x17;//微风
    public static final int WEATHER_CODE_GALE = 0x18;//大风
    public static final int WEATHER_CODE_MIST = 0x19;//雾霭
    public static final int WEATHER_CODE_CLOUDY_TO_CLEAR = 0x1A;//多云转晴

    public boolean isOpen;

    public int year;

    public int month;

    public int day;

    public String city;

    public CurrentWeather currentWeather;

    public FutureWeather nextOneDayWeather;

    public FutureWeather nextTwoDayWeather;

    public FutureWeather nextThreeDayWeather;

    public FutureWeather nextFourDayWeather;

    public FutureWeather nextFiveDayWeather;

    public FutureWeather nextSixDayWeather;


    public void setCurrentWeather(int weatherCode, int temperature, int maxTemperature, int minTemperature, int humidity, int ultravioletIntensity, int pollutionIndex) {
        this.currentWeather = new JWWeatherInfo.CurrentWeather();
        this.currentWeather.weatherCode = weatherCode;
        this.currentWeather.temperature = temperature;
        this.currentWeather.maxTemperature = maxTemperature;
        this.currentWeather.minTemperature = minTemperature;
        this.currentWeather.humidity = humidity;
        this.currentWeather.ultravioletIntensity = ultravioletIntensity;
        this.currentWeather.pollutionIndex = pollutionIndex;
    }

    public void setNextOneDayWeather(int weatherCode, int maxTemperature, int minTemperature) {
        this.nextOneDayWeather = new JWWeatherInfo.FutureWeather();
        this.nextOneDayWeather.weatherCode = weatherCode;
        this.nextOneDayWeather.maxTemperature = maxTemperature;
        this.nextOneDayWeather.minTemperature = minTemperature;
    }

    public void setNextTwoDayWeather(int weatherCode, int maxTemperature, int minTemperature) {
        this.nextTwoDayWeather = new JWWeatherInfo.FutureWeather();
        this.nextTwoDayWeather.weatherCode = weatherCode;
        this.nextTwoDayWeather.maxTemperature = maxTemperature;
        this.nextTwoDayWeather.minTemperature = minTemperature;
    }

    public void setNextThreeDayWeather(int weatherCode, int maxTemperature, int minTemperature) {
        this.nextThreeDayWeather = new JWWeatherInfo.FutureWeather();
        this.nextThreeDayWeather.weatherCode = weatherCode;
        this.nextThreeDayWeather.maxTemperature = maxTemperature;
        this.nextThreeDayWeather.minTemperature = minTemperature;
    }

    public void setNextFourDayWeather(int weatherCode, int maxTemperature, int minTemperature) {
        this.nextFourDayWeather = new JWWeatherInfo.FutureWeather();
        this.nextFourDayWeather.weatherCode = weatherCode;
        this.nextFourDayWeather.maxTemperature = maxTemperature;
        this.nextFourDayWeather.minTemperature = minTemperature;
    }

    public void setNextFiveDayWeather(int weatherCode, int maxTemperature, int minTemperature) {
        this.nextFiveDayWeather = new JWWeatherInfo.FutureWeather();
        this.nextFiveDayWeather.weatherCode = weatherCode;
        this.nextFiveDayWeather.maxTemperature = maxTemperature;
        this.nextFiveDayWeather.minTemperature = minTemperature;
    }

    public void setNextSixDayWeather(int weatherCode, int maxTemperature, int minTemperature) {
        this.nextSixDayWeather = new JWWeatherInfo.FutureWeather();
        this.nextSixDayWeather.weatherCode = weatherCode;
        this.nextSixDayWeather.maxTemperature = maxTemperature;
        this.nextSixDayWeather.minTemperature = minTemperature;
    }

    public static class CurrentWeather implements Serializable {

        /**
         * 天气状态码
         */
        public int weatherCode;

        /**
         * unit celsius
         * 当前温度 单位 摄氏度
         */
        public int temperature;

        /**
         * unit celsius
         * 最高温度，单位 摄氏度
         */
        public int maxTemperature;

        /**
         * unit celsius
         * 最低温度，单位 摄氏度
         */
        public int minTemperature;

        /**
         * unit %rh
         * 当前湿度 单位 %rh
         */
        public int humidity;

        /**
         * unit intensity range 1 - 5
         * 当前紫外线强度 1 - 5，越高紫外线越强
         */
        public int ultravioletIntensity;

        /**
         * unit level 1 - 6
         * 当前污染指数 1 - 6，越高污染越严重
         */
        public int pollutionIndex;

        @Override
        public String toString() {
            return "CurrentWeather{" +
                    "weatherCode=" + weatherCode +
                    ", temperature=" + temperature +
                    ", maxTemperature=" + maxTemperature +
                    ", minTemperature=" + minTemperature +
                    ", humidity=" + humidity +
                    ", ultravioletIntensity=" + ultravioletIntensity +
                    ", pollutionIndex=" + pollutionIndex +
                    '}';
        }
    }

    public static class FutureWeather implements Serializable {

        /**
         * 天气状态码
         */
        public int weatherCode;

        /**
         * unit celsius
         * 最高温度，单位 摄氏度
         */
        public int maxTemperature;

        /**
         * unit celsius
         * 最低温度，单位 摄氏度
         */
        public int minTemperature;

        @Override
        public String toString() {
            return "FutureWeather{" +
                    "weatherCode=" + weatherCode +
                    ", maxTemperature=" + maxTemperature +
                    ", minTemperature=" + minTemperature +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "JWWeatherInfo{" +
                "isOpen=" + isOpen +
                ", year=" + year +
                ", month=" + month +
                ", day=" + day +
                ", city='" + city + '\'' +
                ", currentWeather=" + currentWeather +
                ", nextOneDayWeather=" + nextOneDayWeather +
                ", nextTwoDayWeather=" + nextTwoDayWeather +
                ", nextThreeDayWeather=" + nextThreeDayWeather +
                ", nextFourDayWeather=" + nextFourDayWeather +
                ", nextFiveDayWeather=" + nextFiveDayWeather +
                ", nextSixDayWeather=" + nextSixDayWeather +
                '}';
    }
}
