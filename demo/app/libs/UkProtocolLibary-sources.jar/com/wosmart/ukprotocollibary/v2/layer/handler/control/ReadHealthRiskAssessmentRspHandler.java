package com.wosmart.ukprotocollibary.v2.layer.handler.control;

import com.wosmart.ukprotocollibary.v2.entity.function.JWHealthRiskAssessmentInfo;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;


public class ReadHealthRiskAssessmentRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        SendPacketCallback callback = TransportManager.getInstance().getCallbackMap().get(CallbackKeyConstants.KEY_READ_HEALTH_RISK_ASSESSMENT);
        if (callback == null) {
            return;
        }
        if ((data.length < 2) || (data.length % 2) != 0) {
            return;
        }

        JWHealthRiskAssessmentInfo info = new JWHealthRiskAssessmentInfo();
        byte[] subData = new byte[2];
        for (int i = 0; i < data.length / 2; i++) {

            System.arraycopy(data, i * 2, subData, 0, 2);

            int type = subData[0] & 0x0f;
            int value = subData[1] & 0x0f;

            if (type == 0) {
                info.bloodSugarEnable = value != 0;
            } else if (type == 1) {
                info.uricAcidEnable = value != 0;
            } else if (type == 2) {
                info.bloodFatEnable = value != 0;
            }
        }

        callback.onResponse(info);
        TransportManager.getInstance().getCallbackMap().remove(CallbackKeyConstants.KEY_READ_HEALTH_RISK_ASSESSMENT);
    }

}
