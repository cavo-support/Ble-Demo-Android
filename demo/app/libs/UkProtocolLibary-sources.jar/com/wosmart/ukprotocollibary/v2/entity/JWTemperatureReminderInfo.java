package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWTemperatureReminderInfo implements Serializable {

    /**
     * true is open
     */
    public boolean enable;

    /**
     * unit celsius, and range is 37°C - 41.9°C
     */
    public float value;

}
