package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWDeviceInfo implements Serializable {

    /**
     * device number
     * use to different device software
     */
    public int deviceNumber;

    /**
     * device name
     */
    public String deviceName;

    /**
     * device version code example 40043
     */
    public int versionCode;

    /**
     * device version name example 4.4.3
     */
    public String versionName;

    /**
     * font version code
     */
    public int fontVersionCode;

    /**
     * font version name
     */
    public String fontVersionName;

    public int chipType;

    @Override
    public String toString() {
        return "JWDeviceInfo{" +
                "deviceNumber=" + deviceNumber +
                ", deviceName='" + deviceName + '\'' +
                ", versionCode=" + versionCode +
                ", versionName='" + versionName + '\'' +
                ", fontVersionCode=" + fontVersionCode +
                ", fontVersionName='" + fontVersionName + '\'' +
                '}';
    }
}
