package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

public class BodyFatInfo extends BaseHealthDataInfo {

    /**
     * 体重
     */
    public int weight;
    public int weightLevel;
    public int weightMaxLevel;

    /**
     * 身体质量指数 Body Mass Index
     */
    public int bmi;
    public int bmiLevel;
    public int bmiMaxLevel;

    /**
     * 基础代谢率 Basal Metabolic 
     */
    public int bmr;
    public int bmrLevel;
    public int bmrMaxLevel;

    /**
     * 体脂率
     */
    public int bodyFat;
    public int bodyFatLevel;
    public int bodyFatMaxLevel;

    /**
     * 体内水分
     */
    public int bodyWater;
    public int bodyWaterLevel;
    public int bodyWaterMaxLevel;

    /**
     * 蛋白质
     */
    public int protein;
    public int proteinLevel;
    public int proteinMaxLevel;

    /**
     * 骨量
     */
    public int boneMass;
    public int boneMassLevel;
    public int boneMassMaxLevel;

    /**
     * 肌肉率
     */
    public int muscle;
    public int muscleLevel;
    public int muscleMaxLevel;

    public BodyFatInfo() {

    }

    public BodyFatInfo(JWBodyFatInfo info) {
        this.time = info.time;
        this.userID = info.userID;
        this.deviceMac = info.deviceMac;
        this.weight = (int) (info.weight * 10);
        this.weightLevel = info.weightLevel;
        this.bmi = (int) (info.bmi * 10);
        this.bmiLevel = info.bmiLevel;
        this.bmr = (int) (info.bmr * 10);
        this.bmrLevel = info.bmrLevel;
        this.bodyFat = (int) (info.bodyFat * 10);
        this.bodyFatLevel = info.bodyFatLevel;
        this.bodyWater = (int) (info.bodyWater * 10);
        this.bodyWaterLevel = info.bodyWaterLevel;
        this.protein = (int) (info.protein * 10);
        this.proteinLevel = info.proteinLevel;
        this.boneMass = (int) (info.boneMass * 10);
        this.boneMassLevel = info.boneMassLevel;
        this.muscle = (int) (info.muscle * 10);
        this.muscleLevel = info.muscleLevel;
    }

    public JWBodyFatInfo convertToJWBodyFatInfo() {
        JWBodyFatInfo info = new JWBodyFatInfo();
        info.userID = userID;
        info.deviceMac = deviceMac;
        info.time = time;
        info.weight = JWUtils.parserRound(1, weight / 10f);
        info.weightLevel = weightLevel;
        info.weightMaxLevel = weightMaxLevel;
        info.bmi = JWUtils.parserRound(1, bmi / 10f);
        info.bmiLevel = bmiLevel;
        info.bmiMaxLevel = bmiMaxLevel;
        info.bmr = JWUtils.parserRound(1, bmr / 10f);
        info.bmrLevel = bmrLevel;
        info.bmrMaxLevel = bmrMaxLevel;
        info.bodyFat = JWUtils.parserRound(1, bodyFat / 10f);
        info.bodyFatLevel = bodyFatLevel;
        info.bodyFatMaxLevel = bodyFatMaxLevel;
        info.bodyWater = JWUtils.parserRound(1, bodyWater / 10f);
        info.bodyWaterLevel = bodyWaterLevel;
        info.bodyWaterMaxLevel = bodyWaterMaxLevel;
        info.protein = JWUtils.parserRound(1, protein / 10f);
        info.proteinLevel = proteinLevel;
        info.proteinMaxLevel = proteinMaxLevel;
        info.boneMass = JWUtils.parserRound(1, boneMass / 10f);
        info.boneMassLevel = boneMassLevel;
        info.boneMassMaxLevel = boneMassMaxLevel;
        info.muscle = JWUtils.parserRound(1, muscle / 10f);
        info.muscleLevel = muscleLevel;
        info.muscleMaxLevel = muscleMaxLevel;

        return info;
    }

}
