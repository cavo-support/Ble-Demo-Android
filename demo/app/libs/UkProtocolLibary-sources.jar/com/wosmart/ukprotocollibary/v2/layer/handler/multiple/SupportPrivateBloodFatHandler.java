package com.wosmart.ukprotocollibary.v2.layer.handler.multiple;

import com.wosmart.ukprotocollibary.v2.entity.function.JWPrivateBloodFatFunctionInfo;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.TempFunctionInfoListener;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

public class SupportPrivateBloodFatHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length < 5) {
            return;
        }
        TempFunctionInfoListener tempFunctionInfoListener = BaseManager.getInstance().getTempFunctionInfoListener();
        if (tempFunctionInfoListener != null) {
            JWPrivateBloodFatFunctionInfo functionInfo = new JWPrivateBloodFatFunctionInfo();

            functionInfo.enable = (data[0] == 0x01);

            int privateValue = ((data[1] & 0xff) << 8) | (data[2] & 0xff);
            functionInfo.value = JWUtils.parserRound(2, privateValue / 100f);

            tempFunctionInfoListener.onSupportPrivateBloodFat(functionInfo);
        }
    }



}
