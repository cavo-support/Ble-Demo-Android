package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWSpO2Info extends JWHealthData implements Serializable {

    /**
     * current value, unit %
     * 当前血氧 单位百分比
     */
    public int curValue;

    /**
     * high value, unit %
     * 最高血氧 单位百分比
     */
    public int highValue;

    /**
     * low value, unit %
     * 最低血氧 单位百分比
     */
    public int lowValue;


    @Override
    public String toString() {
        return "JWSpO2Info{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", curValue=" + curValue +
                ", highValue=" + highValue +
                ", lowValue=" + lowValue +
                '}';
    }

}
