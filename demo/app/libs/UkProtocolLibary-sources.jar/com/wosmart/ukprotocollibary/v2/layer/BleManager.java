package com.wosmart.ukprotocollibary.v2.layer;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.wosmart.ukprotocollibary.v2.common.JWLog;
import com.wosmart.ukprotocollibary.v2.BaseConstants;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;

import java.lang.reflect.Method;
import java.util.UUID;

import static android.bluetooth.BluetoothDevice.TRANSPORT_LE;

/**
 * 连接流程
 * 1. 发起连接
 * 2. 收到 onConnectionStateChange 成功时发起设置 requestMtu
 * 3. 收到设置成功 mtu 时发起 discoverServices
 * 4. 收到 onServicesDiscovered 成功时判断各服务是否存在
 * 5. 判断各服务存在后，打开 mNotifyCharacteristic 的通知特征描述，这样才能收到消息
 * 6. 收到 onDescriptorWrite 成功回调后后上报认为连接成功
 */
public class BleManager {

    private static final String TAG = "BleManager";

    private static final int DEFAULT_CONNECT_OVER_TIME = 10000;

    private static final int MSG_CONNECT_FAIL = 0x01;
    private static final int MSG_DISCONNECTED = 0x02;
    private static final int MSG_RECONNECT = 0x03;
    private static final int MSG_SET_MTU = 0x04;
    private static final int MSG_DISCOVER_SERVICES = 0x05;
    private static final int MSG_DISCOVER_FAIL = 0x06;
    private static final int MSG_DISCOVER_SUCCESS = 0x07;
    private static final int MSG_CONNECT_OVER_TIME = 0x08;

    private static final int MSG_SEND_DATA_RESULT = 0x09;
    private static final int MSG_SET_MTU_RESULT = 0x0A;
    private static final int MSG_RECEIVE_DATA = 0x0B;



    private BluetoothDevice device;

    private LastState lastState;

    private int connectRetryCount = 0;

    private int setMtuFailedCount = -1;

    private BleGattCallback bleGattCallback;
    private BluetoothGatt bluetoothGatt;

    // UUID
    private final static UUID WRISTBAND_SERVICE_UUID = UUID.fromString("000001ff-3c17-d293-8e48-14fe2e4da212");
    private final static UUID WRISTBAND_WRITE_CHARACTERISTIC_UUID = UUID.fromString("0000ff02-0000-1000-8000-00805f9b34fb");
    private final static UUID WRISTBAND_NOTIFY_CHARACTERISTIC_UUID = UUID.fromString("0000ff03-0000-1000-8000-00805f9b34fb");
    private final static UUID WRISTBAND_NAME_CHARACTERISTIC_UUID = UUID.fromString("0000ff04-0000-1000-8000-00805f9b34fb");
    private final static UUID WRISTBAND_ECG_CHARACTERISTIC_UUID = UUID.fromString("0000FF0A-0000-1000-8000-00805f9b34fb");

    /**
     * Client configuration descriptor that will allow us to enable notifications and indications
     */
    private final static UUID CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private final static UUID CLIENT_CHARACTERISTIC_CONFIG = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private BluetoothGattCharacteristic mWriteCharacteristic;
    private BluetoothGattCharacteristic mNotifyCharacteristic;
    private BluetoothGattCharacteristic mEcgCharacteristic;

    private static final int MTU_SIZE_EXPECT = 247;

    private final MainHandler mainHandler = new MainHandler(Looper.getMainLooper());


    public synchronized void connectDevice(BluetoothDevice device, BleGattCallback callback) {
        this.device = device;
        this.bleGattCallback = callback;
        this.connectRetryCount = 0;
        this.setMtuFailedCount = 0;

        lastState = LastState.CONNECT_CONNECTING;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            bluetoothGatt = device.connectGatt(BaseManager.getInstance().getContext(),
                    false, coreGattCallback, TRANSPORT_LE);
        } else {
            bluetoothGatt = device.connectGatt(BaseManager.getInstance().getContext(),
                    false, coreGattCallback);
        }
        if (bluetoothGatt != null) {
            if (callback != null) {
                callback.onStartConnect();
            }
            Message message = mainHandler.obtainMessage();
            message.what = MSG_CONNECT_OVER_TIME;
            mainHandler.sendMessageDelayed(message, DEFAULT_CONNECT_OVER_TIME);

        } else {
            disconnectGatt();
            refreshDeviceCache();
            closeBluetoothGatt();
            lastState = LastState.CONNECT_FAILURE;
            if (callback != null) {
                callback.onConnectFail(BaseConstants.ERR_CONNECT_DEVICE_FAILED, "GATT connect exception occurred!");
            }

        }
    }

    public synchronized void disconnect() {
        disconnectGatt();
    }

    public synchronized void destroy() {
        lastState = LastState.CONNECT_IDLE;
        disconnectGatt();
        refreshDeviceCache();
        closeBluetoothGatt();
        mainHandler.removeCallbacksAndMessages(null);
    }

    /**
     * write
     */
    public boolean writeData(byte[] data) {
        if (data == null || data.length <= 0) {
            return false;
        }

        if (mWriteCharacteristic == null
                || (mWriteCharacteristic.getProperties() & (BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) == 0) {
            JWLog.e(TAG, "this characteristic not support write!");
            return false;
        }

        if (!mWriteCharacteristic.setValue(data)) {
            JWLog.e(TAG, "Updates the locally stored value of this characteristic fail");
            return false;
        }
        boolean result = bluetoothGatt.writeCharacteristic(mWriteCharacteristic);
        if (!result) {
            JWLog.e(TAG, "gatt writeCharacteristic fail");
        }
        return result;
    }

    private synchronized void disconnectGatt() {
        if (bluetoothGatt != null) {
            bluetoothGatt.disconnect();
        }
    }

    private synchronized void refreshDeviceCache() {
        try {
            final Method refresh = BluetoothGatt.class.getMethod("refresh");
            if (bluetoothGatt != null) {
                refresh.invoke(bluetoothGatt);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private synchronized void closeBluetoothGatt() {
        if (bluetoothGatt != null) {
            bluetoothGatt.close();
        }
    }

    private final class MainHandler extends Handler {

        MainHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_CONNECT_FAIL: {
                    disconnectGatt();
                    refreshDeviceCache();
                    closeBluetoothGatt();

                    if (connectRetryCount < 3) {
                        JWLog.e(TAG, "Connect fail, try reconnect " + 1000 + " millisecond later");
                        ++connectRetryCount;

                        Message message = mainHandler.obtainMessage();
                        message.what = MSG_RECONNECT;
                        mainHandler.sendMessageDelayed(message, 1000);
                    } else {
                        lastState = LastState.CONNECT_FAILURE;

                        if (bleGattCallback != null) {
                            bleGattCallback.onConnectFail(BaseConstants.ERR_CONNECT_DEVICE_FAILED, "connect device failed");
                        }

                    }
                }
                break;

                case MSG_DISCONNECTED: {
                    lastState = LastState.CONNECT_DISCONNECT;

                    disconnect();
                    refreshDeviceCache();
                    closeBluetoothGatt();
                    mainHandler.removeCallbacksAndMessages(null);

                    if (bleGattCallback != null) {
                        bleGattCallback.onDisConnected();
                    }

                }
                break;

                case MSG_RECONNECT: {
                    connectDevice(device, bleGattCallback);
                }
                break;

                case MSG_SET_MTU: {
                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
                        if (setMtuFailedCount != -1 && bluetoothGatt != null) {
                            setMtuFailedCount++;
                            int mtu = MTU_SIZE_EXPECT - 40 * setMtuFailedCount;
                            if (mtu < 20) {
                                mtu = 20;
                            }
                            JWLog.i(TAG, "Attempting to request mtu size check check , expect mtu size is: " + mtu);
                            bluetoothGatt.requestMtu(mtu);
                            if (mtu != 20) {
                                mainHandler.sendEmptyMessageDelayed(MSG_SET_MTU, 2000);
                            }
                        }
                    }
                }
                break;

                case MSG_CONNECT_OVER_TIME: {
                    disconnectGatt();
                    refreshDeviceCache();
                    closeBluetoothGatt();

                    lastState = LastState.CONNECT_FAILURE;

                    if (bleGattCallback != null) {
                        bleGattCallback.onConnectFail(BaseConstants.ERR_CONNECT_DEVICE_TIMEOUT, "connect device timeout");
                    }

                }
                break;

                case MSG_DISCOVER_SERVICES: {
                    if (bluetoothGatt != null) {
                        boolean discoverServiceResult = bluetoothGatt.discoverServices();
                        if (!discoverServiceResult) {
                            mainHandler.sendEmptyMessage(MSG_DISCOVER_FAIL);
                        }
                    } else {
                        mainHandler.sendEmptyMessage(MSG_DISCOVER_FAIL);
                    }
                }
                break;

                case MSG_DISCOVER_FAIL: {
                    disconnectGatt();
                    refreshDeviceCache();
                    closeBluetoothGatt();

                    lastState = LastState.CONNECT_FAILURE;

                    if (bleGattCallback != null) {
                        bleGattCallback.onConnectFail(BaseConstants.ERR_UN_FIND_SERVICE, "GATT discover services exception occurred!");
                    }

                }
                break;

                case MSG_DISCOVER_SUCCESS: {
                    lastState = LastState.CONNECT_CONNECTED;

                    if (bleGattCallback != null) {
                        bleGattCallback.onConnectSuccess();
                    }
                }
                break;

                case MSG_SET_MTU_RESULT: {
                    if (bleGattCallback != null) {
                        bleGattCallback.onMtuChanged(msg.arg1);
                    }
                }
                case MSG_SEND_DATA_RESULT: {
                    if (bleGattCallback != null) {
                        bleGattCallback.onDataSend(msg.arg1 == BluetoothGatt.GATT_SUCCESS);
                    }
                }
                break;
                case MSG_RECEIVE_DATA: {
                    if (bleGattCallback != null) {
                        bleGattCallback.onDataReceived((byte[]) msg.obj);
                    }
                }
                break;

                default:
                    super.handleMessage(msg);
                    break;
            }
        }
    }

    private final BluetoothGattCallback coreGattCallback = new BluetoothGattCallback() {

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);
            JWLog.i(TAG, "BluetoothGattCallback：onConnectionStateChange "
                    + '\n' + "status: " + status
                    + '\n' + "newState: " + newState
                    + '\n' + "currentThread: " + Thread.currentThread().getId());

            bluetoothGatt = gatt;

            mainHandler.removeMessages(MSG_CONNECT_OVER_TIME);

            if (newState == BluetoothProfile.STATE_CONNECTED) {

                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
                    gatt.requestMtu(MTU_SIZE_EXPECT);
                    mainHandler.sendEmptyMessageDelayed(MSG_SET_MTU, 2000);
                } else {
                    mainHandler.sendEmptyMessageDelayed(MSG_DISCOVER_SERVICES, 100);
                }

            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                if (lastState == LastState.CONNECT_CONNECTING) {
                    mainHandler.sendEmptyMessage(MSG_CONNECT_FAIL);

                } else if (lastState == LastState.CONNECT_CONNECTED) {
                    mainHandler.sendEmptyMessage(MSG_DISCONNECTED);
                }
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);
            JWLog.i(TAG, "BluetoothGattCallback：onServicesDiscovered "
                    + '\n' + "status: " + status
                    + '\n' + "currentThread: " + Thread.currentThread().getName());

            bluetoothGatt = gatt;

            if (status != BluetoothGatt.GATT_SUCCESS) {
                mainHandler.sendEmptyMessage(MSG_DISCOVER_FAIL);
                return;
            }

            BluetoothGattService service = gatt.getService(WRISTBAND_SERVICE_UUID);

            if (service == null) {
                JWLog.e(TAG, "WRISTBAND_SERVICE_UUID not supported");
                mainHandler.sendEmptyMessage(MSG_DISCOVER_FAIL);
                return;
            }
            mEcgCharacteristic = service.getCharacteristic(WRISTBAND_ECG_CHARACTERISTIC_UUID);
            mWriteCharacteristic = service.getCharacteristic(WRISTBAND_WRITE_CHARACTERISTIC_UUID);
            mNotifyCharacteristic = service.getCharacteristic(WRISTBAND_NOTIFY_CHARACTERISTIC_UUID);
            if (mWriteCharacteristic == null) {
                JWLog.e(TAG, "WRISTBAND_WRITE_CHARACTERISTIC_UUID not supported");
                mainHandler.sendEmptyMessage(MSG_DISCOVER_FAIL);
                return;
            }
            if (mNotifyCharacteristic == null) {
                JWLog.e(TAG, "WRISTBAND_SERVICE_UUID not supported");
                mainHandler.sendEmptyMessage(MSG_DISCOVER_FAIL);
                return;
            }
            // 开启 notify 特征的描述以接收数据
            if (!gatt.setCharacteristicNotification(mNotifyCharacteristic, true)) {
                JWLog.e(TAG, "setNotifyCharacteristic failed ");
                mainHandler.sendEmptyMessage(MSG_DISCOVER_FAIL);
                return;

            }
            JWLog.d(TAG, "setNotifyCharacteristic success");

            // 等待写入成功回调，如果成功，即连接成功
            boolean setNotifyCharacteristicResult = setCharacteristicNotification(mNotifyCharacteristic);
            if (!setNotifyCharacteristicResult) {
                JWLog.e(TAG, "setNotifyCharacteristic descriptor not found, uuid = " + CLIENT_CHARACTERISTIC_CONFIG.toString());
                mainHandler.sendEmptyMessage(MSG_DISCOVER_FAIL);
                return;
            }

            if (mEcgCharacteristic != null) {
                // 如果有 ecg 特征，直接打开
                setCharacteristicNotification(mEcgCharacteristic);
            }
        }

        private boolean setCharacteristicNotification(BluetoothGattCharacteristic characteristic) {
            BluetoothGattDescriptor descriptor = characteristic.getDescriptor(CLIENT_CHARACTERISTIC_CONFIG);
            if (descriptor == null) {
                JWLog.e(TAG, "setNotifyCharacteristic descriptor not found, uuid = " + CLIENT_CHARACTERISTIC_CONFIG.toString());
                return false;
            }
            boolean setDescriptorResult = descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            boolean writeDescriptorResult = bluetoothGatt.writeDescriptor(descriptor);
            JWLog.i(TAG, "setNotifyCharacteristic, uuid = " + characteristic.getUuid().toString() + ", setDescriptorResult = " + setDescriptorResult + ", writeDescriptorResult = " + writeDescriptorResult);
            return setDescriptorResult && writeDescriptorResult;
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);

            byte[] data = characteristic.getValue();
            if (WRISTBAND_NOTIFY_CHARACTERISTIC_UUID.equals(characteristic.getUuid())) {
                // 收到通信数据
                Message message = mainHandler.obtainMessage();
                message.what = MSG_RECEIVE_DATA;
                message.obj = data;
                mainHandler.sendMessage(message);
            } else if (WRISTBAND_ECG_CHARACTERISTIC_UUID.equals(characteristic.getUuid())) {
                // 收到 ecg 数据
            }
        }


        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);
            if (WRISTBAND_WRITE_CHARACTERISTIC_UUID.equals(characteristic.getUuid())) {
                // 数据发送回调
                Message message = mainHandler.obtainMessage();
                message.what = MSG_SEND_DATA_RESULT;
                message.arg1 = status;

                mainHandler.sendMessage(message);
            }

        }


        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicRead(gatt, characteristic, status);
            if (WRISTBAND_NAME_CHARACTERISTIC_UUID.equals(characteristic.getUuid())) {
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    String name = characteristic.getStringValue(0);
                    JWLog.d(TAG, "device name = " + name);
                }
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorWrite(gatt, descriptor, status);
            if (status != BluetoothGatt.GATT_SUCCESS) {
                JWLog.e(TAG, "descriptor write error: " + status);
                mainHandler.sendEmptyMessage(MSG_DISCOVER_FAIL);
                return;
            }
            if (CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR_UUID.equals(descriptor.getUuid())) {
                if (descriptor.getCharacteristic().getUuid().equals(mNotifyCharacteristic.getUuid())) {
                    boolean enabled = descriptor.getValue()[0] == 1;
                    if (enabled) {
                        // 至此认为连接成功
                        mainHandler.sendEmptyMessage(MSG_DISCOVER_SUCCESS);
                    } else {
                        JWLog.e(TAG, "notification  not enabled!!!");
                        mainHandler.sendEmptyMessage(MSG_DISCOVER_FAIL);
                    }
                }
            }
        }

        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            super.onMtuChanged(gatt, mtu, status);
            JWLog.e(TAG, "onMtuChanged mtu = " + mtu);
            if (status != BluetoothGatt.GATT_SUCCESS) {
                // 设置不成功，再设置小一点
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
                    if (setMtuFailedCount != -1 && bluetoothGatt != null) {
                        setMtuFailedCount++;
                        int newMtu = MTU_SIZE_EXPECT - 40 * setMtuFailedCount;
                        if (newMtu < 20) {
                            newMtu = 20;
                        }
                        JWLog.i(TAG, "Attempting to request mtu size check check , expect mtu size is: " + newMtu);
                        bluetoothGatt.requestMtu(newMtu);
                        if (newMtu != 20) {
                            mainHandler.sendEmptyMessageDelayed(MSG_SET_MTU, 2000);
                        }
                    }
                }
                return;
            }
            setMtuFailedCount = -1;

            mainHandler.sendEmptyMessage(MSG_DISCOVER_SERVICES);

            Message message = mainHandler.obtainMessage();
            message.what = MSG_SET_MTU_RESULT;
            message.arg1 = mtu;

            mainHandler.sendMessage(message);
        }
    };

    enum LastState {
        CONNECT_IDLE,
        CONNECT_CONNECTING,
        CONNECT_CONNECTED,
        CONNECT_FAILURE,
        CONNECT_DISCONNECT
    }

    private static class BleManagerHolder {
        private static final BleManager bleManager = new BleManager();
    }

    public static BleManager getInstance() {
        return BleManager.BleManagerHolder.bleManager;
    }


}
