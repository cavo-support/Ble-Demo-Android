package com.wosmart.ukprotocollibary.v2.common.executor;


import java.util.concurrent.Executor;

/**
 * A static class that serves as a central point to execute common tasks.
 * <p>
 *
 * @hide This API is not final.
 */
public class JWArchTaskExecutor extends JWTaskExecutor {
    private static volatile JWArchTaskExecutor sInstance;

    private JWTaskExecutor mDelegate;

    private JWTaskExecutor mDefaultTaskExecutor;

    private static final Executor sMainThreadExecutor = new Executor() {
        @Override
        public void execute(Runnable command) {
            getInstance().postToMainThread(command);
        }
    };

    private static final Executor sIOThreadExecutor = new Executor() {
        @Override
        public void execute(Runnable command) {
            getInstance().executeOnDiskIO(command);
        }
    };

    private JWArchTaskExecutor() {
        mDefaultTaskExecutor = new JWDefaultTaskExecutor();
        mDelegate = mDefaultTaskExecutor;
    }

    /**
     * Returns an instance of the task executor.
     *
     * @return The singleton ArchTaskExecutor.
     */
    public static JWArchTaskExecutor getInstance() {
        if (sInstance != null) {
            return sInstance;
        }
        synchronized (JWArchTaskExecutor.class) {
            if (sInstance == null) {
                sInstance = new JWArchTaskExecutor();
            }
        }
        return sInstance;
    }

    /**
     * Sets a delegate to handle task execution requests.
     * <p>
     * If you have a common executor, you can set it as the delegate and App Toolkit components will
     * use your executors. You may also want to use this for your tests.
     * <p>
     * Calling this method with {@code null} sets it to the default TaskExecutor.
     *
     * @param taskExecutor The task executor to handle task requests.
     */
    public void setDelegate(JWTaskExecutor taskExecutor) {
        mDelegate = taskExecutor == null ? mDefaultTaskExecutor : taskExecutor;
    }

    @Override
    public void executeOnDiskIO(Runnable runnable) {
        mDelegate.executeOnDiskIO(runnable);
    }

    @Override
    public void postToMainThread(Runnable runnable) {
        mDelegate.postToMainThread(runnable);
    }

    @Override
    public void postToMainThread(Runnable runnable, long delayMillis) {
        mDelegate.postToMainThread(runnable, delayMillis);
    }

    @Override
    public void postToMainThread(Runnable runnable, Object token, long delayMillis) {
        mDelegate.postToMainThread(runnable, token, delayMillis);
    }

    @Override
    public void removeCallbackFromMainThread(Object token) {
        mDelegate.removeCallbackFromMainThread(token);
    }

    public static Executor getMainThreadExecutor() {
        return sMainThreadExecutor;
    }

    public static Executor getIOThreadExecutor() {
        return sIOThreadExecutor;
    }

    @Override
    public boolean isMainThread() {
        return mDelegate.isMainThread();
    }
}

