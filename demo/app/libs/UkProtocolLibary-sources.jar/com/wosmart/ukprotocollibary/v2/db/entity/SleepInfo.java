package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWSleepInfo;

public class SleepInfo extends BaseHealthDataInfo {

    public int mode;

    public SleepInfo(long time, String userID, String mac, int mode) {
        this.time = time;
        this.userID = userID;
        this.deviceMac = mac;
        this.mode = mode;
    }

    public SleepInfo(JWSleepInfo info) {
        this.time = info.getTime();
        this.userID = info.getUserID();
        this.deviceMac = info.deviceMac;
        this.mode = info.getMode();
    }

    public JWSleepInfo convertToJWSleepInfo() {
        JWSleepInfo info = new JWSleepInfo();
        info.setUserID(userID);
        info.deviceMac = deviceMac;
        info.setTime(time);
        info.setMode(mode);

        return info;
    }

}
