package com.wosmart.ukprotocollibary.v2.entity;

public class JWDeviceIndependentSwitchInfo {

    public static final int TYPE_TIME_FORMAT = 0;// 12 hour or 24 hour a day
    public static final int TYPE_LANGUAGE_SELECTION = 1;
    public static final int TYPE_HEART_RATE_MONITOR = 2;
    public static final int TYPE_BLOOD_PRESSURE_MONITOR = 3;
    public static final int TYPE_SPO2_MONITOR = 4;
    public static final int TYPE_TEMPERATURE_MONITOR = 5;
    public static final int TYPE_TEMPERATURE_ADJUST = 6;
    public static final int TYPE_TEMPERATURE_INDEPENDENT = 7;// does not rely on heart rate measurement
    public static final int TYPE_BLOOD_SUGAR_MONITOR = 8;
    public static final int TYPE_TURN_WRIST = 9;// rotate the wrist to turn on the screen


    public int type;

    public boolean enable;


}
