package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWHRVRmssdConfigInfo implements Serializable {

    /**
     * true is open
     */
    public boolean enable;


    /**
     * only support 5 min/times 10 min/times 15 min/times
     */
    public int interval;


}
