package com.wosmart.ukprotocollibary.v2.layer.handler.multiple;

import com.wosmart.ukprotocollibary.v2.entity.function.JWPrivateUricAcidFunctionInfo;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.TempFunctionInfoListener;

public class SupportPrivateUricAcidHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length < 5) {
            return;
        }
        TempFunctionInfoListener tempFunctionInfoListener = BaseManager.getInstance().getTempFunctionInfoListener();
        if (tempFunctionInfoListener != null) {
            JWPrivateUricAcidFunctionInfo functionInfo = new JWPrivateUricAcidFunctionInfo();

            functionInfo.enable = (data[0] == 0x01);
            functionInfo.value = ((data[1] & 0xff) << 8) | (data[2] & 0xff);

            tempFunctionInfoListener.onSupportPrivateUricAcid(functionInfo);
        }
    }



}
