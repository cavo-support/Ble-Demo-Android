package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateVariabilityInfo;

public class HeartRateVariabilityInfo extends BaseHealthDataInfo {

    public int value;

    public HeartRateVariabilityInfo(long time, String userID, String mac, int value) {
        this.time = time;
        this.userID = userID;
        this.deviceMac = mac;
        this.value = value;
    }

    public HeartRateVariabilityInfo(JWHeartRateVariabilityInfo info) {
        this.time = info.getTime();
        this.userID = info.getUserID();
        this.deviceMac = info.deviceMac;
        this.value = info.value;
    }

    public JWHeartRateVariabilityInfo convertToJWHrvInfo() {
        JWHeartRateVariabilityInfo info = new JWHeartRateVariabilityInfo();
        info.setUserID(userID);
        info.deviceMac = deviceMac;
        info.setTime(time);
        info.value = (value);

        return info;
    }

}
