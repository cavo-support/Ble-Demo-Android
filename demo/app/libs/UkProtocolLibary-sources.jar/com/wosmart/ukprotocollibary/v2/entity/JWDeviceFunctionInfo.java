package com.wosmart.ukprotocollibary.v2.entity;


import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodFatFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodSugarCycleFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWPrivateBloodFatFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWPrivateUricAcidFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWUricAcidFunctionInfo;

public class JWDeviceFunctionInfo {

    /**
     * earphone--通话耳机
     */
    public boolean earPhone;

    /**
     * bp measure--血压手动测试
     */
    public boolean bpDetection;

    /**
     * rate auto detection--心率
     */
    public boolean rate;

    /**
     * disturb mode setting--勿扰模式
     */
    public boolean disturb;

    /**
     * step recorder--计步
     */
    public boolean step;

    /**
     * sleep detection--睡眠
     */
    public boolean sleep;

    /**
     * wechat run--微信运动
     */
    public boolean weChatRun;

    /**
     * light duration setting--亮屏时长
     */
    public boolean lightDuration;

    /**
     * notify reminder setting--消息提醒
     */
    public boolean notifyReminder;

    /**
     * screen theme setting--主界面切换
     */
    public boolean screenTheme;

    /**
     * turn wrist light display setting--转腕亮屏
     */
    public boolean turnLight;

    /**
     * multi language--多国语言
     */
    public boolean multiLanguage;

    /**
     * hour system setting--小时制
     */
    public boolean hourSystem;

    /**
     * unit system setting--公英制
     */
    public boolean unitSystem;

    /**
     * ota
     */
    public boolean ota;

    /**
     * nfc
     */
    public boolean nfc;

    /**
     * multi sport--多运动模式
     */
    public boolean multiSport;

    /**
     * step watch setting--秒表
     */
    public boolean stepWatch;

    /**
     * count down setting--倒计时
     */
    public boolean countDown;

    /**
     * rate reminder setting--心率提醒
     */
    public boolean rateReminder;

    /**
     * camera control--遥控拍照
     */
    public boolean cameraControl;

    /**
     * find phone--查找手机
     */
    public boolean findPhone;

    /**
     * find device--查找手环
     */
    public boolean findDevice;

    /**
     * screen light percent setting--亮度控制
     */
    public boolean lightControl;

    /**
     * control phone music--音乐控制
     */
    public boolean musicControl;

    /**
     * control phone volume--音量控制
     */
    public boolean volumeControl;

    /**
     * alarm setting--智能闹钟
     */
    public boolean alarm;

    /**
     * long sit reminder--久坐提醒
     */
    public boolean longSitReminder;

    /**
     * event reminder--事件提醒
     */
    public boolean eventReminder;

    /**
     * auto lock screen--锁屏防触
     */
    public boolean autoLock;


    /**
     * measure rate every seconds--实时心率上传
     * App运动时心率检测
     */
    public boolean appSportRateDetect;

    /**
     * base switch--隐藏功能菜单
     * 基础开关
     */
    public boolean baseSwitch;
    /**
     * today total step and step adjust--当天计步校准
     * 今日数据校准
     */
    public boolean todayAdjust;

    /**
     * today sleep adjust--当天睡眠校准
     * 睡眠数据校准
     */
    public boolean sleepAdjust;

    /**
     * temperature--温度检测
     */
    public boolean temperature;

    /**
     * bp 2.0 --血压
     */
    public boolean bp2;

    /**
     * alarm 2.0 --闹钟
     */
    public boolean alarm2;


    /**
     * custom ui --自定义主界面
     */
    public boolean customUi;

    /**
     * download ui --下载主界面
     */
    public boolean downloadUi;

    /**
     * spo2 measure --血氧测量
     */
    public boolean spo2Measure;

    /**
     * mode1 mode3 升级--显示字库升级
     */
    public boolean modeUpgrade;

    /**
     * sleep quality --第二版本睡眠质量判断
     */
    public boolean sleepQuality2;

    /**
     * sport rate --App运动心率2.0
     */
    public boolean sportRate2;

    /**
     * 心率温度压力数据返回
     */
    public boolean rateTempPressure;
    /**
     * 连续血氧
     */
    public boolean spo2Continuous;

    /**
     * 心电功能
     */
    public boolean ecgFunction;

    /**
     * 同步设备状态
     */
    public boolean deviceStateSync;

    /**
     * 通讯录功能
     */
    public boolean addressBook;

    /**
     * Hrv功能
     */
    public boolean rtkHrv;

    /**
     * 血压3.0
     */
    public boolean rtkBp3;

    /**
     * 血糖功能
     */
    public boolean bloodSugar;

    /**
     * 低氧提醒功能
     */
    public boolean hypoxia;

    /**
     * 心率过高功能
     */
    public boolean highHrv;

    /**
     * 全天睡眠功能
     */
    public boolean sleepAll;

    /**
     * 日期格式功能
     */
    public boolean deviceDateFormat;


    /**
     * 尿酸连续监测功能
     */
    public boolean uricAcidContinuousMonitoring;

    /**
     * 血脂连续监测功能
     */
    public boolean bloodFatContinuousMonitoring;

    /**
     * 私人血压
     */
    public JWPrivateBloodPressureInfo privateBloodPressure;

    /**
     * SOS
     */
    public boolean sosNumber;

    /**
     * 体温提醒
     */
    public JWTemperatureReminderInfo temperatureReminder;

    /**
     * 喝水提醒
     */
    public JWDrinkWaterReminderInfo drinkWaterReminder;

    /**
     * 吃药提醒
     */
    public boolean medicationReminder;

    /**
     * 脉冲
     */
    public boolean pulse;

    /**
     * 睡眠辅助
     */
    public boolean sleepHelp;

    /**
     * 桑拿
     */
    public boolean sauna;

    /**
     * 女性健康
     */
    public boolean femaleHealth;

    /**
     * 天气
     */
    public boolean weather;

    /**
     * 穿戴时长
     */
    public boolean wearingTime;

    /**
     * 尿酸
     */
    public JWUricAcidFunctionInfo uricAcid;

    /**
     * 血脂
     */
    public JWBloodFatFunctionInfo bloodFat;

    /**
     * 血糖
     */
    public JWBloodSugarCycleFunctionInfo bloodSugarCycle;

    /**
     * 私人血脂
     */
    public JWPrivateUricAcidFunctionInfo privateUricAcid;

    /**
     * 私人尿酸
     */
    public JWPrivateBloodFatFunctionInfo privateBloodFat;

    /**
     * 体脂
     */
    public boolean bodyFat;

    /**
     * 体检
     */
    public boolean physicalExam;

    /**
     * 紫外线
     */
    public boolean ultraviolet;

    /**
     * ecg 隐藏 qt 和 hrv
     */
    public boolean hideQTAndHrv;

    /**
     * 心电带
     */
    public boolean ecgBelt;

    /**
     * 隐藏健康功能
     */
    public boolean hideHealthFunction;

    /**
     * 压力
     */
    public boolean pressure;



    @Override
    public String toString() {
        return "JWDeviceFunctionInfo{" +
                "earPhone=" + earPhone +
                ", bpDetection=" + bpDetection +
                ", rate=" + rate +
                ", disturb=" + disturb +
                ", step=" + step +
                ", sleep=" + sleep +
                ", weChatRun=" + weChatRun +
                ", lightDuration=" + lightDuration +
                ", notifyReminder=" + notifyReminder +
                ", screenTheme=" + screenTheme +
                ", turnLight=" + turnLight +
                ", multiLanguage=" + multiLanguage +
                ", hourSystem=" + hourSystem +
                ", unitSystem=" + unitSystem +
                ", ota=" + ota +
                ", nfc=" + nfc +
                ", multiSport=" + multiSport +
                ", stepWatch=" + stepWatch +
                ", countDown=" + countDown +
                ", rateReminder=" + rateReminder +
                ", cameraControl=" + cameraControl +
                ", findPhone=" + findPhone +
                ", findDevice=" + findDevice +
                ", lightControl=" + lightControl +
                ", musicControl=" + musicControl +
                ", volumeControl=" + volumeControl +
                ", alarm=" + alarm +
                ", longSitReminder=" + longSitReminder +
                ", eventReminder=" + eventReminder +
                ", autoLock=" + autoLock +
                ", appSportRateDetect=" + appSportRateDetect +
                ", baseSwitch=" + baseSwitch +
                ", todayAdjust=" + todayAdjust +
                ", sleepAdjust=" + sleepAdjust +
                ", temperature=" + temperature +
                ", bp2=" + bp2 +
                ", alarm2=" + alarm2 +
                ", customUi=" + customUi +
                ", downloadUi=" + downloadUi +
                ", spo2Measure=" + spo2Measure +
                ", modeUpgrade=" + modeUpgrade +
                ", sleepQuality2=" + sleepQuality2 +
                ", sportRate2=" + sportRate2 +
                ", rateTempPressure=" + rateTempPressure +
                ", spo2Continuous=" + spo2Continuous +
                ", ecgFunction=" + ecgFunction +
                ", deviceStateSync=" + deviceStateSync +
                ", addressBook=" + addressBook +
                ", rtkHrv=" + rtkHrv +
                ", rtkBp3=" + rtkBp3 +
                ", glu=" + bloodSugar +
                ", hypoxia=" + hypoxia +
                ", highHrv=" + highHrv +
                ", sleepAll=" + sleepAll +
                ", deviceDateFormat=" + deviceDateFormat +
                ", privateBloodPressure=" + privateBloodPressure +
                ", sosNumber=" + sosNumber +
                ", temperatureReminder=" + temperatureReminder +
                ", drinkWaterReminder=" + drinkWaterReminder +
                ", medicationReminder=" + medicationReminder +
                ", pulse=" + pulse +
                ", sleepHelp=" + sleepHelp +
                ", sauna=" + sauna +
                ", femaleHealth=" + femaleHealth +
                ", weather=" + weather +
                ", wearingTime=" + wearingTime +
                ", uricAcid=" + uricAcid +
                ", bloodFat=" + bloodFat +
                ", bloodSugarCycle=" + bloodSugarCycle +
                ", privateUricAcid=" + privateUricAcid +
                ", privateBloodFat=" + privateBloodFat +
                ", bodyFat=" + bodyFat +
                ", physicalExam=" + physicalExam +
                ", ultraviolet=" + ultraviolet +
                ", hideQTAndHrv=" + hideQTAndHrv +
                ", ecgBelt=" + ecgBelt +
                ", hideHealthFunction=" + hideHealthFunction +
                ", pressure=" + pressure +
                '}';
    }
}
