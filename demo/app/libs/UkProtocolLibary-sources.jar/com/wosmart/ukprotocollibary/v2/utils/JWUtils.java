package com.wosmart.ukprotocollibary.v2.utils;

import java.math.BigDecimal;

public class JWUtils {




    public static float parserRound(int newScale, float f) {
        if (f == 0) {
            return 0;
        }
        BigDecimal bg = new BigDecimal(f).setScale(newScale, BigDecimal.ROUND_HALF_UP);
        return bg.floatValue();
    }


}
