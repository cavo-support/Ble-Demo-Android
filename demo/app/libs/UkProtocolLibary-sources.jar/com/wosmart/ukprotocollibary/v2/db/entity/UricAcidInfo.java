package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWCycleDayStatus;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidInfo;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class UricAcidInfo extends BaseHealthDataInfo {

    public long cycleStartTime;

    public long cycleEndTime;

    public long valueTime;

    public int evaluationResult;

    public int dayStatusList;

    public UricAcidInfo() {

    }

    public UricAcidInfo(long valueTime, String userID, String mac, long cycleStartTime, long cycleEndTime, int evaluationResult, int dayStatusList) {
        this.valueTime = valueTime;
        this.userID = userID;
        this.deviceMac = mac;
        this.cycleStartTime = cycleStartTime;
        this.cycleEndTime = cycleEndTime;
        this.evaluationResult = evaluationResult;
        this.dayStatusList = dayStatusList;
    }

    public UricAcidInfo(JWUricAcidInfo info) {
        this.userID = info.userID;
        this.deviceMac = info.deviceMac;
        this.cycleStartTime = info.cycleStartTime;
        this.cycleEndTime = info.cycleEndTime;
        this.valueTime = info.valueTime;
        this.evaluationResult = info.evaluationResult;

        if (info.dayStatusList != null && !info.dayStatusList.isEmpty()) {
            int status = 0;
            for (int i = 0; i < info.dayStatusList.size(); i++) {
                JWCycleDayStatus dayStatus = info.dayStatusList.get(i);
                if (dayStatus.night == JWCycleDayStatus.VALID) {
                    status |= (1 << i * 2);
                }
                if (dayStatus.day == JWCycleDayStatus.VALID) {
                    status |= (1 << (i * 2 + 1));
                }
            }
            this.dayStatusList = status;
        }
    }

    public JWUricAcidInfo convertToJWUricAcidInfo() {
        JWUricAcidInfo info = new JWUricAcidInfo();

        info.userID = userID;
        info.deviceMac = deviceMac;
        info.cycleStartTime = this.cycleStartTime;
        info.cycleEndTime = this.cycleEndTime;
        info.valueTime = this.valueTime;
        info.evaluationResult = this.evaluationResult;

        List<JWCycleDayStatus> dayStatusArr = new ArrayList<>();

        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(cycleStartTime);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);

        // 获取开始日期的 0 点时间
        long zeroTime = cal.getTimeInMillis();

        long oneDayTime = 24 * 3600000 - 60000;

        for (int i = 0; i < 14; i++) {
            JWCycleDayStatus dayStatus = new JWCycleDayStatus();

            dayStatus.night = ((1 << (i * 2)) & this.dayStatusList) == 0 ? 0 : 1;
            dayStatus.day = ((1 << i * 2 + 1) & this.dayStatusList) == 0 ? 0 : 1;

            dayStatus.time = zeroTime + oneDayTime * (i + 1);

            dayStatusArr.add(dayStatus);
        }

        info.dayStatusList = dayStatusArr;
        return info;
    }

    public static List<JWCycleDayStatus> convertDayStatusList(long cycleStartTime, int dayStatusList) {
        List<JWCycleDayStatus> dayStatusArr = new ArrayList<>();

        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTimeInMillis(cycleStartTime);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);

        // 获取开始日期的 0 点时间
        long zeroTime = cal.getTimeInMillis();

        long oneDayTime = 24 * 3600000 - 60000;

        for (int i = 0; i < 14; i++) {
            JWCycleDayStatus dayStatus = new JWCycleDayStatus();

            dayStatus.night = ((1 << (i * 2)) & dayStatusList) == 0 ? 0 : 1;
            dayStatus.day = ((1 << i * 2 + 1) & dayStatusList) == 0 ? 0 : 1;

            dayStatus.time = zeroTime + oneDayTime * (i + 1);

            dayStatusArr.add(dayStatus);
        }

        return dayStatusArr;
    }

    public static int convertDayStatusList(List<JWCycleDayStatus> dayStatusList) {
        if (dayStatusList == null || dayStatusList.isEmpty()) {
            return 0;
        }
        int status = 0;
        for (int i = 0; i < dayStatusList.size(); i++) {
            JWCycleDayStatus dayStatus = dayStatusList.get(i);
            if (dayStatus.night == JWCycleDayStatus.VALID) {
                status |= (1 << i * 2);
            }
            if (dayStatus.day == JWCycleDayStatus.VALID) {
                status |= (1 << (i * 2 + 1));
            }
        }
        return status;
    }

}
