package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;

public interface JWFunctionListener {

    void onTakePhoto();

    void onFindPhone(boolean isOpen);

    /**
     * 设备测试状态改变
     *
     * @param status 0 取消测试 canceled
     *               1 测试失败 failed
     *               2 测试成功 success
     */
    void onDeviceMeasureStatusUpdated(int status);

    /**
     * 收到体脂数据
     */
    void onBodyFatDataReceived(JWBodyFatInfo bodyFat);

    /**
     * 收到体检数据
     */
    void onPhysicalExamDataReceived(JWPhysicalExamInfo physicalExam);

}
