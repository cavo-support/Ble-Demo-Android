package com.wosmart.ukprotocollibary.v2.common;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

public class JWContext {

    private static final String TAG = JWContext.class.getSimpleName();

    private Context mContext;

    private Handler mMainHandler = new Handler(Looper.getMainLooper());

    private static class Holder {
        public static JWContext instance = new JWContext();
    }

    public static JWContext getInstance() {
        return Holder.instance;
    }

    private JWContext() {

    }

    public void init(Context context) {
        mContext = context;
    }

    public Context getApplicationContext() {
        return mContext;
    }

    public void runOnMainThread(Runnable runnable) {
        mMainHandler.post(runnable);
    }

}
