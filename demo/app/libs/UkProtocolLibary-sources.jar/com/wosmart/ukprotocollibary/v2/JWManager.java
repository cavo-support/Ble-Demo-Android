package com.wosmart.ukprotocollibary.v2;

import android.content.Context;

import com.wosmart.ukprotocollibary.v2.common.JWSDKInfo;

public abstract class JWManager {

    public static final int CONN_STATUS_UN_CONNECT = 0;// 未连接设备

    public static final int CONN_STATUS_CONNECTING = 1;// 正在连接设备

    public static final int CONN_STATUS_CONNECTED = 2;// 已连接设备


    /**
     * JWManager Instance
     * Currently unavailable, don't use it
     */
    public static JWManager getInstance() {
        return JWManagerImpl.getInstance();
    }

    /**
     * init SDK
     *
     * @param context application context
     * @param config  config info
     * @return true：success；false：failed，if context is null will return false
     */
    public abstract boolean initSDK(Context context, JWSDKConfig config);

    /**
     * get the connStatus of device
     *
     * @return connStatus
     * @see JWManager#CONN_STATUS_UN_CONNECT
     * @see JWManager#CONN_STATUS_CONNECTING
     * @see JWManager#CONN_STATUS_CONNECTED
     */
    public abstract int getConnStatus();

    /**
     * scan ble device
     *
     * @param callback scan callback
     */
    public abstract void scanDevice(JWScanCallback callback);

    /**
     * stop scan
     */
    public abstract void stopScan();

    /**
     * connect device
     * for example connect progress, the status will be CONN_STATUS_UN_CONNECT -> CONN_STATUS_CONNECTING -> CONN_STATUS_LOGGING -> CONN_STATUS_CONNECTED
     * @param macAddress   device mac address
     * @param userID       userID, for login or bind device
     * @param connListener connect listener
     */
    public abstract void connectDevice(String macAddress, String userID, JWConnListener connListener);

    /**
     * disconnect device
     */
    public abstract void disconnectDevice(JWCallback callback);

    /**
     * unbind device, this method will disconnect device and reset device
     */
    public abstract void unbindDevice(JWCallback callback);

    /**
     * get sdk info
     *
     * @return see {@link JWSDKInfo}
     */
    public JWSDKInfo getSDKInfo() {
        return new JWSDKInfo();
    }

    /**
     * data manager
     */
    public static JWDataManager getDataManager() {
        return JWDataManager.getInstance();
    }

    /**
     * settings manager
     */
    public static JWSettingsManager getSettingsManager() {
        return JWSettingsManager.getInstance();
    }

    /**
     * function manager
     */
    public static JWFunctionManager getFunctionManager() {
        return JWFunctionManager.getInstance();
    }

}
