package com.wosmart.ukprotocollibary.v2.layer.handler.custom;

import android.util.SparseArray;

import com.wosmart.ukprotocollibary.util.SDKLogger;
import com.wosmart.ukprotocollibary.v2.common.JWLog;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.TempFunctionInfoListener;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

public class SetPulseRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length >= 3) {
            int status = data[0];
            int duration = (data[1] & 0xFF);
            int level = (data[2] & 0xFF);

            JWLog.i("i", "onSetPulseRsp, isOpen = " + status + ", duration = " + duration + ", level = " + level);

            SparseArray<SendPacketCallback> callbackMap = TransportManager.getInstance().getCallbackMap();
            SendPacketCallback callback = callbackMap.get(CallbackKeyConstants.KEY_SET_PULSE);
            if (callback != null) {
                callback.onResponse(status != 2);
                callbackMap.remove(CallbackKeyConstants.KEY_SET_PULSE);
            }
        }
    }

}
