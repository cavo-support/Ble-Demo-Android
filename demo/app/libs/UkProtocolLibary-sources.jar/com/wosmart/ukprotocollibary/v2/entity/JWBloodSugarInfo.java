package com.wosmart.ukprotocollibary.v2.entity;


import java.io.Serializable;

public class JWBloodSugarInfo extends JWHealthData implements Serializable {

    /**
     * unit mmol/L
     * 单位 mmol/L
     */
    public float value;

    @Override
    public String toString() {
        return "JWBloodSugarInfo{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", value=" + value +
                '}';
    }
}
