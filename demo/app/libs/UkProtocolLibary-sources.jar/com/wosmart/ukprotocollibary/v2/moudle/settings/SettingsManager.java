package com.wosmart.ukprotocollibary.v2.moudle.settings;

import android.annotation.SuppressLint;
import android.content.Context;

import com.wosmart.ukprotocollibary.util.SPWristbandConfigInfo;
import com.wosmart.ukprotocollibary.v2.BaseConstants;
import com.wosmart.ukprotocollibary.v2.JWSettingsManager;
import com.wosmart.ukprotocollibary.v2.common.BleCallback;
import com.wosmart.ukprotocollibary.v2.entity.JWAllNotifyConfigInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWDeviceIndependentSwitchInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWNotifyType;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.moudle.Manager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.function.FunctionManager;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

import java.util.List;

public class SettingsManager extends Manager {


    private Context context;


    private static class SettingsManagerHolder {
        @SuppressLint("StaticFieldLeak")
        private static final SettingsManager settingsManager = new SettingsManager();
    }

    public static SettingsManager getInstance() {
        return SettingsManagerHolder.settingsManager;
    }

    public void init(Context context) {
        this.context = context;
    }


    public void setUserProfile(int gender, int age, float height, float weight, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }

        SPWristbandConfigInfo.setGender(context, gender == JWSettingsManager.GENDER_MALE);
        SPWristbandConfigInfo.setAge(context, age);
        SPWristbandConfigInfo.setHeight(context, (int) (height * 10));
        SPWristbandConfigInfo.setWeight(context, (int) (weight * 10));

        byte[] appPacketData = SettingsPacketHelper.prepareSetUserProfilePacket(gender, age, height, weight);

        sendNormalData(appPacketData, callback);
    }

    public void setPhoneOS(BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        byte[] appPacketData = SettingsPacketHelper.prepareSetPhoneOSPacket();

        sendNormalData(appPacketData, callback);
    }

    public void setTime(BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        byte[] appPacketData = SettingsPacketHelper.prepareSetTimePacket();

        sendNormalData(appPacketData, callback);
    }

    public void setHourSystem(boolean is24Model, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }

        byte[] appPacketData = SettingsPacketHelper.prepareSetHourSystemPacket(is24Model);

        sendNormalData(appPacketData, callback);
    }

    public void setAudioSwitch(boolean enable, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }

        byte[] appPacketData = SettingsPacketHelper.prepareSetAudioSwitchPacket(enable);

        sendNormalData(appPacketData, callback);
    }

    public void getAudioSwitch(BleCallback<Boolean> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }

        byte[] appPacketData = SettingsPacketHelper.prepareGetAudioSwitchPacket();

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_GET_AUDIO_SWITCH, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                if (data == null) {
                    return;
                }
                int status = (int) data;
                if (status == 1) {
                    callback.success(true);
                } else {
                    callback.fail(BaseConstants.ERR_SET_FAILED, "set pulse failed");
                }
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    public void setNotifySwitch(JWNotifyType notifyType, boolean enable, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }

        byte[] appPacketData = SettingsPacketHelper.prepareSetNotifySwitchPacket(context, notifyType, enable);

        sendNormalData(appPacketData, callback);
    }

    public void setAllNotifySwitch(JWAllNotifyConfigInfo notifyConfigInfo, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        
        SPWristbandConfigInfo.setNotifyCallFlag(context, notifyConfigInfo.call);
        SPWristbandConfigInfo.setNotifyMessageFlag(context, notifyConfigInfo.sms);
        SPWristbandConfigInfo.setNotifyQQFlag(context, notifyConfigInfo.qq);
        SPWristbandConfigInfo.setNotifyWechatFlag(context, notifyConfigInfo.wechat);
        SPWristbandConfigInfo.setNotifyLineFlag(context, notifyConfigInfo.line);
        SPWristbandConfigInfo.setNotifyTwitterFlag(context, notifyConfigInfo.twitter);
        SPWristbandConfigInfo.setNotifyFacebookFlag(context, notifyConfigInfo.facebook);
        SPWristbandConfigInfo.setNotifyMessengerFlag(context, notifyConfigInfo.messenger);
        SPWristbandConfigInfo.setNotifyWhatsAppFlag(context, notifyConfigInfo.whatsapp);
        SPWristbandConfigInfo.setNotifyLinkedInFlag(context, notifyConfigInfo.linkedin);
        SPWristbandConfigInfo.setNotifyInstagramFlag(context, notifyConfigInfo.instagram);
        SPWristbandConfigInfo.setNotifySkypeFlag(context, notifyConfigInfo.skype);
        SPWristbandConfigInfo.setNotifyViberFlag(context, notifyConfigInfo.viber);
        SPWristbandConfigInfo.setNotifyKakaoTalkFlag(context, notifyConfigInfo.kakaoTalk);
        SPWristbandConfigInfo.setNotifyVkontakteFlag(context, notifyConfigInfo.vkontakte);
        SPWristbandConfigInfo.setNotifyTimFlag(context, notifyConfigInfo.tim);
        SPWristbandConfigInfo.setNotifyGmailFlag(context, notifyConfigInfo.gmail);
        SPWristbandConfigInfo.setNotifyDingTalkFlag(context, notifyConfigInfo.dingTalk);
        SPWristbandConfigInfo.setNotifyWorkWechatFlag(context, notifyConfigInfo.workWeChat);
        SPWristbandConfigInfo.setNotifyOtherFlag(context, notifyConfigInfo.other);

        byte[] appPacketData = SettingsPacketHelper.prepareSetAllNotifySwitchPacket(notifyConfigInfo);

        sendNormalData(appPacketData, callback);
    }

    public void getAllNotifySwitch(BleCallback<JWAllNotifyConfigInfo> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }

        byte[] appPacketData = SettingsPacketHelper.prepareGetAllNotifySwitchPacket();

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_GET_ALL_NOTIFY_SWITCH, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                if (data == null) {
                    return;
                }
                JWAllNotifyConfigInfo configInfo = (JWAllNotifyConfigInfo) data;
                if (callback != null) {
                    callback.success(configInfo);
                }
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    public void setDateFormat(int dateFormat, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }

        byte[] appPacketData = SettingsPacketHelper.prepareSetDateFormatPacket(dateFormat);

        sendNormalData(appPacketData, callback);
    }

    public void getDateFormat(BleCallback<Integer> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }

        byte[] appPacketData = SettingsPacketHelper.prepareGetDateFormatPacket();

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_GET_DATE_FORMAT, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                if (data == null) {
                    return;
                }
                int dateFormat = (Integer) data;
                if (callback != null) {
                    callback.success(dateFormat);
                }
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    public void setTemperatureUnit(boolean isCelsiusUnit, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        boolean measure = false;
        boolean adjust = false;
        boolean hasFoundMeasureSwitch = false;
        boolean hasFoundAdjustSwitch = false;
        List<JWDeviceIndependentSwitchInfo> deviceIndependentSwitchInfoList = BaseManager.getInstance().getDeviceIndependentSwitchInfoList();
        if (deviceIndependentSwitchInfoList != null && !deviceIndependentSwitchInfoList.isEmpty()) {
            for (JWDeviceIndependentSwitchInfo switchInfo : deviceIndependentSwitchInfoList) {
                if (switchInfo.type == JWDeviceIndependentSwitchInfo.TYPE_TEMPERATURE_MONITOR) {
                    // 温度监测
                    hasFoundMeasureSwitch = true;
                    measure = switchInfo.enable;
                } else if (switchInfo.type == JWDeviceIndependentSwitchInfo.TYPE_TEMPERATURE_ADJUST) {
                    // 温度补偿
                    hasFoundAdjustSwitch = true;
                    adjust = switchInfo.enable;
                }
            }
        }
        if (!hasFoundMeasureSwitch) {
            // 设备无独立开关，获取 sdk 默认配置
            measure = SPWristbandConfigInfo.getTempMeasure(BaseManager.getInstance().getContext());
        }
        if (!hasFoundAdjustSwitch) {
            // 设备无独立开关，获取 sdk 默认配置
            adjust = SPWristbandConfigInfo.getTempAdjust(BaseManager.getInstance().getContext());
        }

        FunctionManager.getInstance().setTemperatureControl(measure, adjust, isCelsiusUnit, callback);
    }

}
