package com.wosmart.ukprotocollibary.v2.entity.function;

import java.io.Serializable;

public class JWCommonFunctionInfo implements Serializable {


    public boolean enable = false;

    @Override
    public String toString() {
        return "JWCommonFunctionInfo{" +
                "enable=" + enable +
                '}';
    }
}
