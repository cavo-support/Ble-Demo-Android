package com.wosmart.ukprotocollibary.v2.layer.handler.settings;

import com.wosmart.ukprotocollibary.v2.entity.JWMedicationReminderInfo;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class GetMedicationReminderRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        SendPacketCallback callback = TransportManager.getInstance().getCallbackMap().get(CallbackKeyConstants.KEY_GET_MEDICATION_REMINDER);
        if (callback == null) {
            return;
        }
        List<JWMedicationReminderInfo> reminderInfoList = new ArrayList<>();
        if ((data.length < 5) || (data.length % 5) != 0) {
            callback.onResponse(reminderInfoList);
            TransportManager.getInstance().getCallbackMap().remove(CallbackKeyConstants.KEY_GET_MEDICATION_REMINDER);
            return;
        }

        Calendar calendar = Calendar.getInstance();
        byte[] subData = new byte[5];
        for (int i = 0; i < data.length / 5; i++) {

            System.arraycopy(data, i * 5, subData, 0, 5);

            int year = (subData[0] >> 2) & 0x3f;
            int month = ((subData[0] << 2) & 0x0f) | ((subData[1] >> 6) & 0x03);
            int day = (subData[1] >> 1) & 0x1f;
            int hour = ((subData[1] << 4) & 0x10) | ((subData[2] >> 4) & 0x0f);
            int minute = ((subData[2] << 2) & 0x3f) | ((subData[3] >> 6) & 0x03);
            int id = (subData[3] >> 3) & 0x07;
            byte dayFlags = (byte) (subData[4] & 0x7f);

            JWMedicationReminderInfo info = new JWMedicationReminderInfo();

            calendar.clear();
            calendar.set(2000 + year, month - 1, day);

            long time = calendar.getTimeInMillis();

            time += hour * 3600000;
            time += minute * 60000;
            info.setTime(time);

            info.setId(id);
            info.setFlags(dayFlags);

            reminderInfoList.add(info);
        }

        callback.onResponse(reminderInfoList);
        TransportManager.getInstance().getCallbackMap().remove(CallbackKeyConstants.KEY_GET_MEDICATION_REMINDER);
    }

}
