package com.wosmart.ukprotocollibary.v2.db.dao;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.db.entity.SpO2Info;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.AbstractDaoSession;
import org.greenrobot.greendao.Property;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseStatement;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.List;

public class SpO2InfoDao extends AbstractDao<SpO2Info, Long> {

    public static final String TABLENAME = "SPO2_INFO";

    public static class Properties {
        public final static Property time = new Property(0, Long.class, "time", true, "TIME");
        public final static Property userID = new Property(1, String.class, "userID", true, "USER_ID");
        public final static Property mac = new Property(2, String.class, "mac", true, "MAC");
        public final static Property date = new Property(3, java.util.Date.class, "date", false, "DATE");
        public final static Property curValue = new Property(4, int.class, "curValue", false, "CUR_VALUE");
        public final static Property lowValue = new Property(5, int.class, "lowValue", false, "LOW_VALUE");
        public final static Property highValue = new Property(6, int.class, "highValue", false, "HIGH_VALUE");
    }

    public SpO2InfoDao(DaoConfig config) {
        super(config);
    }

    public SpO2InfoDao(DaoConfig config, AbstractDaoSession daoSession) {
        super(config, daoSession);
    }



    public List<SpO2Info> queryDataList(String userID, String mac, long timeBegin, long timePeriod, int count) {
        String timeColName = Properties.time.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;
        String dateColName = Properties.date.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition;
        if (timeBegin == 0) {
            // 从当前时间
            timeCondition = timeColName + " <= " + System.currentTimeMillis();
        } else {
            timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));
        }
        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");
        String macCondition = TextUtils.isEmpty(mac) ? "" : (" " + macColName + " = '" + mac + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        if (!TextUtils.isEmpty(macCondition)) {
            sb.append(" and ").append(macCondition);
        }
        sb.append(")");

        String orderBy = "ORDER BY " + dateColName + " ASC";
        String limit = count == 0 ? "" : (" LIMIT " + count);

        sb.append(orderBy);
        sb.append(limit);

        return queryRaw(sb.toString());
    }












    public static void createTable(Database db) {
        db.execSQL("create table IF NOT EXISTS " + TABLENAME + "\n" +
                "(\n" +
                Properties.time.columnName + " bigint not null ,\n" +
                Properties.userID.columnName + " varchar(256) not null ,\n" +
                Properties.mac.columnName + " varchar(256) ,\n" +
                Properties.date.columnName + " varchar(50) not null ,\n" +
                Properties.curValue.columnName + " int not null ,\n" +
                Properties.lowValue.columnName + " int not null ,\n" +
                Properties.highValue.columnName + " int not null ,\n" +
                " primary key (" + Properties.time.columnName + ", " + Properties.userID.columnName + ")\n" +
                ");");
    }

    public static void dropTable(Database db) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
    }

    @Override
    protected SpO2Info readEntity(Cursor cursor, int offset) {
        long time = cursor.getLong(offset + Properties.time.ordinal);
        String userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        String mac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        int curValue = cursor.getInt(offset + Properties.curValue.ordinal);
        int lowValue = cursor.getInt(offset + Properties.lowValue.ordinal);
        int highValue = cursor.getInt(offset + Properties.highValue.ordinal);
        return new SpO2Info(time, userID, mac, curValue, lowValue, highValue);
    }

    @Override
    protected Long readKey(Cursor cursor, int offset) {
        return cursor.getLong(offset);
    }

    @Override
    protected void readEntity(Cursor cursor, SpO2Info info, int offset) {
        info.time = cursor.getLong(offset + Properties.time.ordinal);
        info.userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        info.deviceMac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        info.curValue = cursor.getInt(offset + Properties.curValue.ordinal);
        info.lowValue = cursor.getInt(offset + Properties.lowValue.ordinal);
        info.highValue = cursor.getInt(offset + Properties.highValue.ordinal);
    }

    @Override
    protected void bindValues(DatabaseStatement stmt, SpO2Info info) {

    }

    @Override
    protected void bindValues(SQLiteStatement stmt, SpO2Info info) {
        stmt.clearBindings();

        stmt.bindLong(Properties.time.ordinal + 1, info.time);
        stmt.bindString(Properties.userID.ordinal + 1, TextUtils.isEmpty(info.userID) ? "" : info.userID);
        stmt.bindString(Properties.mac.ordinal + 1, TextUtils.isEmpty(info.deviceMac) ? "" : info.deviceMac);
        stmt.bindString(Properties.date.ordinal + 1, DateUtil.toTime2(info.time));
        stmt.bindLong(Properties.curValue.ordinal + 1, info.curValue);
        stmt.bindLong(Properties.lowValue.ordinal + 1, info.lowValue);
        stmt.bindLong(Properties.highValue.ordinal + 1, info.lowValue);
    }

    @Override
    protected Long updateKeyAfterInsert(SpO2Info info, long rowID) {
        return info.time;
    }

    @Override
    protected Long getKey(SpO2Info info) {
        return info.time;
    }

    @Override
    protected boolean hasKey(SpO2Info info) {
        return false;
    }

    @Override
    protected boolean isEntityUpdateable() {
        return true;
    }
}
