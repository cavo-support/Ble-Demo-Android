package com.wosmart.ukprotocollibary.v2.layer.handler.custom;

import com.wosmart.ukprotocollibary.v2.JWSaunaListener;
import com.wosmart.ukprotocollibary.v2.entity.JWSaunaInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class SyncSaunaDataRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        JWSaunaListener saunaListener = TransportManager.getInstance().getSaunaListener();
        if (saunaListener == null) {
            return;
        }
        if ((data.length < 8) || (data.length % 8) != 0) {
            return;
        }
        List<JWSaunaInfo> saunaInfoList = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        byte[] subData = new byte[8];
        for (int i = 0; i < data.length / 8; i++) {

            System.arraycopy(data, i * 8, subData, 0, 8);

            // 该时间戳为 2000.1.1 以后的秒
            long timestamp = (((subData[0] & 0xff) << 24) | ((subData[1] & 0xff) << 16) | ((subData[2] & 0xff) << 8) | ((subData[3] & 0xff)));
            int heartRateValue = subData[4] & 0xff;
            int temperature = (((subData[5] & 0xff) << 8) | (subData[6] & 0xff)) & 0xffff;
            int label = (subData[7] >> 4) & 0x0f;
            int movement = subData[7] & 0x0f;

            calendar.clear();
            calendar.set(2000, 0, 1);

            long time = calendar.getTimeInMillis();

            time += timestamp * 1000;

            JWSaunaInfo info = new JWSaunaInfo();

            info.time = time;
            info.userID = BaseManager.getInstance().getUserID();
            info.deviceMac = BaseManager.getInstance().getMacAddress();
            info.heartRateValue = heartRateValue;
            info.temperature = JWUtils.parserRound(1, temperature / 10f);
            info.label = label;
            info.movement = movement;

            saunaInfoList.add(info);
        }

        saunaListener.onSaunaDataReceived(saunaInfoList);
    }

}
