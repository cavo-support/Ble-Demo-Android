package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;
import java.util.List;

public class JWSyncDataInfo implements Serializable {

    public int totalCount;

    public List<SyncDataItemInfo> itemInfoList;

    public static class SyncDataItemInfo implements Serializable {

        /**
         * step，步数
         */
        public static final int ITEM_TYPE_STEP = 1;

        /**
         * sleep，睡眠
         */
        public static final int ITEM_TYPE_SLEEP = 2;

        /**
         * heart rate，心率
         */
        public static final int ITEM_TYPE_HEART_RATE = 3;

        /**
         * blood pressure，血压
         */
        public static final int ITEM_TYPE_BLOOD_PRESSURE = 4;

        /**
         * sport，运动
         */
        public static final int ITEM_TYPE_SPORT = 5;

        /**
         * SpO2，血氧
         */
        public static final int ITEM_TYPE_SPO2 = 6;

        /**
         * heart rate variability，心率变异性
         */
        public static final int ITEM_TYPE_HEART_RATE_VARIABILITY = 7;

        /**
         * blood sugar，血糖
         */
        public static final int ITEM_TYPE_BLOOD_SUGAR = 8;

        /**
         * wearing time，佩戴时间
         */
        public static final int ITEM_TYPE_WEARING_TIME = 9;

        /**
         * uric acid，尿酸
         */
        public static final int ITEM_TYPE_URIC_ACID = 10;

        /**
         * blood fat，血脂
         */
        public static final int ITEM_TYPE_BLOOD_FAT = 11;

        /**
         * blood sugar cycle，血糖周期
         */
        public static final int ITEM_TYPE_BLOOD_SUGAR_CYCLE = 12;

        /**
         * uric acid continuous monitoring，尿酸连续监测
         */
        public static final int ITEM_TYPE_URIC_ACID_CONTINUOUS_MONITORING = 13;

        /**
         * blood fat continuous monitoring，血脂连续监测
         */
        public static final int ITEM_TYPE_BLOOD_FAT_CONTINUOUS_MONITORING = 14;

        /**
         * unknown
         */
        public static final int ITEM_TYPE_UNKNOWN = 0;


        public int type = ITEM_TYPE_UNKNOWN;

        public int count = 0;

        public int getType() {
            return type;
        }

        public int getCount() {
            return count;
        }

    }

}
