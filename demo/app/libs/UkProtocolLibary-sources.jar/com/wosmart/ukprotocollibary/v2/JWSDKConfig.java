package com.wosmart.ukprotocollibary.v2;

public class JWSDKConfig {

    public static final int JW_LOG_NONE = 0;
    public static final int JW_LOG_DEBUG = 3;
    public static final int JW_LOG_INFO = 4;
    public static final int JW_LOG_WARN = 5;
    public static final int JW_LOG_ERROR = 6;

    private int logLevel = 4;


    private int connectTimeout = 60;

    private int reConnectCount = 3;

    /**
     * 自动同步校验
     */
    private boolean autoSyncCheck = true;

    private JWDBConfig dbConfig = new JWDBConfig();

    /**
     * 设置写日志等级，必须在 sdk 初始化之前调用，在 sdk 初始化之后设置无效
     */
    public void setLogLevel(int logLevel) {
        this.logLevel = logLevel;
    }

    public int getLogLevel() {
        return logLevel;
    }

    public int getConnectTimeout() {
        return connectTimeout;
    }

    public void setConnectTimeout(int connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    public int getReConnectCount() {
        return reConnectCount;
    }

    public void setReConnectCount(int reConnectCount) {
        this.reConnectCount = reConnectCount;
    }

    /**
     * 设置数据库存储配置
     *
     * @param dbConfig 数据库存储配置
     */
    public void setDBConfig(JWDBConfig dbConfig) {
        this.dbConfig = dbConfig;
    }

    public boolean isAutoSyncCheck() {
        return autoSyncCheck;
    }

    public void setAutoSyncCheck(boolean autoSyncCheck) {
        this.autoSyncCheck = autoSyncCheck;
    }

    public JWDBConfig getDBConfig() {
        if (dbConfig == null) {
            dbConfig = new JWDBConfig();
        }
        return dbConfig;
    }

}
