package com.wosmart.ukprotocollibary.v2.layer.handler.control;

import com.wosmart.ukprotocollibary.v2.entity.JWDeviceIndependentSwitchInfo;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.TempFunctionInfoListener;

import java.util.ArrayList;
import java.util.List;

public class DeviceIndependentSwitchHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        TempFunctionInfoListener tempFunctionInfoListener = BaseManager.getInstance().getTempFunctionInfoListener();
        if (tempFunctionInfoListener == null || data.length < 2) {
            return;
        }
        List<JWDeviceIndependentSwitchInfo> switchInfoList = new ArrayList<>();
        for (int i = 0; i < data.length / 2; i++) {
            JWDeviceIndependentSwitchInfo switchInfo = new JWDeviceIndependentSwitchInfo();
            if (i == 0) {
                switchInfo.type = data[0] & 0xff;
                switchInfo.enable = ((data[1] & 0xff) == 1);
            } else {
                switchInfo.type = data[i * 2] & 0xff;
                switchInfo.enable = ((data[i * 2 + 1] & 0xff) == 1);
            }
            switchInfoList.add(switchInfo);
        }

        tempFunctionInfoListener.onDeviceIndependentSwitchInfoList(switchInfoList);
    }

}
