package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWHRMovementInfo extends JWHealthData implements Serializable {

    public int heartRateValue;

    /**
     * unit celsius
     */
    public float temperature;

    public int label;

    public int movement;

    @Override
    public String toString() {
        return "\nJWHRMovementInfo{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", heartRateValue=" + heartRateValue +
                ", temperature=" + temperature +
                ", label=" + label +
                ", movement=" + movement +
                '}';
    }
}
