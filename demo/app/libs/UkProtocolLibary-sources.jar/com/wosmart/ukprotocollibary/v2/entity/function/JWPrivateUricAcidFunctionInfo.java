package com.wosmart.ukprotocollibary.v2.entity.function;


import java.io.Serializable;

public class JWPrivateUricAcidFunctionInfo extends JWCommonFunctionInfo implements Serializable {

    /**
     * default is 250 - 300, range is 170 - 500
     */
    public int value;


    @Override
    public String toString() {
        return "JWPrivateUricAcidFunctionInfo{" +
                "value=" + value +
                ", isOpen=" + enable +
                '}';
    }
}
