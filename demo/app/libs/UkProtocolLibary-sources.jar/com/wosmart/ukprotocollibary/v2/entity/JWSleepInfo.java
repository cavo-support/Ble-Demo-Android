package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWSleepInfo extends JWHealthData implements Serializable {

    /**
     * 浅睡
     */
    public static final int SLEEP_MODE_LIGHT = 1;

    /**
     * 深睡
     */
    public static final int SLEEP_MODE_DEEP = 2;

    /**
     * 苏醒
     */
    public static final int SLEEP_MODE_AWAKE = 3;

    public int mode;

    /**
     * sleep model
     * {@link JWSleepInfo#SLEEP_MODE_LIGHT}
     * {@link JWSleepInfo#SLEEP_MODE_DEEP}
     * {@link JWSleepInfo#SLEEP_MODE_AWAKE}
     */
    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

    @Override
    public String toString() {
        return "JWSleepInfo{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", mode=" + mode +
                '}';
    }
}
