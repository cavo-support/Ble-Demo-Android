package com.wosmart.ukprotocollibary.v2.layer.handler.custom;

import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdConfigInfo;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;



public class ReadHRVRmssdConfigRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        SendPacketCallback callback = TransportManager.getInstance().getCallbackMap().get(CallbackKeyConstants.KEY_READ_HRV_RMSSD_CONFIG);
        if (callback == null || data.length != 1) {
            return;
        }
        int value = data[0] & 0xff;

        JWHRVRmssdConfigInfo configInfo = new JWHRVRmssdConfigInfo();
        configInfo.enable = value != 0;
        configInfo.interval = value;

        callback.onResponse(configInfo);
        TransportManager.getInstance().getCallbackMap().remove(CallbackKeyConstants.KEY_READ_HRV_RMSSD_CONFIG);
    }

}
