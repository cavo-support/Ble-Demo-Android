package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWPulseInfo;

public class PulseInfo extends BaseHealthDataInfo{

    public long startTime;

    public int duration;

    public PulseInfo(long startTime, String userID, String mac, int duration) {
        this.startTime = startTime;
        this.userID = userID;
        this.deviceMac = mac;
        this.duration = duration;
    }

    public PulseInfo(JWPulseInfo info) {
        this.startTime = info.startTime;
        this.userID = info.userID;
        this.deviceMac = info.deviceMac;
        this.duration = info.duration;
    }

    public JWPulseInfo convertToJWPulseInfo() {
        return new JWPulseInfo(userID, deviceMac, startTime, duration);
    }
}
