package com.wosmart.ukprotocollibary.v2.layer.handler.multiple;

import com.wosmart.ukprotocollibary.v2.entity.JWPrivateBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.TempFunctionInfoListener;

public class SupportPrivateBPHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length < 3) {
            return;
        }
        TempFunctionInfoListener tempFunctionInfoListener = BaseManager.getInstance().getTempFunctionInfoListener();
        if (tempFunctionInfoListener != null) {
            JWPrivateBloodPressureInfo bloodPressureInfo = new JWPrivateBloodPressureInfo();
            bloodPressureInfo.enable = ((data[0]) == 0x01);
            bloodPressureInfo.highValue = (data[1] & 0xFF);
            bloodPressureInfo.lowValue = (data[2] & 0xFF);

            tempFunctionInfoListener.onSupportPrivateBloodPressureInfo(bloodPressureInfo);
        }
    }

}
