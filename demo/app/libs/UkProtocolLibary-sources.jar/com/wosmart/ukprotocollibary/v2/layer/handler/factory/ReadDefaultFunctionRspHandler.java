package com.wosmart.ukprotocollibary.v2.layer.handler.factory;

import com.wosmart.ukprotocollibary.v2.entity.function.JWDefaultFunctionInfo;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;


public class ReadDefaultFunctionRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        SendPacketCallback callback = TransportManager.getInstance().getCallbackMap().get(CallbackKeyConstants.KEY_READ_DEFAULT_FUNCTION);
        if (callback == null || data.length != 1) {
            return;
        }
        byte key = data[0];

        JWDefaultFunctionInfo functionInfo = new JWDefaultFunctionInfo();
        functionInfo.bloodPressureEnable = (key & 1) == 1;
        functionInfo.temperatureEnable = (key >> 1 & 1) == 1;
        functionInfo.pressureEnable = (key >> 2 & 1) == 1;
        functionInfo.sceneEnable = (key >> 3 & 1) == 1;
        functionInfo.alexaEnable = (key >> 4 & 1) == 1;
        functionInfo.lightSenseEnable = (key >> 5 & 1) == 1;

        callback.onResponse(functionInfo);

        TransportManager.getInstance().getCallbackMap().remove(CallbackKeyConstants.KEY_READ_DEFAULT_FUNCTION);
    }

}
