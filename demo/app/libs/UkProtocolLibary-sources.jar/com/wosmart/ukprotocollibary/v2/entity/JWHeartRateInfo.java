package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWHeartRateInfo extends JWHealthData implements Serializable {

    /**
     * unit times/min
     * 单位 次/分
     */
    public int value;

    @Override
    public String toString() {
        return "JWHeartRateInfo{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", value=" + value +
                '}';
    }
}
