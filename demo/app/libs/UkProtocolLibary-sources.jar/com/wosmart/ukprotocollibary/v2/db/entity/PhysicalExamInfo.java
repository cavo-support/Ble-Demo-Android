package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

public class PhysicalExamInfo extends BaseHealthDataInfo {

    /**
     * 心率
     */
    public int heartRate;

    /**
     * 血氧
     */
    public int spo2;

    /**
     * 压力
     */
    public int pressure;

    /**
     * 体温
     */
    public int temperature;

    /**
     * 皮肤温度
     */
    public int skinTemperature;

    /**
     * 血管弹性
     */
    public int bloodVesselElasticity;

    /**
     * 心血管风险
     * 0 low risk 低风险
     * 1 medium risk 中风险
     * 2 high risk 高风险
     */
    public int cardiovascularRisk;

    public PhysicalExamInfo() {

    }

    public PhysicalExamInfo(JWPhysicalExamInfo info) {
        this.time = info.time;
        this.userID = info.userID;
        this.deviceMac = info.deviceMac;
        this.heartRate = info.heartRate;
        this.spo2 = info.spo2;
        this.pressure = info.pressure;
        this.temperature = (int) (info.temperature * 10);
        this.skinTemperature = (int) (info.skinTemperature * 10);
        this.bloodVesselElasticity = info.bloodVesselElasticity;
        this.cardiovascularRisk = info.cardiovascularRisk;
    }

    public JWPhysicalExamInfo convertToJWPhysicalExamInfo() {
        JWPhysicalExamInfo info = new JWPhysicalExamInfo();
        info.userID = userID;
        info.deviceMac = deviceMac;
        info.time = time;

        info.heartRate = heartRate;
        info.spo2 = spo2;
        info.pressure = pressure;
        info.temperature = JWUtils.parserRound(1, temperature / 10f);
        info.skinTemperature = JWUtils.parserRound(1, skinTemperature / 10f);
        info.bloodVesselElasticity = bloodVesselElasticity;
        info.cardiovascularRisk = cardiovascularRisk;

        return info;
    }

}
