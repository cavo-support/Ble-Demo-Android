package com.wosmart.ukprotocollibary.v2.common.logger;

import static com.wosmart.ukprotocollibary.v2.common.logger.Utils.checkNotNull;


/**
 * This is used to saves log messages to the disk.
 * By default it uses {@link CsvFormatStrategy} to translates text message into CSV format.
 */
public class DiskLogAdapter implements LogAdapter {

    private final FormatStrategy formatStrategy;

    public DiskLogAdapter(String path, String userID) {
        formatStrategy = CsvFormatStrategy.newBuilder().build(path, userID);
    }

    public DiskLogAdapter(FormatStrategy formatStrategy) {
        this.formatStrategy = checkNotNull(formatStrategy);
    }

    @Override
    public boolean isLoggable(int priority, String tag) {
        return true;
    }

    @Override
    public void log(int priority, String tag, String message) {
        formatStrategy.log(priority, tag, message);
    }
}
