package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWAddressBook implements Serializable {

    public String addressName;

    public String addressPhone;

}
