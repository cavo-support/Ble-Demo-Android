package com.wosmart.ukprotocollibary.v2.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.util.Log;

import com.wosmart.ukprotocollibary.v2.db.dao.BloodFatContinuousMonitoringInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodFatInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodPressureInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodSugarCycleInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodSugarInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BodyFatInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HRMovementInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HRVRmssdInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HeartRateInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HeartRateVariabilityInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.PhysicalExamInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.PressureInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.PulseInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SaunaInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SleepInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SpO2InfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SportInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.StepInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.TemperatureInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.UltravioletInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.UricAcidContinuousMonitoringInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.UricAcidInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.WearingTimeInfoDao;

import org.greenrobot.greendao.AbstractDaoMaster;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseOpenHelper;
import org.greenrobot.greendao.identityscope.IdentityScopeType;

public class DatabaseMaster extends AbstractDaoMaster {

    public static final int SCHEMA_VERSION = 1;


    public static void createAllTables(Database db) {
        BloodPressureInfoDao.createTable(db);
        BloodSugarInfoDao.createTable(db);
        HeartRateInfoDao.createTable(db);
        HeartRateVariabilityInfoDao.createTable(db);
        SleepInfoDao.createTable(db);
        SpO2InfoDao.createTable(db);
        SportInfoDao.createTable(db);
        StepInfoDao.createTable(db);
        TemperatureInfoDao.createTable(db);
        PulseInfoDao.createTable(db);
        SaunaInfoDao.createTable(db);
        HRMovementInfoDao.createTable(db);
        WearingTimeInfoDao.createTable(db);
        UricAcidInfoDao.createTable(db);
        BloodFatInfoDao.createTable(db);
        BloodSugarCycleInfoDao.createTable(db);
        UricAcidContinuousMonitoringInfoDao.createTable(db);
        BloodFatContinuousMonitoringInfoDao.createTable(db);
        BodyFatInfoDao.createTable(db);
        PhysicalExamInfoDao.createTable(db);
        HRVRmssdInfoDao.createTable(db);
        UltravioletInfoDao.createTable(db);
        PressureInfoDao.createTable(db);
    }


    public static void dropAllTables(Database db) {
        BloodPressureInfoDao.dropTable(db);
        BloodSugarInfoDao.dropTable(db);
        HeartRateInfoDao.dropTable(db);
        HeartRateVariabilityInfoDao.dropTable(db);
        SleepInfoDao.dropTable(db);
        SpO2InfoDao.dropTable(db);
        SportInfoDao.dropTable(db);
        StepInfoDao.dropTable(db);
        TemperatureInfoDao.dropTable(db);
        PulseInfoDao.dropTable(db);
        SaunaInfoDao.dropTable(db);
        HRMovementInfoDao.dropTable(db);
        WearingTimeInfoDao.dropTable(db);
        UricAcidInfoDao.dropTable(db);
        BloodFatInfoDao.dropTable(db);
        BloodSugarCycleInfoDao.dropTable(db);
        UricAcidContinuousMonitoringInfoDao.dropTable(db);
        BloodFatContinuousMonitoringInfoDao.dropTable(db);
        BodyFatInfoDao.dropTable(db);
        PhysicalExamInfoDao.dropTable(db);
        HRVRmssdInfoDao.dropTable(db);
        UltravioletInfoDao.dropTable(db);
        PressureInfoDao.dropTable(db);
    }



    public static abstract class OpenHelper extends DatabaseOpenHelper {

        public OpenHelper(Context context, String name, CursorFactory factory) {
            super(context, name, factory, SCHEMA_VERSION);
        }

        @Override
        public void onCreate(Database db) {
            Log.i("greenDAO", "Creating tables for schema version " + SCHEMA_VERSION);
            dropAllTables(db);
            createAllTables(db);
        }
    }

    /**
     * WARNING: Drops all table on Upgrade! Use only during development.
     */
    public static class DevOpenHelper extends OpenHelper {
        public DevOpenHelper(Context context, String name, CursorFactory factory) {
            super(context, name, factory);
        }

        @Override
        public void onUpgrade(Database db, int oldVersion, int newVersion) {
            Log.i("greenDAO", "Upgrading schema from version " + oldVersion + " to " + newVersion + " by dropping all tables");
        }
    }

    public DatabaseMaster(Database db) {
        super(db, SCHEMA_VERSION);
        registerDaoClass(BloodPressureInfoDao.class);
        registerDaoClass(BloodSugarInfoDao.class);
        registerDaoClass(HeartRateInfoDao.class);
        registerDaoClass(HeartRateVariabilityInfoDao.class);
        registerDaoClass(SleepInfoDao.class);
        registerDaoClass(SpO2InfoDao.class);
        registerDaoClass(SportInfoDao.class);
        registerDaoClass(StepInfoDao.class);
        registerDaoClass(TemperatureInfoDao.class);
        registerDaoClass(PulseInfoDao.class);
        registerDaoClass(SaunaInfoDao.class);
        registerDaoClass(HRMovementInfoDao.class);
        registerDaoClass(WearingTimeInfoDao.class);
        registerDaoClass(UricAcidInfoDao.class);
        registerDaoClass(BloodFatInfoDao.class);
        registerDaoClass(BloodSugarCycleInfoDao.class);
        registerDaoClass(UricAcidContinuousMonitoringInfoDao.class);
        registerDaoClass(BloodFatContinuousMonitoringInfoDao.class);
        registerDaoClass(BodyFatInfoDao.class);
        registerDaoClass(PhysicalExamInfoDao.class);
        registerDaoClass(HRVRmssdInfoDao.class);
        registerDaoClass(UltravioletInfoDao.class);
        registerDaoClass(PressureInfoDao.class);
    }

    @Override
    public DatabaseSession newSession() {
        return new DatabaseSession(db, IdentityScopeType.Session, daoConfigMap);
    }

    @Override
    public DatabaseSession newSession(IdentityScopeType type) {
        return new DatabaseSession(db, type, daoConfigMap);
    }

}
