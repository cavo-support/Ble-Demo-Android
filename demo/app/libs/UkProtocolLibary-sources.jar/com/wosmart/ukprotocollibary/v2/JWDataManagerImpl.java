package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.common.BleCallback;
import com.wosmart.ukprotocollibary.v2.common.JWLog;
import com.wosmart.ukprotocollibary.v2.common.executor.JWArchTaskExecutor;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRMovementInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHealthData;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateVariabilityInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPulseInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSaunaInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSleepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSpO2Info;
import com.wosmart.ukprotocollibary.v2.entity.JWSportInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWStepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUltravioletInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWearingTimeInfo;
import com.wosmart.ukprotocollibary.v2.moudle.data.DataManager;

import java.util.ArrayList;
import java.util.List;

public class JWDataManagerImpl extends JWDataManager {

    private static final String TAG = "JWDataManagerImpl";

    private JWPulseListener mPulseListener;
    private final List<JWPulseListener> mPulseListenerList;

    private JWSaunaListener mSaunaListener;
    private final List<JWSaunaListener> mSaunaListenerList;

    private JWHRVRmssdListener mHRVRmssdListener;
    private final List<JWHRVRmssdListener> mHRVRmssdListenerList;

    private JWUltravioletListener mUltravioletListener;
    private final List<JWUltravioletListener> mUltravioletListenerList;

    private JWPressureListener mPressureListener;
    private final List<JWPressureListener> mPressureListenerList;

    private JWDataManagerImpl() {
        this.mPulseListenerList = new ArrayList<>();
        this.mSaunaListenerList = new ArrayList<>();
        this.mHRVRmssdListenerList = new ArrayList<>();
        this.mUltravioletListenerList = new ArrayList<>();
        this.mPressureListenerList = new ArrayList<>();
        this.initListener();
    }

    private void initListener() {
        if (mPulseListener == null) {
            mPulseListener = new JWPulseListener() {
                @Override
                public void onSyncDataStart(int totalCount) {
                    for (JWPulseListener listener : JWDataManagerImpl.this.mPulseListenerList) {
                        listener.onSyncDataStart(totalCount);
                    }
                }

                @Override
                public void onPulseDataReceived(List<JWPulseInfo> pulseInfoList) {
                    for (JWPulseListener listener : JWDataManagerImpl.this.mPulseListenerList) {
                        listener.onPulseDataReceived(pulseInfoList);
                    }
                }

                @Override
                public void onSyncDataFinished() {
                    for (JWPulseListener listener : JWDataManagerImpl.this.mPulseListenerList) {
                        listener.onSyncDataFinished();
                    }
                }

                @Override
                public void onPulseFinished(int duration) {
                    for (JWPulseListener listener : JWDataManagerImpl.this.mPulseListenerList) {
                        listener.onPulseFinished(duration);
                    }
                }
            };
        }

        if (mSaunaListener == null) {
            mSaunaListener = new JWSaunaListener() {
                @Override
                public void onSyncDataStart(int totalCount) {
                    for (JWSaunaListener listener : JWDataManagerImpl.this.mSaunaListenerList) {
                        listener.onSyncDataStart(totalCount);
                    }
                }

                @Override
                public void onSaunaDataReceived(List<JWSaunaInfo> saunaInfoList) {
                    for (JWSaunaListener listener : JWDataManagerImpl.this.mSaunaListenerList) {
                        listener.onSaunaDataReceived(saunaInfoList);
                    }
                }

                @Override
                public void onSyncDataFinished() {
                    for (JWSaunaListener listener : JWDataManagerImpl.this.mSaunaListenerList) {
                        listener.onSyncDataFinished();
                    }
                }

                @Override
                public void onHRMovementDataReceived(List<JWHRMovementInfo> hrMovementInfoList) {
                    for (JWSaunaListener listener : JWDataManagerImpl.this.mSaunaListenerList) {
                        listener.onHRMovementDataReceived(hrMovementInfoList);
                    }
                }
            };
        }

        if (mHRVRmssdListener == null) {
            mHRVRmssdListener = new JWHRVRmssdListener() {
                @Override
                public void onHRVRmssdDataReceived(List<JWHRVRmssdInfo> dataList) {
                    for (JWHRVRmssdListener listener : JWDataManagerImpl.this.mHRVRmssdListenerList) {
                        listener.onHRVRmssdDataReceived(dataList);
                    }
                }
            };
        }

        if (mUltravioletListener == null) {
            mUltravioletListener = new JWUltravioletListener() {
                @Override
                public void onUltravioletDataReceived(List<JWUltravioletInfo> dataList) {
                    for (JWUltravioletListener listener : JWDataManagerImpl.this.mUltravioletListenerList) {
                        listener.onUltravioletDataReceived(dataList);
                    }
                }

                @Override
                public void onSyncUltravioletDataEnd() {
                    for (JWUltravioletListener listener : JWDataManagerImpl.this.mUltravioletListenerList) {
                        listener.onSyncUltravioletDataEnd();
                    }
                }
            };
        }

        if (mPressureListener == null) {
            mPressureListener = new JWPressureListener() {
                @Override
                public void onPressureDataReceived(List<JWPressureInfo> pressureInfoList) {
                    for (JWPressureListener listener : JWDataManagerImpl.this.mPressureListenerList) {
                        listener.onPressureDataReceived(pressureInfoList);
                    }
                }

                @Override
                public void onSyncPressureDataEnd() {
                    for (JWPressureListener listener : JWDataManagerImpl.this.mPressureListenerList) {
                        listener.onSyncPressureDataEnd();
                    }
                }
            };
        }

        DataManager.getInstance().setPulseListener(mPulseListener);
        DataManager.getInstance().setSaunaListener(mSaunaListener);
        DataManager.getInstance().setHRVRmssdListener(mHRVRmssdListener);
        DataManager.getInstance().setUltravioletListener(mUltravioletListener);
        DataManager.getInstance().setPressureListener(mPressureListener);
    }

    static JWDataManagerImpl getInstance() {
        return JWDataManagerImplHolder.dataManagerImpl;
    }

    @Override
    public void addPulseListener(JWPulseListener listener) {
        if (listener == null) {
            return;
        }
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                if (!JWDataManagerImpl.this.mPulseListenerList.contains(listener)) {
                    JWDataManagerImpl.this.mPulseListenerList.add(listener);
                }
            }
        });
    }

    @Override
    public void removePulseListener(JWPulseListener listener) {
        if (listener == null) {
            return;
        }
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                JWDataManagerImpl.this.mPulseListenerList.remove(listener);
            }
        });
    }

    @Override
    public void addSaunaListener(JWSaunaListener listener) {
        if (listener == null) {
            return;
        }
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                if (!JWDataManagerImpl.this.mSaunaListenerList.contains(listener)) {
                    JWDataManagerImpl.this.mSaunaListenerList.add(listener);
                }
            }
        });
    }

    @Override
    public void removeSaunaListener(JWSaunaListener listener) {
        if (listener == null) {
            return;
        }
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                JWDataManagerImpl.this.mSaunaListenerList.remove(listener);
            }
        });
    }

    @Override
    public void addHRVRmssdListener(JWHRVRmssdListener listener) {
        if (listener == null) {
            return;
        }
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                if (!JWDataManagerImpl.this.mHRVRmssdListenerList.contains(listener)) {
                    JWDataManagerImpl.this.mHRVRmssdListenerList.add(listener);
                }
            }
        });
    }

    @Override
    public void removeHRVRmssdListener(JWHRVRmssdListener listener) {
        if (listener == null) {
            return;
        }
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                JWDataManagerImpl.this.mHRVRmssdListenerList.remove(listener);
            }
        });
    }

    @Override
    public void addUltravioletListener(JWUltravioletListener listener) {
        if (listener == null) {
            return;
        }
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                if (!JWDataManagerImpl.this.mUltravioletListenerList.contains(listener)) {
                    JWDataManagerImpl.this.mUltravioletListenerList.add(listener);
                }
            }
        });
    }

    @Override
    public void remoteUltravioletListener(JWUltravioletListener listener) {
        if (listener == null) {
            return;
        }
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                JWDataManagerImpl.this.mUltravioletListenerList.remove(listener);
            }
        });
    }

    @Override
    public void addPressureListener(JWPressureListener listener) {
        if (listener == null) {
            return;
        }
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                if (!JWDataManagerImpl.this.mPressureListenerList.contains(listener)) {
                    JWDataManagerImpl.this.mPressureListenerList.add(listener);
                }
            }
        });
    }

    @Override
    public void removePressureListener(JWPressureListener listener) {
        if (listener == null) {
            return;
        }
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                JWDataManagerImpl.this.mPressureListenerList.remove(listener);
            }
        });
    }

    @Override
    public void syncHealthData(JWSyncDataListener syncDataListener) {
        DataManager.getInstance().syncHealthData(syncDataListener);
    }


    @Override
    public void getHistoryStepListByDate(int year, int month, int day, JWValueCallback<List<JWStepInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.Step);

        getHistoryStepList(params, callback);
    }

    @Override
    public void getHistoryStepList(JWHealthDataSearchParams params, JWValueCallback<List<JWStepInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.Step);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistoryStepList(params, new BleCallback<List<JWStepInfo>>(callback) {
            @Override
            public void success(List<JWStepInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWStepInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistorySleepListByDate(int year, int month, int day, JWValueCallback<List<JWSleepInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);// 当天 0 点
        timeBegin -= 4 * 3600000;// 从昨晚 8 点开始计算
        long timePeriod = 14 * 3600000;// 持续 14 小时

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.Sleep);

        getHistorySleepList(params, callback);
    }

    @Override
    public void getHistorySleepList(JWHealthDataSearchParams params, JWValueCallback<List<JWSleepInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.Sleep);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistorySleepList(params, new BleCallback<List<JWSleepInfo>>(callback) {
            @Override
            public void success(List<JWSleepInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWSleepInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistoryBloodPressureListByDate(int year, int month, int day, JWValueCallback<List<JWBloodPressureInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.BloodPressure);

        getHistoryBloodPressureList(params, callback);
    }

    @Override
    public void getHistoryBloodPressureList(JWHealthDataSearchParams params, JWValueCallback<List<JWBloodPressureInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.BloodPressure);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistoryBloodPressureList(params, new BleCallback<List<JWBloodPressureInfo>>(callback) {
            @Override
            public void success(List<JWBloodPressureInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWBloodPressureInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistoryBloodSugarListByDate(int year, int month, int day, JWValueCallback<List<JWBloodSugarInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.BloodSugar);

        getHistoryBloodSugarList(params, callback);
    }

    @Override
    public void getHistoryBloodSugarList(JWHealthDataSearchParams params, JWValueCallback<List<JWBloodSugarInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.BloodSugar);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistoryBloodSugarList(params, new BleCallback<List<JWBloodSugarInfo>>(callback) {
            @Override
            public void success(List<JWBloodSugarInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWBloodSugarInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistoryHeartRateListByDate(int year, int month, int day, JWValueCallback<List<JWHeartRateInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.HeartRate);

        getHistoryHeartRateList(params, callback);
    }

    @Override
    public void getHistoryHeartRateList(JWHealthDataSearchParams params, JWValueCallback<List<JWHeartRateInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.HeartRate);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistoryHeartRateList(params, new BleCallback<List<JWHeartRateInfo>>(callback) {
            @Override
            public void success(List<JWHeartRateInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWHeartRateInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistoryHeartRateVariabilityListByDate(int year, int month, int day, JWValueCallback<List<JWHeartRateVariabilityInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.HeartRateVariability);

        getHistoryHeartRateVariabilityList(params, callback);
    }

    @Override
    public void getHistoryHeartRateVariabilityList(JWHealthDataSearchParams params, JWValueCallback<List<JWHeartRateVariabilityInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.HeartRateVariability);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistoryHeartRateVariabilityList(params, new BleCallback<List<JWHeartRateVariabilityInfo>>(callback) {
            @Override
            public void success(List<JWHeartRateVariabilityInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWHeartRateVariabilityInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistoryPulseListByDate(int year, int month, int day, JWValueCallback<List<JWPulseInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.Pulse);

        getHistoryPulseList(params, callback);
    }

    @Override
    public void getHistoryPulseList(JWHealthDataSearchParams params, JWValueCallback<List<JWPulseInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.Pulse);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistoryPulseList(params, new BleCallback<List<JWPulseInfo>>(callback) {
            @Override
            public void success(List<JWPulseInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWPulseInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistorySaunaListByDate(int year, int month, int day, JWValueCallback<List<JWSaunaInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.Sauna);

        getHistorySaunaList(params, callback);
    }

    @Override
    public void getHistorySaunaList(JWHealthDataSearchParams params, JWValueCallback<List<JWSaunaInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.Sauna);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistorySaunaList(params, new BleCallback<List<JWSaunaInfo>>(callback) {
            @Override
            public void success(List<JWSaunaInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWSaunaInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistoryHRMovementListByDate(int year, int month, int day, JWValueCallback<List<JWHRMovementInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.HRMovement);

        getHistoryHRMovementList(params, callback);
    }

    @Override
    public void getHistoryHRMovementList(JWHealthDataSearchParams params, JWValueCallback<List<JWHRMovementInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.HRMovement);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistoryHRMovementList(params, new BleCallback<List<JWHRMovementInfo>>(callback) {
            @Override
            public void success(List<JWHRMovementInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWHRMovementInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistorySpO2ListByDate(int year, int month, int day, JWValueCallback<List<JWSpO2Info>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.SpO2);

        getHistorySpO2List(params, callback);
    }

    @Override
    public void getHistorySpO2List(JWHealthDataSearchParams params, JWValueCallback<List<JWSpO2Info>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.SpO2);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistorySpO2List(params, new BleCallback<List<JWSpO2Info>>(callback) {
            @Override
            public void success(List<JWSpO2Info> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWSpO2Info> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistorySportListByDate(int year, int month, int day, JWValueCallback<List<JWSportInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.Sport);

        getHistorySportList(params, callback);
    }

    @Override
    public void getHistorySportList(JWHealthDataSearchParams params, JWValueCallback<List<JWSportInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.Sport);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistorySportList(params, new BleCallback<List<JWSportInfo>>(callback) {
            @Override
            public void success(List<JWSportInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWSportInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistoryTemperatureListByDate(int year, int month, int day, JWValueCallback<List<JWTemperatureInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.Temperature);

        getHistoryTemperatureList(params, callback);
    }

    @Override
    public void getHistoryTemperatureList(JWHealthDataSearchParams params, JWValueCallback<List<JWTemperatureInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.Temperature);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistoryTemperatureList(params, new BleCallback<List<JWTemperatureInfo>>(callback) {
            @Override
            public void success(List<JWTemperatureInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWTemperatureInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistoryWearingTimeListByDate(int year, int month, int day, JWValueCallback<List<JWWearingTimeInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.WearingTime);

        getHistoryWearingTimeList(params, callback);
    }

    @Override
    public void getHistoryWearingTimeList(JWHealthDataSearchParams params, JWValueCallback<List<JWWearingTimeInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.WearingTime);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistoryWearingTimeList(params, new BleCallback<List<JWWearingTimeInfo>>(callback) {
            @Override
            public void success(List<JWWearingTimeInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWWearingTimeInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getRecentUricAcid(JWHealthDataSearchParams params, JWValueCallback<JWUricAcidInfo> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.UricAcid);

        long timeBegin = params.getTimeBegin();
        if (timeBegin == 0) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getRecentUricAcid(params, new BleCallback<JWUricAcidInfo>(callback) {
            @Override
            public void success(JWUricAcidInfo data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, JWUricAcidInfo data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getRecentBloodFat(JWHealthDataSearchParams params, JWValueCallback<JWBloodFatInfo> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.BloodFat);

        long timeBegin = params.getTimeBegin();
        if (timeBegin == 0) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getRecentBloodFat(params, new BleCallback<JWBloodFatInfo>(callback) {
            @Override
            public void success(JWBloodFatInfo data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, JWBloodFatInfo data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getRecentBloodSugarCycle(JWHealthDataSearchParams params, JWValueCallback<JWBloodSugarCycleInfo> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.BloodSugarCycle);

        long timeBegin = params.getTimeBegin();
        if (timeBegin == 0) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getRecentBloodSugarCycle(params, new BleCallback<JWBloodSugarCycleInfo>(callback) {
            @Override
            public void success(JWBloodSugarCycleInfo data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, JWBloodSugarCycleInfo data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistoryUricAcidContinuousMonitoringListByDate(int year, int month, int day, JWValueCallback<List<JWUricAcidContinuousMonitoringInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.WearingTime);

        getHistoryUricAcidContinuousMonitoringList(params, callback);
    }

    @Override
    public void getHistoryUricAcidContinuousMonitoringList(JWHealthDataSearchParams params, JWValueCallback<List<JWUricAcidContinuousMonitoringInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.UricAcidContinuousMonitoring);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistoryUricAcidContinuousMonitoringList(params, new BleCallback<List<JWUricAcidContinuousMonitoringInfo>>(callback) {
            @Override
            public void success(List<JWUricAcidContinuousMonitoringInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWUricAcidContinuousMonitoringInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistoryBloodFatContinuousMonitoringListByDate(int year, int month, int day, JWValueCallback<List<JWBloodFatContinuousMonitoringInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.WearingTime);

        getHistoryBloodFatContinuousMonitoringList(params, callback);
    }

    @Override
    public void getHistoryBloodFatContinuousMonitoringList(JWHealthDataSearchParams params, JWValueCallback<List<JWBloodFatContinuousMonitoringInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.BloodFatContinuousMonitoring);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistoryBloodFatContinuousMonitoringList(params, new BleCallback<List<JWBloodFatContinuousMonitoringInfo>>(callback) {
            @Override
            public void success(List<JWBloodFatContinuousMonitoringInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWBloodFatContinuousMonitoringInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getRecentBodyFat(JWHealthDataSearchParams params, JWValueCallback<JWBodyFatInfo> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.BodyFat);

        long timeBegin = params.getTimeBegin();
        if (timeBegin == 0) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getRecentBodyFat(params, new BleCallback<JWBodyFatInfo>(callback) {
            @Override
            public void success(JWBodyFatInfo data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, JWBodyFatInfo data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistoryBodyFatListByDate(int year, int month, int day, JWValueCallback<List<JWBodyFatInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.BodyFat);

        getHistoryBodyFatListByDate(params, callback);
    }

    @Override
    public void getHistoryBodyFatListByDate(JWHealthDataSearchParams params, JWValueCallback<List<JWBodyFatInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.BodyFat);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistoryBodyFatList(params, new BleCallback<List<JWBodyFatInfo>>(callback) {
            @Override
            public void success(List<JWBodyFatInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWBodyFatInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistoryPhysicalExamList(JWHealthDataSearchParams params, JWValueCallback<List<JWPhysicalExamInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.PhysicalExam);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistoryPhysicalExamList(params, new BleCallback<List<JWPhysicalExamInfo>>(callback) {
            @Override
            public void success(List<JWPhysicalExamInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWPhysicalExamInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }

    @Override
    public void getHistoryHRVRmssdList(int year, int month, int day, JWValueCallback<List<JWHRVRmssdInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (year < 1970 || (month < 1 || month > 12) || (day < 1 || day > 31)) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        long timeBegin = DateUtil.getDate(year, month, day);
        long timePeriod = 24 * 3600000;

        JWHealthDataSearchParams params = new JWHealthDataSearchParams();
        params.setTimeBegin(timeBegin);
        params.setTimePeriod(timePeriod);
        params.setDataType(JWHealthData.DateType.HRVRmssd);

        getHistoryHRVRmssdList(params, callback);
    }

    @Override
    public void getHistoryHRVRmssdList(JWHealthDataSearchParams params, JWValueCallback<List<JWHRVRmssdInfo>> callback) {
        if (callback == null) {
            JWLog.w(TAG, "callback cannot be null");
            return;
        }
        if (params == null) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "params cannot be null");
            return;
        }
        params.setDataType(JWHealthData.DateType.HRVRmssd);
        long timeBegin = params.getTimeBegin();
        long timePeriod = params.getTimePeriod();
        if ((timeBegin == 0 && timePeriod != 0) || timeBegin < timePeriod) {
            callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "time error");
            return;
        }
        DataManager.getInstance().getHistoryHRVRmssdList(params, new BleCallback<List<JWHRVRmssdInfo>>(callback) {
            @Override
            public void success(List<JWHRVRmssdInfo> data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage, List<JWHRVRmssdInfo> data) {
                super.fail(code, errorMessage, data);
            }
        });
    }


    private static class JWDataManagerImplHolder {
        private static final JWDataManagerImpl dataManagerImpl = new JWDataManagerImpl();
    }

}
