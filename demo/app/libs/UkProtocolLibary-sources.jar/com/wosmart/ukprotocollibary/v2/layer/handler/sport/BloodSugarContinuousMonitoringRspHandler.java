package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import android.util.SparseArray;

import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodSugarContinuousMonitoringFunctionInfo;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

public class BloodSugarContinuousMonitoringRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data == null) {
            return;
        }
        SparseArray<SendPacketCallback> callbackMap = TransportManager.getInstance().getCallbackMap();
        SendPacketCallback callback = callbackMap.get(CallbackKeyConstants.KEY_GET_BLOOD_SUGAR_CONTINUOUS_MONITORING);
        if (callback != null) {
            JWBloodSugarContinuousMonitoringFunctionInfo functionInfo = new JWBloodSugarContinuousMonitoringFunctionInfo();

            if (data.length >= 2) {
                functionInfo.enable = (data[0] & 0xff) == 1;
                functionInfo.interval = data[1] & 0xff;
            } else if (data.length == 1) {
                functionInfo.enable = (data[0] & 0xff) == 1;
            }

            callback.onResponse(functionInfo);
        }
    }
}
