package com.wosmart.ukprotocollibary.v2.layer.handler.settings;

import android.util.SparseArray;

import com.wosmart.ukprotocollibary.v2.entity.JWDeviceInfo;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

public class DeviceInfoHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        JWDeviceInfo deviceInfo = new JWDeviceInfo();
        if (data.length >= 5) {
            if (data.length >= 19) {
                deviceInfo.deviceNumber = ((data[0] & 0xff) << 8) | (data[1] & 0xff);

                int buildNum = (data[7] & 0xF8) >> 3;
                int reversion = ((data[7] & 0x07) << 12) | (data[8] << 4) | ((data[9] & 0xF0) >> 4);
                int minorVersion = ((data[9] & 0x0F) << 4) | ((data[10] & 0xF0) >> 4);
                int majorVersion = data[10] & 0x0F;

                deviceInfo.versionCode = minorVersion * 10000 + reversion * 100 + buildNum;
                deviceInfo.versionName = majorVersion + "." + minorVersion + "." + reversion + "." + buildNum;

                int mode31 = data[15] & 0x0F;
                int mode32 = data[16] & 0x0F;
                int mode33 = data[17] & 0x0F;
                int mode34 = data[18] & 0x0F;

                deviceInfo.fontVersionCode = mode31 * 1000000 + mode32 * 10000 + mode33 * 100 + mode34;
                deviceInfo.fontVersionName = mode31 + "." + mode32 + "." + mode33 + "." + mode34;
            } else if (data.length >= 11) {
                deviceInfo.deviceNumber = ((data[0] & 0xff) << 8) | (data[1] & 0xff);
                int buildNum = (data[7] & 0xF8) >> 3;
                int reversion = ((data[7] & 0x07) << 12) | (data[8] << 4) | ((data[9] & 0xF0) >> 4);
                int minorVersion = ((data[9] & 0x0F) << 4) | ((data[10] & 0xF0) >> 4);
                int majorVersion = data[10] & 0x0F;

                deviceInfo.versionCode = minorVersion * 10000 + reversion * 100 + buildNum;
                deviceInfo.versionName = majorVersion + "." + minorVersion + "." + reversion + "." + buildNum;
            } else {
                deviceInfo.deviceNumber = ((data[0] & 0xff) << 8) | (data[1] & 0xff);
                int majorVersion = data[2] & 0xff;
                int minorVersion = data[3] & 0xff;
                int reversion = data[4] & 0xff;
                deviceInfo.versionCode = majorVersion * 10000 + minorVersion * 100 + reversion;
                deviceInfo.versionName = majorVersion + "." + minorVersion + "." + reversion;
            }
        }

        SparseArray<SendPacketCallback> callbackMap = TransportManager.getInstance().getCallbackMap();
        SendPacketCallback callback = callbackMap.get(CallbackKeyConstants.KEY_GET_DEVICE_INFO);
        if (callback != null) {
            callback.onResponse(deviceInfo);
            callbackMap.remove(CallbackKeyConstants.KEY_GET_DEVICE_INFO);
        }
    }

}
