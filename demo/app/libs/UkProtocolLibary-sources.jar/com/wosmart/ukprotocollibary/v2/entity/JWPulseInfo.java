package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWPulseInfo extends JWHealthData implements Serializable {

    public long startTime;

    public int duration;

    public JWPulseInfo() {
    }

    public JWPulseInfo(String userID, String mac, long startTime, int duration) {
        this.userID = userID;
        this.deviceMac = mac;
        this.startTime = startTime;
        this.duration = duration;
    }

    @Override
    public String toString() {
        return "JWPulseInfo{" +
                "userID='" + userID + '\'' +
                ", startTime=" + startTime +
                ", duration=" + duration +
                '}';
    }
}
