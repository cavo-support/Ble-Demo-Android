package com.wosmart.ukprotocollibary.v2.moudle.connector;

import androidx.annotation.NonNull;

import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerKeyPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerPacket;
import com.wosmart.ukprotocollibary.util.StringByteTrans;
import com.wosmart.ukprotocollibary.v2.layer.BlePacketHelper;
import com.wosmart.ukprotocollibary.v2.layer.BleProtocol;

import java.util.Calendar;

public class BasePacketHelper extends BlePacketHelper {

    public @NonNull static byte[] prepareLoginPacket(String userID) {
        byte[] asciiArray = StringByteTrans.Str2Bytes(userID);
        byte[] keyValue = new byte[32];
        System.arraycopy(asciiArray, 0, keyValue, 0, Math.min(asciiArray.length, 32));

        byte[] keyData = prepareKeyPacket(BleProtocol.BindKey.LOGIN_REQ, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.BIND, keyData);
    }

    public @NonNull static byte[] prepareBindPacket(String userID) {
        byte[] asciiArray = StringByteTrans.Str2Bytes(userID);
        byte[] keyValue = new byte[32];
        System.arraycopy(asciiArray, 0, keyValue, 0, Math.min(asciiArray.length, 32));

        byte[] keyData = prepareKeyPacket(BleProtocol.BindKey.BIND_REQ, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.BIND, keyData);
    }

    public @NonNull static byte[] prepareConfirmBindPacket(String userID) {
        byte[] asciiArray = StringByteTrans.Str2Bytes(userID);
        byte[] keyValue = new byte[32];
        System.arraycopy(asciiArray, 0, keyValue, 0, Math.min(asciiArray.length, 32));

        byte[] keyData = prepareKeyPacket(BleProtocol.BindKey.CONFIRM_BIND_REQ, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.BIND, keyData);
    }

    public @NonNull static byte[] prepareUnBindPacket() {
        byte[] keyValue = new byte[1];
        byte[] keyData = prepareKeyPacket(BleProtocol.BindKey.UNBIND, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.BIND, keyData);
    }

    public @NonNull static byte[] prepareReqDeviceFunctionPacket() {
        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.FUNCTION_REQ, null);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

    public @NonNull static byte[] prepareReqDeviceInfoPacket() {
        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.DEVICE_INFO_REQ, null);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }




}
