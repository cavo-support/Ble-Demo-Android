package com.wosmart.ukprotocollibary.v2.layer.handler.multiple;

import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.TempFunctionInfoListener;

public class SupportMedicationReminderHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        // 有这个 key 即代表支持 吃药提醒，无需解析后续的数据
        TempFunctionInfoListener tempFunctionInfoListener = BaseManager.getInstance().getTempFunctionInfoListener();
        if (tempFunctionInfoListener != null) {
            tempFunctionInfoListener.onSupportMedicationReminder();
        }
    }

}
