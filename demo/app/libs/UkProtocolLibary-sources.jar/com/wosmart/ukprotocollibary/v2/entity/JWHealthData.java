package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWHealthData implements Serializable {

    public String userID;

    /**
     * device mac address
     * 设备蓝牙地址
     */
    public String deviceMac;

    /**
     * timestamp, unit millisecond
     * 时间戳，单位 毫秒
     */
    public long time;

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public String getDeviceMac() {
        return deviceMac;
    }

    public void setDeviceMac(String deviceMac) {
        this.deviceMac = deviceMac;
    }

    public enum DateType {

        /**
         * 血压
         */
        BloodPressure,

        /**
         * 血糖
         */
        BloodSugar,

        /**
         * 心率
         */
        HeartRate,

        /**
         * 心率变异性
         */
        HeartRateVariability,

        /**
         * 脉冲
         */
        Pulse,

        /**
         * 桑拿
         */
        Sauna,

        /**
         * 心率体动
         */
        HRMovement,

        /**
         * 睡眠
         */
        Sleep,

        /**
         * 血氧
         */
        SpO2,

        /**
         * 运动
         */
        Sport,

        /**
         * 步数
         */
        Step,

        /**
         * 温度
         */
        Temperature,

        /**
         * 穿戴时间
         */
        WearingTime,

        /**
         * 尿酸评估
         */
        UricAcid,

        /**
         * 血脂评估
         */
        BloodFat,

        /**
         * 血糖评估
         */
        BloodSugarCycle,

        /**
         * 尿酸持续监测
         */
        UricAcidContinuousMonitoring,

        /**
         * 血脂持续监测
         */
        BloodFatContinuousMonitoring,

        /**
         * 体脂
         */
        BodyFat,

        /**
         * 体检
         */
        PhysicalExam,

        /**
         * 心电
         */
        ECG,

        /**
         * hrv rmssd
         */
        HRVRmssd,

        /**
         * 紫外线
         */
        ULTRAVIOLET,

        /**
         * 压力
         */
        PRESSURE,

    }

}
