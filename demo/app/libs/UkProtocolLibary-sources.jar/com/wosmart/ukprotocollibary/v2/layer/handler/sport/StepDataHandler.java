package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import com.wosmart.ukprotocollibary.v2.common.JWBridge;
import com.wosmart.ukprotocollibary.v2.entity.JWStepInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;

import java.util.ArrayList;
import java.util.List;

public class StepDataHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        int packetLength = 12;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return;
        }
        List<JWStepInfo> dataList = new ArrayList<>();
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            int year = (subData[0] & 0x7e) >> 1;
            int month = ((subData[0] & 0x01) << 3) | (subData[1] >> 5) & 0x07;
            int day = subData[1] & 0x1f;
            int count = subData[3] & 0xff;// 现在 count 已废弃, 只会有一条数据

            int offset = ((subData[4] & 0xff) << 3) | ((subData[5] >> 5) & 0x07);
            int mode = (subData[5] >> 3) & 0x03;
            int stepCount = ((subData[5] & 0x07) << 9) | (subData[6] << 1) & 0x1fe | ((subData[7] >> 7) & 0x01);
            int activeTime = (subData[7] >> 3) & 0x0f;
            int calorie = ((subData[7] & 0x07) << 16) | (subData[8] << 8) & 0xff00 | (subData[9] & 0xff);
            int distance = ((subData[10] << 8) | (subData[11] & 0xff)) & 0xffff;

            JWStepInfo info = new JWStepInfo();

            long time = JWBridge.getTime(year, month, day);
            time += offset * 15 * 60000;

            info.setTime(time);
            info.userID = BaseManager.getInstance().getUserID();
            info.deviceMac = BaseManager.getInstance().getMacAddress();
            info.mode = mode;
            info.stepCount = stepCount;
            info.calorie = calorie;
            info.distance = distance;
            info.activeTime = activeTime;

            dataList.add(info);
        }
        if (TransportManager.getInstance().getSyncDataListener() == null) {
            return;
        }
        TransportManager.getInstance().getSyncDataListener().onStepDataReceived(dataList);

    }
}
