package com.wosmart.ukprotocollibary.v2.layer.handler.bind;

import android.util.SparseArray;

import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

public class BindHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length > 0) {
            SparseArray<SendPacketCallback> callbackMap = TransportManager.getInstance().getCallbackMap();
            SendPacketCallback callback = callbackMap.get(CallbackKeyConstants.KEY_BIND);
            if (callback != null) {
                callback.onResponse(data[0] == 0x00);
                callbackMap.remove(CallbackKeyConstants.KEY_BIND);
            }
        }
    }
    
}
