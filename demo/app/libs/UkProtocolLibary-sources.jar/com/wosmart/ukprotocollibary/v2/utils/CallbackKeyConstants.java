package com.wosmart.ukprotocollibary.v2.utils;

public class CallbackKeyConstants {

    public static final int KEY_NONE = 0;

    public static final int KEY_LOGIN = 1;

    public static final int KEY_BIND = 2;

    public static final int KEY_CONFIRM_BIND = 3;

    public static final int KEY_GET_DEVICE_FUNCTION = 4;

    public static final int KEY_GET_DEVICE_INFO = 5;

    public static final int KEY_SET_PULSE = 100;

    public static final int KEY_SET_SLEEP_HELP = 101;

    public static final int KEY_GET_AUDIO_SWITCH = 102;

    public static final int KEY_GET_ALL_NOTIFY_SWITCH = 103;

    public static final int KEY_GET_MEDICATION_REMINDER = 104;

    public static final int KEY_SET_ADDRESS_BOOK = 105;

    public static final int KEY_SET_SOS_NUMBER = 106;

    public static final int KEY_SET_FEMALE_HEALTH = 107;

    public static final int KEY_SET_WEATHER = 108;

    public static final int KEY_GET_DATE_FORMAT = 109;

    public static final int KEY_GET_HIGH_HEART_RATE_REMINDER = 110;

    public static final int KEY_GET_BLOOD_SUGAR_CONTINUOUS_MONITORING = 111;

    public static final int KEY_GET_BODY_FAT_HISTORY = 112;
    public static final int KEY_GET_PHYSICAL_EXAM_HISTORY = 113;

    public static final int KEY_READ_HRV_RMSSD_CONFIG = 114;
    public static final int KEY_READ_DEFAULT_FUNCTION = 115;

    public static final int KEY_READ_HEALTH_RISK_ASSESSMENT = 116;


}
