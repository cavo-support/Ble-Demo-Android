package com.wosmart.ukprotocollibary.v2.entity;

public class JWDrinkWaterReminderInfo {

    /**
     * true is open
     */
    public boolean enable;

    /**
     * 0 - 23, unit hour
     */
    public int startHour;

    /**
     * 0 - 59, unit min
     */
    public int startMin;

    /**
     * 0 - 23, unit hour
     */
    public int endHour;

    /**
     * 0 - 59, unit min
     */
    public int endMin;

    /**
     * 30 - 240, unit min
     */
    public int interval;


}
