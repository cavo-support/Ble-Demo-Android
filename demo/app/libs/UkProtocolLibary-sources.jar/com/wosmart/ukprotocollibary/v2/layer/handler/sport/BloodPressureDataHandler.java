package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import com.wosmart.ukprotocollibary.v2.common.JWBridge;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;

import java.util.ArrayList;
import java.util.List;

public class BloodPressureDataHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        int packetLength = 12;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return;
        }
        List<JWBloodPressureInfo> dataList = new ArrayList<>();
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            int year = (subData[0] & 0x7e) >> 1;
            int month = ((subData[0] & 0x01) << 3) | (subData[1] >> 5) & 0x07;
            int day = subData[1] & 0x1f;
            int count = subData[3] & 0xff;// 现在 count 已废弃, 只会有一条数据

            int minutes = ((subData[6] << 8) | (subData[7] & 0xff)) & 0xffff;
            int second = (subData[8] & 0xff);
            int value = (subData[9] & 0xff);
            int lowValue = (subData[10] & 0xff);
            int highValue = (subData[11] & 0xff);

            JWBloodPressureInfo info = new JWBloodPressureInfo();

            long time = JWBridge.getTime(year, month, day);
            time += minutes * 60000;
            time += second * 1000;

            info.setTime(time);
            info.userID = BaseManager.getInstance().getUserID();
            info.deviceMac = BaseManager.getInstance().getMacAddress();
            info.lowValue = lowValue;
            info.highValue = highValue;

            dataList.add(info);
        }
        if (TransportManager.getInstance().getSyncDataListener() == null) {
            return;
        }
        TransportManager.getInstance().getSyncDataListener().onBloodPressureDataReceived(dataList);
    }
}
