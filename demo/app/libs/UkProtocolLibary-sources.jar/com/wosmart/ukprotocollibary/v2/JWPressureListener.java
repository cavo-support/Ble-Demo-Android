package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.JWPressureInfo;

import java.util.List;

public interface JWPressureListener {


    /**
     * pressure data received
     */
    void onPressureDataReceived(List<JWPressureInfo> dataList);

    /**
     * sync pressure data end
     */
    void onSyncPressureDataEnd();


}
