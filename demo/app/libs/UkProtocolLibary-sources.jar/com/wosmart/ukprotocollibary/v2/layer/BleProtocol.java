package com.wosmart.ukprotocollibary.v2.layer;

public class BleProtocol {

    public static class CommandID {

        public final static byte IMAGE_UPDATE = 0x01;
        public final static byte SETTINGS = 0x02;
        public final static byte BIND = 0x03;
        public final static byte NOTIFY = 0x04;
        public final static byte SPORTS_DATA = 0x05;
        public final static byte FACTORY_TEST = 0x06;
        public final static byte CONTROL = 0x07;
        public final static byte MULTIPLE_CMD = 0x08;// 多命令
        public final static byte TEST_FLASH = 0x09;
        public final static byte LOG = 0x0a;
        public final static byte CUSTOM_MADE = 0x58;

    }

    public static class SettingsKey {

        public final static byte TIMER = 0x01;
        public final static byte ALARM = 0x02;
        public final static byte GET_ALARM_LIST_REQ = 0x03;
        public final static byte GET_ALARM_LIST_RSP = 0x04;
        public final static byte STEP_TARGET = 0x05;
        public final static byte SLEEP_TARGET = 0x06;
        public final static byte CALC_TARGET = 0x07;
        public final static byte USER_PROFILE = 0x10;
        public final static byte UNIT = 0x11;
        public final static byte UNIT_REQ = 0x12;
        public final static byte UNIT_RSP = 0x13;
        public final static byte LOST_MODE = 0x20;
        public final static byte SIT_TOO_LONG_NOTIFY = 0x21;
        public final static byte LEFT_RIGHT_HAND_NOTIFY = 0x22;
        public final static byte PHONE_OS = 0x23;
        public final static byte INCOMING_CALL_LIST = 0x24;
        public final static byte INCOMING_ON_OFF = 0x25;
        public final static byte SIT_TOO_LONG_SWITCH_REQ = 0x26;
        public final static byte SIT_TOO_LONG_SWITCH_RSP = 0x27;
        public final static byte NOTIFY_SWITCH_REQ = 0x28;
        public final static byte NOTIFY_SWITCH_RSP = 0x29;


        public final static byte TURN_OVER_WRIST_SET = 0x2A;
        public final static byte TURN_OVER_WRIST_REQ = 0x2B;
        public final static byte TURN_OVER_WRIST_RSP = 0x2C;

        public final static byte NOTIFY_ALL = 0x2D;

        public final static byte FUNCTION_REQ = 0x36;
        public final static byte FUNCTION_RSP = 0x37;

        public final static byte DEVICE_HOME_PAGER_SET = 0x38;
        public final static byte DEVICE_HOME_PAGER_REQ = 0x39;
        public final static byte DEVICE_HOME_PAGER_RSP = 0x3A;

        public final static byte DEVICE_MULTI_SPORT_REQ = 0x3B;

        public final static byte DEVICE_HRP_PARAMS_REQ = 0x3F;

        public final static byte HOUR_SYSTEM_SETTING = 0x41;
        public final static byte HOUR_SYSTEM_REQ = 0x42;
        public final static byte HOUR_SYSTEM_RSP = 0x43;

        public final static byte UNIT_SYSTEM_SETTING = 0x44;
        public final static byte UNIT_SYSTEM_REQ = 0x45;
        public final static byte UNIT_SYSTEM_RSP = 0x46;

        public final static byte DISTURB_SETTING = 0x47;
        public final static byte DISTURB_REQ = 0x48;
        public final static byte DISTURB_RSP = 0x49;

        public final static byte SCREEN_LIGHT_DURATION_SETTING = 0x4A;
        public final static byte SCREEN_LIGHT_DURATION_REQ = 0x4B;
        public final static byte SCREEN_LIGHT_DURATION_RSP = 0x4C;

        public final static byte LANGUAGE_SETTING = 0x4E;
        public final static byte LANGUAGE_REQ = 0x4F;
        public final static byte LANGUAGE_RSP = 0x50;

        public final static byte DEVICE_INFO_REQ = 0x51;
        public final static byte DEVICE_INFO_RSP = 0x52;

        public final static byte DEVICE_SCREEN_LIGHT_SETTING = 0x53;
        public final static byte DEVICE_SCREEN_LIGHT_REQ = 0x54;
        public final static byte DEVICE_SCREEN_LIGHT_RSP = 0x55;

        public final static byte DEVICE_SWITCH_SETTING = 0x59;
        public final static byte DEVICE_SWITCH_REQ = 0x5A;
        public final static byte DEVICE_SWITCH_RSP = 0x5B;

        public final static byte CLASSIC_ADDRESS_REQ = 0x60;

        public final static byte CLASSIC_STATUS_REQ = 0x61;

        public final static byte ALARM2_SETTING = 0x65;
        public final static byte ALARM2_REQ = 0x66;
        public final static byte ALARM2_RSP = 0x67;

        public final static byte AUDIO_SET = 0x68;
        public final static byte AUDIO_GET_REQ = 0x69;
        public final static byte AUDIO_GET_RSP = 0x6A;

        public final static byte FULL_SYNC = (byte) 0xFA;

        public final static byte ADDRESS_BOOK_REQ = 0x6D;
        public final static byte ADDRESS_BOOK_RSP = 0x6E;

        public final static byte SLEEP_ALL_SWITCH = 0x6F;
        public final static byte SLEEP_ALL_SWITCH_REQ = 0x70;
        public final static byte SLEEP_ALL_SWITCH_RSP = 0x71;

        public final static byte HYPOXIA_SWITCH = 0x72;
        public final static byte HYPOXIA_SWITCH_REQ = 0x73;
        public final static byte HYPOXIA_SWITCH_RSP = 0x74;

        public final static byte HIGH_HEART_RATE_SWITCH = 0x75;
        public final static byte HIGH_HEART_RATE_SWITCH_REQ = 0x76;
        public final static byte HIGH_HEART_RATE_SWITCH_RSP = 0x77;

        public final static byte DEVICE_DATE_FORMAT_SET = 0x78;
        public final static byte DEVICE_DATE_FORMAT_REQ = 0x79;
        public final static byte DEVICE_DATE_FORMAT_RSP = 0x7A;

        public final static byte SOS_NUMBER_REQ = 0x7B;
        public final static byte SOS_NUMBER_RSP = 0x7C;

        public final static byte MEDICATION_REMINDER_SET = 0x7D;
        public final static byte MEDICATION_REMINDER_REQ = 0x7E;
        public final static byte MEDICATION_REMINDER_RSP = 0x7F;

    }

    public static class BindKey {

        public final static byte BIND_REQ = 0x01;
        public final static byte BIND_RSP = 0x02;
        public final static byte LOGIN_REQ = 0x03;
        public final static byte LOGIN_RSP = 0x04;
        public final static byte UNBIND = 0x05;
        public final static byte SUP_BIND_KEY = 0x06;
        public final static byte CONFIRM_BIND_REQ = 0x07;
        public final static byte CONFIRM_BIND_RSP = 0x08;

    }

    public static class NotifyKey {


    }

    public static class SportKey {

        public final static byte SPORTS_REQ = 0x01;
        public final static byte SPORTS_STEP_RSP = 0x02;
        public final static byte SPORTS_SLEEP_RSP = 0x03;
        public final static byte SPORTS_RUNNIG_RSP_MORE = 0x04;
        public final static byte SPORTS_SLEEP_SET_RSP = 0x05;
        public final static byte SPORTS_DATA_SYNC = 0x06;
        public final static byte SPORTS_HIS_SYNC_BEG = 0x07;
        public final static byte SPORTS_HIS_SYNC_END = 0x08;
        public final static byte SPORTS_DATA_TODAY_SYNC = 0x09;
        public final static byte SPORTS_DATA_LAST_SYNC = 0x0a;
        public final static byte SPORTS_DATA_TODAY_ADJUST_REQ = 0x0b;// 需要确认的功能
        public final static byte SPORTS_DATA_TODAY_ADJUST_RSP = 0x0c;// 需要确认的功能
        public final static byte SPORTS_HRP_SINGLE_REQ = 0x0d;// 单次读取心率请求
        public final static byte SPORTS_HRP_CONTINUE_SET = 0x0e;// 连续心率采集设定
        public final static byte SPORTS_HRP_DATA_RSP = 0x0f;// 心率数据返回
        public final static byte SPORTS_HRP_DEVICE_CANCEL_READ_HRP = 0x10;// 手环取消单次心率读取
        public final static byte SPORTS_HRP_CONTINUE_PARAMS_GET = 0x11;// 连续心率采集参数获取
        public final static byte SPORTS_HRP_CONTINUE_PARAMS_RSP = 0x12;// 连续心率采集参数返回
        public final static byte SPORTS_BP_DATA_RSP = 0x13;
        public final static byte SPORTS_BP_SINGLE_REQ = 0x14;
        public final static byte SPORTS_BP_CANCEL_READ = 0x15;
        public final static byte SPORTS_DATA_RSP = 0x16;
        public final static byte SPORTS_MODEL_RSP = 0x17;
        public final static byte SPORTS_HR_PARAMS_RSP = 0x18;
        public final static byte APP_SPORT_RATE_DETECT_START = 0x19;
        public final static byte APP_SPORT_RATE_DETECT_STOP = 0x1A;
        public final static byte SPORTS_HRP_DATA_LIST_RSP = 0x1B;
        public final static byte SPORTS_DATA_END = 0x1C;
        public final static byte SLEEP_TIME_ADJUST = 0x1E;
        public final static byte SLEEP_ADJUST = 0x1F;
        public final static byte TEMP_SET = 0x20;
        public final static byte TEMP_RSP = 0x21;
        public final static byte TEMP_CONTROL_SET = 0x22;
        public final static byte TEMP_CONTROL_REQ = 0x23;
        public final static byte TEMP_CONTROL_RSP = 0x24;
        public final static byte BP2_CONTROL_SET = 0x25;
        public final static byte BP2_CONTROL_REQ = 0x26;
        public final static byte BP2_CONTROL_RSP = 0x27;
        public final static byte HR_DATA_RSP = 0x28;
        public final static byte HR_DATA_LIST_RSP = 0x29;
        public final static byte DEVICE_STATUS_REQ = 0x2A;
        public final static byte DEVICE_STATUS_RSP = 0x2B;
        public final static byte SPO2_DATA_RSP = 0x2C;
        public final static byte SPO2_SETTING = 0x2D;
        public final static byte SPO2_RSP = 0x2E;
        public final static byte SPO2_CONTINUOUS_SETTING = 0x33;
        public final static byte SPO2_CONTINUOUS_GET = 0x34;
        public final static byte SPO2_CONTINUOUS_RSP = 0x35;
        public final static byte ECG_STATUS_REQ = 0x36;
        public final static byte ECG_BELT_SET = 0x37;
        public final static byte ECG_STATUS_RSP = 0x38;
        public final static byte ECG_DATA_RSP = 0x39;
        public final static byte READ_HEALTH_REQ = 0x3A;
        public final static byte READ_HEALTH_RSP = 0x3B;
        public final static byte RTK_HRV_RSP = 0x3C;
        public final static byte BP3_CONTINUOUS_SET = 0x3d;
        public final static byte BP3_CONTINUOUS_REQ = 0x3e;
        public final static byte BP3_CONTINUOUS_RSP = 0x3f;
        public final static byte GLU_HISTORY_RSP = 0x40;
        public final static byte GLU_TEST_START = 0x41;
        public final static byte GLU_TEST_STOP = 0x42;
        public final static byte GLU_CONTINUOUS_SET = 0x43;
        public final static byte GLU_CONTINUOUS_REQ = 0x44;
        public final static byte GLU_CONTINUOUS_RSP = 0x45;
        public final static byte GLU_PRIVATE_SET = 0x46;
        public final static byte GLU_PRIVATE_REQ = 0x47;
        public final static byte GLU_PRIVATE_RSP = 0x48;
        public final static byte WEARING_TIME_RSP = 0x49;
        public final static byte URIC_ACID_RSP = 0x4A;
        public final static byte BLOOD_FAT_RSP = 0x4B;
        public final static byte BLOOD_SUGAR_CYCLE_RSP = 0x4C;
        public final static byte URIC_ACID_CONTINUOUS_MONITORING_RSP = 0x4D;
        public final static byte BLOOD_FAT_CONTINUOUS_MONITORING_RSP = 0x4E;
        public final static byte CONTINUOUS_MONITORING_SET = 0x4F;
        public final static byte CONTINUOUS_MONITORING_REQ = 0x50;
        public final static byte CONTINUOUS_MONITORING_RSP = 0x51;
        public final static byte DEVICE_MEASURE_SET = 0x52;
        public final static byte DEVICE_MEASURE_CANCELED = 0x53;
        public final static byte BODY_FAT_HISTORY_REQ = 0x54;
        public final static byte BODY_FAT_HISTORY_RSP = 0x55;
        public final static byte PHYSICAL_EXAM_HISTORY_REQ = 0x56;
        public final static byte PHYSICAL_EXAM_HISTORY_RSP = 0x57;
        public final static byte ULTRAVIOLET_RQE = 0x58;
        public final static byte ULTRAVIOLET_RSP = 0x59;
        public final static byte PRESSURE_RQE = 0x5A;
        public final static byte PRESSURE_RSP = 0x5B;

    }

    public static class MultipleCmdKey {
        public final static byte PRIVATE_BP = 0x01;// 私人血压
        public final static byte SOS_NUMBER = 0x02;// SOS
        public final static byte DRINK_WATER_REMINDER = 0x03;// 喝水提醒
        public final static byte TEMPERATURE_REMINDER = 0x04;// 体温提醒
        public final static byte MEDICATION_REMINDER = 0x05;// 吃药提醒
        public final static byte FEMALE_HEALTH = 0x06;// 女性健康
        public final static byte WEATHER = 0x07;// 天气
        public final static byte WEARING_TIME = 0x08;// 佩戴时间
        public final static byte URIC_ACID = 0x09;// 尿酸
        public final static byte BLOOD_FAT = 0x0A;// 血脂
        public final static byte BLOOD_SUGAR_CYCLE = 0x0B;// 血糖
        public final static byte PRIVATE_URIC_ACID = 0x0C;// 私人尿酸
        public final static byte PRIVATE_BLOOD_FAT = 0x0D;// 私人血脂
        public final static byte BODY_FAT = 0x0E;// 体脂
        public final static byte PHYSICAL_EXAM = 0x0F;// 体检
        public final static byte ULTRAVIOLET = 0x10;//

    }

    public static class CustomModeKey {
        public final static byte TRANSLATE_RSP = 0x01;
        public final static byte EXERCISE_SET = 0x02;
        public final static byte NOTIFY_SET = 0x03;
        public final static byte NOTIFY_REQ = 0x04;
        public final static byte NOTIFY_RSP = 0x05;
        public final static byte NOTIFY_SYNC = 0x06;
        public final static byte STYLE_COLOR = 0x07;
        public final static byte NOTIFY_CONTENT = 0x08;
        public final static byte SUPPORT_PULSE = 0x09;
        public final static byte PULSE_SET = 0x0A;
        public final static byte PULSE_RSP = 0x0B;
        public final static byte SUPPORT_SLEEP_HELP = 0x0C;
        public final static byte SLEEP_HELP_SET = 0x0D;
        public final static byte SLEEP_HELP_RSP = 0x0E;
        public final static byte SYNC_PULSE_DATA_RSP = 0x0F;
        public final static byte SYNC_PULSE_STATUS_RSP = 0x10;
        public final static byte PULSE_FINISHED_RSP = 0x11;
        public final static byte SUPPORT_SAUNA = 0x12;
        public final static byte SYNC_SAUNA_DATA_RSP = 0x13;
        public final static byte SYNC_SAUNA_STATUS_RSP = 0x14;
        public final static byte HRV_RMSSD_SET = 0x1A;
        public final static byte HRV_RMSSD_REQ = 0x1B;
        public final static byte HRV_RMSSD_RSP = 0x1C;
        public final static byte SYNC_HRV_RMSSD_RSP = 0x1D;
        public final static byte SYNC_HR_MOVEMENT_DATA_RSP = 0x1E;


    }

    public static class ControlKey {
        public final static byte PHOTO_RSP = 0x01;
        public final static byte FIND_PHONE_RSP = 0x02;
        public final static byte APP_REQ = 0x11;
        public final static byte TIMER_SETTING = 0x12;
        public final static byte TIMER_REQ = 0x13;
        public final static byte TIMER_RSP = 0x14;
        public final static byte CUSTOM_UI_SETTING = 0x15;
        public final static byte CUSTOM_UI_REQ = 0x16;
        public final static byte CUSTOM_UI_RSP = 0x17;
        public final static byte MUSIC_CONTROL = 0x18;
        public final static byte MUSIC_STATUS = 0x19;
        public final static byte OTA_STATUS_REQ = 0x1a;
        public final static byte OTA_STATUS_RSP = 0x1b;
        public final static byte FIND_PHONE_RSP2 = 0x1c;
        public final static byte CUS_REQ = 0x1c;
        public final static byte CUS_RSP = 0x1d;
        public final static byte CUS_SETTING = 0x1e;
        public final static byte FEMALE_SET = 0x1E;
        public final static byte FEMALE_RSP = 0x1F;
        public final static byte WEATHER_SET = 0x20;
        public final static byte WEATHER_RSP = 0x21;
        public final static byte HIDE_HEALTH_FUNCTION_SET = 0x22;
        public final static byte HIDE_HEALTH_FUNCTION_REQ = 0x23;
        public final static byte HIDE_HEALTH_FUNCTION_RSP = 0x24;
    }

    public static class FactoryKey {

        public final static byte DEFAULT_FUNCTION_SET = 0x28;// 默认功能设置
        public final static byte DEFAULT_FUNCTION_REQ = 0x3D;// 读取默认功能
        public final static byte DEFAULT_FUNCTION_RSP = 0x3E;// 默认功能返回

    }


}
