package com.wosmart.ukprotocollibary.v2.layer.handler.settings;

import android.util.SparseArray;

import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

public class SetSOSNumberRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length > 0) {
            SparseArray<SendPacketCallback> callbackMap = TransportManager.getInstance().getCallbackMap();
            SendPacketCallback callback = callbackMap.get(CallbackKeyConstants.KEY_SET_SOS_NUMBER);
            if (callback != null) {
                int status = data[0] & 0xff;
                callback.onResponse(status == 0x02);
            }
        }
    }

}
