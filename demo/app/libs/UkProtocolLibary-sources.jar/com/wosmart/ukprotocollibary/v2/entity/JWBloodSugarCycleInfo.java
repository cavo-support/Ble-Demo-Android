package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;
import java.util.List;

public class JWBloodSugarCycleInfo extends JWHealthData implements Serializable {

    public static final int RESULT_CODE_NONE = 0;

    /**
     * 佩戴时间不足
     */
    public static final int RESULT_CODE_INSUFFICIENT_WEARING_TIME = 1;

    /**
     * 低风险
     */
    public static final int RESULT_CODE_LOW_RISK = 2;

    /**
     * 中风险
     */
    public static final int RESULT_CODE_MEDIUM_RISK = 3;

    /**
     * 高风险
     */
    public static final int RESULT_CODE_HIGH_RISK = 4;

    /**
     * 周期开始时间
     */
    public long cycleStartTime;

    /**
     * 周期结束时间
     */
    public long cycleEndTime;

    /**
     * 周期出值时间，（白天、黑夜 累积有 14 个出值）
     * the result time, day and night cumulatively have 14 out values
     */
    public long valueTime;

    /**
     * 评估结果
     */
    public int evaluationResult;

    /**
     * daily data details
     * 每日数据详情
     */
    public List<JWCycleDayStatus> dayStatusList;



    @Override
    public String toString() {
        return "JWBloodSugarCycleInfo{" +
                "cycleStartTime=" + cycleStartTime +
                ", cycleEndTime=" + cycleEndTime +
                ", valueTime=" + valueTime +
                ", evaluationResult=" + evaluationResult +
                ", dayStatusList=" + dayStatusList +
                '}';
    }

}
