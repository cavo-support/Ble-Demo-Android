package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateVariabilityInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSleepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSpO2Info;
import com.wosmart.ukprotocollibary.v2.entity.JWSportInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWStepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSyncDataInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWearingTimeInfo;

import java.util.List;

public interface JWSyncDataListener extends JWErrorCallback {

    /**
     * sync health data started
     * 同步数据开始
     */
    void onSyncDataStart(JWSyncDataInfo syncDataInfo);

    /**
     * sync health data finished
     * 同步数据结束
     */
    void onSyncDataFinished();

    /**
     * sync health data finished
     * 同步数据失败
     */
    void onSyncDataFailed();

    /**
     * step info received
     * 步数
     */
    void onStepDataReceived(List<JWStepInfo> stepInfoList);

    /**
     * sleep info received
     * 睡眠
     */
    void onSleepDataReceived(List<JWSleepInfo> sleepInfoList);

    /**
     * heart rate info received
     * 心率
     */
    void onHeartRateDataReceived(List<JWHeartRateInfo> heartRateInfoList);

    /**
     * heart rate variability info received
     * 心率变异性
     */
    void onHeartRateVariabilityDataReceived(List<JWHeartRateVariabilityInfo> heartRateVariabilityInfoList);

    /**
     * temperature info received
     * 温度
     */
    void onTemperatureDataReceived(List<JWTemperatureInfo> temperatureInfoList);

    /**
     * blood pressure info received
     * 血压
     */
    void onBloodPressureDataReceived(List<JWBloodPressureInfo> bpInfoList);

    /**
     * SpO2 received
     * 血氧
     */
    void onSpO2DataReceived(List<JWSpO2Info> spo2InfoList);

    /**
     * blood sugar received
     * 血糖
     */
    void onBloodSugarDataReceived(List<JWBloodSugarInfo> bsInfoList);

    /**
     * sport received
     * 运动
     */
    void onSportDataReceived(List<JWSportInfo> sportInfoList);

    /**
     * wearing time received
     * 穿戴时间
     */
    void onWearingTimeDataReceived(List<JWWearingTimeInfo> wearingTimeInfoList);

    /**
     * uric acid received
     * 尿酸周期
     */
    void onUricAcidDataReceived(List<JWUricAcidInfo> uricAcidInfoList);

    /**
     * blood fat received
     * 血脂周期
     */
    void onBloodFatDataReceived(List<JWBloodFatInfo> bloodFatInfoList);

    /**
     * blood sugar cycle received
     * 血糖周期
     */
    void onBloodSugarCycleDataReceived(List<JWBloodSugarCycleInfo> bloodFatInfoList);

    /**
     * uric acid continuous monitoring received
     * 尿酸连续监测
     */
    void onUricAcidContinuousMonitoringDataReceived(List<JWUricAcidContinuousMonitoringInfo> uricAcidContinuousMonitoringInfoList);

    /**
     * blood fat continuous monitoring received
     * 血脂连续监测
     */
    void onBloodSugarContinuousMonitoringDataReceived(List<JWBloodFatContinuousMonitoringInfo> bloodFatContinuousMonitoringInfoList);

}
