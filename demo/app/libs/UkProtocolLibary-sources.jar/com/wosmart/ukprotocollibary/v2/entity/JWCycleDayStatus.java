package com.wosmart.ukprotocollibary.v2.entity;

public class JWCycleDayStatus {

    /**
     * 不达标
     */
    public static final int INVALID = 0;

    /**
     * 达标
     */
    public static final int VALID = 1;

    /**
     * day status
     * 白天状态
     * @see JWCycleDayStatus#INVALID
     * @see JWCycleDayStatus#VALID
     */
    public int day;

    /**
     * night status
     * 晚上状态
     * @see JWCycleDayStatus#INVALID
     * @see JWCycleDayStatus#VALID
     */
    public int night;

    /**
     * time of day
     * 当天时间
     */
    public long time;

    @Override
    public String toString() {
        return "\nJWCycleDayStatus{" +
                "day=" + day +
                ", night=" + night +
                ", time=" + time +
                "}";
    }

}
