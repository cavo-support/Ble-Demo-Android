package com.wosmart.ukprotocollibary.v2.layer.handler.custom;

import com.wosmart.ukprotocollibary.v2.JWPulseListener;
import com.wosmart.ukprotocollibary.v2.entity.JWPulseInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class SyncPulseDataRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        JWPulseListener pulseListener = TransportManager.getInstance().getPulseListener();
        if (pulseListener == null) {
            return;
        }
        if ((data.length < 8) || (data.length % 8) != 0) {
            return;
        }
        List<JWPulseInfo> pulseInfoList = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        byte[] subData = new byte[8];
        for (int i = 0; i < data.length / 8; i++) {

            System.arraycopy(data, i * 8, subData, 0, 8);

            int year = (subData[0] & 0x7e) >> 1;
            int month = ((subData[0] & 0x01) << 3) | (subData[1] >> 5) & 0x07;
            int day = subData[1] & 0x1f;
            int minute = ((subData[2] << 8) | (subData[3] & 0xff)) & 0xffff;
            int second = (subData[4] & 0xff);

            int duration = (((subData[5] & 0xff) << 16) | ((subData[6] & 0xff) << 8) | (subData[7] & 0xff));

            calendar.clear();
            calendar.set(2000 + year, month - 1, day);

            long time = calendar.getTimeInMillis();

            time += minute * 60000;
            time += second * 1000;

            JWPulseInfo info = new JWPulseInfo(BaseManager.getInstance().getUserID(), BaseManager.getInstance().getMacAddress(), time, duration);

            pulseInfoList.add(info);
        }

        pulseListener.onPulseDataReceived(pulseInfoList);
    }

}
