package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRMovementInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateVariabilityInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPulseInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSaunaInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSleepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSpO2Info;
import com.wosmart.ukprotocollibary.v2.entity.JWSportInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWStepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWearingTimeInfo;

import java.util.List;

public abstract class JWDataManager {

    static JWDataManager getInstance() {
        return JWDataManagerImpl.getInstance();
    }

    /**
     * add pulse listener
     */
    public abstract void addPulseListener(JWPulseListener listener);

    /**
     * remove pulse listener
     */
    public abstract void removePulseListener(JWPulseListener listener);

    /**
     * add sauna listener
     */
    public abstract void addSaunaListener(JWSaunaListener listener);

    /**
     * remove sauna listener
     */
    public abstract void removeSaunaListener(JWSaunaListener listener);

    /**
     * add HRVRmssd listener
     */
    public abstract void addHRVRmssdListener(JWHRVRmssdListener listener);

    /**
     * remove HRVRmssd listener
     */
    public abstract void removeHRVRmssdListener(JWHRVRmssdListener listener);

    /**
     * add ultraviolet listener
     */
    public abstract void addUltravioletListener(JWUltravioletListener listener);

    /**
     * remove ultraviolet listener
     */
    public abstract void remoteUltravioletListener(JWUltravioletListener listener);

    /**
     * add pressure listener
     */
    public abstract void addPressureListener(JWPressureListener listener);

    /**
     * remove pressure listener
     */
    public abstract void removePressureListener(JWPressureListener listener);

    /**
     * sync device health data, after synchronized, you can receive some data if the device records
     * step data {@link JWSyncDataListener#onStepDataReceived(List)}
     * sleep data {@link JWSyncDataListener#onSleepDataReceived(List)}
     * heart rate data {@link JWSyncDataListener#onHeartRateDataReceived(List)}
     * temperature data {@link JWSyncDataListener#onTemperatureDataReceived(List)}
     * blood pressure  data {@link JWSyncDataListener#onBloodPressureDataReceived(List)}
     * SpO2 data {@link JWSyncDataListener#onSpO2DataReceived(List)}
     * blood sugar data {@link JWSyncDataListener#onBloodSugarDataReceived(List)}
     * sport data {@link JWSyncDataListener#onSportDataReceived(List)}
     * wearing time data {@link JWSyncDataListener#onWearingTimeDataReceived(List)}
     * uric acid data {@link JWSyncDataListener#onUricAcidDataReceived(List)}
     * blood fat data {@link JWSyncDataListener#onBloodFatDataReceived(List)}
     */
    public abstract void syncHealthData(JWSyncDataListener syncDataListener);

    /**
     * get history step data by date
     *
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistoryStepListByDate(int year, int month, int day, JWValueCallback<List<JWStepInfo>> callback);

    /**
     * get history step data
     *
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistoryStepList(JWHealthDataSearchParams params, JWValueCallback<List<JWStepInfo>> callback);

    /**
     * get history sleep data by date
     * 获取指定日期睡眠数据
     *
     * for example, if you want get sleep data at 2022-03-04, we will search data between 8:00 last night and 10:00 this morning, range 14 hours
     * 举个例子，如果你想获取 2022-03-04 的原始睡眠数据，我们会返回昨晚 8 点到今天 10 点之间的数据
     *
     * this method will return original sleep data without filter, if you don't want to filter invalid data,
     * you can user another method {@link com.wosmart.ukprotocollibary.model.sleep.filter.SleepFilter#filterByData(int, int, int)}
     * this filter method will filter the data between 8:00 last night and 10:00 today, and will also calculate the number of awakenings, deep sleep/light sleep time.
     *
     * 这个函数会返回无过滤的原始数据，我们建议使用 {@link com.wosmart.ukprotocollibary.model.sleep.filter.SleepFilter#filterByData(int, int, int)}
     * 这个函数会过滤昨晚 8 点到今天 10 点之间的数据，同时会计算苏醒次数，深睡/浅睡时间等数据
     *
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistorySleepListByDate(int year, int month, int day, JWValueCallback<List<JWSleepInfo>> callback);

    /**
     * get history sleep data
     *
     * @param params   for example, if you want get sleep data at 2022-03-04, in most cases, begin time = 2022-03-03 20:00, end time 2022-03-04 10:00, range 14 hours
     *                 举个例子，如果你想获取 2022-03-04 的原始睡眠数据，一般情况下我们应该从 2022-03-04 20:00 开始计算，然后到当天 10 点截止
     *                 params.timeBegin = 1646308800000
     *                 params.timePeriod = 14 * 3600s * 1000
     */
    public abstract void getHistorySleepList(JWHealthDataSearchParams params, JWValueCallback<List<JWSleepInfo>> callback);

    /**
     * get history step data by date
     *
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistoryBloodPressureListByDate(int year, int month, int day, JWValueCallback<List<JWBloodPressureInfo>> callback);

    /**
     * get history blood pressure data
     *
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistoryBloodPressureList(JWHealthDataSearchParams params, JWValueCallback<List<JWBloodPressureInfo>> callback);

    /**
     * get history blood sugar data by date
     *
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistoryBloodSugarListByDate(int year, int month, int day, JWValueCallback<List<JWBloodSugarInfo>> callback);

    /**
     * get history blood sugar data
     *
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistoryBloodSugarList(JWHealthDataSearchParams params, JWValueCallback<List<JWBloodSugarInfo>> callback);

    /**
     * get history heart rate data by date
     *
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistoryHeartRateListByDate(int year, int month, int day, JWValueCallback<List<JWHeartRateInfo>> callback);

    /**
     * get history heart rate data
     *
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistoryHeartRateList(JWHealthDataSearchParams params, JWValueCallback<List<JWHeartRateInfo>> callback);

    /**
     * get history heart rate variability data by date
     *
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistoryHeartRateVariabilityListByDate(int year, int month, int day, JWValueCallback<List<JWHeartRateVariabilityInfo>> callback);

    /**
     * get history heart rate variability data
     *
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistoryHeartRateVariabilityList(JWHealthDataSearchParams params, JWValueCallback<List<JWHeartRateVariabilityInfo>> callback);

    /**
     * get history pulse data by date
     *
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistoryPulseListByDate(int year, int month, int day, JWValueCallback<List<JWPulseInfo>> callback);

    /**
     * get history pulse data
     *
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistoryPulseList(JWHealthDataSearchParams params, JWValueCallback<List<JWPulseInfo>> callback);

    /**
     * get history sauna data by date
     *
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistorySaunaListByDate(int year, int month, int day, JWValueCallback<List<JWSaunaInfo>> callback);

    /**
     * get history sauna data
     *
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistorySaunaList(JWHealthDataSearchParams params, JWValueCallback<List<JWSaunaInfo>> callback);

    /**
     * get history hr movement data by date
     *
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistoryHRMovementListByDate(int year, int month, int day, JWValueCallback<List<JWHRMovementInfo>> callback);

    /**
     * get history hr movement data
     *
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistoryHRMovementList(JWHealthDataSearchParams params, JWValueCallback<List<JWHRMovementInfo>> callback);


    /**
     * get history spO2 data by date
     *
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistorySpO2ListByDate(int year, int month, int day, JWValueCallback<List<JWSpO2Info>> callback);

    /**
     * get history spO2 data
     *
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistorySpO2List(JWHealthDataSearchParams params, JWValueCallback<List<JWSpO2Info>> callback);

    /**
     * get history sport data by date
     *
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistorySportListByDate(int year, int month, int day, JWValueCallback<List<JWSportInfo>> callback);

    /**
     * get history sport data
     *
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistorySportList(JWHealthDataSearchParams params, JWValueCallback<List<JWSportInfo>> callback);

    /**
     * get history temperature data by date
     *
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistoryTemperatureListByDate(int year, int month, int day, JWValueCallback<List<JWTemperatureInfo>> callback);

    /**
     * get history temperature data
     *
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistoryTemperatureList(JWHealthDataSearchParams params, JWValueCallback<List<JWTemperatureInfo>> callback);

    /**
     * get history wearing time data by date
     * 指定日期获取佩戴时间
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistoryWearingTimeListByDate(int year, int month, int day, JWValueCallback<List<JWWearingTimeInfo>> callback);

    /**
     * get history wearing time data
     * 指定条件获取佩戴时间
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistoryWearingTimeList(JWHealthDataSearchParams params, JWValueCallback<List<JWWearingTimeInfo>> callback);

    /**
     * get recent uric acid data
     * 根据日期获取最近的尿酸周期
     * @param params   for example, if you want get most recent data from 2022-03-04
     *                 params.deviceMac = ""
     *                 params.timeBegin = 1646348400000
     */
    public abstract void getRecentUricAcid(JWHealthDataSearchParams params, JWValueCallback<JWUricAcidInfo> callback);

    /**
     * get recent blood fat data
     * 指定条件获取最近的血脂周期
     * @param params   for example, if you want get most recent data from 2022-03-04
     *                 params.deviceMac = ""
     *                 params.timeBegin = 1646348400000
     */
    public abstract void getRecentBloodFat(JWHealthDataSearchParams params, JWValueCallback<JWBloodFatInfo> callback);

    /**
     * get recent blood sugar cycle data
     * 指定条件获取最近的血糖周期
     * @param params   for example, if you want get most recent data from 2022-03-04
     *                 params.deviceMac = ""
     *                 params.timeBegin = 1646348400000
     */
    public abstract void getRecentBloodSugarCycle(JWHealthDataSearchParams params, JWValueCallback<JWBloodSugarCycleInfo> callback);

    /**
     * get history uric acid continuous monitoring data by date
     * 指定日期获取尿酸持续监测数据
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistoryUricAcidContinuousMonitoringListByDate(int year, int month, int day, JWValueCallback<List<JWUricAcidContinuousMonitoringInfo>> callback);

    /**
     * get history uric acid continuous monitoring data
     * 指定条件获取尿酸持续监测数据
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistoryUricAcidContinuousMonitoringList(JWHealthDataSearchParams params, JWValueCallback<List<JWUricAcidContinuousMonitoringInfo>> callback);

    /**
     * get history blood fat continuous monitoring data by date
     * 指定日期获取血脂持续监测数据
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistoryBloodFatContinuousMonitoringListByDate(int year, int month, int day, JWValueCallback<List<JWBloodFatContinuousMonitoringInfo>> callback);

    /**
     * get history blood fat continuous monitoring data
     * 指定条件获取血脂持续监测数据
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistoryBloodFatContinuousMonitoringList(JWHealthDataSearchParams params, JWValueCallback<List<JWBloodFatContinuousMonitoringInfo>> callback);

    /**
     * get recent body fat data
     * 根据日期获取最近的体脂
     * @param params   for example, if you want get most recent data from 2022-03-04
     *                 params.deviceMac = ""
     *                 params.timeBegin = 1646348400000
     */
    public abstract void getRecentBodyFat(JWHealthDataSearchParams params, JWValueCallback<JWBodyFatInfo> callback);

    /**
     * get history body fat data by date
     * 指定日期获取体脂数据
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistoryBodyFatListByDate(int year, int month, int day, JWValueCallback<List<JWBodyFatInfo>> callback);

    /**
     * get history body fat data
     * 指定条件获取体脂数据
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistoryBodyFatListByDate(JWHealthDataSearchParams params, JWValueCallback<List<JWBodyFatInfo>> callback);

    /**
     * get history physical exam data
     * 指定条件获取体检数据
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistoryPhysicalExamList(JWHealthDataSearchParams params, JWValueCallback<List<JWPhysicalExamInfo>> callback);

    /**
     * get history hrv rmssd data by date
     *
     * @param year  since 1970
     * @param month 1 - 12
     * @param day   1 - 31
     */
    public abstract void getHistoryHRVRmssdList(int year, int month, int day, JWValueCallback<List<JWHRVRmssdInfo>> callback);

    /**
     * get history hrv rmssd data
     *
     * @param params   for example, if you want get data at 2022-03-04 07:00 - 2022-03-04 08:00
     *                 params.timeBegin = 1646348400000
     *                 params.timePeriod = 3600s * 1000
     * @param callback data callback
     */
    public abstract void getHistoryHRVRmssdList(JWHealthDataSearchParams params, JWValueCallback<List<JWHRVRmssdInfo>> callback);

}
