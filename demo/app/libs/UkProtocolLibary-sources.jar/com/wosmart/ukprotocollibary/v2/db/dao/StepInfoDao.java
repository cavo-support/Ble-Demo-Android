package com.wosmart.ukprotocollibary.v2.db.dao;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.db.entity.StepInfo;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.AbstractDaoSession;
import org.greenrobot.greendao.Property;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseStatement;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.List;

public class StepInfoDao extends AbstractDao<StepInfo, Long> {

    public static final String TABLENAME = "STEP_INFO";

    public static class Properties {
        public final static Property time = new Property(0, Long.class, "time", true, "TIME");
        public final static Property userID = new Property(1, String.class, "userID", true, "USER_ID");
        public final static Property mac = new Property(2, String.class, "mac", true, "MAC");
        public final static Property date = new Property(3, java.util.Date.class, "date", false, "DATE");
        public final static Property stepCount = new Property(4, int.class, "stepCount", false, "STEP_COUNT");
        public final static Property calorie = new Property(5, int.class, "calorie", false, "CALORIE");
        public final static Property distance = new Property(6, int.class, "distance", false, "DISTANCE");
        public final static Property mode = new Property(7, int.class, "mode", false, "MODE");
        public final static Property activeTime = new Property(8, Long.class, "activeTime", false, "ACTIVE_TIME");
    }

    public StepInfoDao(DaoConfig config) {
        super(config);
    }

    public StepInfoDao(DaoConfig config, AbstractDaoSession daoSession) {
        super(config, daoSession);
    }








    public List<StepInfo> queryDataList(String userID, String mac, long timeBegin, long timePeriod, int count) {
        String timeColName = Properties.time.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;
        String dateColName = Properties.date.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition;
        if (timeBegin == 0) {
            // 从当前时间
            timeCondition = timeColName + " <= " + System.currentTimeMillis();
        } else {
            timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));
        }
        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");
        String macCondition = TextUtils.isEmpty(mac) ? "" : (" " + macColName + " = '" + mac + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        if (!TextUtils.isEmpty(macCondition)) {
            sb.append(" and ").append(macCondition);
        }
        sb.append(")");

        String orderBy = "ORDER BY " + dateColName + " ASC";
        String limit = count == 0 ? "" : (" LIMIT " + count);

        sb.append(orderBy);
        sb.append(limit);

        return queryRaw(sb.toString());
    }











    public static void createTable(Database db) {
        db.execSQL("create table IF NOT EXISTS " + TABLENAME + "\n" +
                "(\n" +
                Properties.time.columnName + " bigint not null ,\n" +
                Properties.userID.columnName + " varchar(256) not null ,\n" +
                Properties.mac.columnName + " varchar(256) ,\n" +
                Properties.date.columnName + " varchar(50) not null ,\n" +
                Properties.stepCount.columnName + " int not null ,\n" +
                Properties.calorie.columnName + " int not null ,\n" +
                Properties.distance.columnName + " int not null ,\n" +
                Properties.mode.columnName + " int not null ,\n" +
                Properties.activeTime.columnName + " bigint not null ,\n" +
                " primary key (" + Properties.time.columnName + ", " + Properties.userID.columnName + ")\n" +
                ");");
    }

    public static void dropTable(Database db) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
    }

    @Override
    protected StepInfo readEntity(Cursor cursor, int offset) {
        long time = cursor.getLong(offset + Properties.time.ordinal);
        String userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        String mac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        int stepCount = cursor.getInt(offset + Properties.stepCount.ordinal);
        int calorie = cursor.getInt(offset + Properties.calorie.ordinal);
        int distance = cursor.getInt(offset + Properties.distance.ordinal);
        int mode = cursor.getInt(offset + Properties.mode.ordinal);
        int activeTime = cursor.getInt(offset + Properties.activeTime.ordinal);
        return new StepInfo(time, userID, mac, stepCount, calorie, distance, mode, activeTime);
    }

    @Override
    protected Long readKey(Cursor cursor, int offset) {
        return cursor.getLong(offset);
    }

    @Override
    protected void readEntity(Cursor cursor, StepInfo info, int offset) {
        info.time = cursor.getLong(offset + Properties.time.ordinal);
        info.userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        info.deviceMac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        info.stepCount = cursor.getInt(offset + Properties.stepCount.ordinal);
        info.calorie = cursor.getInt(offset + Properties.calorie.ordinal);
        info.distance = cursor.getInt(offset + Properties.distance.ordinal);
        info.mode = cursor.getInt(offset + Properties.mode.ordinal);
        info.activeTime = cursor.getInt(offset + Properties.activeTime.ordinal);
    }

    @Override
    protected void bindValues(DatabaseStatement stmt, StepInfo info) {

    }

    @Override
    protected void bindValues(SQLiteStatement stmt, StepInfo info) {
        stmt.clearBindings();

        stmt.bindLong(Properties.time.ordinal + 1, info.time);
        stmt.bindString(Properties.userID.ordinal + 1, TextUtils.isEmpty(info.userID) ? "" : info.userID);
        stmt.bindString(Properties.mac.ordinal + 1, TextUtils.isEmpty(info.deviceMac) ? "" : info.deviceMac);
        stmt.bindString(Properties.date.ordinal + 1, DateUtil.toTime2(info.time));
        stmt.bindLong(Properties.stepCount.ordinal + 1, info.stepCount);
        stmt.bindLong(Properties.calorie.ordinal + 1, info.calorie);
        stmt.bindLong(Properties.distance.ordinal + 1, info.distance);
        stmt.bindLong(Properties.mode.ordinal + 1, info.mode);
        stmt.bindLong(Properties.activeTime.ordinal + 1, info.activeTime);
    }

    @Override
    protected Long updateKeyAfterInsert(StepInfo info, long rowID) {
        return info.time;
    }

    @Override
    protected Long getKey(StepInfo info) {
        return info.time;
    }

    @Override
    protected boolean hasKey(StepInfo info) {
        return false;
    }

    @Override
    protected boolean isEntityUpdateable() {
        return true;
    }
}
