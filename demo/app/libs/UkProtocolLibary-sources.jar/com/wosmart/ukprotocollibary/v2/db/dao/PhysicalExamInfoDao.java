package com.wosmart.ukprotocollibary.v2.db.dao;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.db.entity.PhysicalExamInfo;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.AbstractDaoSession;
import org.greenrobot.greendao.Property;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseStatement;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.List;

public class PhysicalExamInfoDao extends AbstractDao<PhysicalExamInfo, Long> {

    public static final String TABLENAME = "PHYSICAL_INFO";



    public static class Properties {

        public final static Property time = new Property(0, Long.class, "time", true, "TIME");
        public final static Property userID = new Property(1, String.class, "userID", true, "USER_ID");
        public final static Property mac = new Property(2, String.class, "mac", true, "MAC");
        public final static Property date = new Property(3, java.util.Date.class, "date", false, "DATE");
        public final static Property heartRate = new Property(4, int.class, "heartRate", false, "HEART_RATE");
        public final static Property spo2 = new Property(5, int.class, "spo2", false, "SPO2");
        public final static Property pressure = new Property(6, int.class, "pressure", false, "PRESSURE");
        public final static Property temperature = new Property(7, int.class, "temperature", false, "TEMPERATURE");
        public final static Property skinTemperature = new Property(8, int.class, "skinTemperature", false, "SKIN_TEMPERATURE");
        public final static Property bloodVesselElasticity = new Property(9, int.class, "bloodVesselElasticity", false, "BLOOD_VESSEL_ELASTICITY");
        public final static Property cardiovascularRisk = new Property(10, int.class, "cardiovascularRisk", false, "CARDIOVASCULAR_RISK");
    }


    public PhysicalExamInfoDao(DaoConfig config) {
        super(config);
    }

    public PhysicalExamInfoDao(DaoConfig config, AbstractDaoSession daoSession) {
        super(config, daoSession);
    }

    public List<PhysicalExamInfo> queryDataList(String userID, String mac, long timeBegin, long timePeriod, int count) {
        String timeColName = Properties.time.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;
        String dateColName = Properties.date.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition;
        if (timeBegin == 0) {
            // 从当前时间
            timeCondition = timeColName + " <= " + System.currentTimeMillis();
        } else {
            timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));
        }
        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");
        String macCondition = TextUtils.isEmpty(mac) ? "" : (" " + macColName + " = '" + mac + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        if (!TextUtils.isEmpty(macCondition)) {
            sb.append(" and ").append(macCondition);
        }
        sb.append(")");

        String orderBy = "ORDER BY " + dateColName + " ASC";
        String limit = count == 0 ? "" : (" LIMIT " + count);

        sb.append(orderBy);
        sb.append(limit);

        return queryRaw(sb.toString());
    }







    public static void createTable(Database db) {
        db.execSQL("create table IF NOT EXISTS " + TABLENAME + "\n" +
                "(\n" +
                Properties.time.columnName + " bigint not null ,\n" +
                Properties.userID.columnName + " varchar(256) not null ,\n" +
                Properties.mac.columnName + " varchar(256) ,\n" +
                Properties.date.columnName + " varchar(50) not null ,\n" +
                Properties.heartRate.columnName + " int not null ,\n" +
                Properties.spo2.columnName + " int not null ,\n" +
                Properties.pressure.columnName + " int not null ,\n" +
                Properties.temperature.columnName + " int not null ,\n" +
                Properties.skinTemperature.columnName + " int not null ,\n" +
                Properties.bloodVesselElasticity.columnName + " int not null ,\n" +
                Properties.cardiovascularRisk.columnName + " int not null ,\n" +
                " primary key (" + Properties.time.columnName + ", " + Properties.userID.columnName + ")\n" +
                ");");
    }

    public static void dropTable(Database db) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
    }

    @Override
    protected PhysicalExamInfo readEntity(Cursor cursor, int offset) {

        long time = cursor.getLong(offset + Properties.time.ordinal);
        String userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        String mac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        int heartRate = cursor.getInt(offset + Properties.heartRate.ordinal);
        int spo2 = cursor.getInt(offset + Properties.spo2.ordinal);
        int pressure = cursor.getInt(offset + Properties.pressure.ordinal);
        int temperature = cursor.getInt(offset + Properties.temperature.ordinal);
        int skinTemperature = cursor.getInt(offset + Properties.skinTemperature.ordinal);
        int bloodVesselElasticity = cursor.getInt(offset + Properties.bloodVesselElasticity.ordinal);
        int cardiovascularRisk = cursor.getInt(offset + Properties.cardiovascularRisk.ordinal);

        PhysicalExamInfo info = new PhysicalExamInfo();

        info.time = time;
        info.userID = userID;
        info.deviceMac = mac;

        info.heartRate = heartRate;
        info.spo2 = spo2;
        info.pressure = pressure;
        info.temperature = temperature;
        info.skinTemperature = skinTemperature;
        info.bloodVesselElasticity = bloodVesselElasticity;
        info.cardiovascularRisk = cardiovascularRisk;

        return info;
    }

    @Override
    protected Long readKey(Cursor cursor, int offset) {
        return cursor.getLong(offset);
    }

    @Override
    protected void readEntity(Cursor cursor, PhysicalExamInfo info, int offset) {
        long time = cursor.getLong(offset + Properties.time.ordinal);
        String userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        String mac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        int heartRate = cursor.getInt(offset + Properties.heartRate.ordinal);
        int spo2 = cursor.getInt(offset + Properties.spo2.ordinal);
        int pressure = cursor.getInt(offset + Properties.pressure.ordinal);
        int temperature = cursor.getInt(offset + Properties.temperature.ordinal);
        int skinTemperature = cursor.getInt(offset + Properties.skinTemperature.ordinal);
        int bloodVesselElasticity = cursor.getInt(offset + Properties.bloodVesselElasticity.ordinal);
        int cardiovascularRisk = cursor.getInt(offset + Properties.cardiovascularRisk.ordinal);

        info.time = time;
        info.userID = userID;
        info.deviceMac = mac;

        info.heartRate = heartRate;
        info.spo2 = spo2;
        info.pressure = pressure;
        info.temperature = temperature;
        info.skinTemperature = skinTemperature;
        info.bloodVesselElasticity = bloodVesselElasticity;
        info.cardiovascularRisk = cardiovascularRisk;
    }

    @Override
    protected void bindValues(DatabaseStatement stmt, PhysicalExamInfo info) {

    }

    @Override
    protected void bindValues(SQLiteStatement stmt, PhysicalExamInfo info) {
        stmt.clearBindings();

        stmt.bindLong(Properties.time.ordinal + 1, info.time);
        stmt.bindString(Properties.userID.ordinal + 1, TextUtils.isEmpty(info.userID) ? "" : info.userID);
        stmt.bindString(Properties.mac.ordinal + 1, TextUtils.isEmpty(info.deviceMac) ? "" : info.deviceMac);
        stmt.bindString(Properties.date.ordinal + 1, DateUtil.toTime2(info.time));
        stmt.bindLong(Properties.heartRate.ordinal + 1, info.heartRate);
        stmt.bindLong(Properties.spo2.ordinal + 1, info.spo2);
        stmt.bindLong(Properties.pressure.ordinal + 1, info.pressure);
        stmt.bindLong(Properties.temperature.ordinal + 1, info.temperature);
        stmt.bindLong(Properties.skinTemperature.ordinal + 1, info.skinTemperature);
        stmt.bindLong(Properties.bloodVesselElasticity.ordinal + 1, info.bloodVesselElasticity);
        stmt.bindLong(Properties.cardiovascularRisk.ordinal + 1, info.cardiovascularRisk);

    }

    @Override
    protected Long updateKeyAfterInsert(PhysicalExamInfo info, long rowID) {
        return info.time;
    }

    @Override
    protected Long getKey(PhysicalExamInfo info) {
        return info.time;
    }

    @Override
    protected boolean hasKey(PhysicalExamInfo info) {
        return false;
    }

    @Override
    protected boolean isEntityUpdateable() {
        return true;
    }
}
