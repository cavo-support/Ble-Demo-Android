package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWSportInfo extends JWHealthData implements Serializable {

    public static final int SPORT_MODE_RUN = 0x00;// 跑步
    public static final int SPORT_MODE_CLIMB = 0x01;// 登山
    public static final int SPORT_MODE_FOOTBALL = 0x02;// 足球
    public static final int SPORT_MODE_CYCLE = 0x03;// 骑行
    public static final int SPORT_MODE_ROPE = 0x04;// 跳绳
    public static final int SPORT_MODE_RUN_OUT_DOOR = 0x05;// 户外跑步
    public static final int SPORT_MODE_RIDE_OUT_DOOR = 0x06;// 户外骑车
    public static final int SPORT_MODE_WALK_OUT_DOOR = 0x07;// 户外健走
    public static final int SPORT_MODE_RUN_IN_DOOR = 0x08;// 室内跑步
    public static final int SPORT_MODE_FREE_TRAIN = 0x09;// 自由训练
    public static final int SPORT_MODE_PLANK = 0x0A;// 平板支撑
    public static final int SPORT_MODE_WALK = 0x0B;// 健走
    public static final int SPORT_MODE_PRANAYAMA = 0x0C;// 呼吸训练
    public static final int SPORT_MODE_YOGA = 0x0D;// 瑜伽
    public static final int SPORT_MODE_HIKING = 0x0E;// 徒步
    public static final int SPORT_MODE_SPINNING = 0x0F;// 动感单车
    public static final int SPORT_MODE_ROWING = 0x10;// 划船机
    public static final int SPORT_MODE_STEPPER = 0x11;// 踏步机
    public static final int SPORT_MODE_ELLIPTICAL = 0x12;// 椭圆机
    public static final int SPORT_MODE_BASKETBALL = 0x13;// 篮球
    public static final int SPORT_MODE_TENNIS = 0x14;// 网球
    public static final int SPORT_MODE_BADMINTON = 0x15;// 羽毛球
    public static final int SPORT_MODE_BASEBALL = 0x16;// 棒球
    public static final int SPORT_MODE_RUGBY = 0x17;// 橄榄球

    public int sportModel;

    /**
     * sport duration minutes
     * 运动分钟
     */
    public int sportMinute;

    /**
     * sport duration seconds
     * 运动秒数
     */
    public int sportSecond;

    /**
     * sport pause count
     * 暂停次数
     */
    public int pauseCount;

    /**
     * sport pause minutes
     * 暂时分钟
     */
    public int pauseMinute;

    /**
     * sport pause seconds
     * 暂停秒数
     */
    public int pauseSecond;

    /**
     * sport total step
     * 步数
     */
    public int steps;

    /**
     * sport total distance, unit meter
     * 距离，单位 米
     */
    public int distance;

    /**
     * sport total calories
     * 卡路里，单位 小卡
     */
    public int calories;

    /**
     * Respiration rate
     * Breath training only
     */
    public int respirationRate;

    /**
     * Respiration rate minute
     * Breath training only
     */
    public int respirationRateMinute;

    /**
     * sport high rate, unit times/min
     * 运动高心率，单位 次/分
     */
    public int rateHigh = 0;

    /**
     * sport avg rate, unit times/min
     * 运动低心率，单位 次/分
     */
    public int rateAvg = 0;

    /**
     * sport low rate, unit times/min
     * 运动平均心率，单位 次/分
     */
    public int rateLow = 0;


    /**
     * sport model
     * @return {@link JWSportInfo#SPORT_MODE_RUN}
     */
    public int getSportModel() {
        return sportModel;
    }

    public void setSportModel(int sportModel) {
        this.sportModel = sportModel;
    }


    @Override
    public String toString() {
        return "JWSportInfo{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", sportModel=" + sportModel +
                ", sportMinute=" + sportMinute +
                ", sportSecond=" + sportSecond +
                ", pauseCount=" + pauseCount +
                ", pauseMinute=" + pauseMinute +
                ", pauseSecond=" + pauseSecond +
                ", steps=" + steps +
                ", distance=" + distance +
                ", calories=" + calories +
                ", respirationRate=" + respirationRate +
                ", respirationRateMinute=" + respirationRateMinute +
                ", rateHigh=" + rateHigh +
                ", rateAvg=" + rateAvg +
                ", rateLow=" + rateLow +
                '}';
    }
}
