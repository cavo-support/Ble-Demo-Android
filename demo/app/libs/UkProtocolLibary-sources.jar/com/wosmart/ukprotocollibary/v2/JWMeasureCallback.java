package com.wosmart.ukprotocollibary.v2;

public abstract class JWMeasureCallback<T> implements JWErrorCallback {

    public abstract void onSuccess(T data);

    public abstract void onCancel();

}
