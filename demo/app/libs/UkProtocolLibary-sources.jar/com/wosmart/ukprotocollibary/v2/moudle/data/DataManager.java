package com.wosmart.ukprotocollibary.v2.moudle.data;

import android.content.Context;

import com.wosmart.ukprotocollibary.v2.BaseConstants;
import com.wosmart.ukprotocollibary.v2.JWHRVRmssdListener;
import com.wosmart.ukprotocollibary.v2.JWHealthDataSearchParams;
import com.wosmart.ukprotocollibary.v2.JWManager;
import com.wosmart.ukprotocollibary.v2.JWPressureListener;
import com.wosmart.ukprotocollibary.v2.JWPulseListener;
import com.wosmart.ukprotocollibary.v2.JWSaunaListener;
import com.wosmart.ukprotocollibary.v2.JWSyncDataListener;
import com.wosmart.ukprotocollibary.v2.JWUltravioletListener;
import com.wosmart.ukprotocollibary.v2.common.BleCallback;
import com.wosmart.ukprotocollibary.v2.common.JWLog;
import com.wosmart.ukprotocollibary.v2.common.executor.JWArchTaskExecutor;
import com.wosmart.ukprotocollibary.v2.db.DatabaseManager;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodFatContinuousMonitoringInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodFatInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodPressureInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodSugarCycleInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodSugarInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BodyFatInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HRMovementInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HRVRmssdInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HeartRateInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HeartRateVariabilityInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.PhysicalExamInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.PressureInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.PulseInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SaunaInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SleepInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SpO2InfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SportInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.StepInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.TemperatureInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.UltravioletInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.UricAcidContinuousMonitoringInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.UricAcidInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.WearingTimeInfoDao;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodFatContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodFatInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodSugarInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.BodyFatInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.HRMovementInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.HRVRmssdInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.HeartRateInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.HeartRateVariabilityInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.PhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.PressureInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.PulseInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.SaunaInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.SleepInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.SpO2Info;
import com.wosmart.ukprotocollibary.v2.db.entity.SportInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.StepInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.TemperatureInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.UltravioletInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.UricAcidContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.UricAcidInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.WearingTimeInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRMovementInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateVariabilityInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPulseInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSaunaInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSleepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSpO2Info;
import com.wosmart.ukprotocollibary.v2.entity.JWSportInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWStepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSyncDataInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUltravioletInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWearingTimeInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.moudle.Manager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataManager extends Manager {

    private static final String TAG = "DataManager";

    private JWSyncDataListener mInternalSyncDataListener;
    private JWSyncDataListener mSyncDataListener;

    private JWPulseListener mPulseListener;
    private JWPulseListener mInternalPulseListener;

    private JWSaunaListener mSaunaListener;
    private JWSaunaListener mInternalSaunaListener;

    private JWHRVRmssdListener mHRVRmssdListener;
    private JWHRVRmssdListener mInternalHRVRmssdListener;

    private JWUltravioletListener mUltravioletListener;
    private JWUltravioletListener mInternalUltravioletListener;

    private JWPressureListener mPressureListener;
    private JWPressureListener mInternalPressureListener;

    private boolean isSynchronizing = false;


    private static class DataManagerHolder {
        private static final DataManager dataManager = new DataManager();
    }

    public static DataManager getInstance() {
        return DataManagerHolder.dataManager;
    }

    public void init(Context context) {
        DatabaseManager.getInstance().init(context);
        initListener();
    }

    public void setPulseListener(JWPulseListener listener) {
        this.mPulseListener = listener;
    }

    public void setSaunaListener(JWSaunaListener listener) {
        this.mSaunaListener = listener;
    }

    public void setHRVRmssdListener(JWHRVRmssdListener listener) {
        this.mHRVRmssdListener = listener;
    }

    public void setUltravioletListener(JWUltravioletListener listener) {
        this.mUltravioletListener = listener;
    }

    public void setPressureListener(JWPressureListener listener) {
        this.mPressureListener = listener;
    }

    public void syncHealthData(JWSyncDataListener syncDataListener) {
        if (!BaseManager.getInstance().isInited()) {
            if (syncDataListener != null) {
                syncDataListener.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init");
            }
            return;
        }
        if (BaseManager.getInstance().getConnStatus() != JWManager.CONN_STATUS_CONNECTED) {
            if (syncDataListener != null) {
                syncDataListener.onError(BaseConstants.ERR_DEVICE_NOT_CONNECTED, "device not connected");
            }
            return;
        }
        if (this.isSynchronizing) {
            if (syncDataListener != null) {
                syncDataListener.onError(BaseConstants.ERR_ALREADY_IN_THE_PROCESS_OF_SYNCHRONIZING, "already in the process of synchronizing");
            }
            return;
        }
        JWLog.i(TAG, "syncHealthData");

        this.mSyncDataListener = syncDataListener;
        this.isSynchronizing = true;

        byte[] appPacketData = DataPacketHelper.prepareSyncHealthDataPacket();

        sendNormalData(appPacketData, null);

    }

    public void getHistoryStepList(final JWHealthDataSearchParams params, final BleCallback<List<JWStepInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final StepInfoDao dao = DatabaseManager.getInstance().getStepDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<StepInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWStepInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (StepInfo step : infoArray) {
                        infoList.add(step.convertToJWStepInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });

    }

    public void getHistorySleepList(final JWHealthDataSearchParams params, final BleCallback<List<JWSleepInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final SleepInfoDao dao = DatabaseManager.getInstance().getSleepDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<SleepInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWSleepInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (SleepInfo info : infoArray) {
                        infoList.add(info.convertToJWSleepInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }

    public void getHistoryBloodPressureList(final JWHealthDataSearchParams params, final BleCallback<List<JWBloodPressureInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final BloodPressureInfoDao dao = DatabaseManager.getInstance().getBloodPressureDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<BloodPressureInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWBloodPressureInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (BloodPressureInfo info : infoArray) {
                        infoList.add(info.convertToJWBpInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }

    public void getHistoryBloodSugarList(final JWHealthDataSearchParams params, final BleCallback<List<JWBloodSugarInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final BloodSugarInfoDao dao = DatabaseManager.getInstance().getBloodSugarDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<BloodSugarInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWBloodSugarInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (BloodSugarInfo info : infoArray) {
                        infoList.add(info.convertToJWBsInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }

    public void getHistoryHeartRateList(final JWHealthDataSearchParams params, final BleCallback<List<JWHeartRateInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final HeartRateInfoDao dao = DatabaseManager.getInstance().getHeartRateDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<HeartRateInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWHeartRateInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (HeartRateInfo info : infoArray) {
                        infoList.add(info.convertToJWHrInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }

    public void getHistoryHeartRateVariabilityList(final JWHealthDataSearchParams params, final BleCallback<List<JWHeartRateVariabilityInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final HeartRateVariabilityInfoDao dao = DatabaseManager.getInstance().getHrvDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<HeartRateVariabilityInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWHeartRateVariabilityInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (HeartRateVariabilityInfo info : infoArray) {
                        infoList.add(info.convertToJWHrvInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }

    public void getHistoryPulseList(final JWHealthDataSearchParams params, final BleCallback<List<JWPulseInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final PulseInfoDao dao = DatabaseManager.getInstance().getPulseDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<PulseInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWPulseInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (PulseInfo info : infoArray) {
                        infoList.add(info.convertToJWPulseInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }

    public void getHistorySaunaList(final JWHealthDataSearchParams params, final BleCallback<List<JWSaunaInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final SaunaInfoDao dao = DatabaseManager.getInstance().getSaunaDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<SaunaInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWSaunaInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (SaunaInfo info : infoArray) {
                        infoList.add(info.convertToJWSaunaInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }

    public void getHistoryHRMovementList(final JWHealthDataSearchParams params, final BleCallback<List<JWHRMovementInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final HRMovementInfoDao dao = DatabaseManager.getInstance().getHRMovementDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<HRMovementInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWHRMovementInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (HRMovementInfo info : infoArray) {
                        infoList.add(info.convertToJWHRMovementInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }

    public void getHistorySpO2List(final JWHealthDataSearchParams params, final BleCallback<List<JWSpO2Info>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final SpO2InfoDao dao = DatabaseManager.getInstance().getSpO2Dao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<SpO2Info> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWSpO2Info> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (SpO2Info info : infoArray) {
                        infoList.add(info.convertToJWSpO2Info());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }

    public void getHistorySportList(final JWHealthDataSearchParams params, final BleCallback<List<JWSportInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final SportInfoDao dao = DatabaseManager.getInstance().getSportDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<SportInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWSportInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (SportInfo info : infoArray) {
                        infoList.add(info.convertToJWTempInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }

    public void getHistoryTemperatureList(final JWHealthDataSearchParams params, final BleCallback<List<JWTemperatureInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final TemperatureInfoDao dao = DatabaseManager.getInstance().getTemperatureDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<TemperatureInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWTemperatureInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (TemperatureInfo info : infoArray) {
                        infoList.add(info.convertToJWTempInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }

    public void getHistoryWearingTimeList(final JWHealthDataSearchParams params, final BleCallback<List<JWWearingTimeInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final WearingTimeInfoDao dao = DatabaseManager.getInstance().getWearingTimeDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<WearingTimeInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWWearingTimeInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (WearingTimeInfo info : infoArray) {
                        infoList.add(info.convertToJWWearingTimeInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }


    public void getRecentUricAcid(final JWHealthDataSearchParams params, final BleCallback<JWUricAcidInfo> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final UricAcidInfoDao dao = DatabaseManager.getInstance().getUricAcidDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                if (callback != null) {
                    UricAcidInfo uricAcidInfo = dao.queryRecentData(params.getUserID(), params.getDeviceMac(), params.getTimeBegin());
                    callback.success(uricAcidInfo == null ? null : uricAcidInfo.convertToJWUricAcidInfo());
                }
            }
        });
    }


    public void getRecentBloodFat(final JWHealthDataSearchParams params, final BleCallback<JWBloodFatInfo> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final BloodFatInfoDao dao = DatabaseManager.getInstance().getBloodFatDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                if (callback != null) {
                    BloodFatInfo bloodFatInfo = dao.queryRecentData(params.getUserID(), params.getDeviceMac(), params.getTimeBegin());
                    callback.success(bloodFatInfo == null ? null : bloodFatInfo.convertToJWBloodFatInfo());
                }
            }
        });
    }


    public void getRecentBloodSugarCycle(final JWHealthDataSearchParams params, final BleCallback<JWBloodSugarCycleInfo> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final BloodSugarCycleInfoDao dao = DatabaseManager.getInstance().getBloodSugarCycleDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                if (callback != null) {
                    BloodSugarCycleInfo bloodSugarCycleInfo = dao.queryRecentData(params.getUserID(), params.getDeviceMac(), params.getTimeBegin());
                    callback.success(bloodSugarCycleInfo == null ? null : bloodSugarCycleInfo.convertToJWBloodSugarCycleInfo());
                }
            }
        });
    }


    public void getHistoryUricAcidContinuousMonitoringList(final JWHealthDataSearchParams params, final BleCallback<List<JWUricAcidContinuousMonitoringInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final UricAcidContinuousMonitoringInfoDao dao = DatabaseManager.getInstance().getUricAcidContinuousMonitoringDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<UricAcidContinuousMonitoringInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWUricAcidContinuousMonitoringInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (UricAcidContinuousMonitoringInfo info : infoArray) {
                        infoList.add(info.convertToJWUricAcidContinuousMonitoringInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }


    public void getHistoryBloodFatContinuousMonitoringList(final JWHealthDataSearchParams params, final BleCallback<List<JWBloodFatContinuousMonitoringInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final BloodFatContinuousMonitoringInfoDao dao = DatabaseManager.getInstance().getBloodFatContinuousMonitoringDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<BloodFatContinuousMonitoringInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWBloodFatContinuousMonitoringInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (BloodFatContinuousMonitoringInfo info : infoArray) {
                        infoList.add(info.convertToJWBloodFatContinuousMonitoringInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }

    public void getRecentBodyFat(final JWHealthDataSearchParams params, final BleCallback<JWBodyFatInfo> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final BodyFatInfoDao dao = DatabaseManager.getInstance().getBodyFatDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                if (callback != null) {
                    BodyFatInfo bodyFatInfo = dao.queryRecentData(params.getUserID(), params.getDeviceMac(), params.getTimeBegin());
                    callback.success(bodyFatInfo == null ? null : bodyFatInfo.convertToJWBodyFatInfo());
                }
            }
        });
    }

    public void getHistoryBodyFatList(final JWHealthDataSearchParams params, final BleCallback<List<JWBodyFatInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final BodyFatInfoDao dao = DatabaseManager.getInstance().getBodyFatDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<BodyFatInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWBodyFatInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (BodyFatInfo info : infoArray) {
                        infoList.add(info.convertToJWBodyFatInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }

    public void getHistoryPhysicalExamList(final JWHealthDataSearchParams params, final BleCallback<List<JWPhysicalExamInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final PhysicalExamInfoDao dao = DatabaseManager.getInstance().getPhysicalExamDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<PhysicalExamInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWPhysicalExamInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (PhysicalExamInfo info : infoArray) {
                        infoList.add(info.convertToJWPhysicalExamInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }

    public void getHistoryHRVRmssdList(final JWHealthDataSearchParams params, final BleCallback<List<JWHRVRmssdInfo>> callback) {
        if (!checkSDKInit(callback)) {
            return;
        }

        final HRVRmssdInfoDao dao = DatabaseManager.getInstance().getHRVRmssdDao();
        if (dao == null) {
            callback.fail(BaseConstants.ERR_DATABASE_NOT_INITIALIZED, "database not init");
            return;
        }

        JWArchTaskExecutor.getInstance().executeOnDiskIO(new Runnable() {
            @Override
            public void run() {
                final List<HRVRmssdInfo> infoArray = dao.queryDataList(params.getUserID(), params.getDeviceMac(), params.getTimeBegin(), params.getTimePeriod(), params.getCount());
                final List<JWHRVRmssdInfo> infoList = new ArrayList<>();
                if (infoArray != null && !infoArray.isEmpty()) {
                    for (HRVRmssdInfo info : infoArray) {
                        infoList.add(info.convertToJWHRVRmssdInfo());
                    }
                }
                if (callback != null) {
                    callback.success(infoList);
                }
            }
        });
    }


    private void initInternalPulseListener() {
        if (mInternalPulseListener == null) {
            mInternalPulseListener = new JWPulseListener() {
                @Override
                public void onSyncDataStart(int totalCount) {
                    JWLog.i(TAG, "pulse onSyncDataStart, count = " + totalCount);
                    if (mPulseListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mPulseListener.onSyncDataStart(totalCount);
                            }
                        });
                    }
                }

                @Override
                public void onPulseDataReceived(List<JWPulseInfo> pulseInfoList) {
                    if (pulseInfoList == null || pulseInfoList.isEmpty()) {
                        return;
                    }
                    JWLog.i(TAG, "pulse onPulseDataReceived pulseInfoList = " + pulseInfoList);
                    PulseInfoDao dao = DatabaseManager.getInstance().getPulseDao();
                    if (dao != null) {
                        List<PulseInfo> pulseList = new ArrayList<>();
                        for (JWPulseInfo info : pulseInfoList) {
                            pulseList.add(new PulseInfo(info));
                        }
                        dao.insertOrReplaceInTx(pulseList);
                    }
                    if (mPulseListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mPulseListener.onPulseDataReceived(pulseInfoList);
                            }
                        });
                    }
                }

                @Override
                public void onSyncDataFinished() {
                    JWLog.i(TAG, "pulse onSyncDataFinish");
                    if (mPulseListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mPulseListener.onSyncDataFinished();
                            }
                        });
                    }
                }

                @Override
                public void onPulseFinished(int duration) {
                    JWLog.i(TAG, "pulse onPulseFinish duration = " + duration);
                    if (mPulseListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mPulseListener.onPulseFinished(duration);
                            }
                        });
                    }
                }
            };
        }
        TransportManager.getInstance().setPulseListener(mInternalPulseListener);
    }

    private void initInternalSaunaListener() {
        if (mInternalSaunaListener == null) {
            mInternalSaunaListener = new JWSaunaListener() {
                @Override
                public void onSyncDataStart(int totalCount) {
                    JWLog.i(TAG, "sauna onSyncDataStart, count = " + totalCount);
                    if (mSaunaListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mSaunaListener.onSyncDataStart(totalCount);
                            }
                        });
                    }
                }

                @Override
                public void onSaunaDataReceived(List<JWSaunaInfo> saunaInfoList) {
                    if (saunaInfoList.isEmpty()) {
                        return;
                    }
                    JWLog.i(TAG, "sauna onSaunaDataReceived saunaInfoList = " + saunaInfoList);
                    SaunaInfoDao dao = DatabaseManager.getInstance().getSaunaDao();
                    if (dao != null) {
                        List<SaunaInfo> saunaList = new ArrayList<>();
                        for (JWSaunaInfo info : saunaInfoList) {
                            saunaList.add(new SaunaInfo(info));
                        }
                        dao.insertOrReplaceInTx(saunaList);
                    }
                    if (mSaunaListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mSaunaListener.onSaunaDataReceived(saunaInfoList);
                            }
                        });
                    }
                }

                @Override
                public void onSyncDataFinished() {
                    JWLog.i(TAG, "sauna onSyncDataFinished");
                    if (mSaunaListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mSaunaListener.onSyncDataFinished();
                            }
                        });
                    }
                }

                @Override
                public void onHRMovementDataReceived(List<JWHRMovementInfo> hrMovementInfoList) {
                    if (hrMovementInfoList.isEmpty()) {
                        return;
                    }
                    JWLog.i(TAG, "onHRMovementDataReceived hrMovementInfoList = " + hrMovementInfoList);
                    HRMovementInfoDao dao = DatabaseManager.getInstance().getHRMovementDao();
                    if (dao != null) {
                        List<HRMovementInfo> movementInfoList = new ArrayList<>();
                        for (JWHRMovementInfo info : hrMovementInfoList) {
                            movementInfoList.add(new HRMovementInfo(info));
                        }
                        dao.insertOrReplaceInTx(movementInfoList);
                    }
                    if (mSaunaListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mSaunaListener.onHRMovementDataReceived(hrMovementInfoList);
                            }
                        });
                    }
                }
            };
        }
        TransportManager.getInstance().setSaunaListener(mInternalSaunaListener);
    }

    private void initInternalHRVRmssdListener() {
        if (mInternalHRVRmssdListener == null) {
            mInternalHRVRmssdListener = new JWHRVRmssdListener() {
                @Override
                public void onHRVRmssdDataReceived(List<JWHRVRmssdInfo> dataList) {
                    if (dataList.isEmpty()) {
                        return;
                    }
                    JWLog.i(TAG, "onHRVRmssdDataReceived dataList = " + dataList);
                    HRVRmssdInfoDao dao = DatabaseManager.getInstance().getHRVRmssdDao();
                    if (dao != null) {
                        List<HRVRmssdInfo> infoList = new ArrayList<>();
                        for (JWHRVRmssdInfo data : dataList) {
                            infoList.add(new HRVRmssdInfo(data));
                        }
                        dao.insertOrReplaceInTx(infoList);
                    }
                    if (mHRVRmssdListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mHRVRmssdListener.onHRVRmssdDataReceived(dataList);
                            }
                        });
                    }
                }
            };
        }
        TransportManager.getInstance().setHRVRmssdListener(mInternalHRVRmssdListener);
    }

    private void initInternalUltravioletListener() {
        if (mInternalUltravioletListener == null) {
            mInternalUltravioletListener = new JWUltravioletListener() {
                @Override
                public void onUltravioletDataReceived(List<JWUltravioletInfo> dataList) {
                    if (dataList.isEmpty()) {
                        return;
                    }
                    JWLog.i(TAG, "onUltravioletDataReceived dataList = " + dataList);
                    UltravioletInfoDao dao = DatabaseManager.getInstance().getUltravioletDao();
                    if (dao != null) {
                        List<UltravioletInfo> infoList = new ArrayList<>();
                        for (JWUltravioletInfo data : dataList) {
                            infoList.add(new UltravioletInfo(data));
                        }
                        dao.insertOrReplaceInTx(infoList);
                    }
                    if (mUltravioletListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mUltravioletListener.onUltravioletDataReceived(dataList);
                            }
                        });
                    }
                }

                @Override
                public void onSyncUltravioletDataEnd() {
                    if (mUltravioletListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mUltravioletListener.onSyncUltravioletDataEnd();
                            }
                        });
                    }
                }
            };
        }
        TransportManager.getInstance().setUltravioletListener(mInternalUltravioletListener);
    }

    private void initInternalPressureListener() {
        if (mInternalPressureListener == null) {
            mInternalPressureListener = new JWPressureListener() {
                @Override
                public void onPressureDataReceived(List<JWPressureInfo> dataList) {
                    if (dataList.isEmpty()) {
                        return;
                    }
                    JWLog.i(TAG, "onPressureDataReceived dataList = " + dataList);
                    PressureInfoDao dao = DatabaseManager.getInstance().getPressureDao();
                    if (dao != null) {
                        List<PressureInfo> infoList = new ArrayList<>();
                        for (JWPressureInfo data : dataList) {
                            infoList.add(new PressureInfo(data));
                        }
                        dao.insertOrReplaceInTx(infoList);
                    }
                    if (mPressureListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mPressureListener.onPressureDataReceived(dataList);
                            }
                        });
                    }
                }

                @Override
                public void onSyncPressureDataEnd() {
                    if (mPressureListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mPressureListener.onSyncPressureDataEnd();
                            }
                        });
                    }
                }
            };
        }
        TransportManager.getInstance().setPressureListener(mInternalPressureListener);
    }

    private void initInternalSyncDataListener() {
        if (mInternalSyncDataListener == null) {
            mInternalSyncDataListener = new JWSyncDataListener() {
                @Override
                public void onError(int code, String desc) {

                }

                @Override
                public void onSyncDataStart(JWSyncDataInfo syncDataInfo) {
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (mSyncDataListener != null) {
                                mSyncDataListener.onSyncDataStart(syncDataInfo);
                            }
                        }
                    });
                }

                @Override
                public void onSyncDataFinished() {
                    isSynchronizing = false;
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (mSyncDataListener != null) {
                                mSyncDataListener.onSyncDataFinished();
                            }
                        }
                    });
                }

                @Override
                public void onSyncDataFailed() {
                    isSynchronizing = false;
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (mSyncDataListener != null) {
                                mSyncDataListener.onSyncDataFailed();
                            }
                        }
                    });
                }

                @Override
                public void onStepDataReceived(List<JWStepInfo> stepInfoList) {
                    if (stepInfoList == null || stepInfoList.isEmpty()) {
                        return;
                    }
                    StepInfoDao dao = DatabaseManager.getInstance().getStepDao();
                    if (dao != null) {
                        List<StepInfo> dataList = new ArrayList<>();
                        for (JWStepInfo info : stepInfoList) {
                            dataList.add(new StepInfo(info));
                        }
                        dao.insertOrReplaceInTx(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onStepDataReceived(stepInfoList);
                            }
                        }
                    });
                }

                @Override
                public void onSleepDataReceived(List<JWSleepInfo> sleepInfoList) {
                    SleepInfoDao dao = DatabaseManager.getInstance().getSleepDao();
                    if (dao != null) {
                        List<SleepInfo> dataList = new ArrayList<>();
                        for (JWSleepInfo info : sleepInfoList) {
                            dataList.add(new SleepInfo(info));
                        }
                        dao.insertOrReplaceInTx(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onSleepDataReceived(sleepInfoList);
                            }
                        }
                    });
                }

                @Override
                public void onHeartRateDataReceived(List<JWHeartRateInfo> heartRateInfoList) {
                    HeartRateInfoDao dao = DatabaseManager.getInstance().getHeartRateDao();
                    if (dao != null) {
                        List<HeartRateInfo> dataList = new ArrayList<>();
                        for (JWHeartRateInfo info : heartRateInfoList) {
                            dataList.add(new HeartRateInfo(info));
                        }
                        dao.insertOrReplaceInTx(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onHeartRateDataReceived(heartRateInfoList);
                            }
                        }
                    });
                }

                @Override
                public void onHeartRateVariabilityDataReceived(List<JWHeartRateVariabilityInfo> heartRateVariabilityInfoList) {
                    HeartRateVariabilityInfoDao dao = DatabaseManager.getInstance().getHrvDao();
                    if (dao != null) {
                        List<HeartRateVariabilityInfo> dataList = new ArrayList<>();
                        for (JWHeartRateVariabilityInfo info : heartRateVariabilityInfoList) {
                            dataList.add(new HeartRateVariabilityInfo(info));
                        }
                        dao.insertOrReplaceInTx(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onHeartRateVariabilityDataReceived(heartRateVariabilityInfoList);
                            }
                        }
                    });
                }

                @Override
                public void onTemperatureDataReceived(List<JWTemperatureInfo> temperatureInfoList) {
                    TemperatureInfoDao dao = DatabaseManager.getInstance().getTemperatureDao();
                    if (dao != null) {
                        List<TemperatureInfo> dataList = new ArrayList<>();
                        for (JWTemperatureInfo info : temperatureInfoList) {
                            dataList.add(new TemperatureInfo(info));
                        }
                        dao.insertOrReplaceInTx(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onTemperatureDataReceived(temperatureInfoList);
                            }
                        }
                    });
                }

                @Override
                public void onBloodPressureDataReceived(List<JWBloodPressureInfo> bpInfoList) {
                    BloodPressureInfoDao dao = DatabaseManager.getInstance().getBloodPressureDao();
                    if (dao != null) {
                        List<BloodPressureInfo> dataList = new ArrayList<>();
                        for (JWBloodPressureInfo info : bpInfoList) {
                            dataList.add(new BloodPressureInfo(info));
                        }
                        dao.insertOrReplaceInTx(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onBloodPressureDataReceived(bpInfoList);
                            }
                        }
                    });
                }

                @Override
                public void onSpO2DataReceived(List<JWSpO2Info> spo2InfoList) {
                    SpO2InfoDao dao = DatabaseManager.getInstance().getSpO2Dao();
                    if (dao != null) {
                        List<SpO2Info> dataList = new ArrayList<>();
                        for (JWSpO2Info info : spo2InfoList) {
                            dataList.add(new SpO2Info(info));
                        }
                        dao.insertOrReplaceInTx(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onSpO2DataReceived(spo2InfoList);
                            }
                        }
                    });
                }

                @Override
                public void onBloodSugarDataReceived(List<JWBloodSugarInfo> bsInfoList) {
                    BloodSugarInfoDao dao = DatabaseManager.getInstance().getBloodSugarDao();
                    if (dao != null) {
                        List<BloodSugarInfo> dataList = new ArrayList<>();
                        for (JWBloodSugarInfo info : bsInfoList) {
                            dataList.add(new BloodSugarInfo(info));
                        }
                        dao.insertOrReplaceInTx(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onBloodSugarDataReceived(bsInfoList);
                            }
                        }
                    });
                }

                @Override
                public void onSportDataReceived(List<JWSportInfo> sportInfoList) {
                    SportInfoDao dao = DatabaseManager.getInstance().getSportDao();
                    if (dao != null) {
                        List<SportInfo> dataList = new ArrayList<>();
                        for (JWSportInfo info : sportInfoList) {
                            dataList.add(new SportInfo(info));
                        }
                        dao.insertOrReplaceInTx(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onSportDataReceived(sportInfoList);
                            }
                        }
                    });
                }

                @Override
                public void onWearingTimeDataReceived(List<JWWearingTimeInfo> wearingTimeInfoList) {
                    WearingTimeInfoDao dao = DatabaseManager.getInstance().getWearingTimeDao();
                    if (dao != null) {
                        List<WearingTimeInfo> dataList = new ArrayList<>();
                        for (JWWearingTimeInfo info : wearingTimeInfoList) {
                            dataList.add(new WearingTimeInfo(info));
                        }
                        dao.insertOrReplaceInTx(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onWearingTimeDataReceived(wearingTimeInfoList);
                            }
                        }
                    });
                }

                @Override
                public void onUricAcidDataReceived(List<JWUricAcidInfo> uricAcidInfoList) {
                    if (uricAcidInfoList == null || uricAcidInfoList.isEmpty()) {
                        return;
                    }

                    // 尿酸协议会返回同一个周期内的多条数据，此处需过滤同一个周期数据，取当前最新周期值
                    Map<Long, JWUricAcidInfo> dataMap = new HashMap<>();
                    for (JWUricAcidInfo data : uricAcidInfoList) {
                        JWUricAcidInfo cacheData = dataMap.get(data.cycleStartTime);
                        if (cacheData == null) {
                            dataMap.put(data.cycleStartTime, data);
                        } else {
                            // 新周期 dayStatusList 会变大
                            int curDayStatus = UricAcidInfo.convertDayStatusList(data.dayStatusList);
                            int cacheDayStatus = UricAcidInfo.convertDayStatusList(cacheData.dayStatusList);
                            if (curDayStatus > cacheDayStatus) {
                                dataMap.put(data.cycleStartTime, data);
                            }
                        }
                    }

                    List<JWUricAcidInfo> infoList = new ArrayList<>(dataMap.values());

                    UricAcidInfoDao dao = DatabaseManager.getInstance().getUricAcidDao();
                    if (dao != null) {
                        List<UricAcidInfo> dataList = new ArrayList<>();
                        for (JWUricAcidInfo info : infoList) {
                            dataList.add(new UricAcidInfo(info));
                        }
                        dao.saveDataList(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onUricAcidDataReceived(infoList);
                            }
                        }
                    });
                }

                @Override
                public void onBloodFatDataReceived(List<JWBloodFatInfo> bloodFatInfoList) {
                    if (bloodFatInfoList == null || bloodFatInfoList.isEmpty()) {
                        return;
                    }

                    // 血脂协议会返回同一个周期内的多条数据，此处需过滤同一个周期数据，取当前最新周期值
                    Map<Long, JWBloodFatInfo> dataMap = new HashMap<>();
                    for (JWBloodFatInfo data : bloodFatInfoList) {
                        JWBloodFatInfo cacheData = dataMap.get(data.cycleStartTime);
                        if (cacheData == null) {
                            dataMap.put(data.cycleStartTime, data);
                        } else {
                            // 新周期 dayStatusList 会变大
                            int curDayStatus = BloodFatInfo.convertDayStatusList(data.dayStatusList);
                            int cacheDayStatus = BloodFatInfo.convertDayStatusList(cacheData.dayStatusList);
                            if (curDayStatus > cacheDayStatus) {
                                dataMap.put(data.cycleStartTime, data);
                            }
                        }
                    }

                    List<JWBloodFatInfo> infoList = new ArrayList<>(dataMap.values());

                    BloodFatInfoDao dao = DatabaseManager.getInstance().getBloodFatDao();
                    if (dao != null) {
                        List<BloodFatInfo> dataList = new ArrayList<>();
                        for (JWBloodFatInfo info : infoList) {
                            dataList.add(new BloodFatInfo(info));
                        }
                        dao.saveDataList(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onBloodFatDataReceived(infoList);
                            }
                        }
                    });
                }

                @Override
                public void onBloodSugarCycleDataReceived(List<JWBloodSugarCycleInfo> bloodFatInfoList) {
                    if (bloodFatInfoList == null || bloodFatInfoList.isEmpty()) {
                        return;
                    }

                    // 血糖协议会返回同一个周期内的多条数据，此处需过滤同一个周期数据，取当前最新周期值
                    Map<Long, JWBloodSugarCycleInfo> dataMap = new HashMap<>();
                    for (JWBloodSugarCycleInfo data : bloodFatInfoList) {
                        JWBloodSugarCycleInfo cacheData = dataMap.get(data.cycleStartTime);
                        if (cacheData == null) {
                            dataMap.put(data.cycleStartTime, data);
                        } else {
                            // 新周期 dayStatusList 会变大
                            int curDayStatus = BloodFatInfo.convertDayStatusList(data.dayStatusList);
                            int cacheDayStatus = BloodFatInfo.convertDayStatusList(cacheData.dayStatusList);
                            if (curDayStatus > cacheDayStatus) {
                                dataMap.put(data.cycleStartTime, data);
                            }
                        }
                    }

                    List<JWBloodSugarCycleInfo> infoList = new ArrayList<>(dataMap.values());

                    BloodSugarCycleInfoDao dao = DatabaseManager.getInstance().getBloodSugarCycleDao();
                    if (dao != null) {
                        List<BloodSugarCycleInfo> dataList = new ArrayList<>();
                        for (JWBloodSugarCycleInfo info : infoList) {
                            dataList.add(new BloodSugarCycleInfo(info));
                        }
                        dao.saveDataList(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onBloodSugarCycleDataReceived(infoList);
                            }
                        }
                    });
                }

                @Override
                public void onUricAcidContinuousMonitoringDataReceived(List<JWUricAcidContinuousMonitoringInfo> uricAcidContinuousMonitoringInfoList) {
                    UricAcidContinuousMonitoringInfoDao dao = DatabaseManager.getInstance().getUricAcidContinuousMonitoringDao();
                    if (dao != null) {
                        List<UricAcidContinuousMonitoringInfo> dataList = new ArrayList<>();
                        for (JWUricAcidContinuousMonitoringInfo info : uricAcidContinuousMonitoringInfoList) {
                            dataList.add(new UricAcidContinuousMonitoringInfo(info));
                        }
                        dao.insertOrReplaceInTx(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onUricAcidContinuousMonitoringDataReceived(uricAcidContinuousMonitoringInfoList);
                            }
                        }
                    });
                }

                @Override
                public void onBloodSugarContinuousMonitoringDataReceived(List<JWBloodFatContinuousMonitoringInfo> bloodFatContinuousMonitoringInfoList) {
                    BloodFatContinuousMonitoringInfoDao dao = DatabaseManager.getInstance().getBloodFatContinuousMonitoringDao();
                    if (dao != null) {
                        List<BloodFatContinuousMonitoringInfo> dataList = new ArrayList<>();
                        for (JWBloodFatContinuousMonitoringInfo info : bloodFatContinuousMonitoringInfoList) {
                            dataList.add(new BloodFatContinuousMonitoringInfo(info));
                        }
                        dao.insertOrReplaceInTx(dataList);
                    }
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isSynchronizing && mSyncDataListener != null) {
                                mSyncDataListener.onBloodSugarContinuousMonitoringDataReceived(bloodFatContinuousMonitoringInfoList);
                            }
                        }
                    });
                }

            };

            TransportManager.getInstance().setSyncDataListener(mInternalSyncDataListener);
        }
    }

    private void initListener() {
        initInternalSyncDataListener();
        initInternalPulseListener();
        initInternalSaunaListener();
        initInternalHRVRmssdListener();
        initInternalUltravioletListener();
        initInternalPressureListener();
    }


}
