package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.entity.JWUltravioletInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;

import java.util.ArrayList;
import java.util.List;

public class UltravioletDataHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        int packetLength = 8;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return;
        }

        List<JWUltravioletInfo> dataList = new ArrayList<>();
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            long startTime = (((subData[0] & 0xff)) | ((subData[1] & 0xff) << 8) | ((subData[2] & 0xff) << 16) | ((subData[3] & 0xff) << 24));
            long time = DateUtil.getDate(2000, 1, 1);
            startTime = startTime * 1000 + time;

            int value = subData[4] & 0xff;
            int vd = subData[5] & 0xff;
            int skin = subData[6] & 0xff;
            int skinCancer = subData[7] & 0xff;


            JWUltravioletInfo info = new JWUltravioletInfo();

            info.time = startTime;
            info.userID = BaseManager.getInstance().getUserID();
            info.deviceMac = BaseManager.getInstance().getMacAddress();
            info.value = value;
            info.vd = vd;
            info.skin = skin;
            info.skinCancer = skinCancer;

            dataList.add(info);
        }
        if (dataList.isEmpty()) {
            return;
        }
        if (TransportManager.getInstance().getSyncDataListener() == null) {
            return;
        }
        JWUltravioletInfo info = dataList.get(0);
        if (dataList.size() == 1 && info.getTime() == 2865908079000L
                && info.value == 111 && info.vd == 118
                && info.skin == 101 && info.skinCancer == 114) {
            // 结束标识
            TransportManager.getInstance().getUltravioletListener().onSyncUltravioletDataEnd();
        } else {
            TransportManager.getInstance().getUltravioletListener().onUltravioletDataReceived(dataList);
        }

    }
}
