package com.wosmart.ukprotocollibary.v2.moudle.settings;

import android.content.Context;

import androidx.annotation.NonNull;

import com.wosmart.ukprotocollibary.util.SPWristbandConfigInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWAllNotifyConfigInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWNotifyType;
import com.wosmart.ukprotocollibary.v2.JWSettingsManager;
import com.wosmart.ukprotocollibary.v2.layer.BlePacketHelper;
import com.wosmart.ukprotocollibary.v2.layer.BleProtocol;

import java.util.Calendar;

public class SettingsPacketHelper extends BlePacketHelper {

    public @NonNull static byte[] prepareSetDateFormatPacket(int format) {
        byte[] keyValue = {(byte) (format == JWSettingsManager.DATE_FORMAT_MM_DD ? 0x00 : 0x01)};
        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.DEVICE_DATE_FORMAT_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

    public @NonNull static byte[] prepareGetDateFormatPacket() {
        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.DEVICE_DATE_FORMAT_REQ, null);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

    public @NonNull static byte[] prepareSetPhoneOSPacket() {
        byte[] keyValue = {0x02, 0x00};
        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.PHONE_OS, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

    public @NonNull static byte[] prepareSetTimePacket() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR) - 2000;
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DATE);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int min = calendar.get(Calendar.MINUTE);
        int sec = calendar.get(Calendar.SECOND);

        byte[] keyValue = new byte[4];
        keyValue[0] = (byte) ((year << 2) | (month >> 2));
        keyValue[1] = (byte) ((month << 6) | (day << 1) | (hour >> 4));
        keyValue[2] = (byte) ((hour << 4) | (min >> 2));
        keyValue[3] = (byte) ((min << 6) | (sec));

        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.TIMER, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

    public @NonNull static byte[] prepareSetUserProfilePacket(int gender, int age, float height, float weight) {
        byte[] keyValue = new byte[4];
        int bHeight = (int) (height * 2);//Accuracy of 0.5
        int bWeight = (int) (weight * 2);//Accuracy of 0.5
        keyValue[0] = (byte) ((gender == JWSettingsManager.GENDER_MALE ? 0x80 : 0x00) | age);
        keyValue[1] = (byte) (bHeight >> 1);
        keyValue[2] = (byte) ((bHeight << 7) | (bWeight >> 3));
        keyValue[3] = (byte) ((bWeight << 5));

        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.USER_PROFILE, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

    public @NonNull static byte[] prepareSetAudioSwitchPacket(boolean enable) {
        byte[] keyValue = new byte[]{(byte) (enable ? 0x01: 0x00)};
        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.AUDIO_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

    public @NonNull static byte[] prepareGetAudioSwitchPacket() {
        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.AUDIO_GET_REQ, null);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

    public @NonNull static byte[] prepareSetHourSystemPacket(boolean is24Model) {
        byte[] keyValue = new byte[]{(byte) (is24Model ? 0x00: 0x01)};
        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.HOUR_SYSTEM_SETTING, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }


    public @NonNull static byte[] prepareGetAllNotifySwitchPacket() {
        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.NOTIFY_SWITCH_REQ, null);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

    public @NonNull static byte[] prepareSetNotifySwitchPacket(Context context, JWNotifyType notifyType, boolean flag) {
        byte mode;
        switch (notifyType) {
            case CALL:
                if (flag) {
                    mode = 0x01;
                } else {
                    mode = 0x02;
                }
                SPWristbandConfigInfo.setNotifyCallFlag(context, flag);
                break;
            case WECHAT:
                if (flag) {
                    mode = 0x05;
                } else {
                    mode = 0x06;
                }
                SPWristbandConfigInfo.setNotifyWechatFlag(context, flag);
                break;
            case SMS:
                if (flag) {
                    mode = 0x07;
                } else {
                    mode = 0x08;
                }
                SPWristbandConfigInfo.setNotifyMessageFlag(context, flag);
                break;
            case LINE:
                if (flag) {
                    mode = 0x09;
                } else {
                    mode = 0x0A;
                }
                SPWristbandConfigInfo.setNotifyLineFlag(context, flag);
                break;
            case TWITTER:
                if (flag) {
                    mode = 0x0B;
                } else {
                    mode = 0x0C;
                }
                SPWristbandConfigInfo.setNotifyTwitterFlag(context, flag);
                break;
            case FACEBOOK:
                if (flag) {
                    mode = 0x0E;
                } else {
                    mode = 0x0F;
                }
                SPWristbandConfigInfo.setNotifyFacebookFlag(context, flag);
                break;
            case MESSENGER:
                if (flag) {
                    mode = 0x10;
                } else {
                    mode = 0x11;
                }
                SPWristbandConfigInfo.setNotifyMessengerFlag(context, flag);
                break;
            case WHATSAPP:
                if (flag) {
                    mode = 0x12;
                } else {
                    mode = 0x13;
                }
                SPWristbandConfigInfo.setNotifyWhatsAppFlag(context, flag);
                break;
            case LINKEDIN:
                if (flag) {
                    mode = 0x14;
                } else {
                    mode = 0x15;
                }
                SPWristbandConfigInfo.setNotifyLinkedInFlag(context, flag);
                break;
            case INSTAGRAM:
                if (flag) {
                    mode = 0x16;
                } else {
                    mode = 0x17;
                }
                SPWristbandConfigInfo.setNotifyInstagramFlag(context, flag);
                break;
            case SKYPE:
                if (flag) {
                    mode = 0x18;
                } else {
                    mode = 0x19;
                }
                SPWristbandConfigInfo.setNotifySkypeFlag(context, flag);
                break;
            case VIBER:
                if (flag) {
                    mode = 0x1A;
                } else {
                    mode = 0x1B;
                }
                SPWristbandConfigInfo.setNotifyViberFlag(context, flag);
                break;
            case KAKAOTALK:
                if (flag) {
                    mode = 0x1C;
                } else {
                    mode = 0x1D;
                }
                SPWristbandConfigInfo.setNotifyKakaoTalkFlag(context, flag);
                break;
            case VKONTAKTE:
                if (flag) {
                    mode = 0x1E;
                } else {
                    mode = 0x1F;
                }
                SPWristbandConfigInfo.setNotifyVkontakteFlag(context, flag);
                break;
            case TIM:
                if (flag) {
                    mode = 0x26;
                } else {
                    mode = 0x27;
                }
                SPWristbandConfigInfo.setNotifyTimFlag(context, flag);
                break;
            case GMAIL:
                if (flag) {
                    mode = 0x28;
                } else {
                    mode = 0x29;
                }
                SPWristbandConfigInfo.setNotifyGmailFlag(context, flag);
                break;
            case DINGTALK:
                if (flag) {
                    mode = 0x2A;
                } else {
                    mode = 0x2B;
                }
                SPWristbandConfigInfo.setNotifyDingTalkFlag(context, flag);
                break;
            case WORKWECHAT:
                if (flag) {
                    mode = 0x2C;
                } else {
                    mode = 0x2D;
                }
                SPWristbandConfigInfo.setNotifyWorkWechatFlag(context, flag);
                break;
            case OTHER:
                if (flag) {
                    mode = 0x36;
                } else {
                    mode = 0x37;
                }
                SPWristbandConfigInfo.setNotifyOtherFlag(context, flag);
                break;
            default:
                if (flag) {
                    mode = 0x03;
                } else {
                    mode = 0x04;
                }
                SPWristbandConfigInfo.setNotifyQQFlag(context, flag);
                break;
        }
        byte[] keyValue = {mode};
        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.INCOMING_ON_OFF, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

    public @NonNull static byte[] prepareSetAllNotifySwitchPacket(JWAllNotifyConfigInfo notifyConfigInfo) {
        byte[] keyValue = new byte[4];

        keyValue[0] = (notifyConfigInfo.other ? (byte) 0x80 : (byte) 0x00);

        keyValue[1] = (byte) (
                (notifyConfigInfo.workWeChat ? (byte) 0x20 : (byte) 0x00)
                        | (notifyConfigInfo.dingTalk ? (byte) 0x10 : (byte) 0x00)
                        | (notifyConfigInfo.gmail ? (byte) 0x08 : (byte) 0x00)
                        | (notifyConfigInfo.tim ? (byte) 0x04 : (byte) 0x00)
        );

        keyValue[2] = (byte) (
                (notifyConfigInfo.vkontakte ? (byte) 0x40 : (byte) 0x00)
                        | (notifyConfigInfo.kakaoTalk ? (byte) 0x20 : (byte) 0x00)
                        | (notifyConfigInfo.viber ? (byte) 0x10 : (byte) 0x00)
                        | (notifyConfigInfo.skype ? (byte) 0x08 : (byte) 0x00)
                        | (notifyConfigInfo.instagram ? (byte) 0x04 : (byte) 0x00)
                        | (notifyConfigInfo.linkedin ? (byte) 0x02 : (byte) 0x00)
                        | (notifyConfigInfo.whatsapp ? (byte) 0x01 : (byte) 0x00)
        );

        keyValue[3] = (byte) (
                (notifyConfigInfo.messenger ? (byte) 0x80 : (byte) 0x00)
                        | (notifyConfigInfo.facebook ? (byte) 0x40 : (byte) 0x00)
                        | (notifyConfigInfo.twitter ? (byte) 0x20 : (byte) 0x00)
                        | (notifyConfigInfo.line ? (byte) 0x10 : (byte) 0x00)
                        | (notifyConfigInfo.sms ? (byte) 0x08 : (byte) 0x00)
                        | (notifyConfigInfo.wechat ? (byte) 0x04 : (byte) 0x00)
                        | (notifyConfigInfo.qq ? (byte) 0x02 : (byte) 0x00)
                        | (notifyConfigInfo.call ? (byte) 0x01 : (byte) 0x00)
        );
        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.NOTIFY_ALL, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }



}
