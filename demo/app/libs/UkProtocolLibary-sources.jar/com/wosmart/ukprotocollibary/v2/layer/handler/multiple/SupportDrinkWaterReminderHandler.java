package com.wosmart.ukprotocollibary.v2.layer.handler.multiple;

import com.wosmart.ukprotocollibary.v2.entity.JWDrinkWaterReminderInfo;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.TempFunctionInfoListener;

public class SupportDrinkWaterReminderHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length < 7) {
            return;
        }
        TempFunctionInfoListener tempFunctionInfoListener = BaseManager.getInstance().getTempFunctionInfoListener();
        if (tempFunctionInfoListener != null) {
            JWDrinkWaterReminderInfo reminderInfo = new JWDrinkWaterReminderInfo();

            reminderInfo.enable = ((data[0]) == 0x01);
            reminderInfo.startHour = (data[1] & 0xFF);
            reminderInfo.startMin = (data[2] & 0xFF);
            reminderInfo.endHour = (data[3] & 0xFF);
            reminderInfo.endMin = (data[4] & 0xFF);
            reminderInfo.interval = ((data[5] & 0xff) << 8) | (data[6] & 0xff);

            tempFunctionInfoListener.onSupportDrinkWaterReminder(reminderInfo);
        }
    }

}
