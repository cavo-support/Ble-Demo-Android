package com.wosmart.ukprotocollibary.v2.layer.handler.settings;

import android.util.SparseArray;

import com.wosmart.ukprotocollibary.v2.entity.JWDeviceFunctionInfo;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

public class DeviceFunctionHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        JWDeviceFunctionInfo functionInfo = new JWDeviceFunctionInfo();
        if (data.length >= 4) {
            functionInfo.earPhone = (data[3] & 0x01) == 1;
            functionInfo.bpDetection = ((data[3] >> 1) & 0x01) == 1;
            functionInfo.rate = ((data[3] >> 2) & 0x01) == 1;
            functionInfo.disturb = ((data[3] >> 3) & 0x01) == 1;
            functionInfo.step = ((data[3] >> 4) & 0x01) == 1;
            functionInfo.sleep = ((data[3] >> 5) & 0x01) == 1;
            functionInfo.weChatRun = ((data[3] >> 6) & 0x01) == 1;
            functionInfo.lightDuration = ((data[3] >> 7) & 0x01) == 1;

            functionInfo.notifyReminder = (data[2] & 0x01) == 1;
            functionInfo.screenTheme = ((data[2] >> 1) & 0x01) == 1;
            functionInfo.turnLight = ((data[2] >> 2) & 0x01) == 1;
            functionInfo.multiLanguage = ((data[2] >> 3) & 0x01) == 1;
            functionInfo.hourSystem = ((data[2] >> 4) & 0x01) == 1;
            functionInfo.unitSystem = ((data[2] >> 5) & 0x01) == 1;
            functionInfo.ota = ((data[2] >> 6) & 0x01) == 1;
            functionInfo.nfc = ((data[2] >> 7) & 0x01) == 1;

            functionInfo.multiSport = (data[1] & 0x01) == 1;
            functionInfo.stepWatch = ((data[1] >> 1) & 0x01) == 1;
            functionInfo.countDown = ((data[1] >> 2) & 0x01) == 1;
            functionInfo.rateReminder = ((data[1] >> 3) & 0x01) == 1;
            functionInfo.cameraControl = ((data[1] >> 4) & 0x01) == 1;
            functionInfo.findPhone = ((data[1] >> 5) & 0x01) == 1;
            functionInfo.findDevice = ((data[1] >> 6) & 0x01) == 1;
            functionInfo.lightControl = ((data[1] >> 7) & 0x01) == 1;

            functionInfo.musicControl = (data[0] & 0x01) == 1;
            functionInfo.volumeControl = ((data[0] >> 1) & 0x01) == 1;
            functionInfo.alarm = ((data[0] >> 2) & 0x01) == 1;
            functionInfo.longSitReminder = ((data[0] >> 3) & 0x01) == 1;
            functionInfo.eventReminder = ((data[0] >> 4) & 0x01) == 1;
            functionInfo.autoLock = ((data[0] >> 5) & 0x01) == 1;
            functionInfo.appSportRateDetect = ((data[0] >> 6) & 0x01) == 1;
            functionInfo.baseSwitch = ((data[0] >> 7) & 0x01) == 1;

            if (data.length >= 8) {
                functionInfo.todayAdjust = ((data[4] >> 7) & 0x01) == 1;
                functionInfo.sleepAdjust = ((data[4] >> 6) & 0x01) == 1;
                functionInfo.temperature = ((data[4] >> 5) & 0x01) == 1;
                functionInfo.bp2 = ((data[4] >> 4) & 0x01) == 1;
                functionInfo.alarm2 = ((data[4] >> 3) & 0x01) == 1;
                functionInfo.customUi = ((data[4] >> 2) & 0x01) == 1;
                functionInfo.downloadUi = ((data[4] >> 1) & 0x01) == 1;
                functionInfo.spo2Measure = ((data[4]) & 0x01) == 1;

                functionInfo.modeUpgrade = ((data[5] >> 7) & 0x01) == 1;
                functionInfo.sleepQuality2 = ((data[5] >> 6) & 0x01) == 1;
                functionInfo.sportRate2 = ((data[5] >> 5) & 0x01) == 1;
                functionInfo.rateTempPressure = ((data[5] >> 4) & 0x01) == 1;
                functionInfo.spo2Continuous = ((data[5] >> 3) & 0x01) == 1;
                functionInfo.ecgFunction = ((data[5] >> 2) & 0x01) == 1;
                functionInfo.deviceStateSync = ((data[5] >> 1) & 0x01) == 1;
                functionInfo.addressBook = ((data[5]) & 0x01) == 1;

                functionInfo.rtkHrv = ((data[6] >> 7) & 0x01) == 1;
                functionInfo.rtkBp3 = ((data[6] >> 6) & 0x01) == 1;
                functionInfo.bloodSugar = ((data[6] >> 5) & 0x01) == 1;
                functionInfo.hypoxia = ((data[6] >> 4) & 0x01) == 1;
                functionInfo.highHrv = ((data[6] >> 3) & 0x01) == 1;
                functionInfo.sleepAll = ((data[6] >> 2) & 0x01) == 1;
                functionInfo.deviceDateFormat = ((data[6] >> 1) & 0x01) == 1;
                functionInfo.hideQTAndHrv = ((data[6]) & 0x01) == 1;

                functionInfo.ecgBelt = ((data[7] >> 7) & 0x01) == 1;
                functionInfo.hideHealthFunction = ((data[7] >> 6) & 0x01) == 1;
                functionInfo.pressure = ((data[7] >> 5) & 0x01) == 1;
            }
        }

        SparseArray<SendPacketCallback> callbackMap = TransportManager.getInstance().getCallbackMap();
        SendPacketCallback callback = callbackMap.get(CallbackKeyConstants.KEY_GET_DEVICE_FUNCTION);
        if (callback != null) {
            callback.onResponse(functionInfo);
            callbackMap.remove(CallbackKeyConstants.KEY_GET_DEVICE_FUNCTION);
        }
    }

}
