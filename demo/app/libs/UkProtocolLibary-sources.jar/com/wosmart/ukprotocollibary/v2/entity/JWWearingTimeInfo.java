package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWWearingTimeInfo extends JWHealthData implements Serializable {

    /**
     * 未佩戴
     */
    public static final int WEAR_STATUS_UN_WEAR = 0;

    /**
     * 已佩戴
     */
    public static final int WEAR_STATUS_WEAR = 1;

    /**
     * 佩戴状态
     */
    public int wearStatus;

    @Override
    public String toString() {
        return "JWWearingTimeInfo{" +
                "userID=" + userID +
                ", time='" + time + '\'' +
                ", wearStatus=" + wearStatus +
                '}';
    }
}
