package com.wosmart.ukprotocollibary.v2.layer.handler.custom;

import com.wosmart.ukprotocollibary.v2.JWHRVRmssdListener;
import com.wosmart.ukprotocollibary.v2.JWSaunaListener;
import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSaunaInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class SyncHRVRmssdDataRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        JWHRVRmssdListener hrvRmssdListener = TransportManager.getInstance().getHRVRmssdListener();
        if (hrvRmssdListener == null) {
            return;
        }
        if ((data.length < 8) || (data.length % 8) != 0) {
            return;
        }
        List<JWHRVRmssdInfo> infoList = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        byte[] subData = new byte[8];
        for (int i = 0; i < data.length / 8; i++) {

            System.arraycopy(data, i * 8, subData, 0, 8);

            // 该时间戳为 2000.1.1 以后的秒
            long timestamp = (((subData[0] & 0xff) << 24) | ((subData[1] & 0xff) << 16) | ((subData[2] & 0xff) << 8) | ((subData[3] & 0xff)));
            int value = (((subData[4] & 0xff) << 8) | (subData[5] & 0xff)) & 0xffff;

            calendar.clear();
            calendar.set(2000, 0, 1);

            long time = calendar.getTimeInMillis();

            time += timestamp * 1000;

            JWHRVRmssdInfo info = new JWHRVRmssdInfo();

            info.time = time;
            info.userID = BaseManager.getInstance().getUserID();
            info.deviceMac = BaseManager.getInstance().getMacAddress();
            info.value = value;

            infoList.add(info);
        }

        hrvRmssdListener.onHRVRmssdDataReceived(infoList);
    }

}
