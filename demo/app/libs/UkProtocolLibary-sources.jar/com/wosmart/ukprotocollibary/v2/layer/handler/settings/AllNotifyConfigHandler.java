package com.wosmart.ukprotocollibary.v2.layer.handler.settings;

import android.util.SparseArray;

import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerNotifyPacket;
import com.wosmart.ukprotocollibary.v2.entity.JWAllNotifyConfigInfo;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

public class AllNotifyConfigHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        ApplicationLayerNotifyPacket applicationLayerNotifyPacket = new ApplicationLayerNotifyPacket();
        applicationLayerNotifyPacket.parseData2(data);
        JWAllNotifyConfigInfo configInfo = new JWAllNotifyConfigInfo();
        if (data.length >= 4) {
            configInfo.call = (data[3] & 0x01) == 1;
            configInfo.qq = ((data[3] >> 1) & 0x01) == 1;
            configInfo.wechat = ((data[3] >> 2) & 0x01) == 1;
            configInfo.sms = ((data[3] >> 3) & 0x01) == 1;
            configInfo.line = ((data[3] >> 4) & 0x01) == 1;
            configInfo.twitter = ((data[3] >> 5) & 0x01) == 1;
            configInfo.facebook = ((data[3] >> 6) & 0x01) == 1;
            configInfo.messenger = ((data[3] >> 7) & 0x01) == 1;

            configInfo.whatsapp = (data[2] & 0x01) == 1;
            configInfo.linkedin = ((data[2] >> 1) & 0x01) == 1;
            configInfo.instagram = ((data[2] >> 2) & 0x01) == 1;
            configInfo.skype = ((data[2] >> 3) & 0x01) == 1;
            configInfo.viber = ((data[2] >> 4) & 0x01) == 1;
            configInfo.kakaoTalk = ((data[2] >> 5) & 0x01) == 1;
            configInfo.vkontakte = ((data[2] >> 6) & 0x01) == 1;

            configInfo.tim = ((data[1] >> 2) & 0x01) == 1;
            configInfo.gmail = ((data[1] >> 3) & 0x01) == 1;
            configInfo.dingTalk = ((data[1] >> 4) & 0x01) == 1;
            configInfo.workWeChat = ((data[1] >> 5) & 0x01) == 1;

            configInfo.other = ((data[0] >> 7) & 0x01) == 1;
        }

        SparseArray<SendPacketCallback> callbackMap = TransportManager.getInstance().getCallbackMap();
        SendPacketCallback callback = callbackMap.get(CallbackKeyConstants.KEY_GET_ALL_NOTIFY_SWITCH);
        if (callback != null) {
            callback.onResponse(configInfo);
            callbackMap.remove(CallbackKeyConstants.KEY_GET_ALL_NOTIFY_SWITCH);
        }
    }

}
