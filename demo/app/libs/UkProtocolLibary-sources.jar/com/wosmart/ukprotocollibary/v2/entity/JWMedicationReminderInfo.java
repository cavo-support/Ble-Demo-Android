package com.wosmart.ukprotocollibary.v2.entity;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class JWMedicationReminderInfo implements Serializable {

    public static int FLAG_NONE = 0x00;

    public static int FLAG_MON = 0x01;
    public static int FLAG_TUE = (0x01 << 1);
    public static int FLAG_WED = (0x01 << 2);
    public static int FLAG_THU = (0x01 << 3);
    public static int FLAG_FRI = (0x01 << 4);
    public static int FLAG_SAT = (0x01 << 5);
    public static int FLAG_SUN = (0x01 << 6);

    private int id;

    private long time;

    private int flags = FLAG_NONE;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public int getFlags() {
        return flags;
    }

    public void setFlags(int flags) {
        this.flags = flags;
    }

    public void setReminderByEveryDay(boolean enable) {
        this.flags = enable ? 0x7F : 0x00;
    }

    public boolean isReminderByEveryDay() {
        return this.flags == 0x7F;
    }

    public void setReminderByWorkDay(boolean enable) {
        this.flags = enable ? 0x1F : 0x00;
    }

    public boolean isReminderByWorkDay() {
        return this.flags == 0x1F;
    }

    /**
     * reminder by one day
     *
     * @param enable  is reminder
     * @param dayFlag day of week
     * @see #FLAG_MON monday
     * @see #FLAG_TUE tuesday
     * @see #FLAG_WED wednesday
     * @see #FLAG_THU thursday
     * @see #FLAG_FRI friday
     * @see #FLAG_SAT saturday
     * @see #FLAG_SUN sunday
     */
    public void setReminderByOneDay(boolean enable, int dayFlag) {
        if (dayFlag != FLAG_MON && dayFlag != FLAG_TUE & dayFlag != FLAG_WED &&
                dayFlag != FLAG_THU & dayFlag != FLAG_FRI && dayFlag != FLAG_SAT & dayFlag != FLAG_SUN) {
            return;
        }
        if (enable) {
            this.flags |= dayFlag;
        } else {
            if (dayFlag == FLAG_MON) {
                this.flags &= 0x7E;
            } else if (dayFlag == FLAG_TUE) {
                this.flags &= 0x7D;
            } else if (dayFlag == FLAG_WED) {
                this.flags &= 0x7B;
            } else if (dayFlag == FLAG_THU) {
                this.flags &= 0x77;
            } else if (dayFlag == FLAG_FRI) {
                this.flags &= 0x6F;
            } else if (dayFlag == FLAG_SAT) {
                this.flags &= 0x5F;
            } else {
                this.flags &= 0x3F;
            }
        }
    }

    /**
     * check reminder by some day
     *
     * @param dayFlag day of week
     * @return is reminder
     * @see #FLAG_MON monday
     * @see #FLAG_TUE tuesday
     * @see #FLAG_WED wednesday
     * @see #FLAG_THU thursday
     * @see #FLAG_FRI friday
     * @see #FLAG_SAT saturday
     * @see #FLAG_SUN sunday
     */
    public boolean isReminderBySomeDay(int dayFlag) {
        if (dayFlag != FLAG_MON && dayFlag != FLAG_TUE & dayFlag != FLAG_WED &&
                dayFlag != FLAG_THU & dayFlag != FLAG_FRI && dayFlag != FLAG_SAT & dayFlag != FLAG_SUN) {
            return false;
        }
        if (dayFlag == FLAG_MON) {
            return (flags & dayFlag) == 1;
        } else if (dayFlag == FLAG_TUE) {
            return ((flags & dayFlag) >> 1) == 1;
        } else if (dayFlag == FLAG_WED) {
            return ((flags & dayFlag) >> 2) == 1;
        } else if (dayFlag == FLAG_THU) {
            return ((flags & dayFlag) >> 3) == 1;
        } else if (dayFlag == FLAG_FRI) {
            return ((flags & dayFlag) >> 4) == 1;
        } else if (dayFlag == FLAG_SAT) {
            return ((flags & dayFlag) >> 5) == 1;
        } else {
            return ((flags & dayFlag) >> 6) == 1;
        }
    }


    @NonNull
    @Override
    public String toString() {
        return "JWMedicationReminderInfo{" +
                "id=" + id +
                ", time=" + time +
                ", flags=" + flags +
                '}';
    }

}
