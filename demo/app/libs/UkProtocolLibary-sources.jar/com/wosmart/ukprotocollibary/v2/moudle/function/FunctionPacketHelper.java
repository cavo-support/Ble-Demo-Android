package com.wosmart.ukprotocollibary.v2.moudle.function;

import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.wosmart.ukprotocollibary.util.StringByteTrans;
import com.wosmart.ukprotocollibary.v2.entity.JWFemaleHealthInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWMedicationReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWeatherInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWDefaultFunctionInfo;
import com.wosmart.ukprotocollibary.v2.layer.BlePacketHelper;
import com.wosmart.ukprotocollibary.v2.layer.BleProtocol;

import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.List;

public class FunctionPacketHelper extends BlePacketHelper {

    public @NonNull static byte[] prepareSetTakePhotoControlPacket(boolean enable) {
        byte[] keyValue = {(byte) (enable ? 0x01 : 0x00)};

        byte[] keyData = prepareKeyPacket(BleProtocol.ControlKey.APP_REQ, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.CONTROL, keyData);
    }

    public @NonNull static byte[] prepareSetPrivateBloodPressurePacket(boolean enable, int highValue, int lowValue) {
        byte[] keyValue = new byte[3];
        keyValue[0] = (byte) (enable ? 0x01 : 0x00);
        keyValue[1] = (byte) (highValue & 0xff);
        keyValue[2] = (byte) (lowValue & 0xff);

        byte[] keyData = prepareKeyPacket(BleProtocol.MultipleCmdKey.PRIVATE_BP, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.MULTIPLE_CMD, keyData);
    }

    public @NonNull static byte[] prepareSetTemperatureReminderPacket(boolean enable, int value) {
        if (!enable) {
            value = 0;// 关闭情况下设置为 0 即可
        }
        byte[] keyValue = new byte[2];
        keyValue[0] = (byte) ((value >> 8) & 0xff);
        keyValue[1] = (byte) (value & 0xff);

        byte[] keyData = prepareKeyPacket(BleProtocol.MultipleCmdKey.TEMPERATURE_REMINDER, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.MULTIPLE_CMD, keyData);
    }

    public @NonNull static byte[] prepareSetDrinkWaterReminderPacket(boolean enable, int startHour, int startMin, int endHour, int endMin, int interval) {
        byte[] keyValue = new byte[7];
        keyValue[0] = (byte) (enable ? 0x01 : 0x00);
        keyValue[1] = (byte) (startHour & 0xFF);
        keyValue[2] = (byte) (startMin & 0xFF);
        keyValue[3] = (byte) (endHour & 0xFF);
        keyValue[4] = (byte) (endMin & 0xFF);
        keyValue[5] = (byte) ((interval >> 8) & 0xFF);
        keyValue[6] = (byte) (interval & 0xFF);

        byte[] keyData = prepareKeyPacket(BleProtocol.MultipleCmdKey.DRINK_WATER_REMINDER, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.MULTIPLE_CMD, keyData);
    }

    public @NonNull static byte[] prepareSetMedicationReminderPacket(List<JWMedicationReminderInfo> reminderInfoList) {
        byte[] keyValue = null;
        if (reminderInfoList != null && !reminderInfoList.isEmpty()) {
            Calendar calendar = Calendar.getInstance();

            int size = reminderInfoList.size();
            keyValue = new byte[size * 5];
            for (int i = 0; i < size; i++) {
                JWMedicationReminderInfo reminderInfo = reminderInfoList.get(i);

                calendar.setTimeInMillis(reminderInfo.getTime());

                int year = calendar.get(Calendar.YEAR) - 2000;
                int month = calendar.get(Calendar.MONTH) + 1;
                int day = calendar.get(Calendar.DATE);
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minute = calendar.get(Calendar.MINUTE);

                byte[] subData = new byte[5];

                subData[0] = (byte) ((year << 2) | (month >> 2));
                subData[1] = (byte) ((month << 6) | (day << 1) | (hour >> 4));
                subData[2] = (byte) ((hour << 4) | (minute >> 2));
                subData[3] = (byte) ((minute << 6) | (reminderInfo.getId() << 3) | (0x00));
                subData[4] = (byte) (reminderInfo.getFlags());

                System.arraycopy(subData, 0, keyValue, i * 5, 5);
            }
        }

        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.MEDICATION_REMINDER_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

    public @NonNull static byte[] prepareGetMedicationReminderPacket() {
        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.MEDICATION_REMINDER_REQ, null);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

    public @NonNull static byte[] prepareSetPulsePacket(boolean enable, int duration, int level) {
        byte[] keyValue = new byte[3];
        keyValue[0] = (byte) (enable ? 0x01 : 0x00);
        keyValue[1] = (byte) (duration & 0xFF);
        keyValue[2] = (byte) (level & 0xFF);

        byte[] keyData = prepareKeyPacket(BleProtocol.CustomModeKey.PULSE_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.CUSTOM_MADE, keyData);
    }

    public @NonNull static byte[] prepareSetSleepHelpPacket(boolean enable, int mode, int duration, int effectiveTime, int level) {
        byte[] keyValue = new byte[5];
        keyValue[0] = (byte) (enable ? 0x01 : 0x00);
        keyValue[1] = (byte) (mode & 0xFF);
        keyValue[2] = (byte) (duration & 0xFF);
        keyValue[3] = (byte) (effectiveTime & 0xFF);
        keyValue[4] = (byte) (level & 0xFF);

        byte[] keyData = prepareKeyPacket(BleProtocol.CustomModeKey.SLEEP_HELP_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.CUSTOM_MADE, keyData);
    }

    public @NonNull static byte[] prepareSetFemaleHealthPacket(JWFemaleHealthInfo healthInfo) {
        byte[] keyValue = new byte[8];
        keyValue[0] = (byte) (healthInfo.enable ? 0x01 : 0x00);
        keyValue[1] = (byte) (healthInfo.mode & 0xFF);
        keyValue[2] = (byte) (healthInfo.periodTime & 0xFF);
        keyValue[3] = (byte) (healthInfo.menstrualPeriodTime & 0xFF);
        keyValue[4] = (byte) ((healthInfo.year >> 8) & 0xFF);
        keyValue[5] = (byte) (healthInfo.year & 0xFF);
        keyValue[6] = (byte) (healthInfo.month & 0xFF);
        keyValue[7] = (byte) (healthInfo.day & 0xFF);

        byte[] keyData = prepareKeyPacket(BleProtocol.ControlKey.FEMALE_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.CONTROL, keyData);
    }

    public @NonNull static byte[] prepareSetWeatherPacket(JWWeatherInfo weatherInfo) {
        byte[] keyValue = new byte[64];
        keyValue[0] = (byte) (weatherInfo.isOpen ? 0x01 : 0x00);
        keyValue[1] = (byte) ((weatherInfo.year >> 8) & 0xFF);
        keyValue[2] = (byte) (weatherInfo.year & 0xFF);
        keyValue[3] = (byte) (weatherInfo.month & 0xFF);
        keyValue[4] = (byte) (weatherInfo.day & 0xFF);

        byte[] cityData = StringByteTrans.stringToBytes(weatherInfo.city, 34);
        cityData[33] = 0;

        System.arraycopy(cityData, 0, keyValue, 5, cityData.length);

        keyValue[39] = (byte) (weatherInfo.currentWeather == null ? 0 : (weatherInfo.currentWeather.weatherCode & 0xFF));
        keyValue[40] = (byte) (weatherInfo.currentWeather == null ? 0 : (weatherInfo.currentWeather.temperature & 0xFF));
        keyValue[41] = (byte) (weatherInfo.currentWeather == null ? 0 : (weatherInfo.currentWeather.maxTemperature & 0xFF));
        keyValue[42] = (byte) (weatherInfo.currentWeather == null ? 0 : (weatherInfo.currentWeather.minTemperature & 0xFF));
        keyValue[43] = (byte) (weatherInfo.currentWeather == null ? 0 : (weatherInfo.currentWeather.humidity & 0xFF));
        keyValue[44] = (byte) (weatherInfo.currentWeather == null ? 0 : (weatherInfo.currentWeather.ultravioletIntensity & 0xFF));
        keyValue[45] = (byte) (weatherInfo.currentWeather == null ? 0 : (weatherInfo.currentWeather.pollutionIndex & 0xFF));

        keyValue[46] = (byte) (weatherInfo.nextOneDayWeather == null ? 0 : (weatherInfo.nextOneDayWeather.weatherCode & 0xFF));
        keyValue[47] = (byte) (weatherInfo.nextOneDayWeather == null ? 0 : (weatherInfo.nextOneDayWeather.maxTemperature & 0xFF));
        keyValue[48] = (byte) (weatherInfo.nextOneDayWeather == null ? 0 : (weatherInfo.nextOneDayWeather.minTemperature & 0xFF));

        keyValue[49] = (byte) (weatherInfo.nextTwoDayWeather == null ? 0 : (weatherInfo.nextTwoDayWeather.weatherCode & 0xFF));
        keyValue[50] = (byte) (weatherInfo.nextTwoDayWeather == null ? 0 : (weatherInfo.nextTwoDayWeather.maxTemperature & 0xFF));
        keyValue[51] = (byte) (weatherInfo.nextTwoDayWeather == null ? 0 : (weatherInfo.nextTwoDayWeather.minTemperature & 0xFF));

        keyValue[52] = (byte) (weatherInfo.nextThreeDayWeather == null ? 0 : (weatherInfo.nextThreeDayWeather.weatherCode & 0xFF));
        keyValue[53] = (byte) (weatherInfo.nextThreeDayWeather == null ? 0 : (weatherInfo.nextThreeDayWeather.maxTemperature & 0xFF));
        keyValue[54] = (byte) (weatherInfo.nextThreeDayWeather == null ? 0 : (weatherInfo.nextThreeDayWeather.minTemperature & 0xFF));

        keyValue[55] = (byte) (weatherInfo.nextFourDayWeather == null ? 0 : (weatherInfo.nextFourDayWeather.weatherCode & 0xFF));
        keyValue[56] = (byte) (weatherInfo.nextFourDayWeather == null ? 0 : (weatherInfo.nextFourDayWeather.maxTemperature & 0xFF));
        keyValue[57] = (byte) (weatherInfo.nextFourDayWeather == null ? 0 : (weatherInfo.nextFourDayWeather.minTemperature & 0xFF));

        keyValue[58] = (byte) (weatherInfo.nextFiveDayWeather == null ? 0 : (weatherInfo.nextFiveDayWeather.weatherCode & 0xFF));
        keyValue[59] = (byte) (weatherInfo.nextFiveDayWeather == null ? 0 : (weatherInfo.nextFiveDayWeather.maxTemperature & 0xFF));
        keyValue[60] = (byte) (weatherInfo.nextFiveDayWeather == null ? 0 : (weatherInfo.nextFiveDayWeather.minTemperature & 0xFF));

        keyValue[61] = (byte) (weatherInfo.nextSixDayWeather == null ? 0 : (weatherInfo.nextSixDayWeather.weatherCode & 0xFF));
        keyValue[62] = (byte) (weatherInfo.nextSixDayWeather == null ? 0 : (weatherInfo.nextSixDayWeather.maxTemperature & 0xFF));
        keyValue[63] = (byte) (weatherInfo.nextSixDayWeather == null ? 0 : (weatherInfo.nextSixDayWeather.minTemperature & 0xFF));

        byte[] keyData = prepareKeyPacket(BleProtocol.ControlKey.WEATHER_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.CONTROL, keyData);
    }

    public @NonNull static byte[] prepareTemperatureControlPacket(boolean enable, boolean isAdjust, boolean isCelsiusUnit) {
        byte[] keyValue = new byte[4];
        keyValue[3] = (byte) ((enable ? 0x01 : 0x00) | (isAdjust ? 0x02 : 0x00) | (isCelsiusUnit ? 0x00 : 0x04));

        byte[] keyData = prepareKeyPacket(BleProtocol.SportKey.TEMP_CONTROL_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SPORTS_DATA, keyData);
    }

    public @NonNull static byte[] prepareSetUricAcidPacket(boolean enable, int privateValue, int privateRTCTime) {
        byte[] keyValue = new byte[7];
        keyValue[0] = (byte) (enable ? 0x01 : 0x00);
        keyValue[1] = (byte) ((privateValue >> 8) & 0xff);
        keyValue[2] = (byte) (privateValue & 0xff);
        keyValue[3] = (byte) ((privateRTCTime) & 0xff);
        keyValue[4] = (byte) ((privateRTCTime >> 8) & 0xff);
        keyValue[5] = (byte) ((privateRTCTime >> 16) & 0xff);
        keyValue[6] = (byte) ((privateRTCTime >> 24) & 0xff);

        byte[] keyData = prepareKeyPacket(BleProtocol.MultipleCmdKey.URIC_ACID, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.MULTIPLE_CMD, keyData);
    }

    public @NonNull static byte[] prepareSetBloodFatPacket(boolean enable, int privateValue, int privateRTCTime) {
        byte[] keyValue = new byte[7];
        keyValue[0] = (byte) (enable ? 0x01 : 0x00);
        keyValue[1] = (byte) ((privateValue >> 8) & 0xff);
        keyValue[2] = (byte) (privateValue & 0xff);
        keyValue[3] = (byte) ((privateRTCTime) & 0xff);
        keyValue[4] = (byte) ((privateRTCTime >> 8) & 0xff);
        keyValue[5] = (byte) ((privateRTCTime >> 16) & 0xff);
        keyValue[6] = (byte) ((privateRTCTime >> 24) & 0xff);

        byte[] keyData = prepareKeyPacket(BleProtocol.MultipleCmdKey.BLOOD_FAT, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.MULTIPLE_CMD, keyData);
    }

    public @NonNull static byte[] prepareSetBloodSugarCyclePacket(boolean enable, int privateValue, int privateRTCTime) {
        byte[] keyValue = new byte[7];
        keyValue[0] = (byte) (enable ? 0x01 : 0x00);
        keyValue[1] = (byte) ((privateValue >> 8) & 0xff);
        keyValue[2] = (byte) (privateValue & 0xff);
        keyValue[3] = (byte) ((privateRTCTime) & 0xff);
        keyValue[4] = (byte) ((privateRTCTime >> 8) & 0xff);
        keyValue[5] = (byte) ((privateRTCTime >> 16) & 0xff);
        keyValue[6] = (byte) ((privateRTCTime >> 24) & 0xff);

        byte[] keyData = prepareKeyPacket(BleProtocol.MultipleCmdKey.BLOOD_SUGAR_CYCLE, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.MULTIPLE_CMD, keyData);
    }

    public @NonNull static byte[] prepareSetPrivateUricAcidPacket(boolean enable, int value) {
        byte[] keyValue = new byte[5];
        keyValue[0] = (byte) (enable ? 0x01 : 0x00);
        keyValue[1] = (byte) ((value >> 8) & 0xff);
        keyValue[2] = (byte) (value & 0xff);
        keyValue[3] = 0;
        keyValue[4] = 0;

        byte[] keyData = prepareKeyPacket(BleProtocol.MultipleCmdKey.PRIVATE_URIC_ACID, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.MULTIPLE_CMD, keyData);
    }

    public @NonNull static byte[] prepareSetPrivateBloodFatPacket(boolean enable, float value) {
        byte[] keyValue = new byte[5];
        keyValue[0] = (byte) (enable ? 0x01 : 0x00);

        int tempValue = (int) (value * 100);
        keyValue[1] = (byte) ((tempValue >> 8) & 0xff);
        keyValue[2] = (byte) (tempValue & 0xff);
        keyValue[3] = 0;
        keyValue[4] = 0;

        byte[] keyData = prepareKeyPacket(BleProtocol.MultipleCmdKey.PRIVATE_BLOOD_FAT, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.MULTIPLE_CMD, keyData);
    }

    public @NonNull static byte[] prepareGetBloodSugarContinuousMonitoringPacket() {
        byte[] keyData = prepareKeyPacket(BleProtocol.SportKey.GLU_CONTINUOUS_REQ, null);
        return prepareDataPacket(BleProtocol.CommandID.SPORTS_DATA, keyData);
    }

    public @NonNull static byte[] prepareSetBloodSugarContinuousMonitoringPacket(boolean enable,  int interval) {
        byte[] keyValue = new byte[2];
        keyValue[0] = (byte) (enable ? 0x01 : 0x00);
        keyValue[1] = (byte) (interval & 0xFF);

        byte[] keyData = prepareKeyPacket(BleProtocol.SportKey.GLU_CONTINUOUS_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SPORTS_DATA, keyData);
    }

    public @NonNull static byte[] prepareSetUricAcidContinuousMonitoringPacket(boolean enable) {
        byte[] keyValue = new byte[3];
        keyValue[0] = (byte) (0x05);
        keyValue[1] = (byte) (enable ? 0x01 : 0x00);
        keyValue[2] = 0;

        byte[] keyData = prepareKeyPacket(BleProtocol.SportKey.CONTINUOUS_MONITORING_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.MULTIPLE_CMD, keyData);
    }

    public @NonNull static byte[] prepareSetBloodFatContinuousMonitoringPacket(boolean enable) {
        byte[] keyValue = new byte[3];
        keyValue[0] = (byte) (0x06);
        keyValue[1] = (byte) (enable ? 0x01 : 0x00);
        keyValue[2] = 0;

        byte[] keyData = prepareKeyPacket(BleProtocol.SportKey.CONTINUOUS_MONITORING_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.MULTIPLE_CMD, keyData);
    }

    public @NonNull static byte[] prepareSetPressureContinuousMonitoringPacket(boolean enable) {
        byte[] keyValue = new byte[3];
        keyValue[0] = (byte) (0x07);
        keyValue[1] = (byte) (enable ? 0x01 : 0x00);
        keyValue[2] = 0;

        byte[] keyData = prepareKeyPacket(BleProtocol.SportKey.CONTINUOUS_MONITORING_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.MULTIPLE_CMD, keyData);
    }

    public @NonNull static byte[] prepareSetBodyFatMeasurePacket(boolean enable) {
        byte[] keyValue = new byte[3];
        keyValue[0] = (byte) (0x05);
        keyValue[1] = (byte) (enable ? 0x01 : 0x00);
        keyValue[2] = 0;

        byte[] keyData = prepareKeyPacket(BleProtocol.SportKey.DEVICE_MEASURE_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SPORTS_DATA, keyData);
    }

    public @NonNull static byte[] prepareGetRecentBodyFatPacket() {
        byte[] keyData = prepareKeyPacket(BleProtocol.SportKey.BODY_FAT_HISTORY_REQ, null);
        return prepareDataPacket(BleProtocol.CommandID.SPORTS_DATA, keyData);
    }

    public @NonNull static byte[] prepareGetPhysicalExamPacket() {
        byte[] keyData = prepareKeyPacket(BleProtocol.SportKey.PHYSICAL_EXAM_HISTORY_REQ, null);
        return prepareDataPacket(BleProtocol.CommandID.SPORTS_DATA, keyData);
    }

    public @NonNull static byte[] prepareSyncUltravioletPacket() {
        byte[] keyData = prepareKeyPacket(BleProtocol.SportKey.ULTRAVIOLET_RQE, null);
        return prepareDataPacket(BleProtocol.CommandID.SPORTS_DATA, keyData);
    }

    public @NonNull static byte[] prepareSyncPressurePacket() {
        byte[] keyData = prepareKeyPacket(BleProtocol.SportKey.PRESSURE_RQE, null);
        return prepareDataPacket(BleProtocol.CommandID.SPORTS_DATA, keyData);
    }

    public @NonNull static byte[] prepareSetEcgBeltPacket(boolean enable) {
        byte[] keyValue = new byte[1];
        keyValue[0] = (byte) (enable ? 0x01 : 0x00);

        byte[] keyData = prepareKeyPacket(BleProtocol.SportKey.ECG_BELT_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SPORTS_DATA, keyData);
    }

    public @NonNull static byte[] prepareSetHRVRmssdPacket(boolean enable, int interval) {
        byte[] keyValue = new byte[1];
        keyValue[0] = (byte) (enable ? interval : 0x00);

        byte[] keyData = prepareKeyPacket(BleProtocol.CustomModeKey.HRV_RMSSD_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.CUSTOM_MADE, keyData);
    }

    public @NonNull static byte[] prepareReadHRVRmssdConfigPacket() {
        byte[] keyData = prepareKeyPacket(BleProtocol.CustomModeKey.HRV_RMSSD_REQ, null);
        return prepareDataPacket(BleProtocol.CommandID.CUSTOM_MADE, keyData);
    }

    public @NonNull static byte[] prepareSetRiskAssessment(byte type, boolean enable) {
        byte[] keyValue = new byte[2];
        keyValue[0] = type;
        keyValue[1] = (byte) (enable ? 0x01 : 0x00);

        byte[] keyData = prepareKeyPacket(BleProtocol.ControlKey.HIDE_HEALTH_FUNCTION_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.CONTROL, keyData);
    }

    public @NonNull static byte[] prepareReadHealthRiskAssessment() {
        byte[] keyData = prepareKeyPacket(BleProtocol.ControlKey.HIDE_HEALTH_FUNCTION_REQ, null);
        return prepareDataPacket(BleProtocol.CommandID.CONTROL, keyData);
    }

    public @NonNull static byte[] prepareSetDefaultFunctionPacket(JWDefaultFunctionInfo functionInfo) {
        byte key = 0b00000000;
        if (functionInfo.bloodPressureEnable) {
            key |= 0b00000001;
        }
        if (functionInfo.temperatureEnable) {
            key |= 0b00000010;
        }
        if (functionInfo.pressureEnable) {
            key |= 0b00000100;
        }
        if (functionInfo.sceneEnable) {
            key |= 0b00001000;
        }
        if (functionInfo.alexaEnable) {
            key |= 0b00010000;
        }
        if (functionInfo.lightSenseEnable) {
            key |= 0b00100000;
        }

        byte[] keyValue = {key};
        byte[] keyData = prepareKeyPacket(BleProtocol.FactoryKey.DEFAULT_FUNCTION_SET, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.FACTORY_TEST, keyData);
    }

    public @NonNull static byte[] prepareReadDefaultFunctionPacket() {
        byte[] keyData = prepareKeyPacket(BleProtocol.FactoryKey.DEFAULT_FUNCTION_REQ, null);
        return prepareDataPacket(BleProtocol.CommandID.FACTORY_TEST, keyData);
    }

    public @NonNull static byte[] prepareSetAddressBookStartOrEndPacket(byte status, int size) {
        byte[] keyValue = new byte[3];
        keyValue[0] = status;
        if (size > 0) {
            keyValue[1] = (byte) ((size >> 8) & 0xff);
            keyValue[2] = (byte) (size & 0xff);
        }

        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.ADDRESS_BOOK_REQ, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

    public @NonNull static byte[] prepareSetAddressPacket(String addressName, String addressPhone) {
        int nameLen = 0;
        int phoneLen = 0;
        byte[] nameData;
        if (!TextUtils.isEmpty(addressName.trim())) {
            nameData = addressName.getBytes(StandardCharsets.UTF_8);
            nameLen = nameData.length;
        }else{
            nameData = new byte[0];
        }
        byte[] phoneData;
        if (!TextUtils.isEmpty(addressPhone.trim())) {
            phoneData = addressPhone.getBytes(StandardCharsets.UTF_8);
            phoneLen = phoneData.length;
        }else{
            phoneData = new byte[0];
        }
        byte[] keyValue = new byte[2 + nameLen + 1 + phoneLen];
        keyValue[0] = 0x02;
        keyValue[1] = (byte) (nameLen & 0xff);
        if (nameLen > 0) {
            System.arraycopy(nameData, 0, keyValue, 2, nameLen);
        }
        keyValue[nameLen + 2] = (byte) (phoneLen & 0xff);
        if (phoneLen > 0) {
            System.arraycopy(phoneData, 0, keyValue, nameLen + 3, phoneLen);
        }

        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.ADDRESS_BOOK_REQ, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }


    public @NonNull static byte[] prepareSetSOSNumberStartOrEndPacket(byte status, int size) {
        byte[] keyValue = new byte[3];
        keyValue[0] = status;
        if (size > 0) {
            keyValue[1] = (byte) ((size >> 8) & 0xff);
            keyValue[2] = (byte) (size & 0xff);
        }

        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.SOS_NUMBER_REQ, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

    public @NonNull static byte[] prepareSetSOSNumberPacket(String addressName, String addressPhone) {
        int nameLen = 0;
        int phoneLen = 0;
        byte[] nameData;
        if (!TextUtils.isEmpty(addressName.trim())) {
            nameData = addressName.getBytes(StandardCharsets.UTF_8);
            nameLen = nameData.length;
        }else{
            nameData = new byte[0];
        }
        byte[] phoneData;
        if (!TextUtils.isEmpty(addressPhone.trim())) {
            phoneData = addressPhone.getBytes(StandardCharsets.UTF_8);
            phoneLen = phoneData.length;
        }else{
            phoneData = new byte[0];
        }
        byte[] keyValue = new byte[2 + nameLen + 1 + phoneLen];
        keyValue[0] = 0x02;
        keyValue[1] = (byte) (nameLen & 0xff);
        if (nameLen > 0) {
            System.arraycopy(nameData, 0, keyValue, 2, nameLen);
        }
        keyValue[nameLen + 2] = (byte) (phoneLen & 0xff);
        if (phoneLen > 0) {
            System.arraycopy(phoneData, 0, keyValue, nameLen + 3, phoneLen);
        }

        byte[] keyData = prepareKeyPacket(BleProtocol.SettingsKey.SOS_NUMBER_REQ, keyValue);
        return prepareDataPacket(BleProtocol.CommandID.SETTINGS, keyData);
    }

}
