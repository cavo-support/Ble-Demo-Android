package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import android.content.Context;

import com.wosmart.ukprotocollibary.util.SPWristbandConfigInfo;
import com.wosmart.ukprotocollibary.util.TranslateBpUtil;
import com.wosmart.ukprotocollibary.v2.common.JWBridge;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWDeviceFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 这里可能需要解析出心率，血压，温度 3 种数据
 *
 * 取接收数据包前12个字节的最后2字节做为判断条件
 * 等于0x0000: item长度12字节，8B解析
 * 等于0x0001: item长度8字节，8B解析
 * 其他: item长度12字节，12B解析
 */
public class HeartRateListDataHandler extends AbstractDataHandler {

    public static final int MODE_DEFAULT = 0;
    public static final int MODE_PARSE_BY_12 = 1;// 按 12 个字节解析一组数据

    private int mode;

    public HeartRateListDataHandler(int mode) {
        this.mode = mode;
    }

    @Override
    protected void action(byte[] data) {
        Context context = BaseManager.getInstance().getContext();
        if (data == null || context == null) {
            return;
        }
        JWDeviceFunctionInfo deviceFunctionInfo = BaseManager.getInstance().getDeviceFunctionInfo();

        List<JWBloodPressureInfo> bpList = new ArrayList<>();
        List<JWTemperatureInfo> tempList = new ArrayList<>();
        List<JWHeartRateInfo> hrList = new ArrayList<>();

        boolean bpMeasure = SPWristbandConfigInfo.getBpMeasure(context);
        boolean isPrivateBp = SPWristbandConfigInfo.getBpPrivateMode(context);
        int age = SPWristbandConfigInfo.getAge(context);
        int privateBpHigh = SPWristbandConfigInfo.getBpPrivateHigh(context);
        int privateBpLow = SPWristbandConfigInfo.getBpPrivateLow(context);

        boolean isBp2 = deviceFunctionInfo.bp2;
        boolean isSupportTemp = deviceFunctionInfo.temperature;
        boolean isSupportBp2 = bpMeasure && isBp2;

        int size = data.length;
        if (mode == MODE_PARSE_BY_12) {
            int itemLength = 12;
            int dataType = 12;
            int count = size / itemLength;
            for (int i = 0; i < count; i++) {
                byte[] subData = new byte[dataType];
                System.arraycopy(data, i * itemLength, subData, 0, dataType);

                parseSubData(subData, hrList, bpList, tempList, isSupportTemp, isSupportBp2, isPrivateBp, privateBpHigh, privateBpLow, age);
            }
        } else {
            if (size < 12) {
                // 只有一个数据包，按 8 字节解析
                byte[] subData = new byte[8];
                System.arraycopy(data, 0, subData, 0, 8);

                parseSubData(subData, hrList, bpList, tempList, isSupportTemp, isSupportBp2, isPrivateBp, privateBpHigh, privateBpLow, age);
            } else {
                int itemLength;
                int dataType;
                // 先取第 11，12 字节判断数据类型
                byte n11 = data[10];
                byte n12 = data[11];
                if (n11 == 0 && n12 == 0) {
                    itemLength = 12;
                    dataType = 8;
                } else if (n11 == 0 && n12 == 1) {
                    itemLength = 8;
                    dataType = 8;
                } else {
                    itemLength = 12;
                    dataType = 12;
                }

                int count = size / itemLength;
                for (int i = 0; i < count; i++) {
                    byte[] subData = new byte[dataType];
                    System.arraycopy(data, i * itemLength, subData, 0, dataType);

                    parseSubData(subData, hrList, bpList, tempList, isSupportTemp, isSupportBp2, isPrivateBp, privateBpHigh, privateBpLow, age);
                }
            }
        }

        if (TransportManager.getInstance().getSyncDataListener() == null) {
            return;
        }
        if (!hrList.isEmpty()) {
            TransportManager.getInstance().getSyncDataListener().onHeartRateDataReceived(hrList);
        }
        if (!tempList.isEmpty()) {
            TransportManager.getInstance().getSyncDataListener().onTemperatureDataReceived(tempList);
        }
        if (!bpList.isEmpty()) {
            TransportManager.getInstance().getSyncDataListener().onBloodPressureDataReceived(bpList);
        }
    }

    private void parseSubData(byte[] data, List<JWHeartRateInfo> hrList, List<JWBloodPressureInfo> bpList, List<JWTemperatureInfo> tempList,
                              boolean isSupportTemp, boolean isSupportBp2, boolean isPrivateBp, int privateBpHigh, int privateBpLow, int age) {
        int year = 0;
        int month = 0;
        int day = 0;
        int minutes = 0;
        int second = 0;
        int value = 0;
        if (data.length >= 12) {
            year = (data[0] & 0x7e) >> 1;
            month = ((data[0] & 0x01) << 3) | (data[1] >> 5) & 0x07;
            day = data[1] & 0x1f;
            int count = data[3] & 0xff;

            minutes = ((data[8] << 8) | (data[9] & 0xff)) & 0xffff;
            second = (data[10] & 0xff);
            value = (data[11] & 0xff);

            boolean animationStatus = ((data[5] >> 2) & 0x01) == 1;
            boolean adjustStatus = ((data[5] >> 1) & 0x01) == 1;
            boolean wearStatus = (data[5] & 0x01) == 1;

            int temp = ((data[6] << 8) | (data[7] & 0xff)) & 0xffff;
            float temperature = 0f;
            if (temp > 0) {
                if (animationStatus) {
                    temperature = JWUtils.parserRound(1, temp / 10f);
                } else {
                    if (temp >= 368) {
                        temperature = JWUtils.parserRound(1, temp / 10f);
                    } else {
                        //自动检测的 不只保留一位小数
                        if (wearStatus && adjustStatus) {
                            float temp2 = 368 - (368 - temp) / 20f;
                            temperature = JWUtils.parserRound(1, temp2 / 10f);
                        } else {
                            temperature = JWUtils.parserRound(1, temp / 10f);
                        }
                    }
                }
            }

            long time = JWBridge.getTime(year, month, day);
            time += minutes * 60000;
            time += second * 1000;

            setupTempInfo(tempList, isSupportTemp, adjustStatus, wearStatus, temp, temperature, time);
        } else if (data.length >= 8) {
            year = (data[0] & 0x7e) >> 1;
            month = ((data[0] & 0x01) << 3) | (data[1] >> 5) & 0x07;
            day = data[1] & 0x1f;
            int count = data[3] & 0xff;

            minutes = ((data[4] << 8) | (data[5] & 0xff)) & 0xffff;
            second = (data[6] & 0xff);
            value = (data[7] & 0xff);
        }

        long time = JWBridge.getTime(year, month, day);
        time += minutes * 60000;
        time += second * 1000;

        if (value == 0) {
            return;
        }
        setupHeartRateInfo(hrList, value, time);

        setupBpInfo(bpList, isSupportBp2, isPrivateBp, privateBpHigh, privateBpLow, age, minutes, value, time);
    }

    private void setupTempInfo(List<JWTemperatureInfo> tempList, boolean isSupportTemp, boolean adjustStatus, boolean wearStatus, int temp, float temperature, long time) {
        if (isSupportTemp && temp > 0) {
            JWTemperatureInfo temperatureInfo = new JWTemperatureInfo();
            temperatureInfo.time = time;
            temperatureInfo.userID = BaseManager.getInstance().getUserID();
            temperatureInfo.deviceMac = BaseManager.getInstance().getMacAddress();
            temperatureInfo.compensationStatus = adjustStatus;
            temperatureInfo.wearStatus = wearStatus;
            temperatureInfo.temperatureValue = temperature;
            temperatureInfo.temperatureOriginValue = JWUtils.parserRound(1, temp / 10f);

            tempList.add(temperatureInfo);
        }
    }

    private void setupHeartRateInfo(List<JWHeartRateInfo> hrList, int value, long time) {
        JWHeartRateInfo heartRateInfo = new JWHeartRateInfo();
        heartRateInfo.time = time;
        heartRateInfo.userID = BaseManager.getInstance().getUserID();
        heartRateInfo.deviceMac = BaseManager.getInstance().getMacAddress();
        heartRateInfo.value = value;

        hrList.add(heartRateInfo);
    }

    private void setupBpInfo(List<JWBloodPressureInfo> bpList, boolean isSupportBp2, boolean isPrivateBp, int privateBpHigh, int privateBpLow, int age, int minutes, int value, long time) {
        if (isSupportBp2) {
            int hour = minutes / 60;
            int min = minutes % 60;
            if (min > 0) {
                hour += 1;
            }
            //区分 私人血压 和 通用血压
            int[] bpValueArr;
            if (isPrivateBp) {
                bpValueArr = TranslateBpUtil.getPrivateBp(value, 70, privateBpHigh, privateBpLow);
            } else {
                bpValueArr = TranslateBpUtil.getBloodPressure(value, hour, age);
            }
            JWBloodPressureInfo bloodPressureInfo = new JWBloodPressureInfo();
            bloodPressureInfo.time = time;
            bloodPressureInfo.userID = BaseManager.getInstance().getUserID();
            bloodPressureInfo.deviceMac = BaseManager.getInstance().getMacAddress();
            bloodPressureInfo.highValue = bpValueArr[0];
            bloodPressureInfo.lowValue = bpValueArr[1];

            bpList.add(bloodPressureInfo);
        }
    }
}
