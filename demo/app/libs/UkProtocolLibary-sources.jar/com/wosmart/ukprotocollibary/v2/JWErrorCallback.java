package com.wosmart.ukprotocollibary.v2;

public interface JWErrorCallback {

    void onError(int code, String desc);

}
