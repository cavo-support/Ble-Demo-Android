package com.wosmart.ukprotocollibary.v2.moudle.connector;

import com.wosmart.ukprotocollibary.v2.entity.JWDeviceIndependentSwitchInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWDrinkWaterReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPrivateBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodFatFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodSugarCycleFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWPrivateBloodFatFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWPrivateUricAcidFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWUricAcidFunctionInfo;

import java.util.List;

public interface TempFunctionInfoListener {

    void onSupportSOS();

    void onSupportMedicationReminder();

    void onSupportPulse();

    void onSupportSleepHelp();

    void onSupportSauna();

    void onSupportFemaleHealth();

    void onSupportWeather();

    void onSupportWearingTime();

    void onSupportBodyFat();

    void onSupportPhysicalExam();

    void onSupportUltraviolet();

    void onSupportTemperatureReminder(JWTemperatureReminderInfo reminderInfo);

    void onSupportDrinkWaterReminder(JWDrinkWaterReminderInfo reminderInfo);

    void onSupportPrivateBloodPressureInfo(JWPrivateBloodPressureInfo privateBloodPressureInfo);

    void onDeviceIndependentSwitchInfoList(List<JWDeviceIndependentSwitchInfo> deviceIndependentSwitchInfoList);

    void onSupportUricAcid(JWUricAcidFunctionInfo functionInfo);

    void onSupportBloodFat(JWBloodFatFunctionInfo functionInfo);

    void onSupportBloodSugarCycle(JWBloodSugarCycleFunctionInfo functionInfo);

    void onSupportPrivateUricAcid(JWPrivateUricAcidFunctionInfo functionInfo);

    void onSupportPrivateBloodFat(JWPrivateBloodFatFunctionInfo functionInfo);

}
