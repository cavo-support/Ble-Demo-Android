package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWSportInfo;

public class SportInfo extends BaseHealthDataInfo {

    public int sportModel;

    public int sportMinute;

    public int sportSecond;

    public int pauseCount;

    public int pauseMinute;

    public int pauseSecond;

    public int steps;

    public int distance;

    public int calories;

    public int respirationRate;

    public int respirationRateMinute;

    public int rateHigh;

    public int rateAvg;

    public int rateLow;

    public SportInfo(long time, String userID, String mac, int sportModel, int sportMinute, int sportSecond,
                     int pauseCount, int pauseMinute, int pauseSecond, int steps, int distance, int calories,
                     int respirationRate, int respirationRateMinute, int rateHigh, int rateAvg, int rateLow) {
        this.time = time;
        this.userID = userID;
        this.deviceMac = mac;
        this.sportModel = sportModel;
        this.sportMinute = sportMinute;
        this.sportSecond = sportSecond;
        this.pauseCount = pauseCount;
        this.pauseMinute = pauseMinute;
        this.pauseSecond = pauseSecond;
        this.steps = steps;
        this.distance = distance;
        this.calories = calories;
        this.respirationRate = respirationRate;
        this.respirationRateMinute = respirationRateMinute;
        this.rateHigh = rateHigh;
        this.rateAvg = rateAvg;
        this.rateLow = rateLow;
    }

    public SportInfo(JWSportInfo info) {
        this.time = info.getTime();
        this.userID = info.getUserID();
        this.deviceMac = info.deviceMac;
        this.sportModel = info.getSportModel();
        this.sportMinute = info.sportMinute;
        this.sportSecond = info.sportSecond;
        this.pauseCount = info.pauseCount;
        this.pauseMinute = info.pauseMinute;
        this.pauseSecond = info.pauseSecond;
        this.steps = info.steps;
        this.distance = info.distance;
        this.calories = info.calories;
        this.respirationRate = info.respirationRate;
        this.respirationRateMinute = info.respirationRateMinute;
        this.rateHigh = info.rateHigh;
        this.rateAvg = info.rateAvg;
        this.rateLow = info.rateLow;
    }

    public JWSportInfo convertToJWTempInfo() {
        JWSportInfo info = new JWSportInfo();
        info.setUserID(userID);
        info.deviceMac = deviceMac;
        info.setTime(time);
        info.setSportModel(sportModel);
        info.sportMinute = (sportMinute);
        info.sportSecond = (sportSecond);
        info.pauseCount = (pauseCount);
        info.pauseMinute = (pauseMinute);
        info.pauseSecond = (pauseSecond);
        info.steps = (steps);
        info.distance = (distance);
        info.calories = (calories);
        info.respirationRate = (respirationRate);
        info.respirationRateMinute = (respirationRateMinute);
        info.rateHigh = (rateHigh);
        info.rateAvg = (rateAvg);
        info.rateLow = (rateLow);

        return info;
    }


}
