package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;

public class DeviceMeasureCanceledHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        int status = data[0] & 0xff;
        TransportManager.getInstance().getFunctionListener().onDeviceMeasureStatusUpdated(status);
    }

}
