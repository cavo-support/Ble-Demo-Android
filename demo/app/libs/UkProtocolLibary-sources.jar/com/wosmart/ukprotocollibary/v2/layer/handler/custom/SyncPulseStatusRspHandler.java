package com.wosmart.ukprotocollibary.v2.layer.handler.custom;

import com.wosmart.ukprotocollibary.v2.JWPulseListener;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;

public class SyncPulseStatusRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length < 3) {
            return;
        }
        JWPulseListener pulseListener = TransportManager.getInstance().getPulseListener();
        if (pulseListener == null) {
            return;
        }

        int status = data[0] & 0xff;
        int count = ((data[1] & 0xff) << 8) | (data[2] & 0xff);
        if (status == 1) {
            pulseListener.onSyncDataStart(count);
        } else {
            pulseListener.onSyncDataFinished();
        }
    }

}
