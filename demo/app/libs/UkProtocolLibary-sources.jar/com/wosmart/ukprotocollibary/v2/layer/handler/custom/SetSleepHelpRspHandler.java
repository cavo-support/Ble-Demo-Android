package com.wosmart.ukprotocollibary.v2.layer.handler.custom;

import android.util.SparseArray;

import com.wosmart.ukprotocollibary.v2.common.JWLog;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

public class SetSleepHelpRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length >= 5) {
            int status = data[0];
            int mode = (data[1] & 0xFF);
            int duration = (data[2] & 0xFF);
            int effectiveTime = (data[3] & 0xFF);
            int level = (data[4] & 0xFF);

            JWLog.i("i", "onSetSleepHelpRsp, isOpen = " + status + ", mode = " + mode + ", duration = " + duration + ", effectiveTime = " + effectiveTime + ", level = " + level);

            SparseArray<SendPacketCallback> callbackMap = TransportManager.getInstance().getCallbackMap();
            SendPacketCallback callback = callbackMap.get(CallbackKeyConstants.KEY_SET_SLEEP_HELP);
            if (callback != null) {
                callback.onResponse(status);
                callbackMap.remove(CallbackKeyConstants.KEY_SET_SLEEP_HELP);
            }
        }
    }

}
