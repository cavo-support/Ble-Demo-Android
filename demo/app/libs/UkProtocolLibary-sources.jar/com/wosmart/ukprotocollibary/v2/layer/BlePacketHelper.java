package com.wosmart.ukprotocollibary.v2.layer;

public class BlePacketHelper {

    // Version
    public final static int VERSION_CODE = 0;

    // Header Length
    public final static int KEY_HEADER_LENGTH = 3;

    // Header Length
    public final static int DATA_HEADER_LENGTH = 2;


    public static int getVersion() {
        return VERSION_CODE;
    }


    /**
     * prepare the Transport Layer Packet to send
     *
     * @param data the send key value
     * @param key the key number
     *
     * @return the integrated Application Layer Key Packet
     * */
    public static byte[] prepareKeyPacket(byte key, byte[] data) {
        byte[] keyData;
        if(data != null) {
            keyData = new byte[data.length + KEY_HEADER_LENGTH];
            System.arraycopy(data, 0, keyData, KEY_HEADER_LENGTH, data.length);
            // prepare header
            keyData[0] = key;
            keyData[1] = (byte) ((data.length >> 8) & 0x01);
            keyData[2] = (byte) (data.length & 0xff);
        } else {
            keyData = new byte[KEY_HEADER_LENGTH];
            // prepare header
            keyData[0] = key;
            keyData[1] = 0;
            keyData[2] = 0;
        }

        return keyData;
    }

    /**
     * prepare the Application Layer Packet to send
     *
     * @param cmd the command id
     * @param keyData the send key data
     *
     * @return the integrated Application Layer Packet
     * */
    public static byte[] prepareDataPacket(byte cmd, byte[] keyData) {
        byte[] data = new byte[DATA_HEADER_LENGTH + keyData.length];
        data[0] = cmd;
        data[1] = (byte) ((getVersion() << 4) & 0xff);
        System.arraycopy(keyData, 0, data, DATA_HEADER_LENGTH, keyData.length);
        return data;
    }

}
