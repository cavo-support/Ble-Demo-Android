package com.wosmart.ukprotocollibary.v2.layer;

import android.bluetooth.BluetoothDevice;
import android.os.Handler;
import android.util.SparseArray;

import com.wosmart.ukprotocollibary.util.DataConverter;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerKeyPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerPacket;
import com.wosmart.ukprotocollibary.gattlayer.GattLayerCallback;
import com.wosmart.ukprotocollibary.transportlayer.TransportLayerPacket;
import com.wosmart.ukprotocollibary.v2.BaseConstants;
import com.wosmart.ukprotocollibary.v2.JWFunctionListener;
import com.wosmart.ukprotocollibary.v2.JWHRVRmssdListener;
import com.wosmart.ukprotocollibary.v2.JWPressureListener;
import com.wosmart.ukprotocollibary.v2.JWPulseListener;
import com.wosmart.ukprotocollibary.v2.JWSaunaListener;
import com.wosmart.ukprotocollibary.v2.JWSyncDataListener;
import com.wosmart.ukprotocollibary.v2.JWUltravioletListener;
import com.wosmart.ukprotocollibary.v2.common.JWLog;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.bind.BindHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.bind.ChipTypeRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.bind.ConfirmBindHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.bind.LoginHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.control.DeviceIndependentSwitchHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.control.FindPhoneRsp2Handler;
import com.wosmart.ukprotocollibary.v2.layer.handler.control.FindPhoneRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.control.ReadHealthRiskAssessmentRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.control.SetFemaleHealthRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.control.SetWeatherRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.control.TakePhotoRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.custom.PulseFinishedRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.custom.ReadHRVRmssdConfigRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.custom.SetPulseRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.custom.SetSleepHelpRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.custom.SupportPulseHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.custom.SupportSaunaHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.custom.SupportSleepHelpHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.custom.SyncHRMovementDataRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.custom.SyncHRVRmssdDataRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.custom.SyncPulseDataRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.custom.SyncPulseStatusRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.custom.SyncSaunaDataRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.custom.SyncSaunaStatusRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.factory.ReadDefaultFunctionRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportBloodFatHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportBloodSugarCycleHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportBodyFatHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportDrinkWaterReminderHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportFemaleHealthHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportMedicationReminderHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportPhysicalExamHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportPrivateBPHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportPrivateBloodFatHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportPrivateUricAcidHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportSOSNumberHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportTemperatureReminderHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportUltravioletHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportUricAcidHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportWearingTimeHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.multiple.SupportWeatherHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.settings.AllNotifyConfigHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.settings.DateFormatRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.settings.DeviceFunctionHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.settings.DeviceInfoHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.settings.GetMedicationReminderRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.settings.SetAddressBookRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.settings.SetSOSNumberRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.BloodFatContinuousMonitoringDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.BloodFatDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.BloodPressureDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.BloodSugarContinuousMonitoringRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.BloodSugarCycleDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.BloodSugarDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.BodyFatDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.DeviceMeasureCanceledHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.HeartRateDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.HeartRateListDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.HeartRateVariabilityDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.PhysicalExamDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.SleepDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.SpO2DataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.SportDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.StepDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.SyncHealthDataBeginHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.SyncHealthDataEndHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.SyncPressureDataRspHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.UltravioletDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.UricAcidContinuousMonitoringDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.UricAcidDataHandler;
import com.wosmart.ukprotocollibary.v2.layer.handler.sport.WearingTimeDataHandler;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TransportManager {

    // Log
    private final static String TAG = "TransportManager";

    // state control
    private final ArrayList<SendPacket> mTxPacketList = new ArrayList<>();

    private volatile Integer mTxState = TX_STATE_IDLE;
    private final static int TX_STATE_IDLE = 0;
    private final static int TX_STATE_IN_TX = 1;
    private final static int TX_STATE_IN_SEND_ACK = 2;

    private TransportLayerPacket mCurrentRxPacket;

    private final ArrayList<TransportLayerPacket> mRxPacketList = new ArrayList<>();
    private volatile Integer mRxState = RX_STATE_HEADER;
    private final static int RX_STATE_HEADER = 0;
    private final static int RX_STATE_DATA = 1;

    // use to manager current transport layer sequence
    private volatile int mCurrentTxSequenceId;
    private volatile int mLastRxSequenceId;

    // use to manager packet send
    private volatile boolean isAckCome;
    private volatile boolean isSentAckRight;
    private final Object mAckLock = new Object();

    // retry control.
    private int mRetryCounter;
    private final static int MAX_RETRY_COUNT = 3;

    // Thread for unpack send
    private ThreadTx mThreadTx;
    private ThreadRx mThreadRx;
    private static int MTU_PAYLOAD_SIZE_LIMIT = 20;

    // Use to manager data send
    private boolean isDataSend;
    private final Object mSendDataLock = new Object();

    private final SparseArray<SendPacketCallback> callbackMap = new SparseArray<>();

    private JWSyncDataListener mSyncDataListener;
    private JWSaunaListener mSaunaListener;
    private JWPulseListener mPulseListener;
    private JWHRVRmssdListener mHRVRmssdListener;
    private JWUltravioletListener mUltravioletListener;
    private JWPressureListener mPressureListener;
    private JWFunctionListener mFunctionListener;

    private BleGattCallback connListener;

    private final BleGattCallback bleGattCallback = new BleGattCallback() {
        @Override
        public void onStartConnect() {
            if (connListener != null) {
                connListener.onStartConnect();
            }
        }

        @Override
        public void onConnectFail(int code, String desc) {
            releaseResources();
            if (connListener != null) {
                connListener.onConnectFail(code, desc);
            }
        }

        @Override
        public void onConnectSuccess() {
            if (connListener != null) {
                connListener.onConnectSuccess();
            }
        }

        @Override
        public void onDisConnected() {
            releaseResources();
            if (connListener != null) {
                connListener.onDisConnected();
            }
        }

        @Override
        public void onDataSend(boolean result) {
            synchronized(mSendDataLock) {
                isDataSend = true;
                mSendDataLock.notifyAll();
            }
        }

        @Override
        public void onDataReceived(byte[] data) {
            receiveData(data);
        }

        @Override
        public void onMtuChanged(int mtu) {
            MTU_PAYLOAD_SIZE_LIMIT = mtu - 3;
        }
    };


    public void connectDevice(BluetoothDevice device, BleGattCallback connListener) {
        this.connListener = connListener;

        mCurrentTxSequenceId = 1;
        mRetryCounter = 0;
        mLastRxSequenceId = -1;

        mCurrentRxPacket = new TransportLayerPacket();
        mTxPacketList.clear();
        mRxPacketList.clear();

        // 初始化读写线程状态
        initialTxState();
        initialRxState();

        // 创建读写线程
        startTxSchedule();
        startRxSchedule();

        BleManager.getInstance().connectDevice(device, bleGattCallback);
    }

    public void disconnect() {
        releaseResources();

        BleManager.getInstance().disconnect();
    }

    public SparseArray<SendPacketCallback> getCallbackMap() {
        return callbackMap;
    }

    private void releaseResources() {
        stopRxSchedule();
        stopTxSchedule();
        stopRxTimer();

        mTxPacketList.clear();
        mRxPacketList.clear();

        callbackMap.clear();
    }

    private void initialTxState() {
        synchronized (mTxState) {
            mTxState = TX_STATE_IDLE;
        }
    }

    private boolean checkTxStateInTx() {
        boolean status = false;
        synchronized (mTxState) {
            status = (mTxState != TX_STATE_IDLE);
        }
        return status;
    }

    private void changeToTxDataState() {
        synchronized (mTxState) {
            mTxState = TX_STATE_IN_TX;
        }
    }

    private void changeToTxAckState() {
        synchronized (mTxState) {
            mTxState = TX_STATE_IN_SEND_ACK;
        }
    }


    private void initialRxState() {
        synchronized (mRxState) {
            mRxState = RX_STATE_HEADER;
        }
    }

    private boolean checkRxStateInReceiveHeaderMode() {
        boolean status = false;
        synchronized (mRxState) {
            status = mRxState == RX_STATE_HEADER;
        }
        return status;
    }

    private void changeToRxDataState() {
        synchronized (mRxState) {
            mRxState = RX_STATE_DATA;
        }
    }

    private void addToTxPacketList(SendPacket packet) {
        synchronized (mTxPacketList) {
            mTxPacketList.add(packet);
            mTxPacketList.notifyAll();
        }
    }

    private SendPacket getFromTxPacketList() {
        SendPacket packet = null;
        synchronized (mTxPacketList) {
            if(mTxPacketList.size() > 0) {
                packet = mTxPacketList.remove(0);
            }else{
                try {
                    mTxPacketList.wait(1000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
            }
        }
        return packet;
    }

    private int getTxPacketListSize() {
        synchronized (mTxPacketList) {
            return mTxPacketList.size();
        }
    }

    private void addToRxPacketList(TransportLayerPacket packet) {
        synchronized (mRxPacketList) {
            mRxPacketList.add(packet);
            mRxPacketList.notifyAll();
        }
    }

    private TransportLayerPacket getFromRxPacketList() {
        TransportLayerPacket packet = null;
        synchronized (mRxPacketList) {
            if(mRxPacketList.size() > 0) {
                packet = mRxPacketList.remove(0);
            } else {
                try {
                    mRxPacketList.wait(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        return packet;
    }

    /**
     * When the Low Layer receive a packet, it will call this method
     *
     * @param data the receive data
     * */
    public void receiveData(byte[] data) {
        decodeReceiveData(data);
    }

    /**
     * Send Data packet to the remote. Up stack can use this method to send data.
     * If last packet didn't send ok, didn't allow send next packet.
     *
     * @param data the send data
     *
     * */
    public synchronized boolean sendData(byte[] data, int callbackKey, SendPacketCallback callback){

        // generate a data packet
        byte[] dataPacket = TransportLayerPacket.prepareDataPacket(data, mCurrentTxSequenceId);

        SendPacket sendPacket = new SendPacket();
        sendPacket.data = dataPacket;
        sendPacket.callback = callback;

        if (callbackKey != CallbackKeyConstants.KEY_NONE) {
            callbackMap.put(callbackKey, callback);
        }

        // Pending to tx list.
        addToTxPacketList(sendPacket);

        mCurrentTxSequenceId += 1;

        return true;
    }

    /**
     * In callback, maybe it will do lot of thing, we make let it work in a thread.
     * */
    private void tellUpStackPacketSend(final SendPacket sendPacket, final boolean sendOK) {
        if(TransportLayerPacket.checkIsAckPacket(sendPacket.data) || sendPacket.isAck) {
            JWLog.d(TAG, "is ack packet, don't need tell up stack.");
            return;
        }

        if (sendPacket.callback != null) {
            if (sendOK) {
                sendPacket.callback.onSendSuccess();
            } else {
                sendPacket.callback.onSendFailed(BaseConstants.ERR_SEND_DATA_FAILED, "send data failed");
            }
        }
    }

    /**
     * Save the receive data to receive buffer. when state is normal or rx.
     *
     * @param data receive data
     *
     * */
    private void decodeReceiveData(byte[] data) {
        int result;
        // start rx timer
        startRxTimer();

        // Check parse header or data
        if(checkRxStateInReceiveHeaderMode()) {
            // change the state
            changeToRxDataState();
            JWLog.d(TAG, "parse header.");
            // parse the header
            result = mCurrentRxPacket.parseHeader(data);
        } else {
            JWLog.d(TAG, "parse data.");
            // parse the header
            result = mCurrentRxPacket.parseData(data);
        }


        JWLog.d(TAG,"result = "+ result);
        // stop rx timer
        if(result != TransportLayerPacket.LT_SUCCESS) {
            stopRxTimer();
        }
        switch(result) {
            // Receive ACK
            case TransportLayerPacket.LT_ERROR_ACK:
                isSentAckRight = false;
            case TransportLayerPacket.LT_SUCCESS_ACK:
                isSentAckRight = true;
                // update state
                initialRxState();
                // Update tx status
                synchronized (mAckLock) {
                    isAckCome = true;
                    JWLog.i(TAG, "<<<--- Receive ack, ack flag: " + isSentAckRight);
                    mAckLock.notifyAll();
                }
                break;
            case TransportLayerPacket.LT_FULL_PACKET:
                // initial Rx state
                initialRxState();
                JWLog.i(TAG, "<<<--- Receive a full packet, full packet : "+ DataConverter.bytes2Hex(data));

                JWLog.i(TAG, "<<<--- Receive a full packet, packet real payload: "+ Arrays.toString(mCurrentRxPacket.getRealPayload())+"\n" + DataConverter.bytes2Hex(mCurrentRxPacket.getRealPayload())+
                        "\nmCurrentRxPacket.getSequenceId()="+mCurrentRxPacket.getSequenceId()+"\nmLastRxSequenceId="+ mLastRxSequenceId);

                // check whether a retransmit packet
                if(mCurrentRxPacket.getSequenceId() == mLastRxSequenceId) {
                    JWLog.w(TAG, "<<<--- Maybe a retrans packet, send success ack");
                    // send success ack to remote
                    if (!mCurrentRxPacket.isNoAck()) {
                        sendAckPacket(mCurrentRxPacket.getSequenceId(), false);
                    }
                    return;
                }
                // update the last sequence id
                mLastRxSequenceId = mCurrentRxPacket.getSequenceId();

                TransportLayerPacket packet = mCurrentRxPacket;

                // Need create a new packet
                mCurrentRxPacket = new TransportLayerPacket();

                // send success ack to remote
                if (!packet.isNoAck()) {
                    sendAckPacket(packet.getSequenceId(), false);
                }

                // Add the packet to rx list
                addToRxPacketList(packet);

                break;
            case TransportLayerPacket.LT_SUCCESS:
                // Only check in the end of a packet
				/*
				// check whether a retransmit packet
				if(mPacket.getSequenceId() == mLastRxSuquenceId) {
					JWLog.d(TAG, "Receive a retransmit packet, mPacket.getSequenceId(): " + mPacket.getSequenceId() +
												", mLastRxSuquenceId: " + mLastRxSuquenceId);
					// update state
					mState = STATE_NORMAL;//State change must before ack send.
					// send success ack to remote
					sendAckPacketUseThread(false);
					return;
				}*/
                break;

            case TransportLayerPacket.LT_LENGTH_ERROR:
            case TransportLayerPacket.LT_CRC_ERROR:
                JWLog.e(TAG, "<<<--- Some error when receive data, with result: " + result);
                // update state
                initialRxState();

                sendAckPacket(mCurrentRxPacket.getSequenceId(), true);
                break;
            case TransportLayerPacket.LT_MAGIC_ERROR:
                // if a magic error occur, just return
                JWLog.e(TAG, "<<<--- Some error when receive data, with result: " + result);
                // update state
                initialRxState();
                break;
            default:
                JWLog.e(TAG, "<<<--- Some error, with result: " + result);
                break;
        }
    }

    /**
     * Send ACK packet to the remote.
     *
     * @param err error ack or a success ack
     *
     * */
    private void sendAckPacket(int id, boolean err){
        // generate a ack packet
        final byte[] sendByte = TransportLayerPacket.prepareAckPacket(err, id);

        if(sendByte == null) {
            JWLog.e(TAG, "--->>> Something error in send ack packet, with null packet.");
            return;
        }

        //send it
        JWLog.i(TAG, "pending to tx list, err: " + err + ", sendByte: " + DataConverter.bytes2Hex(sendByte));

        SendPacket sendPacket = new SendPacket();
        sendPacket.isAck = true;
        sendPacket.data = sendByte;
        addToTxPacketList(sendPacket);

        // protect tx ack packet
        changeToTxAckState();
        // send the data, here we do nothing while the data send error, we just think this operation will be done
        //sendGattLayerData(sendByte);
    }

    /**
     * Send transport packet to gatt layer.
     * <p>This is an synchronous operation. It will wait the {@link GattLayerCallback#onDataSend} callback is invoked.
     *
     * @param data the send data
     *
     * */
    private boolean sendGattLayerData(byte[] data) {
        isDataSend = false;
        JWLog.d(TAG,"sendData-->"+ com.wosmart.ukprotocollibary.util.DataConverter.bytes2Hex(data));
        if(!BleManager.getInstance().writeData(data)) {
            JWLog.w(TAG, "sendGattLayerData error.");
            return false;
        }

        synchronized(mSendDataLock) {
            if(!isDataSend) {
                try {
                    mSendDataLock.wait(3000);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
        return isDataSend;
    }

    private void handleReceiveData(byte[] data) {
        ApplicationLayerPacket appPacket = new ApplicationLayerPacket();
        appPacket.parseData(data);

        // dispatch the key value
        List<ApplicationLayerKeyPacket> keyPackets = appPacket.getKeyPacketArrays();
        for (ApplicationLayerKeyPacket keyPacket : keyPackets) {
            byte commandID = appPacket.getCommandId();
            byte keyID = keyPacket.getKey();
            byte[] keyData = keyPacket.getKeyData();

            int handleKey = commandID * 10000 + keyID;

            AbstractDataHandler handler = HANDLERS.get(handleKey);
            if (handler != null) {
                handler.execute(keyData);
            } else {
                JWLog.e(TAG, "未找到处理handler，CommandID = " + DataConverter.bytes2Hex(new byte[]{commandID}) + ", keyID = " + DataConverter.bytes2Hex(new byte[]{keyID}));
            }
        }
    }

    public void startRxSchedule() {
        JWLog.d(TAG, "startRxSchedule.");
        if(mThreadRx != null) {
            mThreadRx.StopRx();
        }

        mThreadRx = new TransportManager.ThreadRx();
        mThreadRx.start();
    }

    public void stopRxSchedule() {
        if(mThreadRx != null) {
            JWLog.d(TAG, "stopRxSchedule.");
            mThreadRx.StopRx();
        }
    }

    public class ThreadRx extends Thread {

        private Boolean _stop = false;

        public void run() {
            JWLog.d(TAG, "ThreadRx is run");

            TransportLayerPacket receiveData;

            while (true) {
                // Use to protect tx packet
                if(!checkTxStateInTx()) {
                    if ((receiveData = getFromRxPacketList()) != null) {
                        // tell up stack, send the packet to upstack
                        int len = receiveData.getPayloadLength();
                        byte[] rcv = new byte[len];
                        if(len != 0) {
                            System.arraycopy(receiveData.getRealPayload(), 0, rcv, 0, len);
                        }
                        // tell up stack
                        //JWLog.d(TAG, "tell up stack, receive full packet");
                        JWLog.d(TAG,"ThreadRx--rcv[]="+ Arrays.toString(rcv));
                        handleReceiveData(rcv);
                    }
                }

                synchronized (_stop) {
                    if (_stop) {
                        break;
                    }
                }
            }
            JWLog.d(TAG, "ThreadRx stop");
        }//run

        public void StopRx() {
            synchronized (_stop) {
                _stop = true;
            }
        }
    }


    public void startTxSchedule() {
        JWLog.d(TAG, "startTxSchedule.");
        if(mThreadTx != null) {
            mThreadTx.StopTx();
        }

        mThreadTx = new TransportManager.ThreadTx();
        mThreadTx.start();
    }

    public void stopTxSchedule() {
        JWLog.d(TAG, "stopTxSchedule.");
        if(mThreadTx != null) {
            mThreadTx.StopTx();
            synchronized(mAckLock) {
                isAckCome = false;
                isSentAckRight = false;
                mAckLock.notifyAll();
            }
        }
    }

    // unpack and send thread
    public class ThreadTx extends Thread {

        private Boolean _stop = false;

        public void run() {
            JWLog.d(TAG, "ThreadTx is run");

            SendPacket sendPacket = null;

            while (true) {

                if((sendPacket = getFromTxPacketList()) != null && sendPacket.data != null) {
                    // Use to protect tx packet
                    changeToTxDataState();

                    mRetryCounter = 0;
                    boolean packetSendStatus = false;
                    packetSendStatus = UnpackSendPacket(sendPacket.data);
                    // If the packet list have packet, just send it
                    if(!packetSendStatus) {
                        // check reach the max retry time
                        while(mRetryCounter < MAX_RETRY_COUNT) {
                            synchronized (_stop) {
                                if(_stop) {
                                    return;
                                }
                            }
                            mRetryCounter++;

                            JWLog.w(TAG, "---> retry send it, mRetryCounter: " + mRetryCounter
                                    + ", sendData: " + DataConverter.bytes2Hex(sendPacket.data)
                                    + ", isAckCome: " + isAckCome
                                    + ", isSentAckRight: " + isSentAckRight);
                            // resend data
                            packetSendStatus = UnpackSendPacket(sendPacket.data);

                            if(packetSendStatus) {
                                break;
                            }
                        }
                    }

                    // tell up stack.
                    tellUpStackPacketSend(sendPacket, packetSendStatus);

                    // Use to protect tx packet
                    // Maybe need send ack.
                    if(getTxPacketListSize() == 0) {
                        initialTxState();
                    }
                }
                synchronized (_stop) {
                    if(_stop) {
                        break;
                    }
                }
            }

            JWLog.d(TAG, "ThreadTx stop");
        }//run

        public void StopTx() {
            synchronized (_stop) {
                _stop = true;
            }
        }
    }

    private boolean UnpackSendPacket(byte[] data) {
        // send data to the remote device
        JWLog.i(TAG, "---> data: " + DataConverter.bytes2Hex(data));

        // initial is ack come flag.
        isSentAckRight = false;
        isAckCome = false;
        // unpack the send data, because of the MTU size is limit
        int length = data.length;
        int unpackCount = 0;
        byte[] realSendData;
        do {

            if(length <= MTU_PAYLOAD_SIZE_LIMIT) {
                realSendData = new byte[length];
                System.arraycopy(data, unpackCount * MTU_PAYLOAD_SIZE_LIMIT, realSendData, 0, length);

                // update length value
                length = 0;
            } else {
                realSendData = new byte[MTU_PAYLOAD_SIZE_LIMIT];
                System.arraycopy(data, unpackCount * MTU_PAYLOAD_SIZE_LIMIT, realSendData, 0, MTU_PAYLOAD_SIZE_LIMIT);

                // update length value
                length = length - MTU_PAYLOAD_SIZE_LIMIT;
            }
            // send the data, here we do nothing while the data send error, we just think this operation will be done
            if(!sendGattLayerData(realSendData)) {
                JWLog.e(TAG, "---> Send data error, may link is loss or gatt initial failed.");
                return false;
            }

            // unpack counter increase
            unpackCount++;

        } while(length != 0);
        // Check is a ACK packet or not
        if(TransportLayerPacket.checkIsAckPacket(data)) {
            return true;
        }
        // make sure ack be changed in receive ack
        synchronized(mAckLock) {
            if (!isAckCome) {
                // start wait ack timer
                try {
                    mAckLock.wait(MAX_ACK_WAIT_TIME);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                return isSentAckRight;
            }
        }

        return true;
    }


    // Ack super timer
    private final int MAX_ACK_WAIT_TIME = 5000;


    // Rx super timer
    private final int MAX_RX_WAIT_TIME = 30000;
    final Handler mRxHandler = new Handler();
    Runnable mRxSuperTask = new Runnable(){
        @Override
        public void run() {
            // TODO Auto-generated method stub
            JWLog.w(TAG, "Rx Packet Timeout");
            // update state
            initialRxState();

            // send error ack to remote
            sendAckPacket(mCurrentRxPacket.getSequenceId(), true);
            // stop timer
            stopRxTimer();
        }
    };
    private void startRxTimer(){
        JWLog.d(TAG, "startRxTimer()");
        synchronized (mRxHandler) {
            mRxHandler.postDelayed(mRxSuperTask, MAX_RX_WAIT_TIME);
            //JWLog.d(TAG, "mRxHandler.postDelayed");
        }
    }
    private void stopRxTimer() {
        synchronized (mRxHandler) {
            mRxHandler.removeCallbacks(mRxSuperTask);
        }
    }


    public void setSyncDataListener(JWSyncDataListener syncDataListener) {
        this.mSyncDataListener = syncDataListener;
    }

    public JWSyncDataListener getSyncDataListener() {
        return this.mSyncDataListener;
    }

    public void setPulseListener(JWPulseListener pulseListener) {
        this.mPulseListener = pulseListener;
    }

    public JWPulseListener getPulseListener() {
        return this.mPulseListener;
    }

    public JWHRVRmssdListener getHRVRmssdListener() {
        return mHRVRmssdListener;
    }

    public void setHRVRmssdListener(JWHRVRmssdListener listener) {
        this.mHRVRmssdListener = listener;
    }

    public void setSaunaListener(JWSaunaListener saunaListener) {
        this.mSaunaListener = saunaListener;
    }

    public JWSaunaListener getSaunaListener() {
        return this.mSaunaListener;
    }

    public JWUltravioletListener getUltravioletListener() {
        return mUltravioletListener;
    }

    public void setUltravioletListener(JWUltravioletListener listener) {
        this.mUltravioletListener = listener;
    }

    public JWPressureListener getPressureListener() {
        return mPressureListener;
    }

    public void setPressureListener(JWPressureListener pressureListener) {
        this.mPressureListener = pressureListener;
    }

    public void setFunctionListener(JWFunctionListener listener) {
        this.mFunctionListener = listener;
    }

    public JWFunctionListener getFunctionListener() {
        return this.mFunctionListener;
    }


    private static final SparseArray<AbstractDataHandler> HANDLERS = new SparseArray<>();

    static {
        // 登录/绑定模块
        HANDLERS.put(BleProtocol.CommandID.BIND * 10000 + BleProtocol.BindKey.LOGIN_RSP, new LoginHandler());
        HANDLERS.put(BleProtocol.CommandID.BIND * 10000 + BleProtocol.BindKey.BIND_RSP, new BindHandler());
        HANDLERS.put(BleProtocol.CommandID.BIND * 10000 + BleProtocol.BindKey.CONFIRM_BIND_RSP, new ConfirmBindHandler());
        HANDLERS.put(BleProtocol.CommandID.BIND * 10000 + BleProtocol.BindKey.SUP_BIND_KEY, new ChipTypeRspHandler());

        // 设置模块
        HANDLERS.put(BleProtocol.CommandID.SETTINGS * 10000 + BleProtocol.SettingsKey.FUNCTION_RSP, new DeviceFunctionHandler());
        HANDLERS.put(BleProtocol.CommandID.SETTINGS * 10000 + BleProtocol.SettingsKey.DEVICE_INFO_RSP, new DeviceInfoHandler());
        HANDLERS.put(BleProtocol.CommandID.SETTINGS * 10000 + BleProtocol.SettingsKey.NOTIFY_SWITCH_RSP, new AllNotifyConfigHandler());
        HANDLERS.put(BleProtocol.CommandID.SETTINGS * 10000 + BleProtocol.SettingsKey.MEDICATION_REMINDER_RSP, new GetMedicationReminderRspHandler());
        HANDLERS.put(BleProtocol.CommandID.SETTINGS * 10000 + BleProtocol.SettingsKey.ADDRESS_BOOK_RSP, new SetAddressBookRspHandler());
        HANDLERS.put(BleProtocol.CommandID.SETTINGS * 10000 + BleProtocol.SettingsKey.SOS_NUMBER_RSP, new SetSOSNumberRspHandler());
        HANDLERS.put(BleProtocol.CommandID.SETTINGS * 10000 + BleProtocol.SettingsKey.DEVICE_DATE_FORMAT_RSP, new DateFormatRspHandler());

        // 运动模块
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.SPORTS_HIS_SYNC_BEG, new SyncHealthDataBeginHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.SPORTS_HIS_SYNC_END, new SyncHealthDataEndHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.SPORTS_STEP_RSP, new StepDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.SPORTS_SLEEP_RSP, new SleepDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.SPORTS_BP_DATA_RSP, new BloodPressureDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.GLU_HISTORY_RSP, new BloodSugarDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.SPORTS_DATA_RSP, new SportDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.SPO2_DATA_RSP, new SpO2DataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.SPORTS_HRP_DATA_RSP, new HeartRateDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.HR_DATA_RSP, new HeartRateDataHandler());// 与上面同一个解析器
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.SPORTS_HRP_DATA_LIST_RSP, new HeartRateListDataHandler(HeartRateListDataHandler.MODE_DEFAULT));
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.HR_DATA_LIST_RSP, new HeartRateListDataHandler(HeartRateListDataHandler.MODE_PARSE_BY_12));// 与上面同一个解析器
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.RTK_HRV_RSP, new HeartRateVariabilityDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.WEARING_TIME_RSP, new WearingTimeDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.URIC_ACID_RSP, new UricAcidDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.BLOOD_FAT_RSP, new BloodFatDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.BLOOD_SUGAR_CYCLE_RSP, new BloodSugarCycleDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.GLU_CONTINUOUS_RSP, new BloodSugarContinuousMonitoringRspHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.URIC_ACID_CONTINUOUS_MONITORING_RSP, new UricAcidContinuousMonitoringDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.BLOOD_FAT_CONTINUOUS_MONITORING_RSP, new BloodFatContinuousMonitoringDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.DEVICE_MEASURE_CANCELED, new DeviceMeasureCanceledHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.BODY_FAT_HISTORY_RSP, new BodyFatDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.PHYSICAL_EXAM_HISTORY_RSP, new PhysicalExamDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.ULTRAVIOLET_RSP, new UltravioletDataHandler());
        HANDLERS.put(BleProtocol.CommandID.SPORTS_DATA * 10000 + BleProtocol.SportKey.PRESSURE_RSP, new SyncPressureDataRspHandler());


        // 多命令
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.PRIVATE_BP, new SupportPrivateBPHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.SOS_NUMBER, new SupportSOSNumberHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.MEDICATION_REMINDER, new SupportMedicationReminderHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.TEMPERATURE_REMINDER, new SupportTemperatureReminderHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.DRINK_WATER_REMINDER, new SupportDrinkWaterReminderHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.FEMALE_HEALTH, new SupportFemaleHealthHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.WEATHER, new SupportWeatherHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.WEARING_TIME, new SupportWearingTimeHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.URIC_ACID, new SupportUricAcidHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.BLOOD_FAT, new SupportBloodFatHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.BLOOD_SUGAR_CYCLE, new SupportBloodSugarCycleHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.PRIVATE_URIC_ACID, new SupportPrivateUricAcidHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.PRIVATE_BLOOD_FAT, new SupportPrivateBloodFatHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.BODY_FAT, new SupportBodyFatHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.PHYSICAL_EXAM, new SupportPhysicalExamHandler());
        HANDLERS.put(BleProtocol.CommandID.MULTIPLE_CMD * 10000 + BleProtocol.MultipleCmdKey.ULTRAVIOLET, new SupportUltravioletHandler());

        // 自定义
        HANDLERS.put(BleProtocol.CommandID.CUSTOM_MADE * 10000 + BleProtocol.CustomModeKey.SUPPORT_PULSE, new SupportPulseHandler());
        HANDLERS.put(BleProtocol.CommandID.CUSTOM_MADE * 10000 + BleProtocol.CustomModeKey.PULSE_RSP, new SetPulseRspHandler());
        HANDLERS.put(BleProtocol.CommandID.CUSTOM_MADE * 10000 + BleProtocol.CustomModeKey.SUPPORT_SLEEP_HELP, new SupportSleepHelpHandler());
        HANDLERS.put(BleProtocol.CommandID.CUSTOM_MADE * 10000 + BleProtocol.CustomModeKey.SLEEP_HELP_RSP, new SetSleepHelpRspHandler());
        HANDLERS.put(BleProtocol.CommandID.CUSTOM_MADE * 10000 + BleProtocol.CustomModeKey.SYNC_PULSE_DATA_RSP, new SyncPulseDataRspHandler());
        HANDLERS.put(BleProtocol.CommandID.CUSTOM_MADE * 10000 + BleProtocol.CustomModeKey.SYNC_PULSE_STATUS_RSP, new SyncPulseStatusRspHandler());
        HANDLERS.put(BleProtocol.CommandID.CUSTOM_MADE * 10000 + BleProtocol.CustomModeKey.PULSE_FINISHED_RSP, new PulseFinishedRspHandler());
        HANDLERS.put(BleProtocol.CommandID.CUSTOM_MADE * 10000 + BleProtocol.CustomModeKey.SUPPORT_SAUNA, new SupportSaunaHandler());
        HANDLERS.put(BleProtocol.CommandID.CUSTOM_MADE * 10000 + BleProtocol.CustomModeKey.SYNC_SAUNA_DATA_RSP, new SyncSaunaDataRspHandler());
        HANDLERS.put(BleProtocol.CommandID.CUSTOM_MADE * 10000 + BleProtocol.CustomModeKey.SYNC_HR_MOVEMENT_DATA_RSP, new SyncHRMovementDataRspHandler());
        HANDLERS.put(BleProtocol.CommandID.CUSTOM_MADE * 10000 + BleProtocol.CustomModeKey.SYNC_SAUNA_STATUS_RSP, new SyncSaunaStatusRspHandler());
        HANDLERS.put(BleProtocol.CommandID.CUSTOM_MADE * 10000 + BleProtocol.CustomModeKey.HRV_RMSSD_RSP, new ReadHRVRmssdConfigRspHandler());
        HANDLERS.put(BleProtocol.CommandID.CUSTOM_MADE * 10000 + BleProtocol.CustomModeKey.SYNC_HRV_RMSSD_RSP, new SyncHRVRmssdDataRspHandler());

        // 控制
        HANDLERS.put(BleProtocol.CommandID.CONTROL * 10000 + BleProtocol.ControlKey.PHOTO_RSP, new TakePhotoRspHandler());
        HANDLERS.put(BleProtocol.CommandID.CONTROL * 10000 + BleProtocol.ControlKey.FIND_PHONE_RSP, new FindPhoneRspHandler());
        HANDLERS.put(BleProtocol.CommandID.CONTROL * 10000 + BleProtocol.ControlKey.FIND_PHONE_RSP2, new FindPhoneRsp2Handler());
        HANDLERS.put(BleProtocol.CommandID.CONTROL * 10000 + BleProtocol.ControlKey.FEMALE_RSP, new SetFemaleHealthRspHandler());
        HANDLERS.put(BleProtocol.CommandID.CONTROL * 10000 + BleProtocol.ControlKey.WEATHER_RSP, new SetWeatherRspHandler());
        HANDLERS.put(BleProtocol.CommandID.CONTROL * 10000 + BleProtocol.ControlKey.CUS_RSP, new DeviceIndependentSwitchHandler());
        HANDLERS.put(BleProtocol.CommandID.CONTROL * 10000 + BleProtocol.ControlKey.HIDE_HEALTH_FUNCTION_RSP, new ReadHealthRiskAssessmentRspHandler());

        // 厂测
        HANDLERS.put(BleProtocol.CommandID.FACTORY_TEST * 10000 + BleProtocol.FactoryKey.DEFAULT_FUNCTION_RSP, new ReadDefaultFunctionRspHandler());// 读取默认功能返回
    }

    private static class TransportManagerHolder {
        private static final TransportManager transportManager = new TransportManager();
    }

    public static TransportManager getInstance() {
        return TransportManager.TransportManagerHolder.transportManager;
    }

}
