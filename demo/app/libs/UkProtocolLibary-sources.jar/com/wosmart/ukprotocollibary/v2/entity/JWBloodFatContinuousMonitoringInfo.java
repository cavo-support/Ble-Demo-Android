package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

/**
 * 血脂连续监测信息
 */
public class JWBloodFatContinuousMonitoringInfo extends JWHealthData implements Serializable {


    /**
     * unit mmol/L
     * default is 1.0 - 3.0, range is 0.5 - 8.0
     */
    public float value;


    @Override
    public String toString() {
        return "JWBloodFatContinuousMonitoringInfo{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", value=" + value +
                '}';
    }

}
