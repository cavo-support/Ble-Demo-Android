package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWUricAcidContinuousMonitoringInfo;

public class UricAcidContinuousMonitoringInfo extends BaseHealthDataInfo {

    public int value;

    public UricAcidContinuousMonitoringInfo(long time, String userID, String mac, int value) {
        this.time = time;
        this.userID = userID;
        this.deviceMac = mac;
        this.value = value;
    }

    public UricAcidContinuousMonitoringInfo(JWUricAcidContinuousMonitoringInfo info) {
        this.time = info.time;
        this.userID = info.userID;
        this.deviceMac = info.deviceMac;
        this.value = info.value;
    }

    public JWUricAcidContinuousMonitoringInfo convertToJWUricAcidContinuousMonitoringInfo() {
        JWUricAcidContinuousMonitoringInfo info = new JWUricAcidContinuousMonitoringInfo();
        info.userID = userID;
        info.deviceMac = deviceMac;
        info.time = time;
        info.value = value;

        return info;
    }

}
