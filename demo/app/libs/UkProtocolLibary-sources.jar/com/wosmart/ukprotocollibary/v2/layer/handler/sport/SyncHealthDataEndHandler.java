package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;

public class SyncHealthDataEndHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        TransportManager.getInstance().getSyncDataListener().onSyncDataFinished();
    }

}
