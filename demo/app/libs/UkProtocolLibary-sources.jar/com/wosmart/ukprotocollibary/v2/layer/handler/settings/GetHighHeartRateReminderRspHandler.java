package com.wosmart.ukprotocollibary.v2.layer.handler.settings;

import android.util.SparseArray;

import com.wosmart.ukprotocollibary.v2.entity.JWHighHeartRateReminderInfo;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

public class GetHighHeartRateReminderRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length < 2) {
            return;
        }
        SparseArray<SendPacketCallback> callbackMap = TransportManager.getInstance().getCallbackMap();
        SendPacketCallback callback = callbackMap.get(CallbackKeyConstants.KEY_GET_HIGH_HEART_RATE_REMINDER);
        if (callback != null) {
            JWHighHeartRateReminderInfo reminderInfo = new JWHighHeartRateReminderInfo();
            reminderInfo.isOpen = (data[0] & 0x01) == 0x01;
            reminderInfo.value = data[1] & 0xFF;

            callback.onResponse(reminderInfo);
        }
    }

}
