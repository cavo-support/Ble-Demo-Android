package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import com.wosmart.ukprotocollibary.WristbandManagerCallback;
import com.wosmart.ukprotocollibary.v2.JWPressureListener;
import com.wosmart.ukprotocollibary.v2.common.executor.JWArchTaskExecutor;
import com.wosmart.ukprotocollibary.v2.entity.JWPressureInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class SyncPressureDataRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        JWPressureListener pressureListener = TransportManager.getInstance().getPressureListener();
        if (pressureListener == null) {
            return;
        }
        if ((data.length < 8) || (data.length % 8) != 0) {
            return;
        }
        List<JWPressureInfo> infoList = new ArrayList<>();
        byte[] subData = new byte[8];
        for (int i = 0; i < data.length / 8; i++) {

            System.arraycopy(data, i * 8, subData, 0, 8);

            // 该时间戳为 2000.1.1 以后的秒
            long timestamp = (((subData[0] & 0xff)) | ((subData[1] & 0xff) << 8) | ((subData[2] & 0xff) << 16) | ((subData[3] & 0xff) << 24));
            int value = subData[4] & 0xff;
            if (value == 0) {
                continue;
            }

            timestamp = timestamp * 1000 + 946656000000L;

            JWPressureInfo info = new JWPressureInfo();

            info.time = timestamp;
            info.userID = BaseManager.getInstance().getUserID();
            info.deviceMac = BaseManager.getInstance().getMacAddress();
            info.value = value;

            infoList.add(info);
        }

        if (infoList.size() == 1 && infoList.get(0).getTime() == 2865908079000L
                && infoList.get(0).value == 111) {
            // 结束标识
            pressureListener.onSyncPressureDataEnd();
        } else {
            pressureListener.onPressureDataReceived(infoList);
        }
    }

}
