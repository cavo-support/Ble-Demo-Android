package com.wosmart.ukprotocollibary.v2.db.dao;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.db.entity.TemperatureInfo;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.AbstractDaoSession;
import org.greenrobot.greendao.Property;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseStatement;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.List;

public class TemperatureInfoDao extends AbstractDao<TemperatureInfo, Long> {

    public static final String TABLENAME = "TEMPERATURE_INFO";

    public float temperatureValue;

    public float temperatureOriginValue;

    public int wearStatus;

    public int compensationStatus;

    public static class Properties {
        public final static Property time = new Property(0, Long.class, "time", true, "TIME");
        public final static Property userID = new Property(1, String.class, "userID", true, "USER_ID");
        public final static Property mac = new Property(2, String.class, "mac", true, "MAC");
        public final static Property date = new Property(3, java.util.Date.class, "date", false, "DATE");
        public final static Property temperatureValue = new Property(4, int.class, "temperatureValue", false, "TEMPERATURE_VALUE");
        public final static Property temperatureOriginValue = new Property(5, int.class, "temperatureOriginValue", false, "TEMPERATURE_ORIGIN_VALUE");
        public final static Property wearStatus = new Property(6, int.class, "wearStatus", false, "WEAR_STATUS");
        public final static Property compensationStatus = new Property(7, int.class, "compensationStatus", false, "COMPENSATION_STATUS");
    }

    public TemperatureInfoDao(DaoConfig config) {
        super(config);
    }

    public TemperatureInfoDao(DaoConfig config, AbstractDaoSession daoSession) {
        super(config, daoSession);
    }


    public List<TemperatureInfo> queryDataList(String userID, String mac, long timeBegin, long timePeriod, int count) {
        String timeColName = Properties.time.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;
        String dateColName = Properties.date.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition;
        if (timeBegin == 0) {
            // 从当前时间
            timeCondition = timeColName + " <= " + System.currentTimeMillis();
        } else {
            timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));
        }
        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");
        String macCondition = TextUtils.isEmpty(mac) ? "" : (" " + macColName + " = '" + mac + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        if (!TextUtils.isEmpty(macCondition)) {
            sb.append(" and ").append(macCondition);
        }
        sb.append(")");

        String orderBy = "ORDER BY " + dateColName + " ASC";
        String limit = count == 0 ? "" : (" LIMIT " + count);

        sb.append(orderBy);
        sb.append(limit);

        return queryRaw(sb.toString());
    }


    public static void createTable(Database db) {
        db.execSQL("create table IF NOT EXISTS " + TABLENAME + "\n" +
                "(\n" +
                Properties.time.columnName + " bigint not null ,\n" +
                Properties.userID.columnName + " varchar(256) not null ,\n" +
                Properties.mac.columnName + " varchar(256) ,\n" +
                Properties.date.columnName + " varchar(50) not null ,\n" +
                Properties.temperatureValue.columnName + " int not null ,\n" +
                Properties.temperatureOriginValue.columnName + " int not null ,\n" +
                Properties.wearStatus.columnName + " int not null ,\n" +
                Properties.compensationStatus.columnName + " int not null ,\n" +
                " primary key (" + Properties.time.columnName + ", " + Properties.userID.columnName + ")\n" +
                ");");
    }

    public static void dropTable(Database db) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
    }

    @Override
    protected TemperatureInfo readEntity(Cursor cursor, int offset) {
        long time = cursor.getLong(offset + Properties.time.ordinal);
        String userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        String mac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        int temperatureValue = cursor.getInt(offset + Properties.temperatureValue.ordinal);
        int temperatureOriginValue = cursor.getInt(offset + Properties.temperatureOriginValue.ordinal);
        int wearStatus = cursor.getInt(offset + Properties.wearStatus.ordinal);
        int compensationStatus = cursor.getInt(offset + Properties.compensationStatus.ordinal);

        return new TemperatureInfo(time, userID, mac, temperatureValue, temperatureOriginValue, wearStatus, compensationStatus);
    }


    @Override
    protected Long readKey(Cursor cursor, int offset) {
        return cursor.getLong(offset);
    }

    @Override
    protected void readEntity(Cursor cursor, TemperatureInfo info, int offset) {
        info.time = cursor.getLong(offset + Properties.time.ordinal);
        info.userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        info.deviceMac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        info.temperatureValue = cursor.getInt(offset + Properties.temperatureValue.ordinal);
        info.temperatureOriginValue = cursor.getInt(offset + Properties.temperatureOriginValue.ordinal);
        info.wearStatus = cursor.getInt(offset + Properties.wearStatus.ordinal);
        info.compensationStatus = cursor.getInt(offset + Properties.compensationStatus.ordinal);
    }

    @Override
    protected void bindValues(DatabaseStatement stmt, TemperatureInfo info) {

    }

    @Override
    protected void bindValues(SQLiteStatement stmt, TemperatureInfo info) {
        stmt.clearBindings();

        stmt.bindLong(Properties.time.ordinal + 1, info.time);
        stmt.bindString(Properties.userID.ordinal + 1, TextUtils.isEmpty(info.userID) ? "" : info.userID);
        stmt.bindString(Properties.mac.ordinal + 1, TextUtils.isEmpty(info.deviceMac) ? "" : info.deviceMac);
        stmt.bindString(Properties.date.ordinal + 1, DateUtil.toTime2(info.time));
        stmt.bindLong(Properties.temperatureValue.ordinal + 1, info.temperatureValue);
        stmt.bindLong(Properties.temperatureOriginValue.ordinal + 1, info.temperatureOriginValue);
        stmt.bindLong(Properties.wearStatus.ordinal + 1, info.wearStatus);
        stmt.bindLong(Properties.compensationStatus.ordinal + 1, info.compensationStatus);
    }

    @Override
    protected Long updateKeyAfterInsert(TemperatureInfo info, long rowID) {
        return info.time;
    }

    @Override
    protected Long getKey(TemperatureInfo info) {
        return info.time;
    }

    @Override
    protected boolean hasKey(TemperatureInfo info) {
        return false;
    }

    @Override
    protected boolean isEntityUpdateable() {
        return true;
    }



}
