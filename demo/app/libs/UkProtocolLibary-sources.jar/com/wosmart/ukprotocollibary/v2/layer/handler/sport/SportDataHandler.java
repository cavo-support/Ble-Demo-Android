package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import com.wosmart.ukprotocollibary.v2.common.JWBridge;
import com.wosmart.ukprotocollibary.v2.entity.JWSportInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;

import java.util.ArrayList;
import java.util.List;

public class SportDataHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if ((data.length < 28)) {// 最少 28 字节
            return;
        }
        List<JWSportInfo> dataList = new ArrayList<>();

        int year = (data[0] & 0x7e) >> 1;
        int month = ((data[0] & 0x01) << 3) | (data[1] >> 5) & 0x07;
        int day = data[1] & 0x1f;
        int count = data[3] & 0xff;

        if ((data.length - 4) == count * 24) {
            for (int i = 0; i < count; i++) {
                byte[] sportItemData = new byte[24];
                System.arraycopy(data, 4 + i * 24, sportItemData, 0, 24);

                int minutes = ((sportItemData[1] & 0xff) << 8) | (sportItemData[2] & 0xff);
                int seconds = sportItemData[3] & 0xff;
                int sportModel = sportItemData[4] & 0xff;
                int sportMinute = ((sportItemData[5] & 0xff) << 8) | (sportItemData[6] & 0xff);
                int sportSecond = sportItemData[7] & 0xff;
                int pauseCount = sportItemData[8] & 0xff;
                int pauseMinute = ((sportItemData[9] & 0xff) << 8) | (sportItemData[10] & 0xff);
                int pauseSecond = sportItemData[11] & 0xff;
                int steps = ((sportItemData[12] & 0xff) << 24) | ((sportItemData[13] & 0xff) << 16) | ((sportItemData[14] & 0xff) << 8) | ((sportItemData[15] & 0xff));
                int distance = ((sportItemData[16] & 0xff) << 24) | ((sportItemData[17] & 0xff) << 16) | ((sportItemData[18] & 0xff) << 8) | ((sportItemData[19] & 0xff));
                int calories = ((sportItemData[20] & 0xff) << 24) | ((sportItemData[21] & 0xff) << 16) | ((sportItemData[22] & 0xff) << 8) | ((sportItemData[23] & 0xff));

                JWSportInfo info = new JWSportInfo();

                long time = JWBridge.getTime(year, month, day);
                time += minutes * 60000;
                time += seconds * 1000;

                info.time = time;
                info.userID = BaseManager.getInstance().getUserID();
                info.deviceMac = BaseManager.getInstance().getMacAddress();
                info.sportModel = sportModel;
                info.sportMinute = sportMinute;
                info.sportSecond = sportSecond;
                info.pauseCount = pauseCount;
                info.pauseMinute = pauseMinute;
                info.pauseSecond = pauseSecond;
                info.steps = steps;
                info.distance = distance;
                info.calories = calories;

                dataList.add(info);
            }
        } else if ((data.length - 4) == count * 28) {
            for (int i = 0; i < count; i++) {
                byte[] sportItemData = new byte[28];
                System.arraycopy(data, 4 + i * 28, sportItemData, 0, 28);

                int minutes = ((sportItemData[1] & 0xff) << 8) | (sportItemData[2] & 0xff);
                int seconds = sportItemData[3] & 0xff;
                int sportModel = sportItemData[4] & 0xff;
                int sportMinute = ((sportItemData[5] & 0xff) << 8) | (sportItemData[6] & 0xff);
                int sportSecond = sportItemData[7] & 0xff;
                int pauseCount = sportItemData[8] & 0xff;
                int pauseMinute = ((sportItemData[9] & 0xff) << 8) | (sportItemData[10] & 0xff);
                int pauseSecond = sportItemData[11] & 0xff;
                int steps = ((sportItemData[12] & 0xff) << 24) | ((sportItemData[13] & 0xff) << 16) | ((sportItemData[14] & 0xff) << 8) | ((sportItemData[15] & 0xff));
                int distance = ((sportItemData[16] & 0xff) << 24) | ((sportItemData[17] & 0xff) << 16) | ((sportItemData[18] & 0xff) << 8) | ((sportItemData[19] & 0xff));
                int calories = ((sportItemData[20] & 0xff) << 24) | ((sportItemData[21] & 0xff) << 16) | ((sportItemData[22] & 0xff) << 8) | ((sportItemData[23] & 0xff));
                int rateHigh = sportItemData[24] & 0xff;
                int rateAvg = sportItemData[25] & 0xff;
                int rateLow = sportItemData[26] & 0xff;

                JWSportInfo info = new JWSportInfo();

                long time = JWBridge.getTime(year, month, day);
                time += minutes * 60000;
                time += seconds * 1000;

                info.time = time;
                info.userID = BaseManager.getInstance().getUserID();
                info.deviceMac = BaseManager.getInstance().getMacAddress();
                info.sportModel = sportModel;
                info.sportMinute = sportMinute;
                info.sportSecond = sportSecond;
                info.pauseCount = pauseCount;
                info.pauseMinute = pauseMinute;
                info.pauseSecond = pauseSecond;
                info.steps = steps;
                info.distance = distance;
                info.calories = calories;
                info.rateHigh = rateHigh;
                info.rateAvg = rateAvg;
                info.rateLow = rateLow;

                dataList.add(info);
            }
        }
        if (TransportManager.getInstance().getSyncDataListener() == null) {
            return;
        }
        TransportManager.getInstance().getSyncDataListener().onSportDataReceived(dataList);

    }

}

