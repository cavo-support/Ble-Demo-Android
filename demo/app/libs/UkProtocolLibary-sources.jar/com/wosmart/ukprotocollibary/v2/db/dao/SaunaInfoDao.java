package com.wosmart.ukprotocollibary.v2.db.dao;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.db.entity.SaunaInfo;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.AbstractDaoSession;
import org.greenrobot.greendao.Property;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseStatement;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.List;

public class SaunaInfoDao extends AbstractDao<SaunaInfo, Long> {

    public static final String TABLENAME = "SAUNA_INFO";

    public static class Properties {
        public final static Property time = new Property(0, Long.class, "time", true, "TIME");
        public final static Property userID = new Property(1, String.class, "userID", true, "USER_ID");
        public final static Property mac = new Property(2, String.class, "mac", true, "MAC");
        public final static Property date = new Property(3, java.util.Date.class, "date", false, "DATE");
        public final static Property heartRateValue = new Property(4, int.class, "heartRateValue", false, "HEART_RATE_VALUE");
        public final static Property temperature = new Property(5, int.class, "temperature", false, "TEMPERATURE");
        public final static Property label = new Property(6, int.class, "label", false, "LABEL");
        public final static Property movement = new Property(7, int.class, "movement", false, "MOVEMENT");
    }

    public SaunaInfoDao(DaoConfig config) {
        super(config);
    }

    public SaunaInfoDao(DaoConfig config, AbstractDaoSession daoSession) {
        super(config, daoSession);
    }


    public List<SaunaInfo> queryDataList(String userID, String mac, long timeBegin, long timePeriod, int count) {
        String timeColName = Properties.time.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;
        String dateColName = Properties.date.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition;
        if (timeBegin == 0) {
            // 从当前时间
            timeCondition = timeColName + " <= " + System.currentTimeMillis();
        } else {
            timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));
        }
        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");
        String macCondition = TextUtils.isEmpty(mac) ? "" : (" " + macColName + " = '" + mac + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        if (!TextUtils.isEmpty(macCondition)) {
            sb.append(" and ").append(macCondition);
        }
        sb.append(")");

        String orderBy = "ORDER BY " + dateColName + " ASC";
        String limit = count == 0 ? "" : (" LIMIT " + count);

        sb.append(orderBy);
        sb.append(limit);

        return queryRaw(sb.toString());
    }


    public static void createTable(Database db) {
        db.execSQL("create table IF NOT EXISTS " + TABLENAME + "\n" +
                "(\n" +
                Properties.time.columnName + " bigint not null ,\n" +
                Properties.userID.columnName + " varchar(256) not null ,\n" +
                Properties.mac.columnName + " varchar(256) ,\n" +
                Properties.date.columnName + " varchar(50) not null ,\n" +
                Properties.heartRateValue.columnName + " int not null ,\n" +
                Properties.temperature.columnName + " int not null ,\n" +
                Properties.label.columnName + " int not null ,\n" +
                Properties.movement.columnName + " int not null ,\n" +
                " primary key (" + Properties.time.columnName + ", " + Properties.userID.columnName + ")\n" +
                ");");
    }

    public static void dropTable(Database db) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
    }

    @Override
    protected SaunaInfo readEntity(Cursor cursor, int offset) {
        long time = cursor.getLong(offset + Properties.time.ordinal);
        String userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        String mac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        int heartRateValue = cursor.getInt(offset + Properties.heartRateValue.ordinal);
        int temperature = cursor.getInt(offset + Properties.temperature.ordinal);
        int label = cursor.getInt(offset + Properties.label.ordinal);
        int movement = cursor.getInt(offset + Properties.movement.ordinal);

        return new SaunaInfo(userID, mac, time, heartRateValue, temperature, label, movement);
    }

    @Override
    protected Long readKey(Cursor cursor, int offset) {
        return cursor.getLong(offset);
    }

    @Override
    protected void readEntity(Cursor cursor, SaunaInfo info, int offset) {
        info.time = cursor.getLong(offset + Properties.time.ordinal);
        info.userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        info.deviceMac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        info.heartRateValue = cursor.getInt(offset + Properties.heartRateValue.ordinal);
        info.temperature = cursor.getInt(offset + Properties.temperature.ordinal);
        info.label = cursor.getInt(offset + Properties.label.ordinal);
        info.movement = cursor.getInt(offset + Properties.movement.ordinal);
    }

    @Override
    protected void bindValues(DatabaseStatement stmt, SaunaInfo info) {

    }

    @Override
    protected void bindValues(SQLiteStatement stmt, SaunaInfo info) {
        stmt.clearBindings();

        stmt.bindLong(Properties.time.ordinal + 1, info.time);
        stmt.bindString(Properties.userID.ordinal + 1, TextUtils.isEmpty(info.userID) ? "" : info.userID);
        stmt.bindString(Properties.mac.ordinal + 1, TextUtils.isEmpty(info.deviceMac) ? "" : info.deviceMac);
        stmt.bindString(Properties.date.ordinal + 1, DateUtil.toTime2(info.time));
        stmt.bindLong(Properties.heartRateValue.ordinal + 1, info.heartRateValue);
        stmt.bindLong(Properties.temperature.ordinal + 1, info.temperature);
        stmt.bindLong(Properties.label.ordinal + 1, info.label);
        stmt.bindLong(Properties.movement.ordinal + 1, info.movement);
    }

    @Override
    protected Long updateKeyAfterInsert(SaunaInfo info, long rowID) {
        return info.time;
    }

    @Override
    protected Long getKey(SaunaInfo info) {
        return info.time;
    }

    @Override
    protected boolean hasKey(SaunaInfo info) {
        return false;
    }

    @Override
    protected boolean isEntityUpdateable() {
        return true;
    }
}
