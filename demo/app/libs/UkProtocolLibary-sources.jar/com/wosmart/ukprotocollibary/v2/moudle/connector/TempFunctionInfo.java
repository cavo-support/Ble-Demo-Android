package com.wosmart.ukprotocollibary.v2.moudle.connector;

import com.wosmart.ukprotocollibary.v2.entity.JWDrinkWaterReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPrivateBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodFatFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodSugarCycleFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWPrivateBloodFatFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWPrivateUricAcidFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWUricAcidFunctionInfo;

public class TempFunctionInfo {

    public boolean isSupportSOS = false;// 多命令--SOS

    public boolean isSupportMedicationReminder = false;// 多命令--吃药提醒

    public boolean isSupportPulse = false;// 支持脉冲

    public boolean isSupportSleepHelp = false;// 支持睡眠辅助

    public boolean isSupportSauna = false;// 支持桑拿

    public boolean isSupportFemaleHealth = false;// 支持女性健康

    public boolean isSupportWeather = false;// 支持天气

    public boolean isSupportWearingTime = false;// 支持穿戴时长

    public boolean isSupportBodyFat = false;// 支持体脂
    public boolean isSupportPhysicalExam = false;// 支持体检
    public boolean isSupportUltraviolet = false;// 支持紫外线

    public JWUricAcidFunctionInfo uricAcidFunctionInfo;// 尿酸

    public JWBloodFatFunctionInfo bloodFatFunctionInfo;// 血脂

    public JWBloodSugarCycleFunctionInfo bloodSugarCycleFunctionInfo;// 血糖

    public JWPrivateUricAcidFunctionInfo privateUricAcidFunctionInfo;// 私人尿酸

    public JWPrivateBloodFatFunctionInfo privateBloodFatFunctionInfo;// 私人血脂

    public JWPrivateBloodPressureInfo privateBloodPressureInfo;// 私人血压

    public JWDrinkWaterReminderInfo drinkWaterReminderInfo;// 喝水提醒

    public JWTemperatureReminderInfo temperatureReminderInfo;// 体温提醒

    public void init() {
        isSupportSOS = false;
        isSupportMedicationReminder = false;
        isSupportPulse = false;
        isSupportSleepHelp = false;
        isSupportSauna = false;
        isSupportFemaleHealth = false;
        isSupportWeather = false;
        isSupportWearingTime = false;
        isSupportBodyFat = false;
        isSupportPhysicalExam = false;
        isSupportUltraviolet = false;

        drinkWaterReminderInfo = null;
        temperatureReminderInfo = null;
        privateBloodPressureInfo = null;
        uricAcidFunctionInfo = null;
        bloodFatFunctionInfo = null;
        bloodSugarCycleFunctionInfo = null;
        privateUricAcidFunctionInfo = null;
        privateBloodFatFunctionInfo = null;
    }

}
