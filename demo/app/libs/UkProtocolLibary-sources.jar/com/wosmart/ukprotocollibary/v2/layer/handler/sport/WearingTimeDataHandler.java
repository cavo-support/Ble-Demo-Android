package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.entity.JWWearingTimeInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;

import java.util.ArrayList;
import java.util.List;

public class WearingTimeDataHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        int packetLength = 8;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return;
        }
        List<JWWearingTimeInfo> dataList = new ArrayList<>();
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            long timestamp = (((subData[0] & 0xff)) | ((subData[1] & 0xff) << 8) | ((subData[2] & 0xff) << 16) | ((subData[3] & 0xff) << 24));
            int wearStatus = subData[4] & 0xff;

            JWWearingTimeInfo info = new JWWearingTimeInfo();

            long time = DateUtil.getDate(2000, 1, 1);

            time += (timestamp * 1000);

            info.setTime(time);
            info.userID = BaseManager.getInstance().getUserID();
            info.deviceMac = BaseManager.getInstance().getMacAddress();
            info.wearStatus = wearStatus;

            dataList.add(info);
        }
        if (TransportManager.getInstance().getSyncDataListener() == null) {
            return;
        }
        TransportManager.getInstance().getSyncDataListener().onWearingTimeDataReceived(dataList);

    }
}
