package com.wosmart.ukprotocollibary.v2.moudle.data;

import androidx.annotation.NonNull;

import com.wosmart.ukprotocollibary.v2.layer.BlePacketHelper;
import com.wosmart.ukprotocollibary.v2.layer.BleProtocol;

public class DataPacketHelper extends BlePacketHelper {

    public @NonNull static byte[] prepareSyncHealthDataPacket() {
        byte[] keyData = prepareKeyPacket(BleProtocol.SportKey.SPORTS_REQ, null);
        return prepareDataPacket(BleProtocol.CommandID.SPORTS_DATA, keyData);
    }


}
