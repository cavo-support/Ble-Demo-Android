package com.wosmart.ukprotocollibary.v2.common;

import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerAlarmPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerBpListItemPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerGLUPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerHrpItemPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerRateItemPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerRtkHrvPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSpo2Packet;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerSportItemPacket;
import com.wosmart.ukprotocollibary.applicationlayer.ApplicationLayerStepItemPacket;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHeartRateVariabilityInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWMedicationReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSleepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWSpO2Info;
import com.wosmart.ukprotocollibary.v2.entity.JWSportInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWStepInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureInfo;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

import java.util.Calendar;

public class JWBridge {

    public static long getTime(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(2000 + year, month - 1, day);

        return calendar.getTimeInMillis();
    }



    public static JWStepInfo convertToJWStepInfo(String userID, String mac, int year, int month, int day, ApplicationLayerStepItemPacket packet) {
        JWStepInfo info = new JWStepInfo();

        long time = getTime(year, month, day);

        time += packet.getOffset() * 15 * 60000;
        info.setTime(time);
        info.setUserID(userID);
        info.deviceMac = mac;

        info.stepCount = (packet.getStepCount());
        info.calorie = (packet.getCalory());
        info.distance = (packet.getDistance());
        info.mode = (packet.getMode());
        info.activeTime = (packet.getActiveTime());

        return info;
    }

    public static JWSleepInfo convertToJWSleepInfo(String userID, String mac, int year, int month, int day, int minutes, int mode) {
        JWSleepInfo info = new JWSleepInfo();

        long time = getTime(year, month, day);

        time += minutes * 60000;
        info.setTime(time);
        info.setUserID(userID);
        info.deviceMac = mac;

        info.setMode(mode);

        return info;
    }

    public static JWHeartRateInfo convertToJWHeartRateInfo(String userID, String mac, int year, int month, int day, ApplicationLayerHrpItemPacket packet) {
        JWHeartRateInfo info = new JWHeartRateInfo();

        long time = getTime(year, month, day);

        time += packet.getMinutes() * 60000;
        info.time = time;
        info.userID = userID;
        info.deviceMac = mac;

        info.value = packet.getValue();

        return info;
    }

    public static JWHeartRateInfo convertToJWHeartRateInfo(String userID, String mac, ApplicationLayerRateItemPacket packet) {
        JWHeartRateInfo info = new JWHeartRateInfo();

        long time = getTime(packet.getYear(), packet.getMonth(), packet.getDay());

        time += packet.getMinutes() * 60000;
        time += packet.getSequenceNum() * 1000;
        info.time = time;
        info.userID = userID;
        info.deviceMac = mac;

        info.value = packet.getValue();

        return info;
    }

    public static JWTemperatureInfo convertToJWTemperatureInfo(String userID, String mac, int year, int month, int day, ApplicationLayerHrpItemPacket packet) {
        JWTemperatureInfo info = new JWTemperatureInfo();

        long time = getTime(year, month, day);

        time += packet.getMinutes() * 60000;
        info.setTime(time);
        info.setUserID(userID);
        info.deviceMac = mac;

        info.temperatureValue = (packet.getTemperature());
        info.temperatureOriginValue = (packet.getTempOriginValue());
        info.compensationStatus = (packet.isAdjustStatus());
        info.wearStatus = (packet.isWearStatus());

        return info;
    }

    public static JWTemperatureInfo convertToJWTemperatureInfo(String userID, String mac, ApplicationLayerRateItemPacket packet) {
        JWTemperatureInfo info = new JWTemperatureInfo();

        long time = getTime(packet.getYear(), packet.getMonth(), packet.getDay());

        time += packet.getMinutes() * 60000;
        info.time = time;
        info.userID = userID;
        info.deviceMac = mac;

        info.temperatureValue = (packet.getTemperature());
        info.temperatureOriginValue = (packet.getTempOriginValue());
        info.compensationStatus = (packet.isAdjustStatus());
        info.wearStatus = (packet.isWearStatus());

        return info;
    }

    public static JWHeartRateVariabilityInfo convertToJWHrvInfo(String userID, String mac, ApplicationLayerRtkHrvPacket packet) {
        JWHeartRateVariabilityInfo info = new JWHeartRateVariabilityInfo();

        info.setTime(packet.getTime() * 1000);
        info.setUserID(userID);
        info.deviceMac = mac;

        info.value = (packet.getHrvValue());

        return info;
    }

    public static JWBloodPressureInfo convertToJWBpInfo(String userID, String mac, int year, int month, int day, int minutes, int highValue, int lowValue) {
        JWBloodPressureInfo info = new JWBloodPressureInfo();

        long time = getTime(year, month, day);

        time += minutes * 60000;
        info.time = time;
        info.userID = userID;
        info.deviceMac = mac;

        info.highValue = highValue;
        info.lowValue = lowValue;

        return info;
    }

    public static JWBloodPressureInfo convertToJWBpInfo(String userID, String mac, ApplicationLayerBpListItemPacket packet) {
        JWBloodPressureInfo info = new JWBloodPressureInfo();

        long time = getTime(packet.getmYear(), packet.getmMonth(), packet.getmDay());

        time += packet.getmMinutes() * 60000;
        info.time = time;
        info.userID = userID;
        info.deviceMac = mac;

        info.highValue = packet.getmHighValue();
        info.lowValue = packet.getmLowValue();

        return info;
    }

    public static JWSpO2Info convertToJWSpO2Info(String userID, String mac, ApplicationLayerSpo2Packet packet) {
        JWSpO2Info info = new JWSpO2Info();

        long time = getTime(packet.getmYear(), packet.getmMonth(), packet.getmDay());

        time += packet.getmMinutes() * 60000;
        info.setTime(time);
        info.setUserID(userID);
        info.deviceMac = mac;

        info.curValue = packet.getmCurValue();
        info.highValue = (packet.getmHighValue());
        info.lowValue = (packet.getmLowValue());

        return info;
    }

    public static JWBloodSugarInfo convertToJWBloodSugarInfo(String userID, String mac, ApplicationLayerGLUPacket packet) {
        JWBloodSugarInfo info = new JWBloodSugarInfo();

        long time = getTime(packet.getmYear(), packet.getmMonth(), packet.getmDay());

        time += packet.getmMinutes() * 60000;
        time += packet.getmSecond() * 1000;
        info.time = time;
        info.userID = userID;
        info.deviceMac = mac;

        info.value = JWUtils.parserRound(1, packet.getmGluValue() / 10f);

        return info;
    }

    public static JWSportInfo convertToJWSportInfo(String userID, String mac, int year, int month, int day, ApplicationLayerSportItemPacket packet) {
        JWSportInfo info = new JWSportInfo();

        long time = getTime(year, month, day);

        time += packet.getMinutes() * 60000;
        time += packet.getSeconds() * 1000;
        info.setTime(time);
        info.setUserID(userID);
        info.deviceMac = mac;

        info.setSportModel(packet.getSportModel());
        info.sportMinute = (packet.getSportMinute());
        info.sportSecond = (packet.getSportSecond());
        info.steps = (packet.getSteps());
        info.calories = (packet.getCalories());
        info.distance = (packet.getDistance());
        info.pauseCount = (packet.getPauseCount());
        info.pauseMinute = (packet.getPauseMinute());
        info.pauseSecond = (packet.getPauseSecond());
        info.rateAvg = (packet.getRateAvg());
        info.rateHigh = (packet.getRateHigh());
        info.rateLow = (packet.getRateLow());
        info.respirationRate = (packet.getRespirationRate());
        info.respirationRateMinute = (packet.getRespirationRateMinute());

        return info;
    }

    public static JWMedicationReminderInfo convertToJWMedicationReminderInfo(ApplicationLayerAlarmPacket packet) {
        JWMedicationReminderInfo info = new JWMedicationReminderInfo();

        long time = getTime(packet.getmYear(), packet.getmMonth(), packet.getmDay());

        time += packet.getHour() * 3600000;
        time += packet.getmMinute() * 60000;
        info.setTime(time);

        info.setId(packet.getId());
        info.setFlags(packet.getDayFlags());

        return info;
    }

}
