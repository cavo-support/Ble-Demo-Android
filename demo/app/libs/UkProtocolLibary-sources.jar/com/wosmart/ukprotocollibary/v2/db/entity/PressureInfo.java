package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWPressureInfo;

public class PressureInfo extends BaseHealthDataInfo {

    public int value;

    public PressureInfo(String userID, String mac, long time, int value) {
        this.userID = userID;
        this.time = time;
        this.value = value;
    }

    public PressureInfo(JWPressureInfo info) {
        this.userID = info.userID;
        this.deviceMac = info.deviceMac;
        this.time = info.time;
        this.value = info.value;
    }

    public JWPressureInfo convertToJWPressureInfo() {
        JWPressureInfo info = new JWPressureInfo();

        info.userID = this.userID;
        info.deviceMac = deviceMac;
        info.time = this.time;
        info.value = this.value;
        return info;
    }
}
