package com.wosmart.ukprotocollibary.v2.entity.function;

import java.io.Serializable;

public class JWDefaultFunctionInfo implements Serializable {

    /**
     * 血压
     */
    public boolean bloodPressureEnable;

    /**
     * 温度
     */
    public boolean temperatureEnable;

    /**
     * 压力
     */
    public boolean pressureEnable;

    /**
     * 场景控制
     */
    public boolean sceneEnable;

    /**
     * 智能
     */
    public boolean alexaEnable;

    /**
     * 光感
     */
    public boolean lightSenseEnable;

    /**
     * 老化模式
     */
    public boolean agingModeEnable;

    @Override
    public String toString() {
        return "JWDefaultFunctionInfo{" +
                "bloodPressureEnable=" + bloodPressureEnable +
                ", temperatureEnable=" + temperatureEnable +
                ", pressureEnable=" + pressureEnable +
                ", sceneEnable=" + sceneEnable +
                ", alexaEnable=" + alexaEnable +
                ", lightSenseEnable=" + lightSenseEnable +
                ", agingModeEnable=" + agingModeEnable +
                '}';
    }
}
