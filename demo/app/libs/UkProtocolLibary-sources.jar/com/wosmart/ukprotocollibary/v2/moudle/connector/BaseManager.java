package com.wosmart.ukprotocollibary.v2.moudle.connector;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;

import com.wosmart.ukprotocollibary.v2.BaseConstants;
import com.wosmart.ukprotocollibary.v2.JWConnListener;
import com.wosmart.ukprotocollibary.v2.JWFunctionChangeListener;
import com.wosmart.ukprotocollibary.v2.JWManager;
import com.wosmart.ukprotocollibary.v2.JWSDKConfig;
import com.wosmart.ukprotocollibary.v2.common.BleCallback;
import com.wosmart.ukprotocollibary.v2.common.JWContext;
import com.wosmart.ukprotocollibary.v2.common.JWLog;
import com.wosmart.ukprotocollibary.v2.common.executor.JWArchTaskExecutor;
import com.wosmart.ukprotocollibary.v2.entity.JWDeviceFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWDeviceIndependentSwitchInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWDeviceInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWDrinkWaterReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPrivateBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodFatFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodSugarCycleFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWPrivateBloodFatFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWPrivateUricAcidFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWUricAcidFunctionInfo;
import com.wosmart.ukprotocollibary.v2.layer.BleGattCallback;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.moudle.Manager;
import com.wosmart.ukprotocollibary.v2.moudle.data.DataManager;
import com.wosmart.ukprotocollibary.v2.moudle.settings.SettingsManager;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

import java.util.List;

public class BaseManager extends Manager {

    private static final String TAG = BaseManager.class.getSimpleName();

    private static final int TOKEN_CONNECT_TIMER = 999;

    private boolean isInit = false;

    private Context mContext;

    private BleGattCallback bleGattCallback;

    private String mUserID;
    private String mMacAddress;

    private int mConnStatus;

    private JWDeviceInfo deviceInfo;
    private JWDeviceFunctionInfo deviceFunctionInfo;
    private List<JWDeviceIndependentSwitchInfo> deviceIndependentSwitchInfoList;

    private final TempFunctionInfo tempFunctionInfo = new TempFunctionInfo();

    private TempFunctionInfoListener tempFunctionInfoListener;

    private JWConnListener mConnListener;

    private JWFunctionChangeListener mFunctionChangeListener;

    private BluetoothAdapter bluetoothAdapter;

    private static class BaseManagerHolder {
        @SuppressLint("StaticFieldLeak")
        private static final BaseManager baseManager = new BaseManager();
    }

    public static BaseManager getInstance() {
        return BaseManager.BaseManagerHolder.baseManager;
    }

    public boolean initSDK(Context context, JWSDKConfig sdkConfig) {
        if (null == context) {
            JWLog.e(TAG, "null context");
            return false;
        }

        if (isInit) {
            JWLog.w(TAG, "has initSDK");
            return true;
        }

        mContext = context.getApplicationContext();

        BluetoothManager bluetoothManager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);

        bluetoothAdapter = bluetoothManager.getAdapter();

        JWContext.getInstance().init(mContext);
        DataManager.getInstance().init(mContext);
        SettingsManager.getInstance().init(mContext);

        initListener(context);

        isInit = true;
        return true;
    }


    public Context getContext() {
        return mContext;
    }

    public BluetoothAdapter getBluetoothAdapter() {
        return bluetoothAdapter;
    }

    public boolean isBluetoothEnable() {
        return bluetoothAdapter != null && bluetoothAdapter.isEnabled();
    }


    public void connectDevice(String macAddress, String userID, JWConnListener connListener) {
        if (!isInit) {
            connListener.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "SDK not initialized");
            return;
        }

        if (mConnStatus != JWManager.CONN_STATUS_UN_CONNECT) {
            connListener.onError(BaseConstants.ERR_ALREADY_CONNECT_DEVICE, "already connect device");
            return;
        }

        BluetoothDevice device = this.getBluetoothAdapter().getRemoteDevice(macAddress);
        if (device == null) {
            connListener.onError(BaseConstants.ERR_CONNECT_DEVICE_FAILED, "device not found, unable to connect");
            return;
        }

        this.mMacAddress = macAddress;
        this.mUserID = userID;
        this.mConnStatus = JWManager.CONN_STATUS_CONNECTING;
        this.mConnListener = connListener;

        this.tempFunctionInfo.init();

        // 延时 45 秒检测连接流程是否完成
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                mConnStatus = JWManager.CONN_STATUS_UN_CONNECT;
                if (mConnListener != null) {
                    mConnListener.onConnectFailed(BaseConstants.ERR_CONNECT_DEVICE_TIMEOUT, "connect device timeout");
                }
            }
        }, TOKEN_CONNECT_TIMER, 45000);
        TransportManager.getInstance().connectDevice(device, bleGattCallback);
    }

    public void disconnectDevice(BleCallback<Void> callback) {
        if (!isInit) {
            if (callback != null) {
                callback.fail(BaseConstants.ERR_SDK_NOT_INITIALIZED, "SDK not initialized");
            }
            return;
        }

        if (mConnStatus != JWManager.CONN_STATUS_CONNECTED) {
            if (callback != null) {
                callback.fail(BaseConstants.ERR_DEVICE_NOT_CONNECTED, "device not connected");
            }
            return;
        }

        TransportManager.getInstance().disconnect();
        if (callback != null) {
            callback.success(null);
        }
    }

    public void unbindDevice(BleCallback<Void> callback) {
        if (!isInit) {
            if (callback != null) {
                callback.fail(BaseConstants.ERR_SDK_NOT_INITIALIZED, "SDK not initialized");
            }
            return;
        }

        if (mConnStatus != JWManager.CONN_STATUS_CONNECTED) {
            if (callback != null) {
                callback.fail(BaseConstants.ERR_DEVICE_NOT_CONNECTED, "device not connected");
            }
            return;
        }

        byte[] appPacketData = BasePacketHelper.prepareUnBindPacket();

        sendNormalData(appPacketData, callback);
    }


    public boolean isInited() {
        return isInit;
    }

    public int getConnStatus() {
        return mConnStatus;
    }

    public String getUserID() {
        return mUserID;
    }

    public String getMacAddress() {
        return mMacAddress;
    }

    public JWDeviceInfo getDeviceInfo() {
        return deviceInfo == null ? new JWDeviceInfo() : deviceInfo;
    }

    public JWDeviceFunctionInfo getDeviceFunctionInfo() {
        return deviceFunctionInfo == null ? new JWDeviceFunctionInfo() : deviceFunctionInfo;
    }

    public void setFunctionChangeListener(JWFunctionChangeListener listener) {
        this.mFunctionChangeListener = listener;
    }

    private void login() {
        byte[] appPacketData = BasePacketHelper.prepareLoginPacket(mUserID);

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_LOGIN, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                int status = (int) data;
                JWLog.i(TAG, "onLoginRsp = " + status);
                if (status == 0x00) {
                    // 登录成功，请求设备功能
                    reqDeviceFunction();
                    return;
                }
                if (status == 0x02) {
                    // 需要双向绑定
                    confirmBindDevice();
                    return;
                }
                // 其它情况都认为登录失败，执行绑定流程
                bindDevice();
            }

            @Override
            public void onSendFailed(int code, String desc) {
                mConnStatus = JWManager.CONN_STATUS_UN_CONNECT;
                JWArchTaskExecutor.getInstance().removeCallbackFromMainThread(TOKEN_CONNECT_TIMER);
                TransportManager.getInstance().disconnect();
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mConnListener != null) {
                            mConnListener.onConnectFailed(BaseConstants.ERR_LOGIN_FAILED, "login failed");
                        }
                    }
                });
            }
        });
    }

    private void bindDevice() {
        byte[] appPacketData = BasePacketHelper.prepareBindPacket(mUserID);
        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_BIND, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                boolean result = (boolean) data;
                JWLog.i(TAG, "onBindRsp = " + result);
                if (result) {
                    // 绑定成功，请求设备功能
                    reqDeviceFunction();
                    return;
                }
                mConnStatus = JWManager.CONN_STATUS_UN_CONNECT;
                JWArchTaskExecutor.getInstance().removeCallbackFromMainThread(TOKEN_CONNECT_TIMER);
                TransportManager.getInstance().disconnect();
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mConnListener != null) {
                            mConnListener.onConnectFailed(BaseConstants.ERR_BIND_DEVICE_FAILED, "bind device failed");
                        }
                    }
                });
            }

            @Override
            public void onSendFailed(int code, String desc) {
                mConnStatus = JWManager.CONN_STATUS_UN_CONNECT;
                JWArchTaskExecutor.getInstance().removeCallbackFromMainThread(TOKEN_CONNECT_TIMER);
                TransportManager.getInstance().disconnect();
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mConnListener != null) {
                            mConnListener.onConnectFailed(BaseConstants.ERR_BIND_DEVICE_FAILED, "bind device failed");
                        }
                    }
                });
            }
        });
    }

    private void confirmBindDevice() {
        byte[] appPacketData = BasePacketHelper.prepareConfirmBindPacket(mUserID);

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_CONFIRM_BIND, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                int status = (int) data;
                JWLog.i(TAG, "onConfirmBindRsp = " + status);
                if (status == 0x00) {
                    // 绑定成功，请求设备功能
                    reqDeviceFunction();
                    return;
                }
                if (status == 0x02) {
                    // 绑定超时
                    mConnStatus = JWManager.CONN_STATUS_UN_CONNECT;
                    JWArchTaskExecutor.getInstance().removeCallbackFromMainThread(TOKEN_CONNECT_TIMER);
                    TransportManager.getInstance().disconnect();
                    JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                        @Override
                        public void run() {
                            if (mConnListener != null) {
                                mConnListener.onConnectFailed(BaseConstants.ERR_BIND_DEVICE_TIMEOUT, "bind device time out");
                            }
                        }
                    });
                    return;
                }
                // 其它情况都认为绑定失败
                mConnStatus = JWManager.CONN_STATUS_UN_CONNECT;
                JWArchTaskExecutor.getInstance().removeCallbackFromMainThread(TOKEN_CONNECT_TIMER);
                TransportManager.getInstance().disconnect();
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mConnListener != null) {
                            mConnListener.onConnectFailed(BaseConstants.ERR_BIND_DEVICE_FAILED, "bind device failed");
                        }
                    }
                });
            }

            @Override
            public void onSendFailed(int code, String desc) {
                mConnStatus = JWManager.CONN_STATUS_UN_CONNECT;
                JWArchTaskExecutor.getInstance().removeCallbackFromMainThread(TOKEN_CONNECT_TIMER);
                TransportManager.getInstance().disconnect();
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mConnListener != null) {
                            mConnListener.onConnectFailed(BaseConstants.ERR_BIND_DEVICE_FAILED, "bind device failed");
                        }
                    }
                });
            }
        });
    }

    private void reqDeviceFunction() {
        SettingsManager.getInstance().setPhoneOS(null);
        SettingsManager.getInstance().setTime(null);

        byte[] appPacketData = BasePacketHelper.prepareReqDeviceFunctionPacket();

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_GET_DEVICE_FUNCTION, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                deviceFunctionInfo = (JWDeviceFunctionInfo) data;

                deviceFunctionInfo.sosNumber = tempFunctionInfo.isSupportSOS;
                deviceFunctionInfo.medicationReminder = tempFunctionInfo.isSupportMedicationReminder;
                deviceFunctionInfo.pulse = tempFunctionInfo.isSupportPulse;
                deviceFunctionInfo.sleepHelp = tempFunctionInfo.isSupportSleepHelp;
                deviceFunctionInfo.sauna = tempFunctionInfo.isSupportSauna;
                deviceFunctionInfo.femaleHealth = tempFunctionInfo.isSupportFemaleHealth;
                deviceFunctionInfo.weather = tempFunctionInfo.isSupportWeather;
                deviceFunctionInfo.wearingTime = tempFunctionInfo.isSupportWearingTime;
                deviceFunctionInfo.bodyFat = tempFunctionInfo.isSupportBodyFat;
                deviceFunctionInfo.physicalExam = tempFunctionInfo.isSupportPhysicalExam;
                deviceFunctionInfo.ultraviolet = tempFunctionInfo.isSupportUltraviolet;
                deviceFunctionInfo.uricAcid = tempFunctionInfo.uricAcidFunctionInfo;
                deviceFunctionInfo.bloodFat = tempFunctionInfo.bloodFatFunctionInfo;
                deviceFunctionInfo.bloodSugarCycle = tempFunctionInfo.bloodSugarCycleFunctionInfo;
                deviceFunctionInfo.privateUricAcid = tempFunctionInfo.privateUricAcidFunctionInfo;
                deviceFunctionInfo.privateBloodFat = tempFunctionInfo.privateBloodFatFunctionInfo;
                deviceFunctionInfo.temperatureReminder = tempFunctionInfo.temperatureReminderInfo;
                deviceFunctionInfo.drinkWaterReminder = tempFunctionInfo.drinkWaterReminderInfo;
                deviceFunctionInfo.privateBloodPressure = tempFunctionInfo.privateBloodPressureInfo;

                JWLog.i(TAG, "onDeviceFunctionRsp = " + deviceFunctionInfo.toString());
                reqDeviceInfo();
            }

            @Override
            public void onSendFailed(int code, String desc) {
                mConnStatus = JWManager.CONN_STATUS_UN_CONNECT;
                JWArchTaskExecutor.getInstance().removeCallbackFromMainThread(TOKEN_CONNECT_TIMER);
                TransportManager.getInstance().disconnect();
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mConnListener != null) {
                            mConnListener.onConnectFailed(BaseConstants.ERR_REQ_DEVICE_FUNCTION_FAILED, "get device function failed");
                        }
                    }
                });
            }
        });
    }

    private void reqDeviceInfo() {
        byte[] appPacketData = BasePacketHelper.prepareReqDeviceInfoPacket();

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_GET_DEVICE_INFO, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                JWDeviceInfo curDeviceInfo = (JWDeviceInfo) data;
                JWLog.i(TAG, "onDeviceInfoRsp = " + curDeviceInfo.toString());
                if (BaseManager.this.deviceInfo != null) {
                    curDeviceInfo.chipType = BaseManager.this.deviceInfo.chipType;
                }
                BaseManager.this.deviceInfo = curDeviceInfo;
                // 至此登录流程结束
                mConnStatus = JWManager.CONN_STATUS_CONNECTED;
                JWArchTaskExecutor.getInstance().removeCallbackFromMainThread(TOKEN_CONNECT_TIMER);

                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mConnListener != null) {
                            mConnListener.onConnectSuccess(BaseManager.this.deviceInfo, BaseManager.this.deviceFunctionInfo);
                        }
                    }
                });
            }

            @Override
            public void onSendFailed(int code, String desc) {
                mConnStatus = JWManager.CONN_STATUS_UN_CONNECT;
                JWArchTaskExecutor.getInstance().removeCallbackFromMainThread(TOKEN_CONNECT_TIMER);
                TransportManager.getInstance().disconnect();
                JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mConnListener != null) {
                            mConnListener.onConnectFailed(BaseConstants.ERR_REQ_DEVICE_INFO_FAILED, "get device info failed");
                        }
                    }
                });
            }
        });
    }

    private void initListener(Context context) {
        initTempFunctionInfoListener();
        if (bleGattCallback == null) {
            bleGattCallback = new BleGattCallback() {
                @Override
                public void onStartConnect() {
                    if (mConnListener != null) {
                        mConnListener.onConnecting();
                    }
                }

                @Override
                public void onConnectFail(int code, String desc) {
                    mConnStatus = JWManager.CONN_STATUS_UN_CONNECT;
                    JWArchTaskExecutor.getInstance().removeCallbackFromMainThread(TOKEN_CONNECT_TIMER);
                    if (mConnListener != null) {
                        mConnListener.onConnectFailed(code, desc);
                    }
                }

                @Override
                public void onConnectSuccess() {
                    if (mConnStatus != JWManager.CONN_STATUS_CONNECTING) {
                        return;
                    }
                    // 主动调用连接的情况下连接成功后开始登录流程
                    login();
                }

                @Override
                public void onDisConnected() {
                    mConnStatus = JWManager.CONN_STATUS_UN_CONNECT;
                    JWArchTaskExecutor.getInstance().removeCallbackFromMainThread(TOKEN_CONNECT_TIMER);
                    if (mConnListener != null) {
                        mConnListener.onDisConnected();
                    }
                }
            };
        }
    }

    private void initTempFunctionInfoListener() {
        if (tempFunctionInfoListener == null) {
            tempFunctionInfoListener = new TempFunctionInfoListener() {
                @Override
                public void onSupportSOS() {
                    tempFunctionInfo.isSupportSOS = true;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.sosNumber = true;
                    }
                }

                @Override
                public void onSupportMedicationReminder() {
                    tempFunctionInfo.isSupportMedicationReminder = true;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.medicationReminder = true;
                    }
                }

                @Override
                public void onSupportPulse() {
                    tempFunctionInfo.isSupportPulse = true;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.pulse = true;
                    }
                }

                @Override
                public void onSupportSleepHelp() {
                    tempFunctionInfo.isSupportSleepHelp = true;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.sleepHelp = true;
                    }
                }

                @Override
                public void onSupportSauna() {
                    tempFunctionInfo.isSupportSauna = true;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.sauna = true;
                    }
                }

                @Override
                public void onSupportFemaleHealth() {
                    tempFunctionInfo.isSupportFemaleHealth = true;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.femaleHealth = true;
                    }
                }

                @Override
                public void onSupportWeather() {
                    tempFunctionInfo.isSupportWeather = true;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.weather = true;
                    }
                }

                @Override
                public void onSupportWearingTime() {
                    tempFunctionInfo.isSupportWearingTime = true;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.wearingTime = true;
                    }
                }

                @Override
                public void onSupportBodyFat() {
                    tempFunctionInfo.isSupportBodyFat = true;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.bodyFat = true;
                    }
                }

                @Override
                public void onSupportPhysicalExam() {
                    tempFunctionInfo.isSupportPhysicalExam = true;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.physicalExam = true;
                    }
                }

                @Override
                public void onSupportUltraviolet() {
                    tempFunctionInfo.isSupportUltraviolet = true;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.ultraviolet = true;
                    }
                }

                @Override
                public void onSupportUricAcid(JWUricAcidFunctionInfo functionInfo) {
                    tempFunctionInfo.uricAcidFunctionInfo = functionInfo;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.uricAcid = functionInfo;
                    }
                    if (mFunctionChangeListener != null) {
                        mFunctionChangeListener.onUricAcidFunctionChanged(functionInfo);
                    }
                }

                @Override
                public void onSupportBloodFat(JWBloodFatFunctionInfo functionInfo) {
                    tempFunctionInfo.bloodFatFunctionInfo = functionInfo;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.bloodFat = functionInfo;
                    }
                    if (mFunctionChangeListener != null) {
                        mFunctionChangeListener.onBloodFatFunctionChanged(functionInfo);
                    }
                }

                @Override
                public void onSupportBloodSugarCycle(JWBloodSugarCycleFunctionInfo functionInfo) {
                    tempFunctionInfo.bloodSugarCycleFunctionInfo = functionInfo;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.bloodSugarCycle = functionInfo;
                    }
                    if (mFunctionChangeListener != null) {
                        mFunctionChangeListener.onBloodSugarCycleFunctionChanged(functionInfo);
                    }
                }

                @Override
                public void onSupportPrivateUricAcid(JWPrivateUricAcidFunctionInfo functionInfo) {
                    tempFunctionInfo.privateUricAcidFunctionInfo = functionInfo;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.privateUricAcid = functionInfo;
                    }
                }

                @Override
                public void onSupportPrivateBloodFat(JWPrivateBloodFatFunctionInfo functionInfo) {
                    tempFunctionInfo.privateBloodFatFunctionInfo = functionInfo;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.privateBloodFat = functionInfo;
                    }
                }

                @Override
                public void onSupportTemperatureReminder(JWTemperatureReminderInfo reminderInfo) {
                    tempFunctionInfo.temperatureReminderInfo = reminderInfo;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.temperatureReminder = reminderInfo;
                    }
                }

                @Override
                public void onSupportDrinkWaterReminder(JWDrinkWaterReminderInfo reminderInfo) {
                    tempFunctionInfo.drinkWaterReminderInfo = reminderInfo;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.drinkWaterReminder = reminderInfo;
                    }
                }

                @Override
                public void onSupportPrivateBloodPressureInfo(JWPrivateBloodPressureInfo privateBloodPressureInfo) {
                    tempFunctionInfo.privateBloodPressureInfo = privateBloodPressureInfo;
                    if (deviceFunctionInfo != null) {
                        deviceFunctionInfo.privateBloodPressure = privateBloodPressureInfo;
                    }
                }

                @Override
                public void onDeviceIndependentSwitchInfoList(List<JWDeviceIndependentSwitchInfo> deviceIndependentSwitchInfoList) {
                    BaseManager.this.deviceIndependentSwitchInfoList = deviceIndependentSwitchInfoList;
                }

            };
        }
    }

    public TempFunctionInfoListener getTempFunctionInfoListener() {
        return tempFunctionInfoListener;
    }

    public TempFunctionInfo getTempFunctionInfo() {
        return tempFunctionInfo;
    }

    public List<JWDeviceIndependentSwitchInfo> getDeviceIndependentSwitchInfoList() {
        return deviceIndependentSwitchInfoList;
    }

}
