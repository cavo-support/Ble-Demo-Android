package com.wosmart.ukprotocollibary.v2.layer.handler.bind;

import com.wosmart.ukprotocollibary.v2.entity.JWDeviceInfo;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;

public class ChipTypeRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data.length > 0) {
            int chipType = data[0] & 0xFF;
            JWDeviceInfo deviceInfo = BaseManager.getInstance().getDeviceInfo();
            deviceInfo.chipType = chipType;
        }
    }

}
