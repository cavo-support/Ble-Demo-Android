package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWBodyFatInfo extends JWHealthData implements Serializable {

    /**
     * 体重，单位 kg，unit kg
     */
    public float weight;
    public int weightLevel;
    public int weightMaxLevel;

    /**
     * 身体质量指数 Body Mass Index
     */
    public float bmi;

    public int bmiLevel;
    public int bmiMaxLevel;

    /**
     * 基础代谢率 Basal Metabolic 
     * ，单位 kcal，unit kcal
     */
    public float bmr;
    public int bmrLevel;
    public int bmrMaxLevel;

    /**
     * 体脂，单位 kg，unit kg
     */
    public float bodyFat;
    public int bodyFatLevel;
    public int bodyFatMaxLevel;

    /**
     * 体内水分，单位 kg，unit kg
     */
    public float bodyWater;
    public int bodyWaterLevel;
    public int bodyWaterMaxLevel;

    /**
     * 蛋白质，单位 kg，unit kg
     */
    public float protein;
    public int proteinLevel;
    public int proteinMaxLevel;

    /**
     * 骨量，单位 kg，unit kg
     */
    public float boneMass;
    public int boneMassLevel;
    public int boneMassMaxLevel;

    /**
     * 肌肉，单位 kg，unit kg
     */
    public float muscle;
    public int muscleLevel;
    public int muscleMaxLevel;

    @Override
    public String toString() {
        return "JWBodyFatInfo{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", weight=" + weight +
                ", weightLevel=" + weightLevel +
                ", weightMaxLevel=" + weightMaxLevel +
                ", bmi=" + bmi +
                ", bmiLevel=" + bmiLevel +
                ", bmiMaxLevel=" + bmiMaxLevel +
                ", bmr=" + bmr +
                ", bmrLevel=" + bmrLevel +
                ", bmrMaxLevel=" + bmrMaxLevel +
                ", bodyFat=" + bodyFat +
                ", bodyFatLevel=" + bodyFatLevel +
                ", bodyFatMaxLevel=" + bodyFatMaxLevel +
                ", bodyWater=" + bodyWater +
                ", bodyWaterLevel=" + bodyWaterLevel +
                ", bodyWaterMaxLevel=" + bodyWaterMaxLevel +
                ", protein=" + protein +
                ", proteinLevel=" + proteinLevel +
                ", proteinMaxLevel=" + proteinMaxLevel +
                ", boneMass=" + boneMass +
                ", boneMassLevel=" + boneMassLevel +
                ", boneMassMaxLevel=" + boneMassMaxLevel +
                ", muscle=" + muscle +
                ", muscleLevel=" + muscleLevel +
                ", muscleMaxLevel=" + muscleMaxLevel +
                '}';
    }
}
