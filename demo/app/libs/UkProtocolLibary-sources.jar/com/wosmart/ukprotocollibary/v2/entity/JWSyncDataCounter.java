package com.wosmart.ukprotocollibary.v2.entity;

public class JWSyncDataCounter {

    public int totalCount = 0;

    public int stepCount = 0;

    public int sportCount = 0;

    public int sleepCount = 0;

    public int heartRateCount = 0;

    public int heartRateVariabilityCount = 0;

    public int bloodPressureCount = 0;

    public int bloodSugarCount = 0;

    public int spo2Count = 0;

    public int wearingTimeCount = 0;

    public int uricAcidCount = 0;

    public int bloodFatCount = 0;

    public int bloodSugarCycleCount = 0;

    public int uricAcidContinuousMonitoringCount = 0;

    public int bloodFatContinuousMonitoringCount = 0;

    public void init() {
        totalCount = 0;
        stepCount = 0;
        sportCount = 0;
        sleepCount = 0;
        heartRateCount = 0;
        heartRateVariabilityCount = 0;
        bloodPressureCount = 0;
        bloodSugarCount = 0;
        spo2Count = 0;
        wearingTimeCount = 0;
        uricAcidCount = 0;
        bloodFatCount = 0;
        bloodSugarCycleCount = 0;
        uricAcidContinuousMonitoringCount = 0;
        bloodFatContinuousMonitoringCount = 0;
    }

    public boolean checkData() {
        return (stepCount + sportCount + sleepCount +
                heartRateCount + heartRateVariabilityCount +
                bloodPressureCount + bloodSugarCount + spo2Count +
                wearingTimeCount + uricAcidCount + bloodFatCount + bloodSugarCycleCount +
                uricAcidContinuousMonitoringCount + bloodFatContinuousMonitoringCount) >= totalCount;
    }

    @Override
    public String toString() {
        return "JWSyncDataCounter{" +
                "\ntotalCount=" + totalCount +
                "\nstepCount=" + stepCount +
                "\nsportCount=" + sportCount +
                "\nsleepCount=" + sleepCount +
                "\nheartRateCount=" + heartRateCount +
                "\nheartRateVariabilityCount=" + heartRateVariabilityCount +
                "\nbloodPressureCount=" + bloodPressureCount +
                "\nbloodSugarCount=" + bloodSugarCount +
                "\nspo2Count=" + spo2Count +
                "\nwearingTimeCount=" + wearingTimeCount +
                "\nuricAcidCount=" + uricAcidCount +
                "\nbloodFatCount=" + bloodFatCount +
                "\nbloodSugarCycleCount=" + bloodSugarCycleCount +
                "\nuricAcidContinuousMonitoringCount=" + uricAcidContinuousMonitoringCount +
                "\nbloodFatContinuousMonitoringCount=" + bloodFatContinuousMonitoringCount +
                '}';
    }
}
