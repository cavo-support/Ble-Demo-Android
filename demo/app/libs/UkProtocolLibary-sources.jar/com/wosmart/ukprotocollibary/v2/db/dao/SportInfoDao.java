package com.wosmart.ukprotocollibary.v2.db.dao;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.db.entity.SportInfo;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.AbstractDaoSession;
import org.greenrobot.greendao.Property;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseStatement;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.List;

public class SportInfoDao extends AbstractDao<SportInfo, Long> {

    public static final String TABLENAME = "SPORT_INFO";

    public static class Properties {
        public final static Property time = new Property(0, Long.class, "time", true, "TIME");
        public final static Property userID = new Property(1, String.class, "userID", true, "USER_ID");
        public final static Property mac = new Property(2, String.class, "mac", true, "MAC");
        public final static Property date = new Property(3, java.util.Date.class, "date", false, "DATE");
        public final static Property sportModel = new Property(4, int.class, "sportModel", false, "SPORT_MODEL");
        public final static Property sportMinute = new Property(5, int.class, "sportMinute", false, "SPORT_MINUTE");
        public final static Property sportSecond = new Property(6, int.class, "sportSecond", false, "SPORT_SECOND");
        public final static Property pauseCount = new Property(7, int.class, "pauseCount", false, "PAUSE_COUNT");
        public final static Property pauseMinute = new Property(8, int.class, "pauseMinute", false, "PAUSE_MINUTE");
        public final static Property pauseSecond = new Property(9, int.class, "pauseSecond", false, "PAUSE_SECOND");
        public final static Property steps = new Property(10, int.class, "steps", false, "STEPS");
        public final static Property distance = new Property(11, int.class, "distance", false, "DISTANCE");
        public final static Property calories = new Property(12, int.class, "calories", false, "CALORIES");
        public final static Property respirationRate = new Property(13, int.class, "respirationRate", false, "RESPIRATION_RATE");
        public final static Property respirationRateMinute = new Property(14, int.class, "respirationRateMinute", false, "RESPIRATION_RATE_MINUTE");
        public final static Property rateHigh = new Property(15, int.class, "rateHigh", false, "RATE_HIGH");
        public final static Property rateAvg = new Property(16, int.class, "rateAvg", false, "RATE_AVG");
        public final static Property rateLow = new Property(17, int.class, "rateLow", false, "RATE_LOW");
    }

    public SportInfoDao(DaoConfig config) {
        super(config);
    }

    public SportInfoDao(DaoConfig config, AbstractDaoSession daoSession) {
        super(config, daoSession);
    }



    public List<SportInfo> queryDataList(String userID, String mac, long timeBegin, long timePeriod, int count) {
        String timeColName = Properties.time.columnName;
        String userIDColName = Properties.userID.columnName;
        String macColName = Properties.mac.columnName;
        String dateColName = Properties.date.columnName;

        StringBuilder sb = new StringBuilder();

        String timeCondition;
        if (timeBegin == 0) {
            // 从当前时间
            timeCondition = timeColName + " <= " + System.currentTimeMillis();
        } else {
            timeCondition = (timeColName + " >= " + timeBegin) + " and " + (timeColName + " <= " + (timeBegin + timePeriod));
        }
        String userIDCondition = TextUtils.isEmpty(userID) ? "" : (" " + userIDColName + " = '" + userID + "' ");
        String macCondition = TextUtils.isEmpty(mac) ? "" : (" " + macColName + " = '" + mac + "' ");

        sb.append(" where (");
        sb.append(timeCondition);
        if (!TextUtils.isEmpty(userIDCondition)) {
            sb.append(" and ").append(userIDCondition);
        }
        if (!TextUtils.isEmpty(macCondition)) {
            sb.append(" and ").append(macCondition);
        }
        sb.append(")");

        String orderBy = "ORDER BY " + dateColName + " ASC";
        String limit = count == 0 ? "" : (" LIMIT " + count);

        sb.append(orderBy);
        sb.append(limit);

        return queryRaw(sb.toString());
    }







    public static void createTable(Database db) {
        db.execSQL("create table IF NOT EXISTS " + TABLENAME + "\n" +
                "(\n" +
                Properties.time.columnName + " bigint not null ,\n" +
                Properties.userID.columnName + " varchar(256) not null ,\n" +
                Properties.mac.columnName + " varchar(256) ,\n" +
                Properties.date.columnName + " varchar(50) not null ,\n" +
                Properties.sportModel.columnName + " int not null ,\n" +
                Properties.sportMinute.columnName + " int not null ,\n" +
                Properties.sportSecond.columnName + " int not null ,\n" +
                Properties.pauseCount.columnName + " int not null ,\n" +
                Properties.pauseMinute.columnName + " int not null ,\n" +
                Properties.pauseSecond.columnName + " int not null ,\n" +
                Properties.steps.columnName + " int not null ,\n" +
                Properties.distance.columnName + " int not null ,\n" +
                Properties.calories.columnName + " int not null ,\n" +
                Properties.respirationRate.columnName + " int not null ,\n" +
                Properties.respirationRateMinute.columnName + " int not null ,\n" +
                Properties.rateHigh.columnName + " int not null ,\n" +
                Properties.rateAvg.columnName + " int not null ,\n" +
                Properties.rateLow.columnName + " int not null ,\n" +
                " primary key (" + Properties.time.columnName + ", " + Properties.userID.columnName + ")\n" +
                ");");
    }

    public static void dropTable(Database db) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
    }


    @Override
    protected SportInfo readEntity(Cursor cursor, int offset) {
        long time = cursor.getLong(offset + Properties.time.ordinal);
        String userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        String mac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        int sportModel = cursor.getInt(offset + Properties.sportModel.ordinal);
        int sportMinute = cursor.getInt(offset + Properties.sportMinute.ordinal);
        int sportSecond = cursor.getInt(offset + Properties.sportSecond.ordinal);
        int pauseCount = cursor.getInt(offset + Properties.pauseCount.ordinal);
        int pauseMinute = cursor.getInt(offset + Properties.pauseMinute.ordinal);
        int pauseSecond = cursor.getInt(offset + Properties.pauseSecond.ordinal);
        int steps = cursor.getInt(offset + Properties.steps.ordinal);
        int distance = cursor.getInt(offset + Properties.distance.ordinal);
        int calories = cursor.getInt(offset + Properties.calories.ordinal);
        int respirationRate = cursor.getInt(offset + Properties.respirationRate.ordinal);
        int respirationRateMinute = cursor.getInt(offset + Properties.respirationRateMinute.ordinal);
        int rateHigh = cursor.getInt(offset + Properties.rateHigh.ordinal);
        int rateAvg = cursor.getInt(offset + Properties.rateAvg.ordinal);
        int rateLow = cursor.getInt(offset + Properties.rateLow.ordinal);
        return new SportInfo(time, userID, mac, sportModel, sportMinute, sportSecond, pauseCount, pauseMinute, pauseSecond,
                steps, distance, calories, respirationRate, respirationRateMinute, rateHigh, rateAvg, rateLow);
    }

    @Override
    protected Long readKey(Cursor cursor, int offset) {
        return cursor.getLong(offset);
    }

    @Override
    protected void readEntity(Cursor cursor, SportInfo info, int offset) {
        info.time = cursor.getLong(offset + Properties.time.ordinal);
        info.userID = cursor.isNull(offset + Properties.userID.ordinal) ? null : cursor.getString(offset + Properties.userID.ordinal);
        info.deviceMac = cursor.isNull(offset + Properties.mac.ordinal) ? null : cursor.getString(offset + Properties.mac.ordinal);
        info.sportModel = cursor.getInt(offset + Properties.sportModel.ordinal);
        info.sportMinute = cursor.getInt(offset + Properties.sportMinute.ordinal);
        info.sportSecond = cursor.getInt(offset + Properties.sportSecond.ordinal);
        info.pauseCount = cursor.getInt(offset + Properties.pauseCount.ordinal);
        info.pauseMinute = cursor.getInt(offset + Properties.pauseMinute.ordinal);
        info.pauseSecond = cursor.getInt(offset + Properties.pauseSecond.ordinal);
        info.steps = cursor.getInt(offset + Properties.steps.ordinal);
        info.distance = cursor.getInt(offset + Properties.distance.ordinal);
        info.calories = cursor.getInt(offset + Properties.calories.ordinal);
        info.respirationRate = cursor.getInt(offset + Properties.respirationRate.ordinal);
        info.respirationRateMinute = cursor.getInt(offset + Properties.respirationRateMinute.ordinal);
        info.rateHigh = cursor.getInt(offset + Properties.rateHigh.ordinal);
        info.rateAvg = cursor.getInt(offset + Properties.rateAvg.ordinal);
        info.rateLow = cursor.getInt(offset + Properties.rateLow.ordinal);
    }

    @Override
    protected void bindValues(DatabaseStatement stmt, SportInfo info) {

    }

    @Override
    protected void bindValues(SQLiteStatement stmt, SportInfo info) {
        stmt.clearBindings();

        stmt.bindLong(Properties.time.ordinal + 1, info.time);
        stmt.bindString(Properties.userID.ordinal + 1, TextUtils.isEmpty(info.userID) ? "" : info.userID);
        stmt.bindString(Properties.mac.ordinal + 1, TextUtils.isEmpty(info.deviceMac) ? "" : info.deviceMac);
        stmt.bindString(Properties.date.ordinal + 1, DateUtil.toTime2(info.time));
        stmt.bindLong(Properties.sportModel.ordinal + 1, info.sportModel);
        stmt.bindLong(Properties.sportMinute.ordinal + 1, info.sportMinute);
        stmt.bindLong(Properties.sportSecond.ordinal + 1, info.sportSecond);
        stmt.bindLong(Properties.pauseCount.ordinal + 1, info.pauseCount);
        stmt.bindLong(Properties.pauseMinute.ordinal + 1, info.pauseMinute);
        stmt.bindLong(Properties.pauseSecond.ordinal + 1, info.pauseSecond);
        stmt.bindLong(Properties.steps.ordinal + 1, info.steps);
        stmt.bindLong(Properties.distance.ordinal + 1, info.distance);
        stmt.bindLong(Properties.calories.ordinal + 1, info.calories);
        stmt.bindLong(Properties.respirationRate.ordinal + 1, info.respirationRate);
        stmt.bindLong(Properties.respirationRateMinute.ordinal + 1, info.respirationRateMinute);
        stmt.bindLong(Properties.rateHigh.ordinal + 1, info.rateHigh);
        stmt.bindLong(Properties.rateAvg.ordinal + 1, info.rateAvg);
        stmt.bindLong(Properties.rateLow.ordinal + 1, info.rateLow);

    }

    @Override
    protected Long updateKeyAfterInsert(SportInfo info, long rowID) {
        return info.time;
    }

    @Override
    protected Long getKey(SportInfo info) {
        return info.time;
    }

    @Override
    protected boolean hasKey(SportInfo info) {
        return false;
    }

    @Override
    protected boolean isEntityUpdateable() {
        return true;
    }
}
