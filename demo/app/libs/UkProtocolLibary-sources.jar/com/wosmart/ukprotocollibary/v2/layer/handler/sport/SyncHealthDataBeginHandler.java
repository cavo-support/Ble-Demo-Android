package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import com.wosmart.ukprotocollibary.v2.entity.JWSyncDataInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;

import java.util.ArrayList;
import java.util.List;

public class SyncHealthDataBeginHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (TransportManager.getInstance().getSyncDataListener() == null) {
            return;
        }
        JWSyncDataInfo syncDataInfo = new JWSyncDataInfo();

        if (data == null || data.length == 0 || (data.length / 3 == 0)) {
            TransportManager.getInstance().getSyncDataListener().onSyncDataStart(syncDataInfo);
            return;
        }
        int count = data.length / 3;
        byte[] subData = new byte[3];

        int totalCount = 0;
        List<JWSyncDataInfo.SyncDataItemInfo> itemInfoList = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            JWSyncDataInfo.SyncDataItemInfo itemInfo = new JWSyncDataInfo.SyncDataItemInfo();
            System.arraycopy(data, i * 3, subData, 0, 3);

            int type = subData[0] & 0xff;
            switch (type) {
                case 0:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_STEP;
                    break;
                case 1:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_SLEEP;
                    break;
                case 2:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_HEART_RATE;
                    break;
                case 3:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_BLOOD_PRESSURE;
                    break;
                case 4:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_SPORT;
                    break;
                case 5:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_SPO2;
                    break;
                case 6:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_HEART_RATE_VARIABILITY;
                    break;
                case 7:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_BLOOD_SUGAR;
                    break;
                case 8:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_WEARING_TIME;
                    break;
                case 9:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_URIC_ACID;
                    break;
                case 10:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_BLOOD_FAT;
                    break;
                case 11:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_BLOOD_SUGAR_CYCLE;
                    break;
                case 12:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_URIC_ACID_CONTINUOUS_MONITORING;
                    break;
                case 13:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_BLOOD_FAT_CONTINUOUS_MONITORING;
                    break;
                default:
                    itemInfo.type = JWSyncDataInfo.SyncDataItemInfo.ITEM_TYPE_UNKNOWN;
                    break;
            }
            itemInfo.count = ((subData[1] & 0xff) << 8) | (subData[2] & 0xff);

            totalCount += itemInfo.count;

            itemInfoList.add(itemInfo);
        }

        syncDataInfo.totalCount = totalCount;
        syncDataInfo.itemInfoList = itemInfoList;
        TransportManager.getInstance().getSyncDataListener().onSyncDataStart(syncDataInfo);
    }

}
