package com.wosmart.ukprotocollibary.v2;

public class BaseConstants {

    public static final int ERR_SDK_NOT_INITIALIZED = 6013;// SDK 未初始化

    public static final int ERR_INVALID_PARAMETERS = 6017;// 参数异常

    public static final int ERR_SEND_DATA_FAILED = 6018;// 发送数据失败

    public static final int ERR_SET_FAILED = 6019;// 设置失败

    public static final int ERR_DEVICE_IS_BUSY = 6020;// 设备正忙

    public static final int ERR_DEVICE_NOT_SUPPORT = 6021;// 设备不支持此功能


    public static final int ERR_BLUETOOTH_UN_ENABLE = 5010;// 蓝牙不可用

    public static final int ERR_NO_PERMISSION = 5011;// 无权限

    public static final int ERR_ALREADY_CONNECT_DEVICE = 5012;// 已连接设备

    public static final int ERR_CONNECT_DEVICE_FAILED = 5013;// 连接设备失败

    public static final int ERR_CONNECT_DEVICE_TIMEOUT = 5014;// 连接设备超时

    public static final int ERR_UN_FIND_SERVICE = 5015;// 未发现设备服务
    public static final int ERR_UN_FIND_CHARACTERISTIC = 5016;// 未发现设备特征

    public static final int ERR_SET_MTU_FAILED = 5017;// 设置 MTU 失败
    public static final int ERR_DESCRIPTOR_WRITE_FAILED = 5019;// 描述写入失败

    public static final int ERR_DEVICE_NO_RESP = 5025;// 设备无回应

    public static final int ERR_LOGIN_FAILED = 5026;// 登录设备失败

    public static final int ERR_BIND_DEVICE_FAILED = 5027;// 绑定设备失败

    public static final int ERR_BIND_DEVICE_TIMEOUT = 5028;// 绑定设备超时

    public static final int ERR_REQ_DEVICE_FUNCTION_FAILED = 5029;// 获取设备功能失败

    public static final int ERR_REQ_DEVICE_INFO_FAILED = 5030;// 获取设备信息失败


    public static final int ERR_DEVICE_NOT_CONNECTED = 4014;// 未连接设备

    public static final int ERR_ALREADY_IN_THE_PROCESS_OF_SYNCHRONIZING = 4017;// 已经在同步中

    public static final int ERR_DATABASE_NOT_INITIALIZED = 4018;// 数据库未初始化



}
