package com.wosmart.ukprotocollibary.v2.db;

import android.content.Context;

import com.wosmart.ukprotocollibary.v2.db.dao.BloodFatContinuousMonitoringInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodFatInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodPressureInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodSugarCycleInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BloodSugarInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.BodyFatInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HRMovementInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HRVRmssdInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HeartRateInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.HeartRateVariabilityInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.PhysicalExamInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.PressureInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.PulseInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SaunaInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SleepInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SpO2InfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.SportInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.StepInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.TemperatureInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.UltravioletInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.UricAcidContinuousMonitoringInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.UricAcidInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.WearingTimeInfoDao;


public class DatabaseManager {

    private final static String DB_NAME = "test.db";

    private static DatabaseManager sInstance;


    private DatabaseSession mDatabaseSession;

    private DatabaseManager() {

    }

    public static DatabaseManager getInstance() {
        if(sInstance == null) {
            synchronized (DatabaseManager.class) {
                if(sInstance == null) {
                    sInstance = new DatabaseManager();
                }
            }
        }
        return sInstance;
    }

    public synchronized void init(Context context) {
        DatabaseMaster.OpenHelper helper = new DatabaseMaster.DevOpenHelper(context, DB_NAME, null);
        DatabaseMaster databaseMaster = new DatabaseMaster(helper.getWritableDb());
        mDatabaseSession = databaseMaster.newSession();
    }

    public BloodPressureInfoDao getBloodPressureDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getBloodPressureDao();
    }

    public BloodSugarInfoDao getBloodSugarDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getBloodSugarDao();
    }

    public HeartRateInfoDao getHeartRateDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getHeartRateDao();
    }

    public HeartRateVariabilityInfoDao getHrvDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getHrvDao();
    }

    public SleepInfoDao getSleepDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getSleepDao();
    }

    public SpO2InfoDao getSpO2Dao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getSpO2Dao();
    }

    public SportInfoDao getSportDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getSportDao();
    }

    public StepInfoDao getStepDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getStepDao();
    }

    public TemperatureInfoDao getTemperatureDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getTemperatureDao();
    }

    public PulseInfoDao getPulseDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getPulseDao();
    }

    public SaunaInfoDao getSaunaDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getSaunaDao();
    }

    public HRMovementInfoDao getHRMovementDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getHRMovementDao();
    }

    public WearingTimeInfoDao getWearingTimeDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getWearingTimeDao();
    }

    public UricAcidInfoDao getUricAcidDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getUricAcidInfoDao();
    }

    public BloodFatInfoDao getBloodFatDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getBloodFatInfoDao();
    }

    public BloodSugarCycleInfoDao getBloodSugarCycleDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getBloodSugarCycleInfoDao();
    }

    public UricAcidContinuousMonitoringInfoDao getUricAcidContinuousMonitoringDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getUricAcidContinuousMonitoringInfoDao();
    }

    public BloodFatContinuousMonitoringInfoDao getBloodFatContinuousMonitoringDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getBloodFatContinuousMonitoringInfoDao();
    }

    public BodyFatInfoDao getBodyFatDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getBodyFatInfoDao();
    }

    public PhysicalExamInfoDao getPhysicalExamDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getPhysicalExamInfoDao();
    }

    public HRVRmssdInfoDao getHRVRmssdDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getHRVRmssdDao();
    }

    public UltravioletInfoDao getUltravioletDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getUltravioletDao();
    }

    public PressureInfoDao getPressureDao() {
        if (mDatabaseSession == null) {
            return null;
        }
        return mDatabaseSession.getPressureDao();
    }

}
