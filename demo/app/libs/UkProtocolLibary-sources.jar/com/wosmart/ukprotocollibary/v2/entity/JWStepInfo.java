package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

/**
 * step info
 */
public class JWStepInfo extends JWHealthData implements Serializable {

    /**
     * step count
     * 步数
     */
    public int stepCount;

    /**
     * step calories, unit cal
     * 卡路里，单位 小卡
     */
    public int calorie;

    /**
     * step distance, unit meter
     * 距离，单位 米
     */
    public int distance;

    /**
     * step mode, un available
     */
    public int mode;

    /**
     * active time, un available
     */
    public int activeTime;

    @Override
    public String toString() {
        return "JWStepInfo{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", stepCount=" + stepCount +
                ", calorie=" + calorie +
                ", distance=" + distance +
                ", mode=" + mode +
                ", activeTime=" + activeTime +
                '}';
    }
}
