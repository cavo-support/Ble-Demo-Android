package com.wosmart.ukprotocollibary.v2.common;

import com.wosmart.ukprotocollibary.v2.common.executor.JWArchTaskExecutor;
import com.wosmart.ukprotocollibary.v2.JWCallback;
import com.wosmart.ukprotocollibary.v2.JWValueCallback;

public abstract class BleCallback<T> {

    protected JWCallback callback;
    protected JWValueCallback<T> valueCallback;

    protected BleCallback(JWCallback cb) {
        this.callback = cb;
    }

    protected BleCallback(JWValueCallback<T> cb) {
        this.valueCallback = cb;
    }

    public void success(final T data) {
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                if (callback != null) {
                    callback.onSuccess();
                } else if (valueCallback != null) {
                    valueCallback.onSuccess(data);
                }
            }
        });
    }

    public void fail(final int code, final String errorMessage) {
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                if (callback != null) {
                    callback.onError(code, errorMessage);
                } else if (valueCallback != null) {
                    valueCallback.onError(code, errorMessage);
                }
            }
        });
    }

    public void fail(final int code, final String errorMessage, final T data) {
        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
            @Override
            public void run() {
                if (callback != null) {
                    callback.onError(code, errorMessage);
                } else if (valueCallback != null) {
                    valueCallback.onError(code, errorMessage);
                }
            }
        });
    }

}
