package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWBloodPressureInfo;

public class BloodPressureInfo extends BaseHealthDataInfo {

    public int lowValue;

    public int highValue;

    public BloodPressureInfo(long time, String userID, String mac, int lowValue, int highValue) {
        this.time = time;
        this.userID = userID;
        this.deviceMac = mac;
        this.lowValue = lowValue;
        this.highValue = highValue;
    }

    public BloodPressureInfo(JWBloodPressureInfo info) {
        this.time = info.time;
        this.userID = info.userID;
        this.lowValue = info.lowValue;
        this.highValue = info.highValue;
    }

    public JWBloodPressureInfo convertToJWBpInfo() {
        JWBloodPressureInfo info = new JWBloodPressureInfo();
        info.userID = userID;
        info.deviceMac = deviceMac;
        info.time = time;
        info.lowValue = lowValue;
        info.highValue = highValue;

        return info;
    }
}
