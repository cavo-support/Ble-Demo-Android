package com.wosmart.ukprotocollibary.v2.common;

public class JWSDKInfo {

    /**
     * 制造商信息
     */
    public String manufacturerInformation = "Wo-Smart Technologies";

    /**
     * 平台
     */
    public String platform = "Android";

    /**
     * 版本
     */
    public String version = "1.2.40";


}
