package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWFemaleHealthInfo implements Serializable {

    public static final int MODE_MENSTRUAL_PERIOD = 0x01;

    public static final int MODE_PREGNANCY_PREPARATION_PERIOD = 0x02;

    public static final int MODE_EXPECTED_DATE_OF_CHILDBIRTH = 0x03;

    public static final int MODE_SUCKLING_PERIOD = 0x04;

    public boolean enable;

    public int mode = MODE_MENSTRUAL_PERIOD;

    /**
     * unit day
     */
    public int periodTime;

    /**
     * unit day
     */
    public int menstrualPeriodTime;

    public int year;

    public int month;

    public int day;


}
