package com.wosmart.ukprotocollibary.v2;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.ScanRecord;

public interface JWScanCallback extends JWErrorCallback {

    /**
     * found a device, it's will trigger by sdk < Build.VERSION_CODES.LOLLIPOP
     *
     * @param device     device info
     * @param rssi       signal intensity
     * @param scanRecord scanRecord
     */
    void onDeviceFound(BluetoothDevice device, int rssi, byte[] scanRecord);

    /**
     * found a device, it's will trigger by sdk >= Build.VERSION_CODES.LOLLIPOP
     *
     * @param device     device info
     * @param rssi       signal intensity
     * @param scanRecord scanRecord
     */
    void onDeviceFound(BluetoothDevice device, int rssi, ScanRecord scanRecord);

    /**
     * start scan device
     */
    void onScanStarted();

    /**
     * stop scan device
     */
    void onScanStopped();

    /**
     * cancel scan device
     */
    void onScanCanceled();


}
