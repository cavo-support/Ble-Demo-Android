package com.wosmart.ukprotocollibary.v2.common.executor;


/**
 * A task executor that can divide tasks into logical groups.
 * <p>
 * It holds a collection a executors for each group of task.
 * <p>
 * TODO: Don't use this from outside, we don't know what the API will look like yet.
 *
 * @hide
 */
public abstract class JWTaskExecutor {
    /**
     * Executes the given task in the disk IO thread pool.
     *
     * @param runnable The runnable to run in the disk IO thread pool.
     */
    public abstract void executeOnDiskIO(Runnable runnable);

    /**
     * Posts the given task to the main thread.
     *
     * @param runnable The runnable to run on the main thread.
     */
    public abstract void postToMainThread(Runnable runnable);

    /**
     * Posts the given task to the main thread.
     *
     * @param runnable    The runnable to run on the main thread.
     * @param delayMillis delay millis
     */
    public abstract void postToMainThread(Runnable runnable, long delayMillis);

    /**
     * Posts the given task to the main thread.
     *
     * @param runnable    The runnable to run on the main thread.
     * @param token       The runnable token.
     * @param delayMillis delay millis
     */
    public abstract void postToMainThread(Runnable runnable, Object token, long delayMillis);

    public abstract void removeCallbackFromMainThread(Object token);

    /**
     * Executes the given task on the main thread.
     * <p>
     * If the current thread is a main thread, immediately runs the given runnable.
     *
     * @param runnable The runnable to run on the main thread.
     */
    public void executeOnMainThread(Runnable runnable) {
        if (isMainThread()) {
            runnable.run();
        } else {
            postToMainThread(runnable);
        }
    }

    /**
     * Returns true if the current thread is the main thread, false otherwise.
     *
     * @return true if we are on the main thread, false otherwise.
     */
    public abstract boolean isMainThread();
}
