package com.wosmart.ukprotocollibary.v2.entity.function;


import java.io.Serializable;

public class JWBloodSugarCycleFunctionInfo extends JWCommonFunctionInfo implements Serializable {

    /**
     * 私人值
     * 4.0 - 7.0
     */
    public float privateValue;

    /**
     * 设置私人值时间，默认值为0，精确到秒
     * default is 0, unit second
     */
    public int privateRtcTime;


    @Override
    public String toString() {
        return "JWBloodSugarCycleFunctionInfo{" +
                "privateRtcTime=" + privateRtcTime +
                "privateValue=" + privateValue +
                ", isOpen=" + enable +
                '}';
    }
}
