package com.wosmart.ukprotocollibary.v2.db.entity;

public class BaseHealthDataInfo {

    public String userID;

    public String deviceMac;

    public long time;



}
