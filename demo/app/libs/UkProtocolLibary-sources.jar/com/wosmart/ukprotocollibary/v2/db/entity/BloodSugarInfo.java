package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarInfo;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

public class BloodSugarInfo extends BaseHealthDataInfo {

    public int value;

    public BloodSugarInfo(long time, String userID, String mac, int value) {
        this.time = time;
        this.userID = userID;
        this.deviceMac = mac;
        this.value = value;
    }

    public BloodSugarInfo(JWBloodSugarInfo info) {
        this.time = info.time;
        this.userID = info.userID;
        this.deviceMac = info.deviceMac;
        this.value = (int) (info.value * 10);
    }

    public JWBloodSugarInfo convertToJWBsInfo() {
        JWBloodSugarInfo info = new JWBloodSugarInfo();
        info.time = time;
        info.userID = userID;
        info.deviceMac = deviceMac;
        info.value = JWUtils.parserRound(1, value / 10f);

        return info;
    }


}
