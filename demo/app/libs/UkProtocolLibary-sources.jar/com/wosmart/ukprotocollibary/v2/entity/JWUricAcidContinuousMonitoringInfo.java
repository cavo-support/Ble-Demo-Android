package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;
import java.util.List;

/**
 * 尿酸连续监测信息
 */
public class JWUricAcidContinuousMonitoringInfo extends JWHealthData implements Serializable {


    /**
     * unit μmol/L
     */
    public int value;


    @Override
    public String toString() {
        return "JWUricAcidContinuousMonitoringInfo{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", value=" + value +
                '}';
    }

}
