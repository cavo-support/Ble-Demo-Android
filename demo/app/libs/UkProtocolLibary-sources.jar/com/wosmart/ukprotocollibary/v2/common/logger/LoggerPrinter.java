package com.wosmart.ukprotocollibary.v2.common.logger;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import static com.wosmart.ukprotocollibary.v2.common.logger.Utils.checkNotNull;


class LoggerPrinter implements Printer {

    /**
     * It is used for json pretty print
     */
    private static final int JSON_INDENT = 2;

    /**
     * Provides one-time used tag for the log message
     */
    private final ThreadLocal<String> localTag = new ThreadLocal<>();

    private final List<LogAdapter> appLogAdapters = new ArrayList<>();
    private final List<LogAdapter> sdkLogAdapters = new ArrayList<>();

    @Override
    public synchronized void log(int logType, int priority, String tag, String message, Throwable throwable) {
        if (throwable != null && message != null) {
            message += " : " + Utils.getStackTraceString(throwable);
        }
        if (throwable != null && message == null) {
            message = Utils.getStackTraceString(throwable);
        }
        if (Utils.isEmpty(message)) {
            message = "Empty/NULL log message";
        }

        if (logType == JWLogger.LOG_TYPE_SDK) {
            for (LogAdapter adapter : sdkLogAdapters) {
                if (adapter.isLoggable(priority, tag)) {
                    adapter.log(priority, tag, message);
                }
            }
        } else {
            for (LogAdapter adapter : appLogAdapters) {
                if (adapter.isLoggable(priority, tag)) {
                    adapter.log(priority, tag, message);
                }
            }
        }
    }

    @Override
    public void json(int logType, String json) {
        if (Utils.isEmpty(json)) {
            log(logType, JWLogger.DEBUG, "json", "Empty/Null json content", null);
            return;
        }
        try {
            json = json.trim();
            if (json.startsWith("{")) {
                JSONObject jsonObject = new JSONObject(json);
                String message = jsonObject.toString(JSON_INDENT);
                log(logType, JWLogger.DEBUG, "json", message, null);
                return;
            }
            if (json.startsWith("[")) {
                JSONArray jsonArray = new JSONArray(json);
                String message = jsonArray.toString(JSON_INDENT);
                log(logType, JWLogger.DEBUG, "json", message, null);
                return;
            }
            log(logType, JWLogger.ERROR, "json", "Invalid Json", null);
        } catch (JSONException e) {
            log(logType, JWLogger.ERROR, "json", "Invalid Json", null);
        }
    }

    @Override
    public void xml(int logType, String xml) {
        if (Utils.isEmpty(xml)) {
            log(logType, JWLogger.DEBUG, "xml", "Empty/Null xml content", null);
            return;
        }
        try {
            Source xmlInput = new StreamSource(new StringReader(xml));
            StreamResult xmlOutput = new StreamResult(new StringWriter());
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            transformer.transform(xmlInput, xmlOutput);
            log(logType, JWLogger.DEBUG, "xml", xmlOutput.getWriter().toString().replaceFirst(">", ">\n"), null);
        } catch (TransformerException e) {
            log(logType, JWLogger.ERROR, "xml", "Invalid xml", null);
        }
    }

    @Override
    public void clearLogAdapters(int logType) {
        if (logType == JWLogger.LOG_TYPE_SDK) {
            sdkLogAdapters.clear();
        } else {
            appLogAdapters.clear();
        }
    }


    @Override
    public void addAdapter(int logType, LogAdapter adapter) {
        if (logType == JWLogger.LOG_TYPE_SDK) {
            sdkLogAdapters.add(checkNotNull(adapter));
        } else {
            appLogAdapters.add(checkNotNull(adapter));
        }
    }


    /**
     * @return the appropriate tag based on local or global
     */
    private String getTag() {
        String tag = localTag.get();
        if (tag != null) {
            localTag.remove();
            return tag;
        }
        return null;
    }

    private String createMessage(String message, Object... args) {
        return args == null || args.length == 0 ? message : String.format(message, args);
    }
}
