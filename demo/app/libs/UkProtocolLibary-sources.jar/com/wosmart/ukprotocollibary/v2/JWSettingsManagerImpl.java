package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.common.BleCallback;
import com.wosmart.ukprotocollibary.v2.entity.JWAllNotifyConfigInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWNotifyType;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.settings.SettingsManager;

public class JWSettingsManagerImpl extends JWSettingsManager {

    static JWSettingsManagerImpl getInstance() {
        return JWSettingsManagerImplHolder.settingsManagerImpl;
    }

    @Override
    public void setUserProfile(int gender, int age, float height, float weight, JWCallback callback) {
        if (gender != JWSettingsManager.GENDER_FEMALE && gender != JWSettingsManager.GENDER_MALE) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "gender error");
            }
            return;
        }
        if (age <= 0 || age > 127) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "age error");
            }
            return;
        }
        if (height <= 0 || height > 256) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "height error");
            }
            return;
        }
        if (weight <= 0 || weight > 512) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "weight error");
            }
            return;
        }

        SettingsManager.getInstance().setUserProfile(gender, age, height, weight, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setHourSystem(boolean is24Model, JWCallback callback) {
        SettingsManager.getInstance().setHourSystem(is24Model, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setAudioSwitch(boolean enable, JWCallback callback) {
        SettingsManager.getInstance().setAudioSwitch(enable, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void getAudioSwitch(JWValueCallback<Boolean> callback) {
        SettingsManager.getInstance().getAudioSwitch(new BleCallback<Boolean>(callback) {
            @Override
            public void success(Boolean data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setNotifySwitch(JWNotifyType notifyType, boolean enable, JWCallback callback) {
        if (notifyType == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "notify type cannot be empty");
            }
            return;
        }
        SettingsManager.getInstance().setNotifySwitch(notifyType, enable, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setAllNotifySwitch(JWAllNotifyConfigInfo notifyConfigInfo, JWCallback callback) {
        if (notifyConfigInfo == null) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "notifyConfigInfo cannot be empty");
            }
            return;
        }
        SettingsManager.getInstance().setAllNotifySwitch(notifyConfigInfo, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setDateFormat(int dateFormat, JWCallback callback) {
        if (!BaseManager.getInstance().getDeviceFunctionInfo().deviceDateFormat) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        if (dateFormat != JWSettingsManager.DATE_FORMAT_MM_DD && dateFormat != JWSettingsManager.DATE_FORMAT_DD_MM) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_INVALID_PARAMETERS, "date format error");
            }
            return;
        }
        SettingsManager.getInstance().setDateFormat(dateFormat, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void getDateFormat(JWValueCallback<Integer> callback) {
        if (!BaseManager.getInstance().getDeviceFunctionInfo().deviceDateFormat) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_DEVICE_NOT_SUPPORT, "the current device does not support this function");
            }
            return;
        }
        SettingsManager.getInstance().getDateFormat(new BleCallback<Integer>(callback) {
            @Override
            public void success(Integer data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void setTemperatureUnit(boolean isCelsiusUnit, JWCallback callback) {
        SettingsManager.getInstance().setTemperatureUnit(isCelsiusUnit, new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }


    private static class JWSettingsManagerImplHolder {
        private static final JWSettingsManagerImpl settingsManagerImpl = new JWSettingsManagerImpl();
    }

}
