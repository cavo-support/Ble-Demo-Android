package com.wosmart.ukprotocollibary.v2.layer.handler;

public abstract class AbstractDataHandler {

    public void execute(byte[] data) {
        action(data);
    }

    protected abstract void action(byte[] data);

}
