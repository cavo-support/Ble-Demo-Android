package com.wosmart.ukprotocollibary.v2;

public interface JWCallback extends JWErrorCallback {

    void onSuccess();

}
