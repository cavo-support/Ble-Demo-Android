package com.wosmart.ukprotocollibary.v2.layer;

import android.bluetooth.BluetoothGattCallback;

public abstract class BleGattCallback extends BluetoothGattCallback {

    public abstract void onStartConnect();

    public abstract void onConnectFail(int code, String desc);

    public abstract void onConnectSuccess();

    public abstract void onDisConnected();

    public void onDataSend(boolean result) {

    }

    public void onDataReceived(byte[] data) {

    }

    public void onMtuChanged(int mtu) {

    }

}
