package com.wosmart.ukprotocollibary.v2.layer;

public class SendPacketCallback {

    public void onResponse(Object data) {

    }

    public void onSendSuccess() {

    }

    public void onSendFailed(int code, String desc) {

    }

}
