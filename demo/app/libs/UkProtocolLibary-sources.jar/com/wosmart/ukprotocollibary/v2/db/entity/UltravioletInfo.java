package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWUltravioletInfo;

public class UltravioletInfo extends BaseHealthDataInfo {

    /**
     * 紫外等级
     */
    public int value;

    /**
     * vd 生成指数
     */
    public int vd;

    /**
     * 皮肤变黑指数
     */
    public int skin;

    /**
     * 皮肤受损风险
     */
    public int skinCancer;

    public UltravioletInfo(String userID, String mac, long time, int value, int vd, int skin, int skinCancer) {
        this.userID = userID;
        this.time = time;
        this.value = value;
        this.vd = vd;
        this.skin = skin;
        this.skinCancer = skinCancer;
    }

    public UltravioletInfo(JWUltravioletInfo info) {
        this.userID = info.userID;
        this.deviceMac = info.deviceMac;
        this.time = info.time;
        this.value = info.value;
        this.vd = info.vd;
        this.skin = info.skin;
        this.skinCancer = info.skinCancer;
        this.deviceMac = info.deviceMac;
    }

    public JWUltravioletInfo convertToJWUltravioletInfo() {
        JWUltravioletInfo info = new JWUltravioletInfo();

        info.userID = this.userID;
        info.deviceMac = deviceMac;
        info.time = this.time;
        info.value = this.value;
        info.vd = this.vd;
        info.skin = this.skin;
        info.skinCancer = this.skinCancer;
        return info;
    }
}
