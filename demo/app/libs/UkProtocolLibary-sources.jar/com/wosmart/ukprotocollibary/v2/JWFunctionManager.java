package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.JWAddressBook;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWDrinkWaterReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWFemaleHealthInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdConfigInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWMedicationReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPrivateBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWeatherInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodSugarContinuousMonitoringFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWDefaultFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWHealthRiskAssessmentInfo;

import java.util.List;

public abstract class JWFunctionManager {

    static JWFunctionManager getInstance() {
        return JWFunctionManagerImpl.getInstance();
    }

    /**
     * add function listener
     * 添加功能监听
     */
    public abstract void addFunctionListener(JWFunctionListener listener);

    /**
     * remove function listener
     * 移除功能监听
     */
    public abstract void removeFunctionListener(JWFunctionListener listener);

    /**
     * add function change listener
     * 添加功能更新监听
     */
    public abstract void addFunctionChangeListener(JWFunctionChangeListener listener);

    /**
     * remove function change listener
     * 移除功能更新监听
     */
    public abstract void removeFunctionChangeListener(JWFunctionChangeListener listener);

    /**
     * set take photo control
     * <p>
     * If the status is open, you should set the listener in advance {@link JWFunctionManager#addFunctionListener}
     * and it will be triggered by {@link JWFunctionListener#onTakePhoto()}
     *
     * @param enable true is open
     */
    public abstract void setTakePhotoControl(boolean enable, JWCallback callback);

    /**
     * set private blood pressure info
     *
     * @param privateBloodPressureInfo private blood pressure info {@link JWPrivateBloodPressureInfo}
     */
    public abstract void setPrivateBloodPressureInfo(JWPrivateBloodPressureInfo privateBloodPressureInfo, JWCallback callback);

    /**
     * get private blood pressure info
     */
    public abstract void getPrivateBloodPressureInfo(JWValueCallback<JWPrivateBloodPressureInfo> callback);

    /**
     * set temperature reminder
     * 设置体温提醒
     *
     * @param reminderInfo reminder info {@link JWTemperatureReminderInfo}
     */
    public abstract void setTemperatureReminder(JWTemperatureReminderInfo reminderInfo, JWCallback callback);

    /**
     * get temperature reminder info
     * 获取体温提醒信息
     */
    public abstract void getTemperatureReminder(JWValueCallback<JWTemperatureReminderInfo> callback);

    /**
     * set drink water reminder
     * 设置喝水提醒
     *
     * @param reminderInfo reminder info {@link JWDrinkWaterReminderInfo}
     */
    public abstract void setDrinkWaterReminder(JWDrinkWaterReminderInfo reminderInfo, JWCallback callback);

    /**
     * get drink water reminder info
     * 获取喝水提醒
     */
    public abstract void getDrinkWaterReminder(JWValueCallback<JWDrinkWaterReminderInfo> callback);

    /**
     * set medication reminder
     * 设置吃药提醒
     *
     * @param reminderInfoList reminder info
     */
    public abstract void setMedicationReminder(List<JWMedicationReminderInfo> reminderInfoList, JWCallback callback);

    /**
     * get medication reminder
     * 获取吃药提醒信息
     */
    public abstract void getMedicationReminder(JWValueCallback<List<JWMedicationReminderInfo>> callback);

    /**
     * set pulse
     *
     * @param enable   true is open
     * @param duration 1 - 15, unit min
     * @param level    1 - 7
     */
    public abstract void setPulse(boolean enable, int duration, int level, JWCallback callback);

    /**
     * set sleep help
     *
     * @param enable        true is open
     * @param mode          0 - 2
     * @param duration      1 - 120, unit min
     * @param effectiveTime 1 - 120, unit min, must be less than duration
     * @param level         1 - 7
     * @return callback status 0(close) 1(open) 2(busy)
     */
    public abstract void setSleepHelp(boolean enable, int mode, int duration, int effectiveTime, int level, JWValueCallback<Integer> callback);

    /**
     * set female health info
     *
     * @param healthInfo female health info {@link JWFemaleHealthInfo}
     */
    public abstract void setFemaleHealth(JWFemaleHealthInfo healthInfo, JWCallback callback);

    /**
     * set weather info
     *
     * @param weatherInfo weather info {@link JWWeatherInfo}
     */
    public abstract void setWeather(JWWeatherInfo weatherInfo, JWCallback callback);

    /**
     * set temperature control
     *
     * @param enable        true open false close
     * @param isAdjust      temperature adjust
     * @param isCelsiusUnit true celsius false fahrenheit
     */
    public abstract void setTemperatureControl(boolean enable, boolean isAdjust, boolean isCelsiusUnit, JWCallback callback);

    /**
     * set uric acid
     * 设置尿酸
     *
     * @param enable         true open false close
     * @param privateValue   privateValue
     *                       私人值 男性：238~356 μmol/L man 女性：178~297 μmol/L female
     * @param privateRTCTime 设置私人值时间，默认值为0，精确到秒
     *                       default is 0, unit second
     */
    public abstract void setUricAcid(boolean enable, int privateValue, int privateRTCTime, JWCallback callback);

    /**
     * set blood fat
     * 设置血脂
     *
     * @param enable         true open false close
     * @param privateValue   privateValue
     *                       私人值 男性：238~356 μmol/L man 女性：178~297 μmol/L female
     * @param privateRTCTime 设置私人值时间，默认值为0，精确到秒
     *                       default is 0, unit second
     */
    public abstract void setBloodFat(boolean enable, int privateValue, int privateRTCTime, JWCallback callback);

    /**
     * set blood sugar cycle
     * 设置血糖周期
     *
     * @param enable         true open false close
     * @param privateValue   privateValue
     *                       私人值 4.0 - 7.0 μmol/L
     * @param privateRTCTime 设置私人值时间，默认值为0，精确到秒
     *                       default is 0, unit second
     */
    public abstract void setBloodSugarCycle(boolean enable, float privateValue, int privateRTCTime, JWCallback callback);

    /**
     * set private uric acid
     * 设置私人尿酸
     *
     * @param enable true open false close
     * @param value  value, default is 250 - 300, range is 80 - 500
     */
    public abstract void setPrivateUricAcid(boolean enable, int value, JWCallback callback);

    /**
     * set private blood fat
     * 设置私人血脂
     *
     * @param enable true open false close
     * @param value  value, default is 1.0 - 3.0, range is 0.5 - 8.0
     */
    public abstract void setPrivateBloodFat(boolean enable, float value, JWCallback callback);

    /**
     * get blood sugar continuous monitoring
     * 获取血糖自动监测信息
     */
    public abstract void getBloodSugarContinuousMonitoring(JWValueCallback<JWBloodSugarContinuousMonitoringFunctionInfo> callback);

    /**
     * set blood sugar continuous monitoring
     * 设置血糖自动监测
     *
     * @param enable   true open false close
     * @param interval 间隔，单位 分钟，unit min
     */
    public abstract void setBloodSugarContinuousMonitoring(boolean enable, int interval, JWCallback callback);

    /**
     * set uric acid continuous monitoring
     * 设置尿酸自动监测
     *
     * @param enable true open false close
     */
    public abstract void setUricAcidContinuousMonitoring(boolean enable, JWCallback callback);

    /**
     * set blood fat continuous monitoring
     * 设置血脂自动监测
     *
     * @param enable true open false close
     */
    public abstract void setBloodFatContinuousMonitoring(boolean enable, JWCallback callback);

    /**
     * set pressure continuous monitoring
     * 设置压力自动监测
     *
     * @param enable true open false close
     */
    public abstract void setPressureContinuousMonitoring(boolean enable, JWCallback callback);

    /**
     * set body fat measure
     * 设置体脂监测
     *
     * @param enable true open false close
     */
    public abstract void setBodyFatMeasure(boolean enable, JWCallback callback);

    /**
     * get recent body fat info
     * 获取最近的体脂测量信息
     */
    public abstract void getRecentBodyFat(JWValueCallback<JWBodyFatInfo> callback);

    /**
     * get physical exam info
     * 获取体检信息
     */
    public abstract void getPhysicalExam(JWValueCallback<JWPhysicalExamInfo> callback);

    /**
     * sync ultraviolet info
     * 请求同步紫外线信息
     */
    public abstract void syncUltraviolet(JWCallback callback);

    /**
     * sync pressure info
     * 请求同步压力信息
     */
    public abstract void syncPressure(JWCallback callback);

    /**
     * set ecg belt measure
     * 设置心电带监测
     *
     * @param enable true open false close
     */
    public abstract void setEcgBeltMeasure(boolean enable, JWCallback callback);

    /**
     * set HRV-rmssd
     *
     * @param enable   true open false close
     * @param interval only support 5 min/times 10 min/times 15 min/times
     */
    public abstract void setHRVRmssd(boolean enable, int interval, JWCallback callback);

    /**
     * read HRV-rmssd config info
     */
    public abstract void readHRVRmssdConfig(JWValueCallback<JWHRVRmssdConfigInfo> callback);

    /**
     * set blood sugar risk assessment
     * @param enable true open false close
     */
    public abstract void setBloodSugarRiskAssessment(boolean enable, JWCallback callback);

    /**
     * set uric acid risk assessment
     * @param enable true open false close
     */
    public abstract void setUricAcidRiskAssessment(boolean enable, JWCallback callback);

    /**
     * set blood fat risk assessment
     * @param enable true open false close
     */
    public abstract void setBloodFatRiskAssessment(boolean enable, JWCallback callback);

    /**
     * read health risk assessment info
     */
    public abstract void readHealthRiskAssessment(JWValueCallback<JWHealthRiskAssessmentInfo> callback);

    /**
     * set default function
     *
     * @param defaultFunctionInfo   function info
     */
    public abstract void setDefaultFunction(JWDefaultFunctionInfo defaultFunctionInfo, JWCallback callback);

    /**
     * read default function
     */
    public abstract void readDefaultFunction(JWValueCallback<JWDefaultFunctionInfo> callback);

    /**
     * set address book
     *
     * @param addressBookList address book list
     */
    public abstract void setAddressBook(List<JWAddressBook> addressBookList, JWCallback callback);

    /**
     * set sos number
     *
     * @param numberList number list
     */
    public abstract void setSOSNumber(List<JWAddressBook> numberList, JWCallback callback);

}
