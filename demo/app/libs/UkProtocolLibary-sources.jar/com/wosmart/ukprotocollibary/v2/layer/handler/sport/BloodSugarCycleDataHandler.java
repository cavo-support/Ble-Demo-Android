package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import com.wosmart.ukprotocollibary.util.DateUtil;
import com.wosmart.ukprotocollibary.v2.db.entity.BloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWBloodSugarCycleInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;

import java.util.ArrayList;
import java.util.List;

public class BloodSugarCycleDataHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        int packetLength = 16;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return;
        }

        List<JWBloodSugarCycleInfo> dataList = new ArrayList<>();
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            long cycleStartTime = (((subData[0] & 0xff)) | ((subData[1] & 0xff) << 8) | ((subData[2] & 0xff) << 16) | ((subData[3] & 0xff) << 24));
            int dayStatusList = (((subData[4] & 0xff)) | ((subData[5] & 0xff) << 8) | ((subData[6] & 0xff) << 16) | ((subData[7] & 0xff) << 24));
            long valueTime = (((subData[8] & 0xff)) | ((subData[9] & 0xff) << 8) | ((subData[10] & 0xff) << 16) | ((subData[11] & 0xff) << 24));
            int evaluationResult = subData[12] & 0xff;

            JWBloodSugarCycleInfo info = new JWBloodSugarCycleInfo();

            long time = DateUtil.getDate(2000, 1, 1);

            cycleStartTime = cycleStartTime * 1000 + time;
            valueTime = valueTime == 0 ? 0 : (valueTime * 1000 + time);

            long cycleEndTime = cycleStartTime + 24 * 3600000 * 13;

            // 结束时间为当天最后 1 秒
            cycleEndTime = DateUtil.getLastSecondOfTheDay(cycleEndTime);

            info.cycleStartTime = cycleStartTime;
            info.cycleEndTime = cycleEndTime;
            info.userID = BaseManager.getInstance().getUserID();
            info.deviceMac = BaseManager.getInstance().getMacAddress();
            info.evaluationResult = evaluationResult;
            info.valueTime = valueTime;
            info.dayStatusList = BloodSugarCycleInfo.convertDayStatusList(cycleStartTime, dayStatusList);

            dataList.add(info);
        }
        if (TransportManager.getInstance().getSyncDataListener() == null) {
            return;
        }
        TransportManager.getInstance().getSyncDataListener().onBloodSugarCycleDataReceived(dataList);

    }
}
