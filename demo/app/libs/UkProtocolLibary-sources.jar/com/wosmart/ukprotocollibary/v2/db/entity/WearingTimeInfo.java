package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWWearingTimeInfo;

public class WearingTimeInfo extends BaseHealthDataInfo {

    public int wearStatus;

    public WearingTimeInfo(long time, String userID, String mac, int wearStatus) {
        this.time = time;
        this.userID = userID;
        this.deviceMac = mac;
        this.wearStatus = wearStatus;
    }

    public WearingTimeInfo(JWWearingTimeInfo info) {
        this.time = info.time;
        this.userID = info.userID;
        this.deviceMac = info.deviceMac;
        this.deviceMac = info.deviceMac;
        this.wearStatus = info.wearStatus;
    }

    public JWWearingTimeInfo convertToJWWearingTimeInfo() {
        JWWearingTimeInfo info = new JWWearingTimeInfo();
        info.time = time;
        info.userID = userID;
        info.deviceMac = deviceMac;
        info.wearStatus = wearStatus;

        return info;
    }



}
