package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWHeartRateVariabilityInfo extends JWHealthData implements Serializable {

    /**
     * unit ms
     * 单位 ms
     */
    public int value;

    @Override
    public String toString() {
        return "JWHeartRateVariabilityInfo{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", value=" + value +
                '}';
    }
}
