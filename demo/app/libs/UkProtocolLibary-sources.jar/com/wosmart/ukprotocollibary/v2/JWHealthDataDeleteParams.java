package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.JWHealthData;

public class JWHealthDataDeleteParams {

    private JWHealthData.DateType dataType;
    private String userID;
    private String deviceMac;
    private long timeBegin;
    private long timePeriod;

    /**
     * data type
     *
     * @param dataType {@link JWHealthData.DateType}
     */
    public void setDataType(JWHealthData.DateType dataType) {
        this.dataType = dataType;
    }

    public JWHealthData.DateType getDataType() {
        return this.dataType;
    }

    public String getUserID() {
        return userID;
    }

    /**
     * if you have multiple devices, you can distinguish by user ID
     *
     * @param userID default is null, means delete all
     *               默认为空，即删除所有
     */
    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getDeviceMac() {
        return deviceMac;
    }

    /**
     * if you have multiple devices, you can distinguish by mac address
     *
     * @param deviceMac default is null, means delete all
     *                  默认为空，即删除所有
     */
    public void setDeviceMac(String deviceMac) {
        this.deviceMac = deviceMac;
    }

    public long getTimeBegin() {
        return timeBegin;
    }

    /**
     * begin of time, unit: millisecond
     * 开始时间，单位毫秒
     *
     * @param timeBegin the starting point of the time range
     */
    public void setTimeBegin(long timeBegin) {
        this.timeBegin = timeBegin;
    }

    public long getTimePeriod() {
        return timePeriod;
    }

    /**
     * period of time, unit: millisecond, 24x60x60x1000 means one day
     * 时间周期，单位毫秒
     *
     * @param timePeriod period of time
     */
    public void setTimePeriod(long timePeriod) {
        this.timePeriod = timePeriod;
    }
}
