package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import com.wosmart.ukprotocollibary.v2.common.JWBridge;
import com.wosmart.ukprotocollibary.v2.entity.JWSpO2Info;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;

import java.util.ArrayList;
import java.util.List;

public class SpO2DataHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        int packetLength = 8;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return;
        }
        List<JWSpO2Info> dataList = new ArrayList<>();
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            int year = (subData[0] & 0x7e) >> 1;
            int month = ((subData[0] & 0x01) << 3) | (subData[1] >> 5) & 0x07;
            int day = subData[1] & 0x1f;
            int minutes = ((subData[2] << 8) | (subData[3] & 0xff)) & 0xffff;
            int second = (subData[4] & 0xff);
            int curValue = (subData[5] & 0xff);
            int highValue = (subData[6] & 0xff);
            int lowValue = (subData[7] & 0xff);

            JWSpO2Info info = new JWSpO2Info();

            long time = JWBridge.getTime(year, month, day);
            time += minutes * 60000;
            time += second * 1000;

            info.setTime(time);
            info.userID = BaseManager.getInstance().getUserID();
            info.deviceMac = BaseManager.getInstance().getMacAddress();
            info.curValue = curValue;
            info.lowValue = lowValue;
            info.highValue = highValue;

            dataList.add(info);
        }
        if (TransportManager.getInstance().getSyncDataListener() == null) {
            return;
        }
        TransportManager.getInstance().getSyncDataListener().onSpO2DataReceived(dataList);

    }
}
