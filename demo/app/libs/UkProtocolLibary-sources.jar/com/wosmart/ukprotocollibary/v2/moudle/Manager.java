package com.wosmart.ukprotocollibary.v2.moudle;

import com.wosmart.ukprotocollibary.v2.BaseConstants;
import com.wosmart.ukprotocollibary.v2.JWManager;
import com.wosmart.ukprotocollibary.v2.common.BleCallback;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

public class Manager {


    protected void sendNormalData(byte[] appPacketData, BleCallback<Void> callback) {
        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_NONE, new SendPacketCallback() {

            @Override
            public void onSendSuccess() {
                if (callback != null) {
                    callback.success(null);
                }
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    protected boolean checkSDKInit(BleCallback callback) {
        if (!BaseManager.getInstance().isInited()) {
            if (callback != null) {
                callback.fail(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init");
            }
            return false;
        }
        return true;
    }

    protected boolean checkEnvironment(BleCallback callback) {
        if (!BaseManager.getInstance().isInited()) {
            if (callback != null) {
                callback.fail(BaseConstants.ERR_SDK_NOT_INITIALIZED, "sdk not init");
            }
            return false;
        }
        if (BaseManager.getInstance().getConnStatus() != JWManager.CONN_STATUS_CONNECTED) {
            if (callback != null) {
                callback.fail(BaseConstants.ERR_DEVICE_NOT_CONNECTED, "device not connected");
            }
            return false;
        }
        return true;
    }

}
