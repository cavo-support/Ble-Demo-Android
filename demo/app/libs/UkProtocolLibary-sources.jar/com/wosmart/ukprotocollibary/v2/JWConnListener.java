package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.JWDeviceFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWDeviceInfo;

public interface JWConnListener extends JWErrorCallback {

    /**
     * connecting
     */
    void onConnecting();

    /**
     * connect success -- 连接成功
     *
     * @param deviceInfo   设备信息
     * @param functionInfo 功能列表
     */
    void onConnectSuccess(JWDeviceInfo deviceInfo, JWDeviceFunctionInfo functionInfo);

    /**
     * connect failed
     */
    void onConnectFailed(int code, String error);

    void onDisConnected();

}
