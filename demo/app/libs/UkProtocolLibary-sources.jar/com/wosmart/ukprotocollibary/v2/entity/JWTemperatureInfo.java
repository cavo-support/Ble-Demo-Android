package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWTemperatureInfo extends JWHealthData implements Serializable {


    /**
     * temperature value, unit celsius
     * 校准温度，单位 摄氏度
     */
    public float temperatureValue;

    /**
     * temperature origin value, unit celsius
     * 原始温度，单位 摄氏度
     */
    public float temperatureOriginValue;

    /**
     * temperature wear status
     * 佩戴状态
     */
    public boolean wearStatus;

    /**
     * temperature compensation status
     * 温度补偿状态
     */
    public boolean compensationStatus;

    @Override
    public String toString() {
        return "JWTemperatureInfo{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", temperatureValue=" + temperatureValue +
                ", temperatureOriginValue=" + temperatureOriginValue +
                ", wearStatus=" + wearStatus +
                ", compensationStatus=" + compensationStatus +
                '}';
    }
}
