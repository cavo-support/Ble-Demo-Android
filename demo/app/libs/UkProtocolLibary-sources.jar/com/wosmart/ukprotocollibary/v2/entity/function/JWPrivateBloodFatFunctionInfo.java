package com.wosmart.ukprotocollibary.v2.entity.function;


import java.io.Serializable;

public class JWPrivateBloodFatFunctionInfo extends JWCommonFunctionInfo implements Serializable {

    /**
     * default is 1.0 - 3.0, range is 0.5 - 8.0
     */
    public float value;


    @Override
    public String toString() {
        return "JWPrivateBloodFatFunctionInfo{" +
                "value=" + value +
                ", isOpen=" + enable +
                '}';
    }
}
