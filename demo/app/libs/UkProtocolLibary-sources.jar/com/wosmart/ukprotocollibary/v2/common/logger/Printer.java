package com.wosmart.ukprotocollibary.v2.common.logger;


/**
 * A proxy interface to enable additional operations.
 * Contains all possible Log message usages.
 */
public interface Printer {

  void addAdapter(int logType, LogAdapter adapter);

  void log(int logType, int priority, String tag, String message, Throwable throwable);


  void json(int logType, String json);

  void xml(int logType, String xml);

  void clearLogAdapters(int logType);

}
