package com.wosmart.ukprotocollibary.v2.layer.handler.control;

import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;

public class FindPhoneRsp2Handler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        if (data == null || data.length != 1) {
            return;
        }
        TransportManager.getInstance().getFunctionListener().onFindPhone((data[0] & 0xFF) == 0x01);
    }

}
