package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWStepInfo;

public class StepInfo extends BaseHealthDataInfo {

    public int stepCount;

    public int calorie;

    public int distance;

    public int mode;

    public int activeTime;


    public StepInfo(long time, String userID, String mac, int stepCount, int calorie, int distance, int mode, int activeTime) {
        this.time = time;
        this.userID = userID;
        this.stepCount = stepCount;
        this.calorie = calorie;
        this.distance = distance;
        this.mode = mode;
        this.activeTime = activeTime;
    }

    public StepInfo(JWStepInfo info) {
        this.time = info.getTime();
        this.userID = info.getUserID();
        this.deviceMac = info.deviceMac;
        this.stepCount = info.stepCount;
        this.calorie = info.calorie;
        this.distance = info.distance;
        this.mode = info.mode;
        this.activeTime = info.activeTime;
    }

    public JWStepInfo convertToJWStepInfo() {
        JWStepInfo info = new JWStepInfo();
        info.setUserID(userID);
        info.deviceMac = deviceMac;
        info.setTime(time);
        info.stepCount = (stepCount);
        info.calorie = (calorie);
        info.distance = (distance);
        info.mode = (mode);
        info.activeTime = (activeTime);

        return info;
    }

}
