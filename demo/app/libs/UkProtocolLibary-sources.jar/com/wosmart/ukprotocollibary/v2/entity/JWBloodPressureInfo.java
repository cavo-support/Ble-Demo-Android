package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWBloodPressureInfo extends JWHealthData implements Serializable {

    /**
     * bp low value, unit mmHg
     * 低压 单位 mmHg
     */
    public int lowValue;

    /**
     * bp high value, unit mmHg
     * 高压 单位 mmHg
     */
    public int highValue;

    @Override
    public String toString() {
        return "JWBloodPressureInfo{" +
                "userID='" + userID + '\'' +
                ", time=" + time +
                ", lowValue=" + lowValue +
                ", highValue=" + highValue +
                '}';
    }
}
