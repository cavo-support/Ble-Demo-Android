package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodFatFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodSugarCycleFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWUricAcidFunctionInfo;

public class JWFunctionChangeListener {

    /**
     * 尿酸改变
     * uric acid changed
     *
     * @param functionInfo 尿酸功能信息
     */
    public void onUricAcidFunctionChanged(JWUricAcidFunctionInfo functionInfo) {

    }

    /**
     * 血脂改变
     * blood fat changed
     *
     * @param functionInfo 血脂功能信息
     */
    public void onBloodFatFunctionChanged(JWBloodFatFunctionInfo functionInfo) {

    }

    /**
     * 血糖周期改变
     * blood sugar cycle changed
     *
     * @param functionInfo 血糖功能信息
     */
    public void onBloodSugarCycleFunctionChanged(JWBloodSugarCycleFunctionInfo functionInfo) {

    }

}
