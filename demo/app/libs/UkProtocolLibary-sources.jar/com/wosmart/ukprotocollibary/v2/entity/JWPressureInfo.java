package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWPressureInfo extends JWHealthData implements Serializable {

    /**
     * 压力
     */
    public int value;

}
