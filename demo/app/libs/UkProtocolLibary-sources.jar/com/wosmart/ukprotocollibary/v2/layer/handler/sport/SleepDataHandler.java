package com.wosmart.ukprotocollibary.v2.layer.handler.sport;

import com.wosmart.ukprotocollibary.v2.common.JWBridge;
import com.wosmart.ukprotocollibary.v2.entity.JWSleepInfo;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;

import java.util.ArrayList;
import java.util.List;

public class SleepDataHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        int packetLength = 8;
        if ((data.length < packetLength) || (data.length % packetLength) != 0) {
            return;
        }
        List<JWSleepInfo> dataList = new ArrayList<>();
        byte[] subData = new byte[packetLength];
        for (int i = 0; i < data.length / packetLength; i++) {
            System.arraycopy(data, i * packetLength, subData, 0, packetLength);

            int year = (subData[0] & 0x7e) >> 1;
            int month = ((subData[0] & 0x01) << 3) | (subData[1] >> 5) & 0x07;
            int day = subData[1] & 0x1f;
            int count = subData[3] & 0xff;// 现在 count 已废弃, 只会有一条数据
            int minutes = ((subData[4] << 8) | (subData[5] & 0xff)) & 0xffff;
            int mode = subData[7] & 0x0f;

            JWSleepInfo info = new JWSleepInfo();

            long time = JWBridge.getTime(year, month, day);
            time += minutes * 60000;

            info.setTime(time);
            info.userID = BaseManager.getInstance().getUserID();
            info.deviceMac = BaseManager.getInstance().getMacAddress();
            info.mode = mode;

            dataList.add(info);
        }
        if (TransportManager.getInstance().getSyncDataListener() == null) {
            return;
        }
        TransportManager.getInstance().getSyncDataListener().onSleepDataReceived(dataList);

    }

}

