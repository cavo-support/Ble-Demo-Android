package com.wosmart.ukprotocollibary.v2.layer;

public class SendPacket {

    public byte[] data;

    public SendPacketCallback callback;

    public boolean isAck = false;

}
