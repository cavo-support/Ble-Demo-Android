package com.wosmart.ukprotocollibary.v2.db.entity;

import com.wosmart.ukprotocollibary.v2.entity.JWBloodFatContinuousMonitoringInfo;
import com.wosmart.ukprotocollibary.v2.utils.JWUtils;

public class BloodFatContinuousMonitoringInfo extends BaseHealthDataInfo {

    public int value;

    public BloodFatContinuousMonitoringInfo(long time, String userID, String mac, int value) {
        this.time = time;
        this.userID = userID;
        this.deviceMac = mac;
        this.value = value;
    }

    public BloodFatContinuousMonitoringInfo(JWBloodFatContinuousMonitoringInfo info) {
        this.time = info.time;
        this.userID = info.userID;
        this.deviceMac = info.deviceMac;
        this.value = (int) (info.value * 100);
    }

    public JWBloodFatContinuousMonitoringInfo convertToJWBloodFatContinuousMonitoringInfo() {
        JWBloodFatContinuousMonitoringInfo info = new JWBloodFatContinuousMonitoringInfo();
        info.userID = userID;
        info.deviceMac = deviceMac;
        info.time = time;
        info.value = JWUtils.parserRound(2, value / 100f);

        return info;
    }

}
