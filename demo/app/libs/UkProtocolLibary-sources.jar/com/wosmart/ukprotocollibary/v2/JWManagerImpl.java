package com.wosmart.ukprotocollibary.v2;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.text.TextUtils;

import com.wosmart.ukprotocollibary.v2.common.BleCallback;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.ScanManager;

public class JWManagerImpl extends JWManager {

    public static JWManagerImpl getInstance() {
        return JWManagerImplHolder.jwManagerImpl;
    }

    protected JWManagerImpl() {
    }

    @Override
    public boolean initSDK(Context context, JWSDKConfig config) {
        return BaseManager.getInstance().initSDK(context, config);
    }

    @Override
    public int getConnStatus() {
        return BaseManager.getInstance().getConnStatus();
    }

    @Override
    public void scanDevice(JWScanCallback callback) {
        if (!BaseManager.getInstance().isInited()) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "SDK not initialized");
            }
            return;
        }
        if (!BaseManager.getInstance().isBluetoothEnable()) {
            if (callback != null) {
                callback.onError(BaseConstants.ERR_BLUETOOTH_UN_ENABLE, "please check bluetooth enable");
            }
            return;
        }

        ScanManager.getInstance().scanDevice(callback);
    }

    @Override
    public void stopScan() {
        ScanManager.getInstance().stopScan();
    }

    @Override
    public void connectDevice(String macAddress, String userID, JWConnListener connListener) {
        if (connListener == null) {
            return;
        }
        if (TextUtils.isEmpty(macAddress)) {
            connListener.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "mac address cannot be empty");
            return;
        }
        if (!BaseManager.getInstance().isBluetoothEnable()) {
            connListener.onError(BaseConstants.ERR_BLUETOOTH_UN_ENABLE, "please check bluetooth enable");
            return;
        }
        if (!BluetoothAdapter.checkBluetoothAddress(macAddress)) {
            connListener.onError(BaseConstants.ERR_SDK_NOT_INITIALIZED, "invalid mac address");
            return;
        }
        BaseManager.getInstance().connectDevice(macAddress, userID, connListener);
    }

    @Override
    public void disconnectDevice(JWCallback callback) {
        BaseManager.getInstance().disconnectDevice(new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }

    @Override
    public void unbindDevice(JWCallback callback) {
        BaseManager.getInstance().unbindDevice(new BleCallback<Void>(callback) {
            @Override
            public void success(Void data) {
                super.success(data);
            }

            @Override
            public void fail(int code, String errorMessage) {
                super.fail(code, errorMessage);
            }
        });
    }



    private static class JWManagerImplHolder {
        private static final JWManagerImpl jwManagerImpl = new JWManagerImpl();
    }

}
