package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWAllNotifyConfigInfo implements Serializable {

    /**
     * phone call
     */
    public boolean call = false;

    /**
     * phone message
     */
    public boolean sms = false;

    /**
     * qq notify
     */
    public boolean qq = false;

    /**
     * wechat notify
     */
    public boolean wechat = false;

    /**
     * line notify
     */
    public boolean line = false;

    /**
     * twitter notify
     */
    public boolean twitter = false;

    /**
     * facebook notify
     */
    public boolean facebook = false;

    /**
     * messenger notify
     */
    public boolean messenger = false;

    /**
     * whatsapp notify
     */
    public boolean whatsapp = false;

    /**
     * linkedin notify
     */
    public boolean linkedin = false;

    /**
     * instagram notify
     */
    public boolean instagram = false;

    /**
     * skype notify
     */
    public boolean skype = false;

    /**
     * viber notify
     */
    public boolean viber = false;

    /**
     * kakaoTalk notify
     */
    public boolean kakaoTalk = false;

    /**
     * vkontakte notify
     */
    public boolean vkontakte = false;

    /**
     * tim notify
     */
    public boolean tim = false;

    /**
     * gmail notify
     */
    public boolean gmail = false;

    /**
     * ding talk notify
     */
    public boolean dingTalk = false;


    /**
     * weWork notify
     */
    public boolean workWeChat = false;

    /**
     * other notify
     */
    public boolean other = false;

}
