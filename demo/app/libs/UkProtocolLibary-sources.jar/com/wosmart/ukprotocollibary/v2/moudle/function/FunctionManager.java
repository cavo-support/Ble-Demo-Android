package com.wosmart.ukprotocollibary.v2.moudle.function;

import android.annotation.SuppressLint;
import android.content.Context;

import com.wosmart.ukprotocollibary.util.SPWristbandConfigInfo;
import com.wosmart.ukprotocollibary.v2.BaseConstants;
import com.wosmart.ukprotocollibary.v2.JWFunctionListener;
import com.wosmart.ukprotocollibary.v2.common.BleCallback;
import com.wosmart.ukprotocollibary.v2.common.JWLog;
import com.wosmart.ukprotocollibary.v2.common.executor.JWArchTaskExecutor;
import com.wosmart.ukprotocollibary.v2.db.DatabaseManager;
import com.wosmart.ukprotocollibary.v2.db.dao.BodyFatInfoDao;
import com.wosmart.ukprotocollibary.v2.db.dao.PhysicalExamInfoDao;
import com.wosmart.ukprotocollibary.v2.db.entity.BodyFatInfo;
import com.wosmart.ukprotocollibary.v2.db.entity.PhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWAddressBook;
import com.wosmart.ukprotocollibary.v2.entity.JWBodyFatInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWDeviceIndependentSwitchInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWDrinkWaterReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWFemaleHealthInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdConfigInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWMedicationReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPhysicalExamInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPrivateBloodPressureInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWTemperatureReminderInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWWeatherInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodFatFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodSugarContinuousMonitoringFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWBloodSugarCycleFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWDefaultFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWHealthRiskAssessmentInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWPrivateBloodFatFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWPrivateUricAcidFunctionInfo;
import com.wosmart.ukprotocollibary.v2.entity.function.JWUricAcidFunctionInfo;
import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.moudle.Manager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.TempFunctionInfo;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

import java.util.List;

public class FunctionManager extends Manager {

    private static final String TAG = "FunctionManager";

    private Context context;

    private JWFunctionListener mFunctionListener;
    private JWFunctionListener mInternalFunctionListener;

    private static class FunctionManagerHolder {
        @SuppressLint("StaticFieldLeak")
        private static final FunctionManager settingsManager = new FunctionManager();
    }

    public static FunctionManager getInstance() {
        return FunctionManagerHolder.settingsManager;
    }

    public void init(Context context) {
        this.context = context;
        initListener();
    }

    private void initListener() {
        initFunctionListener();
    }



    public void setFunctionListener(JWFunctionListener listener) {
        if (!BaseManager.getInstance().isInited()) {
            return;
        }
        this.mFunctionListener = listener;
    }

    public void setTakePhotoControl(boolean enable, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setTakePhotoControl");

        byte[] appPacketData = FunctionPacketHelper.prepareSetTakePhotoControlPacket(enable);

        sendNormalData(appPacketData, callback);
    }

    public void setPrivateBloodPressure(JWPrivateBloodPressureInfo privateBloodPressureInfo, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setPrivateBloodPressure");
        // 2.0 血压需自己换算
        SPWristbandConfigInfo.setBpPrivateMode(context, privateBloodPressureInfo.enable);
        SPWristbandConfigInfo.setBpPrivateHigh(context, privateBloodPressureInfo.highValue);
        SPWristbandConfigInfo.setBpPrivateLow(context, privateBloodPressureInfo.lowValue);

        JWPrivateBloodPressureInfo privateBloodPressure = BaseManager.getInstance().getDeviceFunctionInfo().privateBloodPressure;
        if (privateBloodPressure != null) {
            // 3.0 血压设备支持私人血压
            byte[] appPacketData = FunctionPacketHelper.prepareSetPrivateBloodPressurePacket(privateBloodPressureInfo.enable, privateBloodPressureInfo.highValue, privateBloodPressureInfo.lowValue);

            sendNormalData(appPacketData, callback);
        }
    }

    public void getPrivateBloodPressure(BleCallback<JWPrivateBloodPressureInfo> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "getPrivateBloodPressure");
        JWPrivateBloodPressureInfo privateBloodPressureInfo = new JWPrivateBloodPressureInfo();

        privateBloodPressureInfo.enable = SPWristbandConfigInfo.getBpPrivateMode(context);
        privateBloodPressureInfo.highValue = SPWristbandConfigInfo.getBpPrivateHigh(context);
        privateBloodPressureInfo.lowValue = SPWristbandConfigInfo.getBpPrivateLow(context);

        callback.success(privateBloodPressureInfo);
    }

    public void setTemperatureReminder(JWTemperatureReminderInfo reminderInfo, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setTemperatureReminder");
        byte[] appPacketData = FunctionPacketHelper.prepareSetTemperatureReminderPacket(reminderInfo.enable, (int) (reminderInfo.value * 10));

        sendNormalData(appPacketData, callback);

        BaseManager.getInstance().getTempFunctionInfo().temperatureReminderInfo = reminderInfo;
    }

    public void getTemperatureReminder(BleCallback<JWTemperatureReminderInfo> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "getTemperatureReminder");
        callback.success(BaseManager.getInstance().getTempFunctionInfo().temperatureReminderInfo);
    }

    public void setDrinkWaterReminder(JWDrinkWaterReminderInfo drinkWaterReminderInfo, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setDrinkWaterReminder");
        byte[] appPacketData = FunctionPacketHelper.prepareSetDrinkWaterReminderPacket(drinkWaterReminderInfo.enable, drinkWaterReminderInfo.startHour,
                drinkWaterReminderInfo.startMin, drinkWaterReminderInfo.endHour, drinkWaterReminderInfo.endMin, drinkWaterReminderInfo.interval);

        sendNormalData(appPacketData, callback);

        BaseManager.getInstance().getTempFunctionInfo().drinkWaterReminderInfo = drinkWaterReminderInfo;
    }

    public void getDrinkWaterReminder(BleCallback<JWDrinkWaterReminderInfo> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "getDrinkWaterReminder");
        callback.success(BaseManager.getInstance().getTempFunctionInfo().drinkWaterReminderInfo);
    }

    public void setMedicationReminder(List<JWMedicationReminderInfo> reminderInfoList, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setMedicationReminder");
        byte[] appPacketData = FunctionPacketHelper.prepareSetMedicationReminderPacket(reminderInfoList);

        sendNormalData(appPacketData, callback);
    }

    public void getMedicationReminder(BleCallback<List<JWMedicationReminderInfo>> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "getMedicationReminder");
        byte[] appPacketData = FunctionPacketHelper.prepareGetMedicationReminderPacket();

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_GET_MEDICATION_REMINDER, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                if (callback == null) {
                    return;
                }
                if (data == null) {
                    callback.success(null);
                    return;
                }
                callback.success((List<JWMedicationReminderInfo>) data);
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }


    public void setPulse(boolean enable, int duration, int level, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setPulse");
        byte[] appPacketData = FunctionPacketHelper.prepareSetPulsePacket(enable, duration, level);

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_SET_PULSE, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                if (callback == null) {
                    return;
                }
                boolean result = (boolean) data;
                if (result) {
                    callback.success(null);
                } else {
                    callback.fail(BaseConstants.ERR_DEVICE_IS_BUSY, "device is busy");
                }
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    public void setSleepHelp(boolean enable, int mode, int duration, int effectiveTime, int level, BleCallback<Integer> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setSleepHelp");
        byte[] appPacketData = FunctionPacketHelper.prepareSetSleepHelpPacket(enable, mode, duration, effectiveTime, level);

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_SET_SLEEP_HELP, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                if (callback == null) {
                    return;
                }
                callback.success((Integer) data);
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    public void setFemaleHealth(JWFemaleHealthInfo healthInfo, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setFemaleHealth");
        byte[] appPacketData = FunctionPacketHelper.prepareSetFemaleHealthPacket(healthInfo);

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_SET_FEMALE_HEALTH, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                if (callback == null) {
                    return;
                }
                callback.success(null);
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    public void setWeather(JWWeatherInfo weatherInfo, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setWeather");
        byte[] appPacketData = FunctionPacketHelper.prepareSetWeatherPacket(weatherInfo);

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_SET_WEATHER, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                if (callback == null) {
                    return;
                }
                callback.success(null);
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    public void setTemperatureControl(boolean enable, boolean isAdjust, boolean isCelsiusUnit, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setTemperatureControl, enable = " + enable);

        SPWristbandConfigInfo.setTempMeasure(BaseManager.getInstance().getContext(), enable);
        SPWristbandConfigInfo.setTempAdjust(BaseManager.getInstance().getContext(), isAdjust);
        SPWristbandConfigInfo.setTempUnit(BaseManager.getInstance().getContext(), isCelsiusUnit);

        // 如果有独立开关配置，此时也需更改
        List<JWDeviceIndependentSwitchInfo> deviceIndependentSwitchInfoList = BaseManager.getInstance().getDeviceIndependentSwitchInfoList();
        if (deviceIndependentSwitchInfoList != null && !deviceIndependentSwitchInfoList.isEmpty()) {
            for (JWDeviceIndependentSwitchInfo switchInfo : deviceIndependentSwitchInfoList) {
                if (switchInfo.type == JWDeviceIndependentSwitchInfo.TYPE_TEMPERATURE_MONITOR) {
                    // 温度监测
                    switchInfo.enable = enable;
                } else if (switchInfo.type == JWDeviceIndependentSwitchInfo.TYPE_TEMPERATURE_ADJUST) {
                    // 温度补偿
                    switchInfo.enable = enable;
                }
            }
        }

        byte[] appPacketData = FunctionPacketHelper.prepareTemperatureControlPacket(enable, isAdjust, isCelsiusUnit);

        sendNormalData(appPacketData, callback);
    }


    public void setUricAcid(boolean enable, int privateValue, int privateRTCTime, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setUricAcid, enable = " + enable);

        TempFunctionInfo tempFunctionInfo = BaseManager.getInstance().getTempFunctionInfo();
        if (tempFunctionInfo.uricAcidFunctionInfo == null) {
            tempFunctionInfo.uricAcidFunctionInfo = new JWUricAcidFunctionInfo();
        }
        tempFunctionInfo.uricAcidFunctionInfo.enable = enable;
        tempFunctionInfo.uricAcidFunctionInfo.privateValue = privateValue;
        tempFunctionInfo.uricAcidFunctionInfo.privateRtcTime = privateRTCTime;

        byte[] appPacketData = FunctionPacketHelper.prepareSetUricAcidPacket(enable, privateValue, privateRTCTime);

        sendNormalData(appPacketData, callback);
    }


    public void setBloodFat(boolean enable, int privateValue, int privateRTCTime, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setBloodFat, enable = " + enable);

        TempFunctionInfo tempFunctionInfo = BaseManager.getInstance().getTempFunctionInfo();
        if (tempFunctionInfo.bloodFatFunctionInfo == null) {
            tempFunctionInfo.bloodFatFunctionInfo = new JWBloodFatFunctionInfo();
        }
        tempFunctionInfo.bloodFatFunctionInfo.enable = enable;
        tempFunctionInfo.bloodFatFunctionInfo.privateValue = privateValue;
        tempFunctionInfo.bloodFatFunctionInfo.privateRtcTime = privateRTCTime;

        byte[] appPacketData = FunctionPacketHelper.prepareSetBloodFatPacket(enable, privateValue, privateRTCTime);

        sendNormalData(appPacketData, callback);
    }

    public void setBloodSugarCycle(boolean enable, float privateValue, int privateRTCTime, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setBloodSugarCycle, enable = " + enable);

        TempFunctionInfo tempFunctionInfo = BaseManager.getInstance().getTempFunctionInfo();
        if (tempFunctionInfo.bloodSugarCycleFunctionInfo == null) {
            tempFunctionInfo.bloodSugarCycleFunctionInfo = new JWBloodSugarCycleFunctionInfo();
        }
        tempFunctionInfo.bloodSugarCycleFunctionInfo.enable = enable;
        tempFunctionInfo.bloodSugarCycleFunctionInfo.privateValue = privateValue;
        tempFunctionInfo.bloodSugarCycleFunctionInfo.privateRtcTime = privateRTCTime;

        byte[] appPacketData = FunctionPacketHelper.prepareSetBloodSugarCyclePacket(enable, (int) (privateValue * 10), privateRTCTime);

        sendNormalData(appPacketData, callback);
    }




    public void setPrivateUricAcid(boolean enable, int value, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setPrivateUricAcid, enable = " + enable);

        TempFunctionInfo tempFunctionInfo = BaseManager.getInstance().getTempFunctionInfo();
        if (tempFunctionInfo.privateUricAcidFunctionInfo == null) {
            tempFunctionInfo.privateUricAcidFunctionInfo = new JWPrivateUricAcidFunctionInfo();
        }
        tempFunctionInfo.privateUricAcidFunctionInfo.enable = enable;
        tempFunctionInfo.privateUricAcidFunctionInfo.value = value;

        byte[] appPacketData = FunctionPacketHelper.prepareSetPrivateUricAcidPacket(enable, value);

        sendNormalData(appPacketData, callback);
    }

    public void setPrivateBloodFat(boolean enable, float value, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setPrivateBloodFat, enable = " + enable);

        TempFunctionInfo tempFunctionInfo = BaseManager.getInstance().getTempFunctionInfo();
        if (tempFunctionInfo.privateBloodFatFunctionInfo == null) {
            tempFunctionInfo.privateBloodFatFunctionInfo = new JWPrivateBloodFatFunctionInfo();
        }
        tempFunctionInfo.privateBloodFatFunctionInfo.enable = enable;
        tempFunctionInfo.privateBloodFatFunctionInfo.value = value;

        byte[] appPacketData = FunctionPacketHelper.prepareSetPrivateBloodFatPacket(enable, value);

        sendNormalData(appPacketData, callback);
    }

    public void getBloodSugarContinuousMonitoring(BleCallback<JWBloodSugarContinuousMonitoringFunctionInfo> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "getBloodSugarContinuousMonitoring");

        byte[] appPacketData = FunctionPacketHelper.prepareGetBloodSugarContinuousMonitoringPacket();

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_GET_BLOOD_SUGAR_CONTINUOUS_MONITORING, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                if (data == null) {
                    return;
                }
                if (callback != null) {
                    callback.success((JWBloodSugarContinuousMonitoringFunctionInfo) data);
                }
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    public void setBloodSugarContinuousMonitoring(boolean enable, int interval, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setBloodSugarContinuousMonitoring, enable = " + enable);

        byte[] appPacketData = FunctionPacketHelper.prepareSetBloodSugarContinuousMonitoringPacket(enable, interval);

        sendNormalData(appPacketData, callback);
    }

    public void setUricAcidContinuousMonitoring(boolean enable, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setUricAcidContinuousMonitoring, enable = " + enable);

        byte[] appPacketData = FunctionPacketHelper.prepareSetUricAcidContinuousMonitoringPacket(enable);

        sendNormalData(appPacketData, callback);
    }

    public void setBloodFatContinuousMonitoring(boolean enable, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setBloodFatContinuousMonitoring, enable = " + enable);

        byte[] appPacketData = FunctionPacketHelper.prepareSetBloodFatContinuousMonitoringPacket(enable);

        sendNormalData(appPacketData, callback);
    }

    public void setPressureContinuousMonitoring(boolean enable, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setPressureContinuousMonitoring, enable = " + enable);

        byte[] appPacketData = FunctionPacketHelper.prepareSetPressureContinuousMonitoringPacket(enable);

        sendNormalData(appPacketData, callback);
    }


    public void setBodyFatMeasure(boolean enable, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setBodyFatMonitoring, enable = " + enable);

        byte[] appPacketData = FunctionPacketHelper.prepareSetBodyFatMeasurePacket(enable);

        sendNormalData(appPacketData, callback);
    }

    public void getRecentBodyFat(BleCallback<JWBodyFatInfo> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "getRecentBodyFat");

        byte[] appPacketData = FunctionPacketHelper.prepareGetRecentBodyFatPacket();

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_GET_BODY_FAT_HISTORY, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                if (data == null) {
                    return;
                }
                if (callback != null) {
                    callback.success((JWBodyFatInfo) data);
                }
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }


    public void getPhysicalExam(BleCallback<JWPhysicalExamInfo> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "getPhysicalExam");

        byte[] appPacketData = FunctionPacketHelper.prepareGetPhysicalExamPacket();

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_GET_PHYSICAL_EXAM_HISTORY, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                if (data == null) {
                    return;
                }
                if (callback != null) {
                    callback.success((JWPhysicalExamInfo) data);
                }
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    public void syncUltraviolet(BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "syncUltraviolet");

        byte[] appPacketData = FunctionPacketHelper.prepareSyncUltravioletPacket();

        sendNormalData(appPacketData, callback);
    }

    public void syncPressure(BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "syncPressure");

        byte[] appPacketData = FunctionPacketHelper.prepareSyncPressurePacket();

        sendNormalData(appPacketData, callback);
    }

    public void setEcgBeltMeasure(boolean enable, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setEcgBeltMeasure, enable = " + enable);

        byte[] appPacketData = FunctionPacketHelper.prepareSetEcgBeltPacket(enable);

        sendNormalData(appPacketData, callback);
    }

    public void setHRVRmssd(boolean enable, int interval, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setHRVRmssd, enable = " + enable + ", interval = " + interval);

        byte[] appPacketData = FunctionPacketHelper.prepareSetHRVRmssdPacket(enable, interval);

        sendNormalData(appPacketData, callback);
    }

    public void readHRVRmssdConfig(BleCallback<JWHRVRmssdConfigInfo> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "readHRVRmssdConfig");
        byte[] appPacketData = FunctionPacketHelper.prepareReadHRVRmssdConfigPacket();

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_READ_HRV_RMSSD_CONFIG, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                if (callback == null) {
                    return;
                }
                if (data == null) {
                    callback.success(null);
                    return;
                }
                callback.success((JWHRVRmssdConfigInfo) data);
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    public void setBloodSugarRiskAssessment(boolean enable, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setBloodSugarRiskAssessment, enable = " + enable);

        byte[] appPacketData = FunctionPacketHelper.prepareSetRiskAssessment((byte) 0, enable);

        sendNormalData(appPacketData, callback);
    }

    public void setUricAcidRiskAssessment(boolean enable, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setUricAcidRiskAssessment, enable = " + enable);

        byte[] appPacketData = FunctionPacketHelper.prepareSetRiskAssessment((byte) 1, enable);

        sendNormalData(appPacketData, callback);
    }

    public void setBloodFatRiskAssessment(boolean enable, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setBloodFatRiskAssessment, enable = " + enable);

        byte[] appPacketData = FunctionPacketHelper.prepareSetRiskAssessment((byte) 2, enable);

        sendNormalData(appPacketData, callback);
    }

    public void readHealthRiskAssessment(BleCallback<JWHealthRiskAssessmentInfo> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "readHealthRiskAssessment");
        byte[] appPacketData = FunctionPacketHelper.prepareReadHealthRiskAssessment();

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_READ_HEALTH_RISK_ASSESSMENT, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                if (callback == null) {
                    return;
                }
                if (data == null) {
                    callback.success(null);
                    return;
                }
                callback.success((JWHealthRiskAssessmentInfo) data);
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    public void setDefaultFunction(JWDefaultFunctionInfo functionInfo, BleCallback<Void> callback) {
        JWLog.i(TAG, "setDefaultFunction, functionInfo = " + functionInfo);

        byte[] appPacketData = FunctionPacketHelper.prepareSetDefaultFunctionPacket(functionInfo);

        sendNormalData(appPacketData, callback);
    }

    public void readDefaultFunction(BleCallback<JWDefaultFunctionInfo> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "readDefaultFunction");
        byte[] appPacketData = FunctionPacketHelper.prepareReadDefaultFunctionPacket();

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_READ_DEFAULT_FUNCTION, new SendPacketCallback() {
            @Override
            public void onResponse(Object data) {
                if (callback == null) {
                    return;
                }
                if (data == null) {
                    callback.success(null);
                    return;
                }
                callback.success((JWDefaultFunctionInfo) data);
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    private void initFunctionListener() {
        if (mInternalFunctionListener == null) {
            mInternalFunctionListener = new JWFunctionListener() {
                @Override
                public void onTakePhoto() {
                    if (mFunctionListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mFunctionListener.onTakePhoto();
                            }
                        });
                    }
                }

                @Override
                public void onFindPhone(boolean enable) {
                    if (mFunctionListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mFunctionListener.onFindPhone(enable);
                            }
                        });
                    }
                }

                @Override
                public void onDeviceMeasureStatusUpdated(int status) {
                    if (mFunctionListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mFunctionListener.onDeviceMeasureStatusUpdated(status);
                            }
                        });
                    }
                }

                @Override
                public void onBodyFatDataReceived(JWBodyFatInfo bodyFat) {
                    BodyFatInfoDao dao = DatabaseManager.getInstance().getBodyFatDao();
                    if (dao != null) {
                        dao.insertOrReplace(new BodyFatInfo(bodyFat));
                    }
                    if (mFunctionListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mFunctionListener.onBodyFatDataReceived(bodyFat);
                            }
                        });
                    }
                }

                @Override
                public void onPhysicalExamDataReceived(JWPhysicalExamInfo physicalExam) {
                    PhysicalExamInfoDao dao = DatabaseManager.getInstance().getPhysicalExamDao();
                    if (dao != null) {
                        dao.insertOrReplace(new PhysicalExamInfo(physicalExam));
                    }
                    if (mFunctionListener != null) {
                        JWArchTaskExecutor.getInstance().postToMainThread(new Runnable() {
                            @Override
                            public void run() {
                                mFunctionListener.onPhysicalExamDataReceived(physicalExam);
                            }
                        });
                    }
                }
            };
        }
        TransportManager.getInstance().setFunctionListener(mInternalFunctionListener);
    }





    public void setAddressBook(List<JWAddressBook> addressBookList, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        if (addressBookList == null || addressBookList.isEmpty()) {
            JWLog.i(TAG, "setAddressBook empty");
            // 清空 address book, 仅发送开始命令，同时 size = 0
            byte[] startPacketData = FunctionPacketHelper.prepareSetAddressBookStartOrEndPacket((byte) 0x00, 0);
            sendNormalData(startPacketData, callback);
            return;
        }

        JWLog.i(TAG, "setAddressBook start");
        byte[] startPacketData = FunctionPacketHelper.prepareSetAddressBookStartOrEndPacket((byte) 0x00, addressBookList.size());
        TransportManager.getInstance().sendData(startPacketData, CallbackKeyConstants.KEY_NONE, new SendPacketCallback() {

            @Override
            public void onSendSuccess() {
                // 发送开始命令成功，开始发送号码
                setAddressBook(addressBookList, 0, callback);
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    private void setAddressBook(List<JWAddressBook> addressBookList, int index, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setAddressBook sending index = " + index);
        JWAddressBook addressBook = addressBookList.get(index);

        byte[] appPacketData = FunctionPacketHelper.prepareSetAddressPacket(addressBook.addressName, addressBook.addressPhone);

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_SET_ADDRESS_BOOK, new SendPacketCallback() {

            @Override
            public void onResponse(Object data) {
                if ((boolean) data) {
                    // 发送成功，继续下一条
                    if (index == addressBookList.size() - 1) {
                        // 已经最后一条，发送结束命令
                        JWLog.i(TAG, "setAddressBook end");
                        byte[] endPacketData = FunctionPacketHelper.prepareSetAddressBookStartOrEndPacket((byte) 0x01, addressBookList.size());
                        sendNormalData(endPacketData, callback);
                    } else {
                        setAddressBook(addressBookList, index + 1, callback);
                    }
                } else {
                    if (callback != null) {
                        callback.fail(BaseConstants.ERR_SET_FAILED, "set address book failed");
                    }
                }
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    public void setSOSNumber(List<JWAddressBook> numberList, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        if (numberList == null || numberList.isEmpty()) {
            // 清空 sos, 仅发送开始命令，同时 size = 0
            JWLog.i(TAG, "setSOSNumber empty");
            byte[] startPacketData = FunctionPacketHelper.prepareSetSOSNumberStartOrEndPacket((byte) 0x00, 0);
            sendNormalData(startPacketData, callback);
            return;
        }

        JWLog.i(TAG, "setSOSNumber start");
        byte[] startPacketData = FunctionPacketHelper.prepareSetSOSNumberStartOrEndPacket((byte) 0x00, numberList.size());
        TransportManager.getInstance().sendData(startPacketData, CallbackKeyConstants.KEY_NONE, new SendPacketCallback() {

            @Override
            public void onSendSuccess() {
                // 发送开始命令成功，开始发送号码
                setSOSNumber(numberList, 0, callback);
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

    private void setSOSNumber(List<JWAddressBook> numberList, int index, BleCallback<Void> callback) {
        if (!checkEnvironment(callback)) {
            return;
        }
        JWLog.i(TAG, "setSOSNumber sending index = " + index);
        JWAddressBook addressBook = numberList.get(index);

        byte[] appPacketData = FunctionPacketHelper.prepareSetSOSNumberPacket(addressBook.addressName, addressBook.addressPhone);

        TransportManager.getInstance().sendData(appPacketData, CallbackKeyConstants.KEY_SET_SOS_NUMBER, new SendPacketCallback() {

            @Override
            public void onResponse(Object data) {
                if ((boolean) data) {
                    // 发送成功，继续下一条
                    if (index == numberList.size() - 1) {
                        // 已经最后一条，发送结束命令
                        JWLog.i(TAG, "setSOSNumber end");
                        byte[] endPacketData = FunctionPacketHelper.prepareSetSOSNumberStartOrEndPacket((byte) 0x01, numberList.size());
                        sendNormalData(endPacketData, callback);
                    } else {
                        setSOSNumber(numberList, index + 1, callback);
                    }
                } else {
                    if (callback != null) {
                        callback.fail(BaseConstants.ERR_SET_FAILED, "set sos number failed");
                    }
                }
            }

            @Override
            public void onSendFailed(int code, String desc) {
                if (callback != null) {
                    callback.fail(code, desc);
                }
            }
        });
    }

}
