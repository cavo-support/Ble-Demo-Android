package com.wosmart.ukprotocollibary.v2.layer.handler.control;

import android.util.SparseArray;

import com.wosmart.ukprotocollibary.v2.layer.SendPacketCallback;
import com.wosmart.ukprotocollibary.v2.layer.TransportManager;
import com.wosmart.ukprotocollibary.v2.layer.handler.AbstractDataHandler;
import com.wosmart.ukprotocollibary.v2.moudle.connector.BaseManager;
import com.wosmart.ukprotocollibary.v2.moudle.connector.TempFunctionInfoListener;
import com.wosmart.ukprotocollibary.v2.utils.CallbackKeyConstants;

public class SetFemaleHealthRspHandler extends AbstractDataHandler {

    @Override
    protected void action(byte[] data) {
        // 收到该命令即认为设置成功，无需解析数据
        SparseArray<SendPacketCallback> callbackMap = TransportManager.getInstance().getCallbackMap();
        SendPacketCallback callback = callbackMap.get(CallbackKeyConstants.KEY_SET_FEMALE_HEALTH);
        if (callback != null) {
            callback.onResponse(null);
            callbackMap.remove(CallbackKeyConstants.KEY_SET_FEMALE_HEALTH);
        }
    }

}
