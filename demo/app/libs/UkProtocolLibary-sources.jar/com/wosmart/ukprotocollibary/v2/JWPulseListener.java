package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.JWPulseInfo;

import java.util.List;

public interface JWPulseListener {

    /**
     * sync pulse data started
     */
    void onSyncDataStart(int totalCount);

    /**
     * pulse info received
     */
    void onPulseDataReceived(List<JWPulseInfo> pulseInfoList);

    /**
     * sync pulse data finished
     */
    void onSyncDataFinished();


    /**
     * after pulse finished, this callback will be trigger
     *
     * @param duration the pulse duration
     */
    void onPulseFinished(int duration);

}
