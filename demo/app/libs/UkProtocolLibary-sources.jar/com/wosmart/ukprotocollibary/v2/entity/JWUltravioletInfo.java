package com.wosmart.ukprotocollibary.v2.entity;

import java.io.Serializable;

public class JWUltravioletInfo extends JWHealthData implements Serializable {

    /**
     * 紫外等级
     */
    public int value;

    /**
     * vd 生成指数
     */
    public int vd;

    /**
     * 皮肤变黑指数
     */
    public int skin;

    /**
     * 皮肤受损风险
     */
    public int skinCancer;

}
