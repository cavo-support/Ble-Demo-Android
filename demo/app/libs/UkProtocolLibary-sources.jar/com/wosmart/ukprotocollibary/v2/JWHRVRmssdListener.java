package com.wosmart.ukprotocollibary.v2;

import com.wosmart.ukprotocollibary.v2.entity.JWHRVRmssdInfo;
import com.wosmart.ukprotocollibary.v2.entity.JWPulseInfo;

import java.util.List;

public interface JWHRVRmssdListener {



    /**
     * hrv rmssd info received
     */
    void onHRVRmssdDataReceived(List<JWHRVRmssdInfo> dataList);


}
