package com.wosmart.ukprotocollibary.v2.entity.function;


import java.io.Serializable;

public class JWBloodFatFunctionInfo extends JWCommonFunctionInfo implements Serializable {

    /**
     * 私人值
     * 男性：238~356 μmol/L man
     * 女性：178~297 μmol/L female
     */
    public int privateValue;

    /**
     * 设置私人值时间，默认值为0，精确到秒
     * default is 0, unit second
     */
    public int privateRtcTime;


    @Override
    public String toString() {
        return "JWBloodFatFunctionInfo{" +
                "privateRtcTime=" + privateRtcTime +
                "privateValue=" + privateValue +
                ", isOpen=" + enable +
                '}';
    }
}
